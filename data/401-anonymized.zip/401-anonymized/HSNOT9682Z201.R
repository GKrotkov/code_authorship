## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep = read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
library(ggplot2)
library(tinytex)
library(patchwork)


## -----------------------------------------------------------------------------
summary(sleep[c("TotalSleepTime", "term_gpa", "cum_gpa")])


## -----------------------------------------------------------------------------
hist(sleep$TotalSleepTime, col="cornflowerblue", main="Distribution of Total Sleep Time",
     xlab="Average Sleep Time for Student (in minutes)", ylab="Frequency")


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))
hist(sleep$term_gpa, col="blueviolet", main="Distribution of Student's Semester GPA",
     xlab="Student's Semester GPA (out of 4.0)", ylab="Frequency")

hist(sleep$term_gpa^3, col="blueviolet", main="Distribution of Cubic of Student's Semester GPA",
     xlab="Cubic of Student's Semester GPA (out of 4.0)", ylab="Frequency")


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))
hist(sleep$cum_gpa, col="darkseagreen3", main="Distribution of Student's Cumulative GPA",
     xlab="Student's Cumulative GPA (out of 4.0)", ylab="Frequency")

hist(sleep$cum_gpa^3, col="darkseagreen3", main="Distribution of Cubic of Student's Cumulative GPA",
     xlab="Cubic of Student's Cumulative GPA (out of 4.0)", ylab="Frequency")


## -----------------------------------------------------------------------------
plot_gender = ggplot(sleep, aes(x=demo_gender)) + geom_bar() + xlab("Student's Gendeer")
plot_study = ggplot(sleep, aes(x=study)) + geom_bar() + xlab("Number of Hours Student Study")
plot_units = ggplot(sleep, aes(x=term_units)) + geom_bar() + xlab("Student's Semester Units")

plot_study + plot_gender + plot_units


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))
plot(sleep$TotalSleepTime, sleep$term_gpa,
     main="Relationship of term_gpa v.s. Sleep Time",
     xlab="Average Sleep Time for Student (in minutes)", ylab="Student's Semester GPA (out of 4.0)") +
  abline(lm(sleep$term_gpa ~ sleep$TotalSleepTime), col="red")

plot(sleep$TotalSleepTime, sleep$cum_gpa,
     main="Relationship of cum_gpa v.s. Sleep Time",
     xlab="Average Sleep Time for Student (in minutes)", ylab="Student's Cumulative GPA (out of 4.0)") +
  abline(lm(sleep$cum_gpa ~ sleep$TotalSleepTime), col="blue")


## -----------------------------------------------------------------------------
plot(fitted(lm(term_gpa ~ TotalSleepTime, data=sleep)), resid(lm(term_gpa ~ TotalSleepTime, data=sleep)),
     xlab="Fitted Values", ylab="Residuals")
abline(0, 0, col="red")


## -----------------------------------------------------------------------------
plot(sleep$TotalSleepTime, sleep$term_gpa^3,
     main="Relationship of term_gpa^3 v.s. Sleep Time",
     xlab="Average Sleep Time for Student (in minutes)", ylab="Cubic of Student's Semester GPA (out of 4.0)") +
  abline(lm(sleep$term_gpa^3 ~ sleep$TotalSleepTime), col="red")


## -----------------------------------------------------------------------------
fitted_model = lm(term_gpa^3 ~ TotalSleepTime, data=sleep)
par(mfrow = c(2, 2))
plot(fitted_model, 1)
plot(fitted_model, 2)
plot(fitted_model, 4)
plot(fitted_model, 5)


## -----------------------------------------------------------------------------
ggplot(sleep, aes(x=TotalSleepTime, y=term_gpa^3, col=term_units, shape=factor(demo_gender, labels=c("female", "male")))) +
  geom_point() +
  ggtitle("Relationship of Cubic of Student's Semester GPA v.s. Total Sleep Time") +
  xlab("Total Sleep Time (in minutes)") + ylab("Cubic of Student's Semester GPA") +
  facet_wrap(~study,  ncol=2) + labs(shape="Student's Gender", col="Student's Semester Units")


## -----------------------------------------------------------------------------
summary(fitted_model)


## -----------------------------------------------------------------------------
confint(fitted_model, level=0.95)


## -----------------------------------------------------------------------------
summary(lm(term_gpa^3 ~ TotalSleepTime*term_units*study*demo_gender, data=sleep))

