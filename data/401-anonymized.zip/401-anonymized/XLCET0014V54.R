## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## -----------------------------------------------------------------------------
library(tidyverse)
library(broom)
library(modelsummary)
library(stargazer)


## -----------------------------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")
sleep <- sleep %>%
  select(TotalSleepTime, term_gpa, cum_gpa)


## ---- fig.cap="Table 1"-------------------------------------------------------
# Summary Statistics Table
data <- data.frame(
  "Average Total Sleep Time" = sleep$TotalSleepTime,
  "Term GPA" = sleep$term_gpa,
  "Cumulative GPA" = sleep$cum_gpa
)

knitr::kable(summary(data), digits = 2, caption = "Summary Statistics")


## -----------------------------------------------------------------------------
# univariate EDA
sleep %>%
  ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(bins = 25) +
  labs(x = "Average Sleep Time, in minutes", y = "Frequency", title = "Histogram of Total Sleep Time") +
  theme(plot.title = element_text(hjust = 0.5))

sleep %>%
  ggplot(aes(x = term_gpa)) +
  geom_histogram(bins = 30) +
  labs(x = "Average Sleep Time, in minutes", y = "Frequency", title = "Histogram of Total Sleep Time") +
  theme(plot.title = element_text(hjust = 0.5))

sleep %>%
  ggplot(aes(x = cum_gpa)) +
  geom_histogram(bins = 25) +
  labs(x = "Average Sleep Time, in minutes", y = "Frequency", title = "Histogram of Total Sleep Time") +
  theme(plot.title = element_text(hjust = 0.5))


## -----------------------------------------------------------------------------
# bivariate EDA
sleep %>%
  ggplot(aes(x = TotalSleepTime, y = term_gpa)) +
  labs(x = "Mother's Height, in inches", y = "Daughter's Height, in inches") +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm")

sleep %>%
  ggplot(aes(x = TotalSleepTime, y = cum_gpa)) +
  labs(x = "Mother's Height, in inches", y = "Daughter's Height, in inches") +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm")


## -----------------------------------------------------------------------------
# Build models
sleep_model1 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)
summary(sleep_model1)


## -----------------------------------------------------------------------------
# Calculate Cook's distance
augment(sleep_model1) |>
  ggplot(aes(x = term_gpa, y = .cooksd)) +
  geom_point() +
  labs(x = "Term GPA", y = "Cook's distance")

augment(sleep_model1) |>
  ggplot(aes(x = cum_gpa, y = .cooksd)) +
  geom_point() +
  labs(x = "Cumulative GPA", y = "Cook's distance")

# Check assumptions
residual_sleep1 <- residuals(sleep_model1)
plot_data1 <- data.frame(x = sleep$TotalSleepTime, y = residual_sleep1)

plot_data1 %>%
  ggplot(aes(x = x, y = y)) +
  labs(x = "X Values", y = "Residuals") +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm")

qqnorm(residual_sleep1)
qqline(residual_sleep1)


## -----------------------------------------------------------------------------
# Generate a table for model summary
modelsummary(sleep_model1, gof_map = c("r.squared", "nobs"), statistic = c("standard error = {std.error}", 
                           "t statistic = {statistic}",
                           "p-value = {p.value}"), title = "Regression Output")


## -----------------------------------------------------------------------------
# Calculate confidence intervals
confint(sleep_model1, "TotalSleepTime", 0.95)
confint(sleep_model1, "TotalSleepTime", 0.95)*120

