## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=TRUE------------------------------------------------------------
library(ggplot2)
data <- read.csv("cmu-sleep.csv")
rel_data <- data[, c("TotalSleepTime", "term_gpa", "cum_gpa")]

head(rel_data)


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(TotalSleepTime)) + 
  geom_histogram(binwidth=25, fill="azure", color="black") + 
  labs(title="Histogram of total sleep time in minutes",
       x="Total Sleep Time (minutes)", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(term_gpa)) + 
  geom_histogram(binwidth=0.15, fill="azure", color="black") + 
  labs(title="Histogram of the current semester GPA",
       x="Semester GPA", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(cum_gpa)) + 
  geom_histogram(binwidth=0.15, fill="azure", color="black") + 
  labs(title="Histogram of the cumulative GPA",
       x="Cumulative GPA", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(x = TotalSleepTime, 
                  y = term_gpa)) +
  geom_point(alpha=0.45) +
  labs(x = "Total time slept (in minutes)",
       y = "Semester GPA",
       title = "Scatterplot of total time slept vs semester GPA") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(x = TotalSleepTime, 
                  y = cum_gpa)) +
  geom_point(alpha=0.45) +
  labs(x = "Total time slept (in minutes)",
       y = "Cumulative GPA",
       title = "Scatterplot of total time slept vs cumulative GPA") +
  theme_minimal()


## -----------------------------------------------------------------------------
fit <- lm(term_gpa ~ TotalSleepTime, data = data)
cumfit <- lm(cum_gpa ~ TotalSleepTime, data = data)

summary(fit)


## -----------------------------------------------------------------------------
confint(fit, "TotalSleepTime", level=0.95)


## -----------------------------------------------------------------------------
summary(cumfit)


## -----------------------------------------------------------------------------
confint(cumfit, "TotalSleepTime", level=0.95)


## ---- fig.width=6, fig.height=3-----------------------------------------------
plot(fit, which = 1)


## ---- fig.width=6, fig.height=3-----------------------------------------------
plot(fit, which = 2)

