## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="SetUp",include=FALSE----------------
library(alr4)
library(ggplot2)
library(patchwork)
library(regressinator)
library(ggplot2)
library(palmerpenguins)
library(modelsummary)
library(broom)
library(kableExtra)
library(knitr)
sleep_data = read.csv('/Users/bradygess/Downloads/cmu-sleep.csv')


## ---- fig.width=12, fig.height=3, fig.cap="Histograms of Professor's Attributes and there quality rating"----
prof_data = Rateprof
p1 <- ggplot(prof_data,aes(x=gender))+geom_bar()+labs(x="Gender",y='Frequency',title = 'Gender of Professors Histogram')
p2 <- ggplot(prof_data,aes(x=pepper))+geom_bar()+labs(x="Attractiveness",y='Frequency',title = 'Attractiveness of Professors Histogram')
p1 | p2
p3 <- ggplot(prof_data,aes(x=dept))+geom_bar()+labs(x="Department",y='Frequency',title = 'Department of Professors Histogram')+theme(axis.text.x = element_text(angle = 45, hjust = 1))
p3
p4 <- ggplot(prof_data,aes(x=easiness))+geom_histogram(binwidth=0.5)+labs(x="Easiness",y='Frequency',title = 'Easiness of Professor Histogram')
p5 <- ggplot(prof_data,aes(x=quality))+geom_histogram(binwidth=0.5)+labs(x="Quality Rating",y='Frequency',title = 'Quality Rating Histogram')
p4 | p5


## ---- fig.width=12, fig.height=3, fig.cap="Bivariate Analysis of Quality on Gender, Attractiveness, Department, and Easiness"----
sp1 = ggplot(prof_data,aes(y=quality,x= easiness))+geom_point()+labs(y='Quality Rating',x='Easiness of Professor',title = 'Easiness of Professor vs Quality Rating')
bx1 = ggplot(data=prof_data,aes(y=quality,x=gender))+geom_boxplot()+labs(title="Boxplot of QualityRating by Gender",y='Quality',x='Gender')
bx2 = ggplot(data=prof_data,aes(y=quality,x=pepper))+geom_boxplot()+labs(title="Boxplot of Quality Rating by Attractiveness",y='Quality',x='Attractive')
bx3 = ggplot(data=prof_data,aes(y=quality,x=dept))+geom_boxplot()+labs(title="Boxplot of Quality Rating by class department",y='Quality',x='Department')+theme(axis.text.x = element_text(angle = 60, hjust = 1))
sp1
bx1 | bx2
bx3


## ---- fig.width=4, fig.height=3, fig.cap="Linear Regression Models of quality on easiness,gender,attractiveness and department"----
model = lm(data=prof_data,quality~easiness+gender+pepper+dept+helpfulness+clarity+raterInterest+numYears)
better_model = step(model,direction='both',trace=0)
modelsummary(list("Better Model" = better_model),
             gof_map = c("r.squared", "nobs"))
model1 = lm(data=prof_data,quality~easiness+gender+pepper+dept+clarity+helpfulness)
model2 = lm(data=prof_data,quality~easiness:gender+clarity+helpfulness)
model3 = lm(data=prof_data,quality~easiness:dept+clarity+helpfulness)


## ---- fig.width=8, fig.height=3, fig.cap="Residual Plot for Model 1,Model 2 and Model 3",include=FALSE----
ggplot(data=prof_data,aes(x=quality,y=resid(model1)))+geom_point()+labs(x='X',y='Residuals',title='Residual Plot for Quality Rating on Easiness, Gender, Attractiveness, Clarity, Helpfulness and Department')
ggplot(data=prof_data,aes(x=quality,y=resid(model2)))+geom_point()+labs(x='X',y='Residuals',title='Residual Plot for Quality Rating on Easiness with Gender Interaction')
ggplot(data=prof_data,aes(x=quality,y=resid(model3)))+geom_point()+labs(x='X',y='Residuals',title='Residual Plot for Quality Rating on Easiness with Department Interaction')


## ---- fig.width=4, fig.height=3, fig.cap="Normal Q-Q Residual Plots for Model 1, Model 2 and Model 3",include=FALSE----
residuals_model1 <- residuals(model1)
qqnorm(residuals_model1)
qqline(residuals_model1)
residuals_model2 <- residuals(model2)
qqnorm(residuals_model2)
qqline(residuals_model2)
residuals_model3 <- residuals(model3)
qqnorm(residuals_model3)
qqline(residuals_model3)


## ---- fig.width=4, fig.height=3, fig.cap="Summary of Linear Regression Models",include=FALSE----
summary(model1)
summary(model2)
summary(model3)

## ---- fig.width=4, fig.height=3, fig.cap="Summary of Linear Regression Models"----
model_summary = modelsummary(list("Model 1" = model1),
                    gof_map = c("r.squared", "nobs"))
model_summary


## ---- fig.width=4, fig.height=3, fig.cap="Model Comparison excluding Department",include=FALSE----
full_model = lm(data=prof_data,quality~easiness+gender+pepper+dept+clarity+helpfulness)
reduce_model = lm(data=prof_data,quality~easiness+gender+pepper+clarity+helpfulness)
anova_t = anova(full_model,reduce_model)


## ---- fig.width=3, fig.height=2, fig.cap="ANOVA Results Table For Model 1 excluding department"----
anova_table = kable(anova_t,format='html') %>%
  kable_styling()
anova_table


## ---- fig.width=3, fig.height=2, fig.cap="ANOVA Results Table For Model 3 excluding easiness and department interaction"----
full_model3 = lm(data=prof_data,quality~easiness:dept+clarity+helpfulness)
reduce_model3 = lm(data=prof_data,quality~easiness+clarity+helpfulness)
anova_table3 = kable(anova(full_model3,reduce_model3),format='html') %>%
  kable_styling()
anova_table3


## ---- fig.width=3, fig.height=2, fig.cap="ANOVA and Confidence Interval for Gender Interaction"----
full_model2 = lm(data=prof_data,quality~easiness:gender+clarity+helpfulness)
reduce_model2 = lm(data=prof_data,quality~easiness+clarity+helpfulness)
anova_table2 = kable(anova(full_model2,reduce_model2),format='html') %>%
  kable_styling()
x = confint(lm(data=prof_data,quality~easiness:gender+helpfulness+clarity))
low <- x[, "2.5 %"]
high <- x[, "97.5 %"]
table_data <- data.frame(Parameter = rownames(x), '2.5' = low, '97.5' = high)
table_data

