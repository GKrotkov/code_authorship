## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(gridExtra)


## ---- warning=FALSE, fig.width=8,fig.height=4---------------------------------
sleep_data <- read.csv("/Users/jakesiegel/Downloads/cmu-sleep.csv")

par(mfrow = c(1, 2))

h1 <- hist(sleep_data$TotalSleepTime,
     xlab = 'Total Sleep Time (Minutes) with 20 buckets',
     ylab = 'Number of Students',
     main = 'Histogram of Total Sleep Time',
     breaks = 20)

h2 <- hist(sleep_data$TotalSleepTime,
     xlab = 'Total Sleep Time (Minutes) with 30 buckets',
     ylab = 'Number of Students',
     main = 'Histogram of Total Sleep Time',
     breaks = 30)


## ----warning=FALSE, fig.width=8,fig.height=4----------------------------------
par(mfrow = c(1, 2))

h1 <- hist(sleep_data$term_gpa,
     xlab = 'Spring Semester GPA with 15 Buckets',
     ylab = 'Number of Students',
     main = 'Histogram of Spring Semester GPAs',
     breaks = 15)

h1 <- hist(sleep_data$term_gpa,
     xlab = 'Spring Semester GPA with 30 Buckets',
     ylab = 'Number of Students',
     main = 'Histogram of Spring Semester GPAs',
     breaks = 30)


## ----warning=FALSE, echo=FALSE, fig.width=8,fig.height=4----------------------
par(mfrow = c(1, 2))

h1 <- hist(sleep_data$cum_gpa,
     xlab = 'Cumulative GPA with 15 Buckets',
     ylab = 'Number of Students',
     main = 'Histogram of Cumulative GPAs',
     breaks = 15)

h1 <- hist(sleep_data$cum_gpa,
     xlab = 'Cumulative GPA with 30 Buckets',
     ylab = 'Number of Students',
     main = 'Histogram of Cumulative GPAs',
     breaks = 30)


## ---- fig.width=8,fig.height=7------------------------------------------------
par(mfrow = c(2, 2))

p1 <- ggplot(sleep_data, aes(x = TotalSleepTime, y = term_gpa)) + labs(x = "Total Minutes Slept", y = "Term GPA (on 4.0 scale)") + ggtitle("Total Sleep Time vs Term GPA") + geom_point()

p2 <- ggplot(sleep_data, aes(x = log(TotalSleepTime), y = term_gpa)) + labs(x = "log(Total Minutes Slept)", y = "Term GPA (on 4.0 scale)") + ggtitle("log(Total Sleep Time) vs Term GPA") + geom_point()

p3 <- ggplot(sleep_data, aes(x = TotalSleepTime, y = log(term_gpa))) + labs(x = "Total Minutes Slept", y = "log(Term GPA (on 4.0 scale))") + ggtitle("Total Sleep Time vs log(Term GPA)") + geom_point()

p4 <- ggplot(sleep_data, aes(x = log(TotalSleepTime), y = log(term_gpa))) + labs(x = "log(Total Minutes Slept)", y = "log(Term GPA (on 4.0 scale))") + ggtitle("log(Total Sleep Time) vs log(Term GPA)") + geom_point()


grid.arrange(p1, p2, p3, p4, ncol=2, nrow=2)


## ----warning=FALSE, echo=FALSE, fig.width=8,fig.height=6----------------------
par(mfrow = c(2, 2))

male_data = sleep_data[sleep_data$demo_gender == 1, ]
female_data = sleep_data[sleep_data$demo_gender == 0, ]

h1 <- hist(male_data$cum_gpa,
     xlab = 'Cumulative GPA of Men',
     ylab = 'Number of Students',
     main = 'Histogram of Male Cumulative GPAs',
     breaks = 20)

h1 <- hist(male_data$term_gpa,
     xlab = 'Spring Semester GPA of Men',
     ylab = 'Number of Students',
     main = 'Histogram of Male Spring Semester GPAs',
     breaks = 20)

h1 <- hist(female_data$cum_gpa,
     xlab = 'Cumulative GPA of Women',
     ylab = 'Number of Students',
     main = 'Histogram of Female Cumulative GPAs',
     breaks = 20)

h1 <- hist(female_data$term_gpa,
     xlab = 'Spring Semester GPA of Women',
     ylab = 'Number of Students',
     main = 'Histogram of Female Spring Semester GPAs',
     breaks = 20)


## ----warning=FALSE, echo=FALSE, fig.width=8,fig.height=6----------------------
par(mfrow = c(2, 2))

first_data = sleep_data[sleep_data$demo_firstgen == 1, ]
non_data = sleep_data[sleep_data$demo_firstgen == 0, ]

h1 <- hist(first_data$cum_gpa,
     xlab = 'Cumulative GPA of First Generation Students',
     ylab = 'Number of Students',
     main = 'First Generation Students Cumulative GPAs',
     breaks = 20)

h1 <- hist(first_data$term_gpa,
     xlab = 'Term GPA of First Generation Students',
     ylab = 'Number of Students',
     main = 'First Generation Students Term GPAs',
     breaks = 20)

h1 <- hist(non_data$cum_gpa,
     xlab = 'Cumulative GPA of Non-First Generation Students',
     ylab = 'Number of Students',
     main = 'Non-First Gen Students Cumulative GPAs',
     breaks = 20)

h1 <- hist(non_data$term_gpa,
     xlab = 'Term GPA of Non-First Generation Students',
     ylab = 'Number of Students',
     main = 'Non-First Gen Students Term GPAs',
     breaks = 20)


## ----echo=FALSE, message=FALSE, warnings=FALSE--------------------------------
ggplot(sleep_data, aes(x=TotalSleepTime, y=term_gpa)) + geom_point() + geom_smooth(method=lm)


## -----------------------------------------------------------------------------
term_fit <- lm((term_gpa ~ TotalSleepTime), data = sleep_data)


## ---- fig.width=8,fig.height=4------------------------------------------------

p1 <- ggplot(term_fit, aes(x = TotalSleepTime, y = .resid)) + geom_point() + labs(x = "Total Sleep Time (in minutes)", y = "Residuals") + ggtitle("Residuals for Term GPA Model vs Total Sleep Time")

p1


## ---- fig.width=8,fig.height=4------------------------------------------------

p2 <- ggplot(term_fit, aes(sample = .resid)) + labs(x = "Theoretical quantiles", y = "Sample quantiles") + geom_qq_line() + geom_qq()  + ggtitle("Q-Q Plot of Residuals for Term GPA Regression")

p2


## ---- fig.width=8,fig.height=4------------------------------------------------
term_fit |>
ggplot(aes(x = TotalSleepTime, y = .cooksd)) +
geom_point() + labs(x = "Total Sleep Time (in minutes)", y = "Cook's distance") + ggtitle("Total Sleep vs Cook's Distance")

