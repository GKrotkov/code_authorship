## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
data = read.csv("cmu-sleep.csv")

## -----------------------------------------------------------------------------
num_rows <- nrow(data) 


## ---- fig.cap="Amount of sleep histogram"-------------------------------------
sleep_mean = mean(data$TotalSleepTime)
sleep_median = median(data$TotalSleepTime)
sleep_std = sd(data$TotalSleepTime)
hist(data$TotalSleepTime, xlab="Amount of sleep (minutes per day)", main="Histogram for amount of sleep")


## ---- fig.cap=" Cumulative GPA Histogram"-------------------------------------

cum_mean = mean(data$cum_gpa)
cum_median = median(data$cum_gpa)
cum_std = sd(data$cum_gpa)
cum_min = min(data$cum_gpa)
hist(data$cum_gpa, xlab="Fall GPA (4.0 scale)", main="Histogram of Fall GPA")


## ---- fig.cap="Term GPA Histogram"--------------------------------------------
term_mean = mean(data$term_gpa)
term_median = median(data$term_gpa)
term_std = sd(data$term_gpa)
term_min = min(data$term_gpa)
hist(data$term_gpa, xlab="Spring GPA (4.0 scale)", main="Histogram of Spring GPA")


## ---- fig.cap="Average time slept vs Spring GPA scatterplot"------------------
plot(data$TotalSleepTime, data$term_gpa, xlab="Amount of sleep (minutes per day)", ylab="Spring GPA (4.0 scale)", main="Average time slept vs Spring GPA")


## ---- fig.cap="Histogram of transformed Spring GPA Data via exponentiation"----
e_mean = mean(exp(data$term_gpa))
e_median = median(exp(data$term_gpa))
e_std = sd(exp(data$term_gpa))
hist(exp(data$term_gpa), xlab= "exp(GPA) (4.0 Scale)", main="Histogram of transformed Spring GPA Data")


## -----------------------------------------------------------------------------
m = lm(exp(data$term_gpa) ~ data$TotalSleepTime)
s = summary(m)
c = confint(m)


## ---- fig.cap="Residual plot for linear plot"---------------------------------
r = resid(m)
plot(data$TotalSleepTime, r, xlab="Average amount of sleep (minutes per day) ", ylab = "Residuals for transformed GPA", main="Residual plot for linear model")

