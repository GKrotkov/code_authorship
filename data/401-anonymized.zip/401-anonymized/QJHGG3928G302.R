## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(ggplot2)
library(bestglm)


## ---- fig.width = 4, fig.height = 3, echo = FALSE-----------------------------
hist(Rateprof$easiness, main = "easiness", xlab = "easiness", col = "green")


## ---- fig.width = 4, fig.height = 3, echo = FALSE-----------------------------
hist(Rateprof$quality, main = "quality", xlab = "quality", col = "lightpink")


## ---- fig.width = 4, fig.height = 3, echo = FALSE-----------------------------
Rateprof$gender <- factor(Rateprof$gender)
ggplot(Rateprof, aes(x = gender, y = quality)) + geom_boxplot(aes(fill = gender)) + labs(x = "gender", y = "quality", title = "quality based on gender")


## ----fig.width = 4, fig.height = 3, echo = FALSE------------------------------
Rateprof$gender <- factor(Rateprof$gender)
ggplot(Rateprof, aes(x = gender, y = easiness)) + geom_boxplot(aes(fill = gender)) + labs(x = "gender", y = "easiness", title = "easiness based on gender")


## ----fig.width = 4, fig.height = 3, echo = FALSE------------------------------
Rateprof$discipline <- factor(Rateprof$discipline)
ggplot(Rateprof, aes(x = discipline, y = quality)) + geom_boxplot(aes(fill = discipline)) + labs(x = "discipline", y = "quality", title = "quality based on discipline")


## ----fig.width = 4, fig.height = 3, echo = FALSE------------------------------
Rateprof$discipline <- factor(Rateprof$discipline)
ggplot(Rateprof, aes(x = discipline, y = easiness)) + geom_boxplot(aes(fill = discipline)) + labs(x = "discipline", y = "easiness", title = "easiness based on discipline")


## ----fig.width = 4, fig.height = 3, echo = FALSE------------------------------
Rateprof$pepper <- factor(Rateprof$pepper)
ggplot(Rateprof, aes(x = pepper, y = quality)) + geom_boxplot(aes(fill = pepper)) + labs(x = "pepper", y = "quality", title = "quality based on pepper")


## ----fig.width = 4, fig.height = 3, echo = FALSE------------------------------
Rateprof$pepper <- factor(Rateprof$pepper)
ggplot(Rateprof, aes(x = pepper, y = easiness)) + geom_boxplot(aes(fill = pepper)) + labs(x = "pepper", y = "easiness", title = "easiness based on pepper")


## ----fig.width = 4, fig.height = 3, echo = FALSE------------------------------
plot(quality ~ easiness, data = Rateprof, main = "quality vs. easiness")


## ---- echo=FALSE--------------------------------------------------------------
mod1 <- lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)
mod2 <- lm(quality ~ easiness + gender + discipline + pepper + easiness*gender + easiness*discipline, data = Rateprof)

## -----------------------------------------------------------------------------
anova(mod2, mod1)


## ---- echo = FALSE------------------------------------------------------------
library(modelsummary)
mod3 <- lm(quality ~ gender + pepper + easiness, data = Rateprof)
modelsummary(list("Best GLM Model" = mod3),
             gof_map = c("r.squared", "nobs"))


## ---- echo = FALSE------------------------------------------------------------
subsetdf <- Rateprof[c('gender', 'pepper', 'discipline', 'easiness', 'quality')]


## ---- echo=FALSE--------------------------------------------------------------
subsetdf$gender <- factor(subsetdf$gender)
subsetdf$discipline <- factor(subsetdf$discipline)
subsetdf$pepper <- factor(subsetdf$pepper)
subsetdf$logquality <- log(subsetdf$quality)
bestglm(subsetdf[, -5], IC = "AIC")


## ---- echo = FALSE, fig.width = 4, fig.height = 3-----------------------------
plot(mod3, which = 1)


## ---- echo = FALSE, fig.width = 4, fig.height = 3-----------------------------
plot(mod3, which = 2)


## -----------------------------------------------------------------------------
vif(mod3)


## ---- echo = FALSE------------------------------------------------------------
summary(mod3)


## ---- echo = FALSE------------------------------------------------------------
anova(mod3)

