## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----width=4, fig.height=3----------------------------------------------------
data <- read.csv("cmu-sleep.csv")  # Replace with the actual file path
library(ggplot2)
par(mfrow=c(1,2))
hist(data$TotalSleepTime, breaks=20, col="skyblue", main="Histogram of Total Sleep Time", xlab="Total Sleep Time (minutes)")
hist(data$term_gpa, breaks=20, col="salmon", main="Histogram of Term GPA", xlab="Term GPA (0-4.0)")
hist(data$cum_gpa, breaks=20, col="light green", main="Histogram of Term GPA", xlab="Term GPA (0-4.0)")



## ---- fig.width=4, fig.height=3-----------------------------------------------
library(ggplot2)
ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(shape = 1, color = "blue") +
  labs(x = "Total Sleep Time (minutes)", y = "Term GPA") +
  ggtitle("Scatterplot of TotalSleepTime vs. term_gpa")



## ----fig.width=4, fig.height=3------------------------------------------------
library(ggplot2)
ggplot(data, aes(x = TotalSleepTime, y = log(term_gpa))) +
  geom_point(shape = 1, color = "blue") +
  labs(x = "Total Sleep Time (minutes)", y = "GPA") +
  ggtitle("Scatterplot of TotalSleepTime vs. log(term_gpa)")


## ---- fig.width=5, fig.height=4-----------------------------------------------
qqnorm(data$term_gpa, main = "QQ Plot")
qqline(data$term_gpa)


## -----------------------------------------------------------------------------
model0 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)


## ----fig.width=4, fig.height=4------------------------------------------------
residuals <- residuals(model0)
plot(fitted(model0), residuals,
     xlab = "Fitted Values",
     ylab = "Residuals",
     main = "Residual vs. Fitted Plot")
abline(h = 0, col = "red")  # Add a horizontal line at y = 0



## ---- fig.width=4, fig.height=3-----------------------------------------------
model0 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)
summary(model0)


## -----------------------------------------------------------------------------
df.residual(model0)


## -----------------------------------------------------------------------------
confint(model0, level=0.95)


## -----------------------------------------------------------------------------
coefficient <- summary(model0)$coefficients["TotalSleepTime", "Estimate"]
average_gpa_effect <- coefficient * (-120)  # Assuming 2 hours less sleep

cat("The average GPA effect of having 2 hours less sleep is approximately:", round(average_gpa_effect, 5))


## -----------------------------------------------------------------------------
new_data <- data.frame(TotalSleepTime = mean(data$TotalSleepTime) - 120, cum_gpa = mean(data$cum_gpa))

estimated_gpa <- predict(model0, newdata = new_data)
bounds <- predict(model0, newdata = new_data, interval = "prediction", level = 0.95)
lower_bound <- bounds[, "lwr"]
upper_bound <- bounds[, "upr"]

estimated_gpa
mean(lower_bound)
mean(upper_bound)


## ----fig.width=4, fig.height=3------------------------------------------------
model2 <- lm(term_gpa ~ TotalSleepTime + cum_gpa + study + demo_gender + demo_firstgen + term_units, data = data)
summary(model2)


## -----------------------------------------------------------------------------
CI <- confint(model2, level = 0.95)
CI


## -----------------------------------------------------------------------------
confint(model0, level=0.95)


## -----------------------------------------------------------------------------
CI <- confint(model2, level = 0.95)
CI

