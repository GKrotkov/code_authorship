## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ----prework, include=FALSE---------------------------------------------------
############################
# PAPER PRE-WORK
############################
# Importing libraries
library(alr4)
library(ggplot2)
library(dplyr)
library(tidyverse)
library(gridExtra)
library(patchwork)
library(GGally)
library(modelsummary)
library(stats)
library(broom) # broom Source: https://cran.r-project.org/web/packages/broom/vignettes/broom.html
library(knitr) # kable Source: https://bookdown.org/yihui/rmarkdown-cookbook/kable.html
library(kableExtra)

# Rice Rule, Bin Picking (from 36-315)
# Citation: https://en.wikipedia.org/wiki/Histogram
getRiceBinNum <- function(x) {
  n = length(x)
  k = ceiling(2 * n^(1/3))
  return(k)
}

# Selecting relevant data columns
prof.data = Rateprof %>%
              dplyr::select(quality, discipline, easiness, gender, pepper)


## ----fig1, fig.width=2.5, fig.height=1.5, fig.cap="Histogram of average easiness for each professor."----
prof.data %>%
  ggplot(aes(x=easiness)) +
  geom_histogram(bins=getRiceBinNum(prof.data$easiness)) +
  labs(x="Average Easiness (1-5)", y="Count")


## ----fig2, fig.width=2.5, fig.height=1.5, fig.cap="Histogram of average quality rating for each professor."----
prof.data %>%
  ggplot(aes(x=quality)) +
  geom_histogram(bins=getRiceBinNum(prof.data$quality)) +
  labs(x="Average Quality Rating (1-5)", y="Count")


## ----fig3, fig.width=6, fig.height=2, fig.cap="Bar plots of categorical explanatory variables."----
discipline.barplt = prof.data %>%
                      ggplot(aes(x=discipline)) +
                      geom_bar() +
                      labs(x="Discipline", y="Count")

gender.barplt = prof.data %>%
                  ggplot(aes(x=gender)) +
                  geom_bar() +
                  labs(x="Gender", y="Count")

pepper.barplt = prof.data %>%
                  ggplot(aes(x=pepper)) +
                  geom_bar() +
                  labs(x="Attractiveness", y="Count")

grid.arrange(discipline.barplt, gender.barplt,
              pepper.barplt, ncol=3)


## ----fig4, fig.width=4, fig.height=4, fig.cap="Bivariate plots of potential explanatory variables against quality rating."----
easy.qual.plt = prof.data %>%
                    ggplot(aes(x=easiness, y=quality)) +
                    geom_point() +
                    labs(x="Average Easiness", 
                         y="Average Quality")

gender.qual.plt = prof.data %>%
                    ggplot(aes(x=gender, y=quality)) +
                    geom_boxplot() +
                    labs(x="Gender", 
                         y="Average Quality")

discipline.qual.plt = prof.data %>%
                    ggplot(aes(x=discipline, y=quality)) +
                    geom_boxplot() +
                    labs(x="Discipline", 
                         y="Average Quality")

pepper.qual.plt = prof.data %>%
                    ggplot(aes(x=pepper, y=quality)) +
                    geom_boxplot() +
                    labs(x="Attractiveness", 
                         y="Average Quality")

grid.arrange(easy.qual.plt, gender.qual.plt,
             discipline.qual.plt, pepper.qual.plt,
             ncol=2)


## ----fig5, fig.width=4, fig.height=2, fig.cap="Bivariate plots of discipline and gender against easiness rating."----
discipline.easy.plt = prof.data %>%
                        ggplot(aes(x=discipline, y=easiness)) +
                        geom_boxplot() +
                        labs(x="Discipline", 
                             y="Average Easiness")

gender.easy.plt = prof.data %>%
                        ggplot(aes(x=gender, y=easiness)) +
                        geom_boxplot() +
                        labs(x="Gender", 
                             y="Average Easiness")

grid.arrange(discipline.easy.plt, gender.easy.plt, ncol=2)


## ----fig6, fig.width=6, fig.height=2, fig.cap="QQ plots of quality rating (left) and easiness (right) residuals."----
quality.qq = prof.data %>%
              ggplot(aes(sample = quality)) +
              geom_qq() +
              geom_qq_line() +
              labs(x = "Theoretical Quantiles", y = "Observed Quantiles")

easiness.qq = prof.data %>%
                ggplot(aes(sample = easiness)) +
                geom_qq() +
                geom_qq_line() +
                labs(x = "Theoretical Quantiles", y = "Observed Quantiles")

grid.arrange(quality.qq, easiness.qq, ncol=2)


## ---- include=FALSE-----------------------------------------------------------
############################
# MODELS AND INFERENCE FOR Q1
############################
# Full MLR model
q1.model = lm(quality ~ easiness + pepper + discipline + gender, 
                data=prof.data)

# Inference
summary(q1.model)

############################
# MODELS AND TESTS FOR Q2
############################
# Full and partial model
q2.full = lm(quality ~ easiness + discipline + gender, 
             data=prof.data)
q2.partial = lm(quality ~ easiness, 
                data=prof.data)

# Partial F tests
q2.anova = anova(q2.partial, q2.full)


## ----fig7, fig.width=6, fig.height=2, fig.cap="Residual plots for Model 1 (left), Model 2.1 (center), and Model 2.2 (right)."----
# Getting residuals and fitted values
q1.resids = resid(q1.model)
q1.fitted = q1.model$fitted.values

q2partial.resids = resid(q2.partial)
q2partial.fitted = q2.partial$fitted.values

q2full.resids = resid(q2.full)
q2full.fitted = q2.full$fitted.values

# Plotting residual plot
make.resid.plt = function(fitted_vals, resids) {
  resid_plot_df = data.frame(fitted_vals, resids)
  return (resid_plot_df %>%
            ggplot(aes(x = fitted_vals, y = resids)) +
            geom_point() +
            geom_hline(yintercept = 0, color = "red") +
            labs(x = "Fitted Values", y = "Residuals"))
}

q1.resid.plt = make.resid.plt(q1.fitted, q1.resids)
q2partial.resid.plt = make.resid.plt(q2partial.fitted, q2partial.resids)
q2full.resid.plt = make.resid.plt(q2full.fitted, q2full.resids)

grid.arrange(q1.resid.plt, q2partial.resid.plt, q2full.resid.plt,
             ncol=3)

## ----fig8, fig.width=6, fig.height=2, fig.cap="QQ plots for Model 1 (left), Model 2.1 (center), and Model 2.2 (right)."----
make.qq.plt = function(resids) {
  qq_plot_df = data.frame(resids)
  return (qq_plot_df %>%
            ggplot(aes(sample = resids)) +
            geom_qq() +
            geom_qq_line() +
            labs(x = "Theoretical Quantiles", y = "Observed Quantiles"))
}

q1.qq.plt = make.qq.plt(q1.resids)
q2partial.qq.plt = make.qq.plt(q2partial.resids)
q2full.qq.plt = make.qq.plt(q2full.resids)

grid.arrange(q1.qq.plt, q2partial.qq.plt, q2full.qq.plt,
             ncol=3)


## ----cook.dists, include = FALSE----------------------------------------------
get.cooks.dists = function(model) {
  cook_dists = cooks.distance(model)
  return (head(sort(pf(cook_dists, 2, 9), decreasing = TRUE)))
}

get.cooks.dists(q1.model)
get.cooks.dists(q2.partial)
get.cooks.dists(q2.full)


## ---- include = FALSE---------------------------------------------------------
summary(q1.model) # Summary of specific coefficients and p-values
confint(q1.model) # Confidence interval calculations

## ----table1, fig.width=3, fig.height=8, fig.cap="Model 1 parameters."---------
q1.model.formatted = tidy(q1.model)

kable(q1.model.formatted, 
      col.names = c("Variable", "Estimate", "Std. Error", "t value", "Pr(>|t|)"),
      caption = "Model 1 parameters.") %>%
    kable_styling()


## ----table2, fig.width=3, fig.height=8, fig.cap="Partial F test results."-----
q2.anova.formatted = tidy(q2.anova)
q2.anova.formatted["term"] = c("Model 2.2 (Partial)", "Model 2.1 (Full)")

kable(q2.anova.formatted, 
      col.names = c("Model", "Resid df", "RSS", "df", "Sum Sq", "Statistic", "p-value"),
      caption = "Partial F test results.") %>%
    kable_styling()

