## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
install.packages("ggplot2")
install.packages("tidyverse")
install.packages("alr4")


## ---- include=FALSE-----------------------------------------------------------
library("ggplot2")
library("tidyverse")
library("alr4")


## ---- include=FALSE-----------------------------------------------------------
data = Rateprof


## ---- include=TRUE, fig.width=10, fig.height=4--------------------------------
data %>%
  ggplot(aes(x = gender)) +
  geom_bar(color = "black", fill = "red") +
  labs(title = "Professor Gender Distribution",
       x = "Gender", y = "Frequency",
       caption = "Figure 1: Gender Distribution")

data %>%
  ggplot(aes(x = pepper)) +
  geom_bar(color = "black", fill = "red") +
  labs(title = "Professor Attractiveness Distribution",
       x = "Attractive", y = "Frequency",
       caption = "Figure 2: Attractiveness Distribution")

data %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(color = "black", fill = "red", bins = 10) +
  labs(title = "Easiness of Professor Distribution",
       x = "Easiness Rating", y = "Frequency",
       caption = "Figure 3: Easiness Distribution")

data %>%
  ggplot(aes(x = discipline)) +
  geom_bar(color = "black", fill = "red") +
  labs(title = "Professor Discipline Distribution",
       x = "Discipline", y = "Frequency",
       caption = "Figure 4: Disciplines Distribution")



## ---- include=TRUE, fig.width=10, fig.height=4--------------------------------
data %>%
  ggplot(aes(x = quality)) +
  geom_histogram(color = "black", fill = "red", bins = 10) +
  labs(title = "Professor Quality Rating Distribution",
       x = "Quality Rating", y = "Frequency",
       caption = "Figure 5: Quality of Professors Distribution")


## ---- include=TRUE, fig.width=10, fig.height=4--------------------------------
data %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(aes(x = gender), fill = "red") +
  labs(title = "Gender vs Quality Rating Boxplot",
       x = "Gender", y = "Quality Rating",
       caption = "Figure 6: Box plot of Gender vs Quality")

data %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(aes(x = pepper), fill = "red") +
  labs(title = "Attractiveness vs Quality Rating Boxplot",
       x = "Attractive", y = "Quality Rating",
       caption = "Figure 7: Box plot of Attractiveness vs Quality")

data %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(aes(x = discipline), fill = "red") +
  labs(title = "Discipline vs Quality Rating Boxplot",
       x = "Discipline", y = "Quality Rating",
       caption = "Figure 8: Box plot of Discipline vs Quality")


## ---- include=TRUE, fig.width=10, fig.height=4--------------------------------
data %>%
  ggplot(aes(x = easiness, y = quality)) +
  geom_point(alpha = 0.5) +
  geom_smooth(color = "red", method = "lm", se = FALSE) +
  labs(title = "Easiness vs Quality Rating Scatterplot",
       x = "Easiness", y = "Quality Rating",
       caption = "Figure 9: Scatterplot of Easiness vs Quality")


## ---- include=TRUE, fig.width=10, fig.height=4--------------------------------
data %>%
  ggplot(aes(y = easiness)) +
  geom_boxplot(aes(x = gender), fill = "red") +
  labs(title = "Gender vs Easiness Boxplot",
       x = "Gender", y = "Easiness Rating",
       caption = "Figure 10: Box plot of Gender vs Easiness")

data %>%
  ggplot(aes(y = easiness)) +
  geom_boxplot(aes(x = discipline), fill = "red") +
  labs(title = "Discipline vs Easiness Boxplot",
       x = "Discipline", y = "Easiness Rating",
       caption = "Figure 11: Box plot of Discipline vs Easiness")


## ---- include=FALSE-----------------------------------------------------------
linear.model <- lm(data$quality ~ data$gender + data$pepper + data$easiness + data$discipline + data$gender:data$easiness + data$discipline:data$easiness)

summary(linear.model)


## ---- include=FALSE-----------------------------------------------------------
resid <- resid(linear.model)
fitted <- fitted(linear.model)

plot(data$easiness, resid, main="Figure 12: Scatterplot of Easiness vs Residuals", xlab = "Easiness", ylab = "Residuals")

plot(fitted, resid, main="Figure 13: Scatterplot of Fitted Values vs Residuals", xlab = "Fitted Values", ylab = "Residuals")

qqnorm(residuals(linear.model), main = "Figure 14: Model QQ Plot",
       ylab = "Residual Amount")
qqline(residuals(linear.model))


## ---- include=FALSE-----------------------------------------------------------
male.upper <- 0.330677 + (qt(1 - 0.05 / 2, df = 355) * 0.297794)
male.lower <- 0.330677 - (qt(1 - 0.05 / 2, df = 355) * 0.297794)

male.upper
male.lower

pepper.upper <- 0.659997 + (qt(1 - 0.05 / 2, df = 355) * 0.108382)
pepper.lower <- 0.659997 - (qt(1 - 0.05 / 2, df = 355) * 0.108382)

pepper.upper
pepper.lower

easiness.upper <- 0.624020 + (qt(1 - 0.05 / 2, df = 355) * 0.088413)
easiness.lower <- 0.624020 - (qt(1 - 0.05 / 2, df = 355) * 0.088413)

easiness.upper
easiness.lower

gender.easiness.upper <- -0.060323 + (qt(1 - 0.05 / 2, df = 355) * 0.091124)
gender.easiness.lower <- -0.060323 - (qt(1 - 0.05 / 2, df = 355) * 0.091124)

gender.easiness.upper
gender.easiness.lower

socsci.upper <- 0.071453 + (qt(1 - 0.05 / 2, df = 355) * 0.457105)
socsci.lower <- 0.071453 - (qt(1 - 0.05 / 2, df = 355) * 0.457105)

socsci.upper
socsci.lower

stem.upper <- 0.165363 + (qt(1 - 0.05 / 2, df = 355) * 0.367845)
stem.lower <- 0.165363 - (qt(1 - 0.05 / 2, df = 355) * 0.367845)

stem.upper
stem.lower

preprof.upper <- 0.291972 + (qt(1 - 0.05 / 2, df = 355) * 0.421487)
preprof.lower <- 0.291972 - (qt(1 - 0.05 / 2, df = 355) * 0.421487)

preprof.upper
preprof.lower

socsci.easiness.upper <- -0.014358 + (qt(1 - 0.05 / 2, df = 355) * 0.138066)
socsci.easiness.lower <- -0.014358 - (qt(1 - 0.05 / 2, df = 355) * 0.138066)

socsci.easiness.upper
socsci.easiness.lower

stem.easiness.upper <- 0.003056 + (qt(1 - 0.05 / 2, df = 355) * 0.117908)
stem.easiness.lower <- 0.003056 - (qt(1 - 0.05 / 2, df = 355) * 0.117908)

stem.easiness.upper
stem.easiness.lower

preprof.easiness.upper <- -0.097480 + (qt(1 - 0.05 / 2, df = 355) * 0.124420)
preprof.easiness.lower <- -0.097480 - (qt(1 - 0.05 / 2, df = 355) * 0.124420)

preprof.easiness.upper
preprof.easiness.lower


## ---- include=FALSE-----------------------------------------------------------
reduced.model <- lm(data$quality ~ data$gender + data$pepper + data$easiness + data$gender:data$easiness + data$discipline:data$easiness)

reduced.model.1 <- lm(data$quality ~ data$gender + data$pepper + data$easiness + data$discipline + data$gender:data$easiness)

anova_table <- anova(reduced.model, linear.model)
anova_table

anova_table.1 <- anova(reduced.model.1,linear.model)
anova_table.1

