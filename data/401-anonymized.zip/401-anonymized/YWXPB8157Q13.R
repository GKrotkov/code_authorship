## ----setup, include = FALSE, suppressWarnings=TRUE, warning=FALSE, message=FALSE----
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
knitr::kable
library("ggplot2")
library("alr4")
library("kableExtra")


## -----------------------------------------------------------------------------
dataset <- Rateprof[, c("pepper", "gender", "discipline", "easiness", "quality", "raterInterest")]


## ---- include=TRUE, fig.dim = c(4, 3), fig.align='center', fig.cap="Figure 1: Histogram of instructor quality rating.  This shows the distribution of this variable."----
ggplot(dataset, aes(x = quality)) +
  geom_histogram(fill = "skyblue", binwidth = 0.5, color="black") +
  labs(x = "Instructor Quality Rating", y="Count", title = "Instructor Quality Rating Histogram")

## ---- include=TRUE, fig.dim = c(4, 3), fig.align='center', fig.cap="Figure X: "----



## ---- include=TRUE, fig.dim = c(4, 3), fig.align='center', fig.cap="Figure 2: Histogram of course easiness rating.  This shows the distribution of this variable."----
ggplot(dataset, aes(x = easiness)) +
  geom_histogram(fill = "skyblue", binwidth = 0.5, color="black") +
  labs(x = "Course Easiness Rating", y="Count", title = "Course Easiness Rating Histogram")


## ---- include=TRUE, fig.dim = c(6, 3), fig.align='center', fig.cap="Figure 2: Table of variable statistics, provides basic univariate overview of each."----
nicedata <- dataset
colnames(nicedata) <- c("Attractiveness", "Gender","Discipline", "Easiness", "Rating", "Interest")
kable(summary(nicedata), caption = "Unvariate variable statistics, provides basic overview of each.", align = "c")

