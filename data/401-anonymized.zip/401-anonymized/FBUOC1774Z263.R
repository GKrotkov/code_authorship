## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(tidyverse)
library(gridExtra)
library(knitr)
cmu_sleep <- read.csv("/Users/legokidrp/Desktop/36401/Data-Exams/Exam-1/cmu-sleep.csv")
library(lmtest)



## -----------------------------------------------------------------------------

createSummaryTable <- function(variables, data) {
  summary_stats <- data.frame(
    #Variable = variables,
    Mean = sapply(variables, function(var) mean(data[[var]])),
    Median = sapply(variables, function(var) median(data[[var]])),
    Min = sapply(variables, function(var) min(data[[var]])),
    Max = sapply(variables, function(var) max(data[[var]])),
    Q1 = sapply(variables, function(var) quantile(data[[var]], 0.25)),
    Q3 = sapply(variables, function(var) quantile(data[[var]], 0.75))
  )
  return(summary_stats)
}

variables <- c("TotalSleepTime", "term_gpa", "cum_gpa")
ourTable <- createSummaryTable(variables, cmu_sleep)
kable(ourTable, digits = 2, format = "markdown")



## -----------------------------------------------------------------------------
# Histograms
termHist = cmu_sleep %>% 
  ggplot(aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.3, fill = "slategray2", alpha = 0.9) +
  labs(title = "Distribution of \n \"Term GPA\"",
       x = "Term GPA",
       y = "Frequency")

totalSleepHist = cmu_sleep %>%
  ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 45, fill = "gray", alpha = 0.9) +
  labs(title = "Distribution of \n \"Total Sleep Time\"",
       x = "Minutes slept",
       y = "Frequency")

cumulativeHist = cmu_sleep %>% 
  ggplot(aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.3, fill = "salmon2", alpha = 0.9) +
  labs(title = "Distribution of \n \"Cumulative GPA\"",
       x = "Cumulative GPA",
       y = "Frequency")

# Boxplots

termBox = cmu_sleep %>%
  ggplot(aes(y = term_gpa)) +
  geom_boxplot(fill = "slategray2", color = "gray2") +
  labs(title = "Term GPA Boxplot",
       y = "Term GPA")

sleepBox = cmu_sleep %>% 
  ggplot(aes(y = TotalSleepTime)) +
  geom_boxplot(fill = "gray", color = "gray2") +
  labs(title = "Sleep Boxplot",
       y = "Sleep (in Minutes)")
  
  
cumulativeBox = cmu_sleep %>% 
  ggplot(aes(y = cum_gpa)) +
  geom_boxplot(fill = "salmon2", color = "gray2") +
  labs(title = "Cumulative GPA Boxplot",
       y = "Cumulative GPA")


grid.arrange(termHist, totalSleepHist, cumulativeHist, termBox, sleepBox, cumulativeBox, ncol = 3)


## -----------------------------------------------------------------------------
# Create a scatterplot of TotalSleepTime vs. term_gpa
termScatterPlot = ggplot(cmu_sleep, aes(x = TotalSleepTime, y = term_gpa )) +
  geom_point(col = "slategray2", size = 0.8) +
  labs(x = "Minutes Slept", y = "Term GPA") +
  ggtitle("Scatterplot of Time Slept \n vs. Term GPA")

# Create a scatterplot of TotalSleepTime vs. cum_gpa
cumScatterPlot = ggplot(cmu_sleep, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point(col = "salmon2", size = 0.8) +
  labs(x = "Minutes Slept", y = "Cumulative GPA") +
  ggtitle("Scatterplot of Time Slept \n vs. Cumulative GPA")

grid.arrange(termScatterPlot, cumScatterPlot, ncol = 2)


## -----------------------------------------------------------------------------
# Models
termGPAModel <- lm(term_gpa ~ TotalSleepTime, data = cmu_sleep)
cumGPAModel <- lm(cum_gpa ~ TotalSleepTime, data = cmu_sleep)
generate_model_table <- function(model) {
  summary_model <- summary(model)
  coefficients <- summary_model$coefficients
  colnames(coefficients) <- c("Estimate", "Std. Error", "t-value", "P-Value")
  
  table <- data.frame(
    "Variable" = rownames(coefficients),
    coefficients
  )
  
  return(table)
}

termGPATable <- generate_model_table(termGPAModel)
cumGPATable <- generate_model_table(cumGPAModel)

# Table
cat("Summary Statistics for termGPAModel\n")
kable(termGPATable, digits = 4, format = "markdown")

cat("Summary Statistics for CumulativeGPAModel\n")
kable(cumGPATable, digits = 4, format = "markdown")



## -----------------------------------------------------------------------------

# Term GPA models
coef_termGPAModel <- coef(termGPAModel)  
se_termGPAModel <- summary(termGPAModel)$coef[, "Std. Error"] 

t_test_termGPAModel <- coef_termGPAModel / se_termGPAModel  
p_values_termGPAModel <- 2 * (1 - pt(abs(t_test_termGPAModel), df = length(termGPAModel$residuals) - length(coef_termGPAModel))) 

t_test_results_termGPAModel <- data.frame(Coefficient = names(coef_termGPAModel), T_Statistic = t_test_termGPAModel, P_Value = p_values_termGPAModel)

# Table
cat("T-Test Results for termGPAModel\n")
kable(t_test_results_termGPAModel, digits = 4, format = "markdown")

# Cumulative GPA Models
coef_cumGPAModel <- coef(cumGPAModel)  
se_cumGPAModel <- summary(cumGPAModel)$coef[, "Std. Error"]  

t_test_cumGPAModel <- coef_cumGPAModel / se_cumGPAModel  
p_values_cumGPAModel <- 2 * (1 - pt(abs(t_test_cumGPAModel), df = length(cumGPAModel$residuals) - length(coef_cumGPAModel)))  

t_test_results_cumGPAModel <- data.frame(Coefficient = names(coef_cumGPAModel), T_Statistic = t_test_cumGPAModel, P_Value = p_values_cumGPAModel)

# Table
cat("T-Test Results for cumulativeGPAModel\n")
kable(t_test_results_cumGPAModel, digits = 4, format = "markdown")



## -----------------------------------------------------------------------------
# Create residual plots for Model 1
residual_plot_termGPAModel = cmu_sleep %>% 
  ggplot(aes(x = fitted(termGPAModel), y = residuals(termGPAModel))) +
  geom_point(color = "slategray2") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray2") +
  labs(title = "Residual Plot for term_GPA \n linear regression model", x = "Fitted Values", y = "Residuals")

# Create residual plots for Model 2
residual_plot_cumGPAModel = cmu_sleep %>% 
  ggplot(aes(x = fitted(cumGPAModel), y = residuals(cumGPAModel))) +
  geom_point(color = "salmon2") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray2") +
  labs(title = "Residual Plot for cum_GPA \n linear regression model", x = "Fitted Values", y = "Residuals")

# Combine residual plots into one plot
grid.arrange(residual_plot_termGPAModel, residual_plot_cumGPAModel, ncol = 2)


## -----------------------------------------------------------------------------
termPlotWithReg = termScatterPlot +
  geom_abline(intercept = coef(termGPAModel)["(Intercept)"], 
              slope = coef(termGPAModel)["TotalSleepTime"], color = "gray2") +
  labs(title = "Sleep Time vs. term GPA \n with Regression Line")


cumPlotWithReg = cumScatterPlot +
  geom_abline(intercept = coef(cumGPAModel)["(Intercept)"], 
              slope = coef(cumGPAModel)["TotalSleepTime"], color = "gray2") +
  labs(title = "Sleep Time vs. cumulative GPA \n with Regression Line")

grid.arrange(termPlotWithReg, cumPlotWithReg, ncol = 2)



## -----------------------------------------------------------------------------
sleepDiff = 120  
termSleepEffect = coef(termGPAModel)["TotalSleepTime"] * sleepDiff * -1
cumSleepEffect = coef(cumGPAModel)["TotalSleepTime"] * sleepDiff * -1

cat("Expected Term GPA Effect with 2 Hours Less Sleep: ", round(termSleepEffect, 2), " GPA points\n")
cat("Expected Cumulative GPA Effect with 2 Hours Less Sleep: ", round(cumSleepEffect, 2), " GPA points\n")

