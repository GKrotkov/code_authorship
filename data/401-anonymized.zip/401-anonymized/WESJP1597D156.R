## ----include = FALSE----------------------------------------------------------
library(tidyverse)
data <- read.csv('cmu-sleep.csv')
dataset <- select(data, cum_gpa, TotalSleepTime, term_gpa)


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Average Sleep per Night (minutes)"----
library(ggplot2)
ggplot(dataset, aes(x=TotalSleepTime)) + geom_histogram() + labs(
    x = "Average Sleep per Night (minutes)"
  )


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Boxplot of Average Sleep per Night (minutes)"----
library(ggplot2)
ggplot(dataset, aes(x=TotalSleepTime)) + geom_boxplot() + labs(
    x = "Average Sleep per Night (minutes)"
  )



## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Semester GPA (out of 4.0)"----
library(ggplot2)
ggplot(dataset, aes(x=term_gpa)) + geom_histogram() + labs(x = "Semester GPA (out of 4.0)")


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Boxplot of Semester GPA (out of 4.0)"----
library(ggplot2)
ggplot(dataset, aes(x=term_gpa)) + geom_boxplot() + labs(x = "Semester GPA (out of 4.0)")


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Cumulative GPA (out of 4.0)"----
library(ggplot2)
ggplot(dataset, aes(x=cum_gpa)) + geom_histogram() + labs(x = "Cumulative GPA (out of 4.0)")


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Boxplot of Cumulative GPA (out of 4.0)"----
library(ggplot2)
ggplot(dataset, aes(x=term_gpa)) + geom_boxplot() + labs(x = "Cumulative GPA (out of 4.0)")


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Scatterplot of Average Sleep per Night (minutes) vs Semester GPA (out of 4.0)"----
library(ggplot2)
ggplot(dataset, aes(x=term_gpa, y = TotalSleepTime)) + geom_point() + labs(x = "Semester GPA (out of 4.0)", y = "Average Sleep per Night (minutes)")


## ----  echo = FALSE, fig.width=4, fig.height=3, fig.cap="Residual Plot"-------
lm <- lm(data = dataset, term_gpa ~ TotalSleepTime)
residuals <- residuals(lm)
plot(dataset$TotalSleepTime, residuals, xlab = "Average Sleep per Night (minutes)", ylab = "Residuals")


## ----  echo = FALSE, fig.width=4, fig.height=3, fig.cap="Normal Q-Q Plot"-----
qqnorm(residuals)
qqline(residuals, col = "red")


## ---- echo=FALSE, fig.width=4, fig.height=3, fig.cap= "Table of Model Estimates"----
library(broom)
library(kableExtra)
print("Table 1: Simple Linear Regresson Model Estimates")
kable(tidy(lm))


## ---- echo = FALSE,fig.width=4, fig.height=3, fig.cap="Table of 95% Confidence Intervals for Estimates"----
library(knitr)
library(kableExtra)
library(broom)
print("Table 2: 95% Confidence Intervals for Estimates")
kable(confint(lm)) 


## ---- include = FALSE---------------------------------------------------------
summary(lm)$adj.r.squared


## ---- include = FALSE---------------------------------------------------------
cooksd <- cooks.distance(lm)

# Set the threshold values
f_threshold_high <- qf(0.50, 2, 632)

sum(cooksd >= f_threshold_high)


## ---- include = FALSE---------------------------------------------------------
estimate = -120*0.0019846

low = -120*0.001231758

high = -120*0.00273754

