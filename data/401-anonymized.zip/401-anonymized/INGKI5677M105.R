## ----setup, include = FALSE, echo=FALSE, message=FALSE------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, message=FALSE-----------------------------------------------
options(repos = list(CRAN = "https://cran.rstudio.com/"))
install.packages("alr4")
library(alr4)
library(broom)
library(GGally) # necessary for the ggpairs() function
library(dplyr)
data(Rateprof)



## ---- fig.width=3, fig.height=2, fig.cap="Figure 1.1: Histogram of Instructor Quality Ratings"----
ggplot(Rateprof, aes(x = quality)) + 
  geom_histogram(binwidth = 0.1) +
  labs(title = "Figure 1.1: Histogram of Instructor Quality Ratings",
       x = "Quality Rating",
       y = "Count") +
  theme_minimal()


## ---- fig.width=3, fig.height=2, fig.cap="Figure 1.2: Histogram of Class Easiness Ratings"----
ggplot(Rateprof, aes(x = easiness)) + 
  geom_histogram(binwidth = 0.1) +
  labs(title = "Figure 1.2: Histogram of Class Easiness Ratings",
       x = "Easiness Rating",
       y = "Count") +
  theme_minimal()


## ---- fig.width=3, fig.height=2, fig.cap="Figure 1.3: Bar Plot of Instructor Discipline"----
ggplot(Rateprof, aes(x = discipline)) + 
  geom_bar() +
  labs(title = "Figure 1.3: Bar Plot of Instructor Discipline",
       x = "Discipline",
       y = "Count") +
  theme_minimal()


## ---- fig.width=6, fig.height=6, fig.cap="Figure 1.4: Pairs Plot for Rateprof data", message=FALSE, warning=FALSE----
Rateprof %>%
  select(quality, gender, pepper, easiness, discipline) %>%
  ggpairs(progress = FALSE, title = "Figure 1.4: Pairs Plot for Rateprof data")



## ---- fig.width=3, fig.height=4, fig.cap="Figure 2.1: Base Fit", message=FALSE, warning=FALSE----
base_fit <- lm(quality ~ easiness + gender + pepper + discipline, data = Rateprof)

# Create a new data frame with residuals
Rateprof_with_residuals <- Rateprof %>%
  mutate(residuals = resid(base_fit))


## ---- fig.width=3, fig.height=4, fig.cap="Figure 2.2: Residuals vs Predictors", message=FALSE, warning=FALSE----

library(gridExtra)

# Assuming Rateprof_with_residuals and base_fit are already defined in your environment

# Create each plot and save them as separate objects
plot1 <- ggplot(Rateprof_with_residuals, aes(x = easiness, y = residuals)) +
  geom_point() +
  labs(title = "Residuals vs Easiness", x = "Easiness", y = "Residuals") +
  theme_minimal()

plot2 <- ggplot(Rateprof_with_residuals, aes(x = gender, y = residuals)) +
  geom_boxplot() +
  labs(title = "Residuals vs Gender", x = "Gender", y = "Residuals") +
  theme_minimal()

plot3 <- ggplot(Rateprof_with_residuals, aes(x = pepper, y = residuals)) +
  geom_boxplot() +
  labs(title = "Residuals vs Pepper", x = "Pepper", y = "Residuals") +
  theme_minimal()

plot4 <- ggplot(Rateprof_with_residuals, aes(x = discipline, y = residuals)) +
  geom_boxplot() +
  labs(title = "Residuals vs Discipline", x = "Discipline", y = "Residuals") +
  theme_minimal()

# Arrange the plots in a 2x2 grid
grid.arrange(plot1, plot2, plot3, plot4, ncol = 2, nrow = 2)



## ---- fig.width=3, fig.height=2, fig.cap="Figure 2.3: Residuals vs Fitted Values"----
augmented_rateprof <- augment(base_fit)

# Plot the residuals against the fitted values
ggplot(augmented_rateprof, aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(title = "Residuals vs Fitted Values",
       x = "Fitted Value",
       y = "Residual") +
  theme_minimal()


## ---- fig.width=2, fig.height=2, fig.cap="Figure 2.4: Normal QQ Plot"---------

ggplot(augmented_rateprof, aes(sample = .resid)) +
       geom_qq() +
       geom_qq_line() +
       labs(x = "Theoretical quantiles", y = "Sample quantiles")
       


## ---- fig.width=2, fig.height=2, fig.cap="Figure 2.5: Cook's Distances"-------

model_df <- 7

residual_df <- 359

cooks_distances <- augmented_rateprof$.cooksd

top_cooks <- data.frame(Top_Cooks_Distances = head(sort(cooks_distances, decreasing = TRUE), 6))
top_cooks$Percentile <- head(sort(pf(cooks_distances, df1 = model_df, df2 = residual_df), decreasing = TRUE), 6)

knitr::kable(top_cooks, digits = 4, row.name = FALSE, caption = "Top 6 Cook's Distance Data Points")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.1: Base Fit"---------------
base_fit <- lm(quality ~ easiness + gender + pepper + discipline, data = Rateprof)
summary(base_fit)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.2: Cook's Distances"-------
conf_int <- confint(base_fit, level = 0.95)
conf_int


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.2: Refined Base Fit"-------
refined_base_fit <- lm(quality ~ easiness + gender + pepper, data = Rateprof)
summary(refined_base_fit)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.3: Interaction 1 Fit"------
int1_fit <- lm(quality ~ easiness * gender + pepper, data = Rateprof)
summary(int1_fit)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.4: Ease-Gender ANOVA-based F test"----
anova(refined_base_fit, int1_fit)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.3: Interaction 2 Fit"------
int2_fit <- lm(quality ~ easiness + gender + pepper + easiness:discipline, data = Rateprof)
summary(int2_fit)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3.4: Ease-Discipline ANOVA-based F test"----
anova(refined_base_fit, int2_fit)

