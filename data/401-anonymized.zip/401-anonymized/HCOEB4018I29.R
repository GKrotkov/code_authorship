## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(alr4)
library(dplyr)
library(ggplot2)
library(broom)
head(Rateprof)


## ---- fig.width=3,fig.height=3,fig.cap="Distribution of Professors' Quality Ratings"----
ggplot(Rateprof, aes(x=quality))+geom_histogram(binwidth = 0.1)+labs(x="Quality Rating of Professor (scale of 1-5)",y="Count")


## ---- fig.width=5,fig.height=5,fig.cap="Distributions of Predictor Variables"----
p1 <- ggplot(Rateprof, aes(x=gender))+geom_bar()+labs(x="Gender of Professor",y="Count")
p2 <- ggplot(Rateprof, aes(x=pepper))+geom_bar()+labs(x="Is the Professor Attractive?",y="Count")
p3 <- ggplot(Rateprof, aes(x=easiness))+geom_histogram(binwidth=.1)+labs(x="Easiness of Professor (scale of 1-5)",y="Count")
p4 <- ggplot(Rateprof, aes(x=discipline))+geom_bar()+labs(x="Professor's Discipline",y="Count")
gridExtra::grid.arrange(p1,p2,p3,p4,ncol=2)

## ---- include=FALSE-----------------------------------------------------------
summary(Rateprof$quality)
sd(Rateprof$quality)

## ---- include=FALSE-----------------------------------------------------------
summary(Rateprof$gender)

## ---- include=FALSE-----------------------------------------------------------
summary(Rateprof$pepper)

## ---- include=FALSE-----------------------------------------------------------
summary(Rateprof$easiness)
sd(Rateprof$easiness)

## ---- include=FALSE-----------------------------------------------------------
summary(Rateprof$discipline)


## ---- fig.width=4,fig.height=4,fig.cap="Comparison of Predictor Variables to Response Variable"----
pairs(quality ~ gender+pepper+easiness+discipline, data=Rateprof)


## ---- fig.width=12,fig.height=4,fig.cap="Scatterplots of Quality versus Easiness with Categorical Variables Visualized"----
p1 <- ggplot(Rateprof, aes(x=easiness,y=quality,color=pepper))+geom_point()+labs(x="Easiness of Professor (scale 1-5)",y="Quality Rating of Professor (scale 1-5)", color="Is the Professor Attractive?")
p2 <- ggplot(Rateprof, aes(x=easiness,y=quality,color=gender))+geom_point()+labs(x="Easiness of Professor (scale 1-5)",y="Quality Rating of Professor (scale 1-5)",color="Gender of Professor")
p3 <- ggplot(Rateprof, aes(x=easiness,y=quality,color=discipline))+geom_point()+labs(x="Easiness of Professor (scale 1-5)",y="Quality Rating of Professor (scale 1-5)",color="Professor's Discipline")
gridExtra::grid.arrange(p1,p2,p2,ncol=3)


## ---- include=FALSE-----------------------------------------------------------
fit1 <- lm(quality ~ easiness+factor(pepper)+factor(gender)+factor(discipline), Rateprof)
summary(fit1)

## ---- fig.width=5,fig.height=5,fig.cap="Diagnostic Graphs for Model 1"--------
plot1 <- ggplot(augment(fit1), aes(x=.fitted,y=.resid))+geom_point()+labs(x="Fitted Values",y="Residual Values")
plot2 <- ggplot(augment(fit1), aes(x=easiness,y=.resid))+geom_point()+labs(x="Easiness of Professor (scale 1-5)",y="Residual")
plot3 <- ggplot(augment(fit1), aes(x=.fitted,y=.cooksd))+geom_point()+labs(x="Fitted Values",y="Cook's Distance")
plot4 <- ggplot(augment(fit1), aes(sample=.resid))+geom_qq()+geom_qq_line()+labs(x="Theoretical Quantiles",y="Sample Quantiles")
gridExtra::grid.arrange(plot1, plot2, plot3, plot4,ncol=2)


## ---- include=FALSE-----------------------------------------------------------
fit2 <- lm(quality ~ easiness+factor(gender)+factor(discipline)+easiness:factor(gender)+easiness:factor(discipline), Rateprof)
summary(fit2)

## ---- fig.width=5,fig.height=5,fig.cap="Diagnostic Graphs for Model 2"--------
plota <- ggplot(augment(fit2), aes(x=.fitted,y=.resid))+geom_point()+labs(x="Fitted Values",y="Residual Values")
plotb <- ggplot(augment(fit2), aes(x=easiness,y=.resid))+geom_point()+labs(x="Easiness of Professor (scale 1-5)",y="Residual")
plotc <- ggplot(augment(fit2), aes(x=.fitted,y=.cooksd))+geom_point()+labs(x="Fitted Values",y="Cook's Distance")
plotd <- ggplot(augment(fit2), aes(sample=.resid))+geom_qq()+geom_qq_line()+labs(x="Theoretical Quantiles",y="Sample Quantiles")
gridExtra::grid.arrange(plota,plotb,plotc,plotd,ncol=2)


## -----------------------------------------------------------------------------
knitr::kable(tidy(fit1))

## ---- include=FALSE-----------------------------------------------------------
signif1 <-confint(fit1, level=0.95)
knitr::kable(signif1)


## -----------------------------------------------------------------------------
knitr::kable(tidy(fit2))


## ---- include=FALSE-----------------------------------------------------------
signif2 <-confint(fit2)
knitr::kable(signif2)

