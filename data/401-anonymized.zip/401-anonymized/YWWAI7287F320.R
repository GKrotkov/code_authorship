## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(dplyr)
library(broom)
library(alr4)
library(modelsummary)
library(knitr)

df <- Rateprof
df <- df[c('gender', 'discipline', 'easiness', 'quality', 'pepper')]
full_fit <- lm(quality ~ easiness+gender+pepper+discipline +easiness*gender+easiness*discipline+easiness*pepper,
               data = df)


## ----fig.cap="Distribution of Average Quality Ratings of Professors. Even after transformations, distribution is skewed to left", fig.show="hold", out.width="50%"----
hist(df$quality, xlab="Average Quality Rating of Professors (out of 5)",
     ylab="Frequency of Quality Ratings",
     main="")
hist(log(df$quality), xlab="Logarithm of Average Quality Rating of Professors",
     ylab="Frequency of Quality Ratings",
     main="")


## ---- fig.cap="Distribution of Average Easiness Ratings of Professors. Distribution is approximately normal."----
hist(df$easiness, xlab="Average Easiness Rating of Professors (out of 5)",
     ylab="Frequency of Easiness Ratings",
     main="")


## ---- fig.cap="Relationship between Easiness and Quality Ratings. Weak Linear Relationship is observed."----
plot(df$easiness,df$quality,
           xlab="Easiness Rating (out of 5)", ylab="Quality Rating (out of 5)",
          main="")


## ----fig.cap="Distribution of Average Quality Rating against Average Easiness Rating amongst Genders. No significant difference between genders."----
boxplot(quality ~ gender, ylab = "Average Quality Rating", data = df,
xlab = "Gender of Professor", names = c("Female", "Male"))


## ---- fig.cap="Distribution of Average Quality Rating against Average Easiness Rating amongst Attractiveness. Significant difference between attractiveness."----
boxplot(quality ~ pepper, ylab = "Average Quality Rating", data = df,
xlab = "Attractiveness of Professor", names = c("No", "Yes"))


## ----fig.cap="Distribution of Average Quality Rating against Average Easiness Rating amongst Disciplines. No significant difference between disciplines."----
boxplot(quality ~ discipline, ylab = "Average Quality Rating", data = df,
xlab = "Discipline of Professor", names = c("Humanities", "Social Sciences", "STEM", "Professional Training"))


## ----fig.cap="Residual Distribution over Predicted Values. Slight heteroskedasticity towards the right."----
ggplot(augment(full_fit), aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted value", y = "Residual")


## ----fig.cap="Cook's Distances over quality ratings. No notable influenatial points.", out.width="80%"----
augment(full_fit) |>
  ggplot(aes(x = quality, y = .cooksd)) +
  geom_point() +
  labs(x = "Quality Rating", y = "Cook!s distance")


## ----fig.cap="QQ Plot for Errors. Errors are relatively normal.", out.width="80%"----
ggplot(augment(full_fit), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles")

