## ----include=FALSE, message=FALSE, warning=FALSE------------------------------
library(alr4)
library(gridExtra)


## ----echo=FALSE---------------------------------------------------------------
library(ggplot2)
p1<-ggplot(Rateprof, aes(x = gender)) + 
    geom_bar(color="black") +
    labs(title = "Gender Distribution", x = "Gender", y = "Count")
p2<-ggplot(Rateprof, aes(x = discipline)) + 
    geom_bar(color="black") +
    labs(title = "Discipline Distribution", x = "Discipline", y = "Count")
p3<-ggplot(Rateprof, aes(x = pepper)) + 
    geom_bar(color="black") +
    labs(title = "Pepper Distribution", x = "Pepper", y = "Count")
p4<-ggplot(Rateprof, aes(x = quality)) + 
    geom_histogram(bins = 30,color="black") +
    labs(title = "Quality Distribution", x = "Quality", y = "Frequency")
p5<-ggplot(Rateprof, aes(x = easiness)) + 
    geom_histogram(bins = 30,color="black") +
    labs(title = "Easiness Distribution", x = "Easiness", y = "Frequency")

grid.arrange(p1, p2, p3, p4, p5, nrow = 2)
knitr::opts_chunk$set(echo = FALSE)


## ----echo=FALSE---------------------------------------------------------------
p1<-ggplot(Rateprof, aes(x = gender, y = quality)) + 
    geom_boxplot() +
    labs(title = "Quality vs Gender", x = "Gender", y = "Quality")

p2<-ggplot(Rateprof, aes(x = discipline, y = quality)) + 
    geom_boxplot() +
    labs(title = "Quality vs Discipline", x = "Discipline", y = "Quality")

p3<-ggplot(Rateprof, aes(x = pepper, y = quality)) + 
    geom_boxplot() +
    labs(title = "Quality vs Pepper", x = "Pepper", y = "Quality")

p4<-ggplot(Rateprof, aes(x = discipline, y = easiness)) + 
    geom_boxplot() +
    labs(title = "Easiness vs Discipline", x = "Discipline", y = "Easiness")

p5<-ggplot(Rateprof, aes(x = gender, y = easiness)) + 
    geom_boxplot() +
    labs(title = "Easiness vs Gender", x = "Gender", y = "Easiness")

p6<-ggplot(Rateprof, aes(x = easiness, y = quality)) + 
    geom_point() +
    labs(title = "Quality vs Easiness", x = "Easiness", y = "Quality")
grid.arrange(p1, p2, p3, p4, p5, nrow = 2)
knitr::opts_chunk$set(echo = FALSE)




## -----------------------------------------------------------------------------
full_model <- lm(quality ~ easiness + pepper + gender + discipline + easiness:gender + easiness:discipline, data = Rateprof)
fitted_values <- fitted(full_model)
residuals_values <- residuals(full_model)

plot_data <- data.frame(Fitted = fitted_values, Residuals = residuals_values)
ggplot(plot_data, aes(x=Fitted, y=Residuals)) +
  geom_point() + 
  geom_hline(yintercept=mean(residuals_values)) +
  ggtitle("Residuals vs. Fitted") +
  xlab("Fitted values") +
  ylab("Residuals") 
knitr::opts_chunk$set(echo = FALSE)

qqnorm(residuals(full_model))
qqline(residuals(full_model))


knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
full_model <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = Rateprof)
summary(full_model)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
reduced_model <- lm(quality ~ pepper + easiness + discipline + easiness:discipline, data = Rateprof)
anova(reduced_model,full_model)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
reduced_model <- lm(quality ~ gender+ pepper + easiness + easiness:gender, data = Rateprof)
anova(reduced_model,full_model)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
reduced_model <- lm(quality ~ gender + easiness + discipline + easiness:gender + easiness:discipline, data = Rateprof)
anova(reduced_model,full_model)
interval <- confint(full_model, "pepperyes", level=0.95)
print(interval)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
reduced_model <- lm(quality ~ gender + pepper + discipline, data = Rateprof)
anova(reduced_model,full_model)
interval <- confint(full_model, "pepperyes", level=0.95)
print(interval)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
reduced_model <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
anova(reduced_model,full_model)
knitr::opts_chunk$set(echo = FALSE)

