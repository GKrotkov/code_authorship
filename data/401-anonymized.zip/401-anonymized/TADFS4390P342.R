## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)


## ---- include=FALSE-----------------------------------------------------------
profs <- Rateprof


## ---- include=FALSE-----------------------------------------------------------
head(profs)


## ---- fig.width=6, fig.height=4, fig.cap="Histograms of quality ratings showing a left skewed distribution."----
hist(profs$quality, xlab = "Quality rating out of 5", main = "Quality ratings")


## ---- fig.width=6, fig.height=4, fig.cap="Histograms of course easiness showing an approximate normal distribution."----
hist(profs$easiness, xlab = "Easiness rating out of 5", main = "Course easiness")


## ---- fig.width=6, fig.height=4, fig.cap="Boxplot of course easiness between genders showing that female professors had slightly higher easiness ratings."----
boxplot(easiness~gender, data = profs, xlab = "Gender", ylab="Easiness rating out of 5", main = "Boxplot of course easinesses between genders")


## ---- fig.width=6, fig.height=4, fig.cap="Boxplot of course easiness between disciplines, with STEM having the lowest centers and pre-professional having the highest."----
boxplot(easiness~discipline, data = profs, xlab = "Discpline", ylab="Easiness rating out of 5", main = "Boxplot of course easinesses between disciplines")


## ---- fig.width=6, fig.height=4, fig.cap="Histograms of squared quality ratings, transformed to be approximately normal."----
hist(profs$quality^2, xlab = "Squared quality rating out of 25", main = "Squared quality ratings")


## ---- include=FALSE-----------------------------------------------------------
fit <- lm(quality^2~pepper + easiness * gender + easiness * discipline, data = profs)
summary(fit)


## ---- include=FALSE-----------------------------------------------------------
nodisc <- lm(quality^2~pepper + easiness * gender, data = profs)
summary(nodisc)
anova(nodisc, fit)


## ---- include=FALSE-----------------------------------------------------------
sm <- summary(fit)
res <- sm$residuals
f <- fitted(fit)


## ---- fig.width=6, fig.height=4, fig.cap="Residual plot with fitted values, showing no relation between the predictors and the residuals."----
plot(f, res, xlab = "Fitted values", ylab = "Residuals", main = "Residuals vs fitted values")


## ---- include=FALSE-----------------------------------------------------------
sqrt(confint(fit, c("pepperyes", "easiness")))

