## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
data("Rateprof", package = "alr4")
data <- Rateprof


## -----------------------------------------------------------------------------
library(ggplot2)
ggplot(data, aes(x = quality)) + 
  geom_histogram(color = "black", bins = 30) + 
  xlab("Average Quality Rating") + 
  ylab("Frequency") +
  ggtitle("Histogram of Average Quality Rating")


## -----------------------------------------------------------------------------
library("gridExtra")

p1 = ggplot(data, aes(x = gender)) +
  geom_bar() +
  xlab("Instructor Gender") +
  ylab("Frequency") +
  ggtitle("Bar Plot of Instructor Gender")

p2 = ggplot(data, aes(x = pepper)) + 
  geom_bar() + 
  xlab("If the Instructor is Attractive") + 
  ylab("Frequency") +
  ggtitle("Bar Plot of If the Instructor is Attractive") 

p3 = ggplot(data, aes(x = discipline)) + 
  geom_bar() + 
  xlab("the Instructor's Discipline") + 
  ylab("Frequency") +
  ggtitle("Bar Plot of the Instructor's Discipline") 

p4 = ggplot(data, aes(x = easiness)) + 
  geom_histogram(color = "black", bins = 30) + 
  xlab("the Average Easiness Rating") + 
  ylab("Frequency") +
  ggtitle("Histogram of Average Easiness Rating") 

grid.arrange(p1, p2, p3, p4, ncol = 2)


## -----------------------------------------------------------------------------
g1 = ggplot(data, aes(x = easiness, y = quality^2, color = gender)) +
  geom_point() +
  labs(title = "Easiness vs Quality Rating^2 by Gender",
       x = "Easiness",
       y = "Quality") +
  theme_minimal()

g2 = ggplot(data, aes(x = easiness, y = quality^2, color = discipline)) +
  geom_point() +
  labs(title = "Easiness vs Quality Rating^2 by Discipline",
       x = "Easiness",
       y = "Quality") +
  theme_minimal()

grid.arrange(g1, g2, ncol = 2)


## -----------------------------------------------------------------------------
fullmodel <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data)
summary(fullmodel)


## -----------------------------------------------------------------------------
final_model <- lm(quality ~ gender + pepper + easiness, data)


## -----------------------------------------------------------------------------
plot(final_model, which = 1)


## -----------------------------------------------------------------------------
qqnorm(residuals(final_model))
qqline(residuals(final_model))


## -----------------------------------------------------------------------------
cooks_distance <- cooks.distance(final_model)
cooks_df <- data.frame(Cook = cooks_distance, Index = 1:length(cooks_distance))
ggplot(cooks_df, aes(x = Index, y = Cook)) +
  geom_point(shape = 1, size = 3) +  
  geom_hline(yintercept = 4 / length(cooks_distance), linetype = "dashed", color = "red") +  
  labs(title = "Cook's Distance Plot",
       x = "Index",
       y = "Cook's Distance") +
  theme_minimal()


## -----------------------------------------------------------------------------
summary(final_model)
AIC(final_model)

