## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ----echo=FALSE---------------------------------------------------------------
cmu_sleep = read.csv("cmu-sleep.csv")


## ---- fig.height=5, fig.width=6-----------------------------------------------
hist(cmu_sleep$TotalSleepTime, main = "Figure 1: Histogram of Time Students Sleep/Night", xlab = "Total Sleep Time (minutes)")


## ---- fig.width=4, fig.height=3-----------------------------------------------
boxplot(cmu_sleep$TotalSleepTime, main = "Figure 2: Box Plot of Total Sleep Time", ylab = "Sleep per night (minutes)")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(cmu_sleep$term_gpa, main = "Figure 3: Histogram of Term GPA", xlab = "Spring Term GPA")


## ---- fig.width=4, fig.height=3-----------------------------------------------
boxplot(cmu_sleep$term_gpa, main = "Figure 4: Box Plot of Term GPA", ylab = "Spring Term GPA")


## ---- fig.height=5, fig.width=6-----------------------------------------------
hist(exp(cmu_sleep$term_gpa), main = "Figure 5: Transformed Histogram of Term GPA", xlab = "Exponential Value of Spring Term GPA")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(cmu_sleep$cum_gpa, main = "Figure 6: Histogram of Cumulative GPA", xlab = "Cumulative (Fall) GPA")


## ---- fig.width=4, fig.height=3-----------------------------------------------
boxplot(cmu_sleep$cum_gpa, main = "Figure 7: Box Plot of Cumulative GPA", ylab = "Cumulative (Fall) GPA")


## ---- fig.height=5, fig.width=6-----------------------------------------------
hist(exp(cmu_sleep$cum_gpa), main = "Figure 8: Transformed Histogram of Cumulative GPA", xlab = "Cumulative (Fall) GPA")


## -----------------------------------------------------------------------------
plot(cmu_sleep$TotalSleepTime, exp(cmu_sleep$term_gpa), main = "Figure 9: Scatter Plot of Total Sleep Time vs. Term GPA", xlab = "Total Sleep Time (minutes)", ylab = "(Spring) Term GPA")


## -----------------------------------------------------------------------------
plot(cmu_sleep$TotalSleepTime, exp(cmu_sleep$cum_gpa),main = "Figure 10: Scatter Plot of Total Sleep Time vs. Cumulative GPA ", xlab = "Total Sleep Time (minutes)", ylab = "Cumulative (Fall) GPA")


## -----------------------------------------------------------------------------
plot(exp(cmu_sleep$cum_gpa), exp(cmu_sleep$term_gpa), main = "Figure 11: Cumulative GPA vs. Term GPA", xlab = "Cumulative (Fall) GPA", ylab = "(Spring) Term GPA")


## -----------------------------------------------------------------------------
summary(lm(exp(cmu_sleep$term_gpa) ~ cmu_sleep$TotalSleepTime))
confidence_up = 0.0459 + 2*(0.009987)
confidence_down = 0.0459 - 2*(0.009987)


## -----------------------------------------------------------------------------
summary(lm(exp(cmu_sleep$cum_gpa)~exp(cmu_sleep$term_gpa)))

confidence_high = 0.0648 + 2*(0.02718)
confidence_low = 0.0648 - 2*(0.02718)


## -----------------------------------------------------------------------------
x = exp((cmu_sleep$term_gpa) + abs(min(exp(cmu_sleep$term_gpa))) + 1)
y = exp(cmu_sleep$cum_gpa + abs(min(cmu_sleep$cum_gpa)) + 1)
plot(x, y, main="Figure 12: exp(Spring GPA) vs exp(Fall GPA) with linear model", xlab="exp((Spring) Term GPA)", ylab="exp(Cumulative (Fall) GPA)")
cmu.fit = lm(y~x, data=cmu_sleep)
abline(cmu.fit)


## -----------------------------------------------------------------------------
cmu.res = resid(cmu.fit)
plot(x, cmu.res, main = "Figure 13: Plot of Model Residuals", ylab="Residuals of exp(Term GPA)", xlab="exp(Cumulative GPA)")
abline(0,0)

