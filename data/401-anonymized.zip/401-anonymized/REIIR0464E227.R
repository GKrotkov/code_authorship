## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
data(Rateprof)


## -----------------------------------------------------------------------------
library(ggplot2)
library(dplyr)
library(gridExtra)

rateprof_df <- Rateprof
 
p1 <- ggplot(rateprof_df, aes(x=gender)) + geom_bar() + labs(title='Distribution of Gender')
p2 <- ggplot(rateprof_df, aes(x=pepper)) + geom_bar() + labs(title='Distribution of Pepper (Attractiveness)')
p3 <- ggplot(rateprof_df, aes(x=discipline)) + geom_bar() + labs(title='Distribution of Discipline')
p4 <- ggplot(rateprof_df, aes(x=quality)) + geom_histogram(bins=30) + labs(title='Distribution of Quality')
p5 <- ggplot(rateprof_df, aes(x=easiness)) + geom_histogram(bins=30) + labs(title='Distribution of Easiness')

bp1 <- ggplot(rateprof_df, aes(x=gender, y=quality)) + geom_boxplot() + labs(title='Quality vs Gender')
bp2 <- ggplot(rateprof_df, aes(x=pepper, y=quality)) + geom_boxplot() + labs(title='Quality vs Pepper (Attractiveness)')
bp3 <- ggplot(rateprof_df, aes(x=discipline, y=quality)) + geom_boxplot() + labs(title='Quality vs Discipline')
bp4 <- ggplot(rateprof_df, aes(x=easiness, y=quality)) + geom_point() + labs(title='Quality vs Easiness')

univariate_plots <- grid.arrange(p1, p2, p3, p4, p5, ncol=2)

bivariate_plots <- grid.arrange(bp1, bp2, bp3, bp4, ncol=2)

print(univariate_plots)
print(bivariate_plots)




## -----------------------------------------------------------------------------
formula <- quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline
model <- lm(formula, data = Rateprof)

plot(fitted(model), resid(model), main = "Residuals vs Fitted",
     xlab = "Fitted values", ylab = "Residuals")
abline(h = 0, col = "red")

qqnorm(resid(model))
qqline(resid(model), col = "red")


plot(fitted(model), sqrt(abs(resid(model))), main = "Scale-Location",
     xlab = "Fitted values", ylab = "√|Standardized Residuals|")
abline(h = 0, col = "red")

library(car)
influencePlot(model, id.method = "cook", main = "Residuals vs Leverage")

summary(model)


