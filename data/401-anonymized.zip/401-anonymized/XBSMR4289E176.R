## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message = FALSE---------------------------------------------------------
library(alr4)
library(ggplot2)

data(Rateprof)


## ---- fig.width=7, fig.height=4, message = FALSE------------------------------
par(mfrow=c(1,2))
hist(Rateprof$quality, main = "Histogram of Quality Ratings", xlab = "Quality Rating")
hist(Rateprof$easiness, main = "Histogram of Easiness Ratings", xlab = "Easiness Rating")



## ---- fig.width=7, fig.height=3-----------------------------------------------
par(mfrow=c(1,2))
barplot(table(Rateprof$gender), main = "Bar Plot Gender", xlab = "Gender", ylab = "Frequency")
barplot(table(Rateprof$pepper), main = "Bar Plot Pepper (Attractiveness)", xlab = "Pepper", ylab = "Frequency")


## ---- fig.width=7, fig.height=4, message = FALSE------------------------------
plot(Rateprof$quality ~ Rateprof$easiness, main = "Quality vs. Easiness", xlab = "Easiness", ylab = "Quality")



## -----------------------------------------------------------------------------
plot(Rateprof$quality ~ Rateprof$numRaters, main = "Quality vs. Number of Raters", xlab = "Number of Raters", ylab = "Quality")


## ---- message = FALSE, fig.height=2, warning=FALSE----------------------------
library(gridExtra)

plot1 <- ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot() +
  ggtitle("Box Plot of Quality Ratings by Gender") +
  xlab("Gender") +
  ylab("Quality Rating")

plot2 <- ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot() +
  ggtitle("Box Plot of Quality Ratings by Attractiveness (Pepper)") +
  xlab("Attractiveness (Pepper)") +
  ylab("Quality Rating")

grid.arrange(plot1, plot2, ncol = 2)



## ---- fig.width=7, fig.height=2, message = FALSE, warning=FALSE---------------

plot5 <- ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point(alpha = 0.5) + 
  geom_smooth(method = "loess", se = FALSE) +  # loess curve
  ggtitle("Scatter Plot of Quality vs. Easiness with Smooth Line") +
  xlab("Easiness") +
  ylab("Quality Rating")

plot6 <- ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ggtitle("Box Plot of Quality Ratings by Discipline") +
  xlab("Discipline") +
  ylab("Quality Rating")
grid.arrange(plot5, plot6, ncol = 2)


## ---- fig.height=2.5, message = FALSE-----------------------------------------

plot3 <- ggplot(Rateprof, aes(x = easiness, y = quality, color = gender)) +
  geom_point() +
  ggtitle("Interaction of Quality and Easiness by Gender") +
  xlab("Easiness") +
  ylab("Quality Rating")
plot3

## ---- fig.height=2, message = FALSE-------------------------------------------
plot4 <- ggplot(Rateprof, aes(x = easiness, y = quality, color = discipline)) +
  geom_point() +
  ggtitle("Interaction of Quality and Easiness by Discipline") +
  xlab("Easiness") +
  ylab("Quality Rating")
plot4


## ---- message = FALSE, warning=FALSE, results='asis'--------------------------
library(stargazer)
model <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = Rateprof)

stargazer(model, type = "text", 
          title = "Regression Results",
          header = FALSE, 
          single.row = TRUE,
          intercept.bottom = FALSE,
          no.space = TRUE,
          digits=3)


## ---- message = FALSE, warning=FALSE, comment=NA------------------------------
library(car)
vif(model)



## ---- message = FALSE, warning=FALSE, results=FALSE---------------------------
library(lmtest)
dwtest(model)



## ---- message = FALSE, warning=FALSE------------------------------------------
par(mfrow=c(2,2))
plot(model)



## ---- fig.height=2, message = FALSE, warning=FALSE----------------------------
library(broom)
coef_df <- tidy(model, conf.int = TRUE)

ggplot(coef_df, aes(estimate, term)) +
  geom_point() +
  geom_errorbarh(aes(xmin = conf.low, xmax = conf.high), height = 0) +
  labs(x = "Estimate", y = "Term", title = "Model Coefficients and Confidence Intervals")



## ---- message = FALSE, warning=FALSE, comment=NA, results=FALSE---------------
library(xtable)
cf<- confint(model)
xtable(cf)



## ---- message = FALSE, warning=FALSE, comment=NA, results=FALSE---------------
library(broom)
td<- tidy(model, conf.int = TRUE)
xtable(td)
library(broom)


