## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
#plot(dist ~ speed, data = cars,
#     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## ---- message=F---------------------------------------------------------------
library(alr4)
data(Rateprof)
#head(Rateprof)


## ---- fig.width=6, fig.height=3, fig.cap="Histograms for Univariate Analysis"----
par(mfrow=c(1, 2))

hist(Rateprof$quality,
     col = "skyblue",
     breaks=15,
     main="Quality Rating Distribution",
     xlab="Quality Rating")
hist(Rateprof$easiness, 
     col = "lightgreen",
     breaks=15,
     main="Easiness Rating Distribution",
     xlab="Easiness Rating")


## ---- fig.width=6, fig.height=5, fig.cap="Graphs for Bivariate Analysis"------
par(mfrow=c(2, 2))
boxplot(Rateprof$quality ~ Rateprof$gender, 
        main="Quality vs Gender", 
        ylab="Quality Rating",
        xlab="Gender",
        col=c("salmon", "skyblue"),
        las=1,
        border="darkblue",
        cex.main=1.1) 

boxplot(Rateprof$quality ~ Rateprof$pepper,
        main="Quality vs Attractiveness", 
        ylab="Quality Rating", 
        xlab="Attractiveness",
        col=c("grey", "lightgreen"),
        las=1,
        border="darkblue",
        cex.main=1.1)

plot(Rateprof$easiness, Rateprof$quality, 
     col= "darkblue",
     main="Quality vs Easiness", 
     xlab="Easiness Rating",
     ylab="Quality Rating",
     cex.main=1.1)

boxplot(Rateprof$quality ~ Rateprof$discipline,
        main="Quality Rating Across Different Disciplines",
        ylab="Quality Rating",
        xlab="Academic Discipline",
        col=c("skyblue", "palegreen", "salmon", "gold"),
        las=1,
        border="darkblue",
        cex.main=1.1) 




## ---- message=F, fig.width=8, fig.height=2.8,fig.cap="Scatter plots of quality vs. easiness by gender and discipline."----
library(ggplot2)
library(patchwork)


custom_theme <- theme_minimal() +
  theme(plot.title = element_text(size = 13.5),
        axis.title = element_text(size = 12),
        axis.text = element_text(size = 12))

p1 <- ggplot(Rateprof, aes(x = easiness, y = quality, color = gender)) +
  geom_point() +
  stat_smooth(method = "lm", se = FALSE) +
  labs(x = "Easiness Rating", y = "Quality Rating", title = "Quality vs Easiness by Gender") +
  custom_theme +
  scale_color_manual(values = c("male" = "blue", "female" = "red"))

p2 <- ggplot(Rateprof, aes(x = easiness, y = quality, color = discipline)) +
  geom_point() +
  stat_smooth(method = "lm", se = FALSE) +
  labs(x = "Easiness Rating", y = "Quality Rating", title = "Quality vs Easiness by Discipline") +
  custom_theme +
  scale_color_manual(values = c("Hum" = "green", "SocSci" = "yellow", "STEM" = "blue", "Pre-prof" = "red"))

p1 + p2





## ---- include=F---------------------------------------------------------------
# Load necessary library
library(alr4)

# Full Model with Interaction Terms
full_model <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = Rateprof)

# Reduced Model without Interaction Terms
reduced_model <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

summary(full_model)
summary(reduced_model)
# Model Comparison
anova(reduced_model, full_model)



## -----------------------------------------------------------------------------
library(knitr)
anova_table <- data.frame(
  Model = c("Model 1", "Model 2"),
  `Res.Df` = c(359, 355),
  RSS = c(154.60, 154.05),
  Df = c(NA, 4),
  `Sum of Sq` = c(NA, 0.54359),
  F = c(NA, 0.3132),
  `Pr(>F)` = c(NA, 0.8691)
)
kable(anova_table, caption = "ANOVA Table for Model Comparison", booktabs = TRUE)



## ---- fig.width=6, fig.height=5,  fig.cap="Model Diagonostic Analysis"--------
par(mfrow=c(2, 2))
plot(reduced_model)

# Checking for multicollinearity with Variance Inflation Factors
vif_table = vif(reduced_model)



## -----------------------------------------------------------------------------
kable(vif_table, caption = "VIF Table for the Reduced Model", booktabs = TRUE)


## ---- include=F---------------------------------------------------------------
summary(reduced_model)
confint(reduced_model, level = 0.95)


## ---- fig.cap="Model Summary and Coefficients"--------------------------------
# Define the model summary data
model_summary <- data.frame(
  Variable = c("(Intercept)", "gendermale", "pepperyes", "easiness", 
               "disciplineSocSci", "disciplineSTEM", "disciplinePre-prof"),
  Estimate = c(1.57883, 0.14470, 0.65529, 0.56837, 0.03243, 0.17095, -0.02307),
  `Std. Error` = c(0.16132, 0.07109, 0.10740, 0.04659, 0.09890, 0.08943, 0.10069),
  `t value` = c(9.787, 2.035, 6.101, 12.200, 0.328, 1.912, -0.229),
  `Pr(>|t|)` = c("< 2e-16", "0.0426", "2.72e-09", "< 2e-16", "0.7431", "0.0567", "0.8189"),
  `CI Lower` = c(1.26157, 0.00488, 0.44408, 0.47675, -0.16205, -0.00493, -0.22109),
  `CI Upper` = c(1.89609, 0.28451, 0.86651, 0.65999, 0.22692, 0.34682, 0.17495)
)


kable(model_summary, caption = "Model Summary and Confidence Intervals", booktabs = TRUE)

