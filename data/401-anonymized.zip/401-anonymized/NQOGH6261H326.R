## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)


## ---- fig.width = 3, fig.height = 3, fig.cap="Histogram of average sleep time students spent"----
sleepData = read.csv("cmu-sleep.csv")
hist(sleepData$TotalSleepTime, xlab = "Total Sleep Time (min)", main = "", breaks = 20)


## ---- fig.width = 4, fig.height = 3, fig.cap="Scatterplot of average sleep time students spent"----
plot(sleepData$TotalSleepTime, ylab = "Total Sleep Time (min)")


## ---- fig.width=4, fig.height=3 , fig.cap="Scatterplot of student term units on average sleep time"----
plot(TotalSleepTime ~ term_units, data = sleepData,
     xlab = "Units Taken During Term", ylab = "Total Sleep Time (min)")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of student cumulative GPA out of 4.0"----
hist(sleepData$cum_gpa, xlab = "Cumulative GPA", main = "")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of student average sleep on average term GPA."----
plot(term_gpa ~ TotalSleepTime, data = sleepData,
     xlab = "Total Sleep Time (min)", ylab = "Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of logarithm transformed average sleep time on student GPA. Compared to the previous plot, there is a right shift."----
plot(term_gpa ~ log(TotalSleepTime), data = sleepData, 
     xlab = "Log (Total Sleep Time) (min)", ylab = "Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Normality plot of residuals"--------
gpa_sleep_lm <- lm(term_gpa ~ TotalSleepTime, data = sleepData)
library(broom)
gpa_sleep_res <- augment(gpa_sleep_lm)
qqnorm(residuals(gpa_sleep_lm))
qqline(residuals(gpa_sleep_lm))


## ---- fig.width=4, fig.height=3, fig.cap="Residual plot on average student sleep time"----
plot(.resid ~ TotalSleepTime, data = gpa_sleep_res,
     xlab = "Total Sleep Time (min)", ylab = "Residuals")


## ---- fig.width = 4, fig.height = 3, fig.cap = "Residual plot on log transformed average student sleep time"----
plot(.resid ~ log(TotalSleepTime), data = gpa_sleep_res,
                  xlab = "Log(Total Sleep Time) (min)", ylab = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Linear regression model summary statistics"----
summary(gpa_sleep_lm)
#coef(gpa_sleep_lm)
#confint(gpa_sleep_lm)
library(modelsummary)
#config_modelsummary(factory_default = "markdown")
#modelsummary(gpa_sleep_lm)


## ---- fig.width=4, fig.height=3, fig.cap="The red line represents the linear regression model that has been fit over the initial scatterplot of average sleep time on student term GPA."----
plot(term_gpa ~ TotalSleepTime, data = sleepData,
     ylab = "Term GPA", xlab = "Total Sleep Time (min)")
abline(gpa_sleep_lm, lwd = 2, col = 2)


## ---- fig.width = 4, fig.height = 3, fig.cap = "Linear regression model coefficients"----
coef(gpa_sleep_lm)


## ---- fig.width=4, fig.height=3, fig.cap="Cook's distances of average sleep time"----
#head(gpa_sleep_res)
plot(.cooksd ~ TotalSleepTime, data = gpa_sleep_res)


## -----------------------------------------------------------------------------
#predict(gpa_sleep_lm, newdata = data.frame(TotalSleepTime = 120), 
#        interval = "predict", level = 0.95)

