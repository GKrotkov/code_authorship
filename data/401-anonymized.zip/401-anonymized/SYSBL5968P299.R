## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(ggplot2)
library(readr)


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
data <- read.csv("Desktop/cmu-sleep.csv")
hist(data$TotalSleepTime, 
     xlab = 'Total Sleep Time (Minutes)', 
     ylab = 'Number of Students', 
     main = 'Histogram of Total Sleep Time with breaks = 10',
     breaks = 10)
hist(data$TotalSleepTime, 
     xlab = 'Total Sleep Time (Minutes)', 
     ylab = 'Number of Students', 
     main = 'Histogram of Total Sleep Time with breaks = 30',
     breaks = 30)
mean(data$TotalSleepTime)
median(data$TotalSleepTime)
quantile(data$TotalSleepTime)

## ---- message = FALSE, warning = FALSE, echo = FALSE--------------------------
knitr::include_graphics("Desktop/data_exam/1.jpeg")


## ----message=FALSE, warning=FALSE, include = FALSE----------------------------
hist(data$term_gpa, 
     xlab = 'Term GPA (out of 4.0)', 
     ylab = 'Number of Students', 
     main = 'Histogram of Term GPA with breaks=10',
     breaks = 10)
hist(data$term_gpa, 
     xlab = 'Term GPA (out of 4.0)', 
     ylab = 'Number of Students', 
     main = 'Histogram of Term GPA with breaks=30',
     breaks = 30)
mean(data$term_gpa)
median(data$term_gpa)
quantile(data$term_gpa)

## ---- message = FALSE, warning = FALSE, echo = FALSE--------------------------
knitr::include_graphics("Desktop/data_exam/2.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
hist(data$cum_gpa, 
     xlab = 'Cumulative GPA (out of 4.0)', 
     ylab = 'Number of Students', 
     main = 'Histogram of Cumulative GPA with breaks=10', 
     breaks = 10)
hist(data$cum_gpa, 
     xlab = 'Cumulative GPA (out of 4.0)', 
     ylab = 'Number of Students', 
     main = 'Histogram of Cumulative GPA with breaks=30', 
     breaks = 30)
mean(data$cum_gpa)
median(data$cum_gpa)
quantile(data$cum_gpa)

## ---- message = FALSE, warning = FALSE, echo = FALSE, fig.align='center'------
knitr::include_graphics("Desktop/data_exam/3.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
hist(data$term_units, 
     xlab = 'Number of Units', 
     ylab = 'Number of Students', 
     main = 'Histogram of Term Units with breaks=10', 
     breaks = 10)
hist(data$term_units, 
     xlab = 'Number of Units', 
     ylab = 'Number of Students', 
     main = 'Histogram of Term Units with breaks=30', 
     breaks = 30)

## ---- message = FALSE, warning = FALSE, echo = FALSE, fig.align='center'------
knitr::include_graphics("Desktop/data_exam/10.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
ggplot(data, aes(x = data$TotalSleepTime, y = data$term_gpa)) +
  labs(x = "Total Sleep Time (minutes)", 
       y = "Term GPA (Out of 4.0)") + 
  ggtitle("Term GPA vs Total Sleep Time") + 
  geom_point()

## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width="80%", fig.align = 'center'----
knitr::include_graphics("Desktop/data_exam/4.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
ggplot(data, aes(x = log(data$TotalSleepTime), y = data$term_gpa)) +
  labs(x = "log(Total Sleep Time) (minutes)", 
       y = "Term GPA (Out of 4.0)") + 
  ggtitle("Term GPA vs Log(Total Sleep Time)") + 
  geom_point() 

## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width="80%", fig.align = 'center'----
knitr::include_graphics("Desktop/data_exam/5.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
df = data.frame(x = data$TotalSleepTime, 
                y = data$term_gpa)
model <- lm(y ~ x, data = df)
ggplot(data, aes(x = data$TotalSleepTime, y = data$term_gpa)) +
  labs(x = "Total Sleep Time (minutes)", 
       y = "Term GPA (Out of 4.0)") + 
  ggtitle("Term GPA vs Total Sleep Time") + 
  geom_point() +
  geom_smooth(method = "lm")
summary(model)
confint(model, level=0.95)

## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width="80%", fig.align = 'center'----
knitr::include_graphics("Desktop/data_exam/6.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
cook <- cooks.distance(model)
sort(cook, decreasing = TRUE)
ggplot(data, aes(x = data$TotalSleepTime, y = cook)) +
  labs(x = "Total Sleep Time (minutes)", 
       y = "Cook's Distance") + 
  ggtitle("Cook's Distance vs Total Sleep Time") + 
  geom_point() 
outlier <- which.max(cook)
print(outlier)
#summary(model)
#ggplot(newdf, aes(x = newdf$x, y = newdf$y)) +
#  labs(x = "log(Total Sleep Time) (minutes)", 
#       y = "Term GPA (Out of 4.0)") + 
#  ggtitle("Term GPA vs Log(Total Sleep Time)") + 
#  geom_point() + 
#  geom_smooth(method = "lm")
#qqnorm(newModel$residuals)
#qqline(newModel$residuals)

## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width="80%", fig.align = 'center'----
knitr::include_graphics("Desktop/data_exam/7.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
ggplot(data, aes(x = data$TotalSleepTime, y = model$residuals)) +
  labs(x = "Total Sleep Time (minutes)", 
       y = "Residuals") + 
  ggtitle("Residuals vs Total Sleep Time") + 
  geom_point() 
mean(model$residuals)

## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width="80%", fig.align = 'center'----
knitr::include_graphics("Desktop/data_exam/8.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
qqnorm(model$residuals)
qqline(model$residuals)


## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width="80%", fig.align = 'center'----
knitr::include_graphics("Desktop/data_exam/9.jpeg")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
summary(model)

