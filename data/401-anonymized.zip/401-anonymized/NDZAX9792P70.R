## ----setup, include = FALSE, message=FALSE------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(tidyverse)
library(stargazer)
library(alr4)
library(GGally)
library(gridExtra)
library(car)
library(modelsummary)
data("Rateprof")


## ---- fig.cap="Distribution of Overall Ratings", fig.height=2, fig.width=4----
subset_rate <- Rateprof[, c("gender", "pepper", "easiness", "discipline",
                            "quality")]
ggplot(data=subset_rate, aes(x=quality))+
  geom_histogram(bins=15) +
  labs(x = "Overall Professor Rating",
       y = "Count",
       title = "Distribution of Ratings")


## ---- fig.cap="Distribution of Easiness Ratings", fig.height=2, fig.width=4----
ggplot(data=subset_rate, aes(x=easiness))+
  geom_histogram(bins=15) +
  labs(x = "Overall Easiness Rating",
       y = "Count",
       title = "Distribution of Easiness Ratings")


## ---- fig.cap="Relationships to Quality", fig.width=5, fig.height=5-----------
p1 <- ggplot(data=subset_rate, aes(x=gender, y=quality))+
  geom_boxplot()
p2 <- ggplot(data=subset_rate, aes(x=pepper, y=quality))+
  geom_boxplot()
p3 <- ggplot(data=subset_rate, aes(x=discipline, y=quality))+
  geom_boxplot()
p4<- ggplot(data = subset_rate, aes(x=easiness, y=quality))+
  geom_point()
grid.arrange(p1,p2,p3,p4,ncol=2)


## -----------------------------------------------------------------------------
subset.lm <- lm(data = subset_rate, quality ~.)


## ---- eval=F------------------------------------------------------------------
## vif(subset.lm)
## summary(subset.lm)


## ---- fig.cap="Testing Residual of Model 1", fig.width = 8, fig.height=3------
res <- resid(subset.lm)
par(mfrow = c(1, 2))
plot(fitted(subset.lm), res)
abline(0,0)
qqnorm(res, main = "")
qqline(res)


## -----------------------------------------------------------------------------
easiness.gender.discipline <- lm(data = subset_rate, quality ~ easiness +
                                   gender + pepper + discipline +
                                   easiness*gender + easiness*discipline)


## ---- fig.cap="Testing Residual of Model 2", fig.width = 8, fig.height=3------
res <- resid(easiness.gender.discipline)
par(mfrow = c(1, 2))
plot(fitted(easiness.gender.discipline), res)
abline(0,0)
qqnorm(res, main = "")
qqline(res)


## ---- eval=FALSE--------------------------------------------------------------
## summary(easiness.gender.discipline)
## result = anova(easiness.gender.discipline, subset.lm)
## stargazer(result)


## ---- eval=F------------------------------------------------------------------
## stargazer(subset.lm)
## stargazer(easiness.gender.discipline)


## ---- eval=FALSE--------------------------------------------------------------
## confint(subset.lm)

