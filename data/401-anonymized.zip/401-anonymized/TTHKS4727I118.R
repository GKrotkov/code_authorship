## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(dplyr)


## -----------------------------------------------------------------------------
cmu_sleep <- read.csv("C:\\Users\\nihaa\\Downloads\\401\\cmu-sleep.csv")


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x= TotalSleepTime)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Average Sleep Time per Night (in mins)", y = "Frequency", title = "Distribution of Average Sleep Time")


## -----------------------------------------------------------------------------
summary(cmu_sleep$TotalSleepTime)


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x= term_gpa)) +
geom_histogram(color = "black", fill = "lightblue", bins =50) + 
labs(x = "Student GPA (out of 4.0)", y = "Frequency", title = "Histogram of Student's GPA In Semester Studied")


## -----------------------------------------------------------------------------
summary(cmu_sleep$term_gpa)


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x= cum_gpa)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Student GPA (out of 4.0)", y = "Frequency", title = "Histogram of Student's GPA Before Study")


## -----------------------------------------------------------------------------
summary(cmu_sleep$cum_gpa)


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x=TotalSleepTime, y= term_gpa)) +
  geom_point()+
labs(x = "Average Sleep Time per Night (in mins)", y = "Student GPA (out of 4.0)", title = "Scatterplot of Sleep Time vs. Student GPA This Semester")


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x=TotalSleepTime, y= cum_gpa)) +
  geom_point()+
labs(x = "Average Sleep Time per Night (in mins)", y = "Student GPA (out of 4.0)", title = "Scatterplot of Sleep Time vs. Student GPA Prior Semester")


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x=log(TotalSleepTime), y= term_gpa)) +
  geom_point()+
labs(x = "log(Average Sleep Time per Night (in mins))", y = "Student GPA (out of 4.0)", title = "Transformed Scatterplot of Sleep Time vs. Student GPA This Semester", subtitle = "Log transformation is applied")


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x=sqrt(TotalSleepTime), y= term_gpa)) +
  geom_point()+
labs(x = "Sqrt(Average Sleep Time per Night (in mins))", y = "Student GPA (out of 4.0)", title = "Transformed Scatterplot of Sleep Time vs. Student GPA Prior Semester",subtitle = "Sqrt transformation is applied")


## -----------------------------------------------------------------------------
lin_model_sqrt <- lm(term_gpa ~ sqrt(TotalSleepTime), data = cmu_sleep)

plot(lin_model_sqrt, which = 1,)


## -----------------------------------------------------------------------------
plot(lin_model_sqrt, which = 2)


## -----------------------------------------------------------------------------
summary(lin_model_sqrt)


## -----------------------------------------------------------------------------
confint(lin_model_sqrt)

