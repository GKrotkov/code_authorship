## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(alr4)
library(ggplot2)
library(patchwork)
library(broom)
library(modelsummary)
library(bestglm)


## ---- include = FALSE---------------------------------------------------------
summary(Rateprof$gender)
summary(Rateprof$pepper)
summary(Rateprof$discipline)


## ---- fig.width=8, fig.height=3, fig.cap="Barplot displaying Distributions of categorical predictor variables", message=FALSE----
gen_bar <- ggplot(Rateprof, aes(x = gender)) +
  geom_bar(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Gender",
    x = "Gender (Male/Female)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

attr_bar <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Attractiveness",
    x = "Attractiveness (Yes/No)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

dis_bar <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Discipline",
    x = "Discipline (Hum/SocSci/STEM/Pre-prof)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

gen_bar | attr_bar | dis_bar


## ---- include = FALSE---------------------------------------------------------
summary(Rateprof$easiness)
summary(Rateprof$quality)


## ---- fig.width=6, fig.height=3, fig.cap="Histogram displaying Distributions of explanatory variables", message=FALSE----
easi_hist <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Easiness Rating",
    x = "Easiness (on a scale of 1-5)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

qual_hist <- ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Quality Rating",
    x = "Quality (on a scale of 1-5)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

easi_hist | qual_hist


## ---- fig.width=10, fig.height=3, fig.cap="Boxplot & Scatterplot displaying relationship between predictor and response variables", message=FALSE----
boxplot1 <- ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot(aes(fill = gender), show.legend = FALSE) +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(
    title = "Gender vs. Quality Rating",
    x = "Gender (Male/Female)",
    y = "Quality (on a scale of 1-5)"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

boxplot2 <- ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot(aes(fill = pepper), show.legend = FALSE) +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(
    title = "Attractiveness vs. Quality Rating",
    x = "Attractiveness (Yes/No)",
    y = "Quality (on a scale of 1-5)"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

boxplot3 <- ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(aes(fill = discipline), show.legend = FALSE) +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(
    title = "Discipline vs. Quality Rating",
    x = "Discipline (Hum/SocSci/STEM/Pre-prof)",
    y = "Quality (on a scale of 1-5)"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

scatplot1 <- ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(
    title = "Easiness vs. Quality Rating",
    x = "Easiness (on a scale of 1-5)",
    y = "Quality (on a scale of 1-5)"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

boxplot1 | boxplot2 | boxplot3 | scatplot1


## ---- include = FALSE---------------------------------------------------------
## include all
lm_full <- lm(quality ~ gender + pepper + easiness + discipline +
  gender:easiness + discipline:easiness, data = Rateprof)
summary(lm_full)


## ---- include = FALSE---------------------------------------------------------
# exclude interaction
lm_reduced <- lm(quality ~ gender + pepper + easiness + discipline,
  data = Rateprof
)
anova(lm_reduced, lm_full)
summary(lm_reduced)


## ---- include = FALSE---------------------------------------------------------
# exclude discipline
lm_final <- lm(quality ~ gender + pepper + easiness,
  data = Rateprof
)
summary(lm_final)


## ---- include = FALSE---------------------------------------------------------
# stepwise check
lm_step <- step(lm_full, direction = "both", trace = 0)
summary(lm_step)


## ---- include = FALSE---------------------------------------------------------
residuals <- resid(lm_final)
squared_residuals <- residuals^2
fitted <- fitted(lm_final)

resid_data <- data.frame(
  Residuals = residuals,
  Squared_Residuals = squared_residuals,
  Fitted = fitted
)


## ---- fig.width=6, fig.height=2, fig.cap="Residuals & Squared Residuals plot for the fitted model"----
resid_plot <- ggplot(resid_data, aes(x = Fitted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(
    title = "Residual Plot for Multivariate Linear Model",
    x = "Fitted Values", y = "Residuals"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

sq_resid_plot <- ggplot(resid_data, aes(x = Fitted, y = Squared_Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(
    title = "Squared Residual Plot for Multivariate Linear Model",
    x = "Fitted Values", y = "Squared Residuals"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

resid_plot | sq_resid_plot


## ---- fig.width=6, fig.height=2, fig.cap="Normal Q-Q & Cook's Distance plot for the fitted model"----
cook_plot <- augment(lm_final) |>
  ggplot(aes(x = .fitted, y = .cooksd)) +
  geom_point() +
  labs(x = "Fitted value", y = "Cook's distance") +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )


qq_plot <- ggplot(
  augment(lm_final),
  aes(sample = .resid)
) +
  geom_qq() +
  geom_qq_line(color = "red") +
  labs(
    title = "Normal Q-Q Plot for Multivariate Linear Model",
    x = "Theoretical quantiles", y = "Sample quantiles"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

cook_plot | qq_plot


## ---- fig.width=3, fig.height=4-----------------------------------------------
modelsummary(
  list(
    "Full Model" = lm_full, "Reduced Model" = lm_reduced,
    "Final Model" = lm_final, "Stepwise Model" = lm_step
  ),
  gof_map = c("aic", "adj.r.squared", "nobs")
)

