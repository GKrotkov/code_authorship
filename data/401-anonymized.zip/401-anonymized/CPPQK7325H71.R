## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- echo = FALSE------------------------------------------------------------
library(ggplot2)
cmusleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=10, fig.height=4, fig.cap="Distribution of three variables", echo = FALSE----

library(ggplot2)
library(patchwork)

p1 <- ggplot(cmusleep, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 1, col = "skyblue4", fill = "skyblue4") +
  labs(x = "Total Sleep Time")

p2 <- ggplot(cmusleep, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.1, col = "skyblue3", fill = "skyblue3") +
  labs(x = "Term GPA")

p2l <- ggplot(cmusleep, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.01, col = "skyblue2", fill = "skyblue2") +
  scale_x_log10() +
  labs(x = "Log of Term GPA")

p3 <- ggplot(cmusleep, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.1, col = "skyblue1", fill = "skyblue1") +
  labs(x = "Cumulative GPA")

p3l <- ggplot(cmusleep, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.01, col = "skyblue", fill = "skyblue") +
  scale_x_log10() + 
  labs(x = "Log of Cumulative GPA")


p1|p2|p2l|p3|p3l




## ---- fig.width=10, fig.height=4, fig.cap="Relationship Between Total Sleep Time and Term GPA",echo = FALSE----

s1 <-ggplot(cmusleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(col = "hotpink1") +
  labs(x = "Total Sleep Time",
       y = "Term GPA",
       title = "Total Sleep Time vs Term GPA")

s2 <- ggplot(cmusleep, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point(col = "hotpink1") +
  labs(x = "Total Sleep Time",
       y = "Cumulative GPA",
       title = "Total Sleep Time vs Cumulative GPA")


s1|s2


## ----echo = FALSE-------------------------------------------------------------
termgpa_fit <- lm(term_gpa ~ TotalSleepTime, data = cmusleep)
cumgpa_fit <- lm(cum_gpa ~ TotalSleepTime, data = cmusleep)

term_pvalue = summary(termgpa_fit)$coefficients[1, 4]
cum_pvalue = summary(cumgpa_fit)$coefficients[1, 4]


cat("term gpa fit p-value:", term_pvalue,
    "cumulative gpa fit p-value:", cum_pvalue)


## ----echo = FALSE-------------------------------------------------------------
library(palmerpenguins)
library(modelsummary)
modelsummary(list("termgpafit" = termgpa_fit, "cumgpafit" = cumgpa_fit ))



## ----echo = FALSE-------------------------------------------------------------
termB1hat_cl <- predict(termgpa_fit, 
                        newdata = data.frame(TotalSleepTime =
                                               cmusleep$TotalSleepTime), 
                        level = 0.95,
                        interval = "confidence")

cat("Fitted value:", termB1hat_cl[1,1], "Lower Bound:", 
    termB1hat_cl[1,2], "Upper Bound:", termB1hat_cl[1,3])



## ----echo = FALSE-------------------------------------------------------------
cumB1hat_cl <- predict(cumgpa_fit, 
                       newdata = data.frame(TotalSleepTime =
                                              cmusleep$TotalSleepTime),
                       level = 0.95,
                       interval = "confidence")

cat("Fitted value:", cumB1hat_cl[1,1], "Lower Bound:", 
    cumB1hat_cl[1,2], "Upper Bound:", cumB1hat_cl[1,3])



## ----echo = FALSE-------------------------------------------------------------
coef(summary(termgpa_fit))[1, ]


## ----echo = FALSE-------------------------------------------------------------
coef(summary(cumgpa_fit))[1, ]


## ----echo = FALSE-------------------------------------------------------------
termB1hat_pl <- predict(termgpa_fit, 
                        newdata = data.frame(TotalSleepTime =
                                               cmusleep$TotalSleepTime), 
                        level = 0.95,
                        interval = "prediction")


cat("Fitted value:", termB1hat_pl[1,1], "Lower Bound:", termB1hat_pl[1,2], 
    "Upper Bound:", termB1hat_pl[1,3])


## ----echo = FALSE-------------------------------------------------------------
cumB1hat_pl <- predict(cumgpa_fit, 
                       newdata = data.frame(TotalSleepTime =
                                              cmusleep$TotalSleepTime),
                       level = 0.95,
                       interval = "prediction")

cat("Fitted value:", cumB1hat_pl[1,1], "Lower Bound:", cumB1hat_pl[1,2], 
    "Upper Bound:", cumB1hat_pl[1,3])



## ---- fig.width=10, fig.height=4, fig.cap="Fitted vs Residuals", echo = FALSE----

residuals_val <- residuals(cumgpa_fit)
residuals_val2 <- residuals(termgpa_fit)

q1 <- ggplot(data.frame(resid = residuals_val2), aes(sample = resid)) + 
  geom_qq(color = "plum1") + 
  geom_qq_line(color = "forestgreen") + 
  ggtitle("Q-Q plot of residuals from Term GPA")

q2 = ggplot(data.frame(resid = residuals_val), aes(sample = resid)) + 
  geom_qq(color = "plum1") + 
  geom_qq_line(color = "forestgreen") + 
  ggtitle("Q-Q plot of residuals from Cumulative GPA")

q1|q2



## ----fig.width=10, fig.height=4, fig.cap="Fitted vs Residuals", echo = FALSE----

fitted_val <- fitted(cumgpa_fit)

cum_data <- data.frame(Fitted = fitted_val, Residuals = residuals_val)

p11<- ggplot(cum_data, aes(x = Fitted, y = Residuals)) +
  geom_point(color = "orange") +
  geom_hline(yintercept = 0, color = "purple") +
  theme_minimal() +
  labs(title = "Fitted vs. Residuals Plot for Cumulative GPA",
       x = "Fitted values",
       y = "Residuals")

fitted_val2 <- fitted(termgpa_fit)

term_data <- data.frame(Fitted = fitted_val2, Residuals = residuals_val2)

p12<- ggplot(term_data, aes(x = Fitted, y = Residuals)) +
  geom_point(color = "orange") +
  geom_hline(yintercept = 0, color = "purple") +
  theme_minimal() +
  labs(title = "Fitted vs. Residuals Plot for Term GPA",
       x = "Fitted values",
       y = "Residuals")

p12|p11

