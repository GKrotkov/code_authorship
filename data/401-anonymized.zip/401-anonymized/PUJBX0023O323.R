## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(gridExtra)
library(car)
data <- read.csv("cmu-sleep.csv")



## -----------------------------------------------------------------------------
plot1 =ggplot(data, aes(x=TotalSleepTime)) + 
  geom_histogram(binwidth=30, fill='skyblue', color='black') +
  labs(title="Distribution of TotalSleepTime", x="Minutes of Sleep", y="Number of Students")

plot2 = ggplot(data, aes(x=term_gpa)) + 
    geom_histogram(binwidth=0.1, fill='coral', color='black', alpha=0.7) +
    labs(title="Distribution of Term_GPA", x="Term GPA", y="Number of Students") +
    theme_minimal()

plot3 =  ggplot(data, aes(x=cum_gpa)) + 
    geom_histogram(binwidth=0.1, fill='goldenrod', color='black', alpha=0.7) +
    labs(title="Distribution of Cum_GPA", x="Cumulative GPA", y="Number of Students") +
    theme_minimal()

plot4 = ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) +
        geom_point(aes(color=cum_gpa), alpha=0.5) + 
        labs(title="Total Sleep Time vs. term GPA", x="Minutes of Sleep", y="term GPA")

plot1
grid.arrange(plot2, plot3, ncol=2)
plot4


## -----------------------------------------------------------------------------
model1 <- lm(term_gpa ~ TotalSleepTime, data)
#summary(model1)


## -----------------------------------------------------------------------------
model2 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data)
#summary(model2)


## -----------------------------------------------------------------------------
# Generate ggplot objects
p1 <- ggplot(data.frame(Residuals = model1$residuals, Order = 1:length(model1$residuals)), 
             aes(x = Order, y = Residuals)) + 
  geom_point(color = "lightblue", alpha = 0.7) + 
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") + 
  ggtitle("Residuals vs Order for Model 1")

p2 <- ggplot(data.frame(Residuals = model2$residuals, Order = 1:length(model2$residuals)), 
             aes(x = Order, y = Residuals)) + 
  geom_point(color = "lightblue", alpha = 0.7) + 
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") + 
  ggtitle("Residuals vs Order for Model 2")

p3 <- ggplot(data, aes(x = model1$fitted.values, y = term_gpa)) + 
  geom_point(color = "lightblue") + 
  ggtitle("Model 1 Fitted vs Actual")+ labs(x = "fitted.values", y = "term_gpa")

p4 <- ggplot(data, aes(x = model2$fitted.values, y = term_gpa)) + 
  geom_point(color = "lightblue") + 
  ggtitle("Model 2 Fitted vs Actual")+ labs(x = "fitted.values", y = "term_gpa")

p5 <- ggplot(data, aes(x = model1$fitted.values, y = model1$residuals)) + 
  geom_point(color = "lightblue") + 
  ggtitle("Model 1 Fitted vs residuals")+ labs(x = "fitted.values", y = "residuals")

p6 <- ggplot(data, aes(x = model2$fitted.values, y = model2$residuals)) + 
  geom_point(color = "lightblue") + 
  ggtitle("Model 2 Fitted vs residuals") + labs(x = "fitted.values", y = "residuals")

#vif(model2)
# Arrange the ggplot objects
grid.arrange(p1, p2, ncol=2)
grid.arrange(p3, p4, ncol=2)
grid.arrange(p5, p6, ncol=2)


## -----------------------------------------------------------------------------
#confint(model1, "TotalSleepTime", level = 0.95)
#confint(model2, "TotalSleepTime", level = 0.95)



