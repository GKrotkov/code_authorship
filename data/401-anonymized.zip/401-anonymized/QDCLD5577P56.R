## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
# Libraries
library(ggplot2)
library(tidyverse)


## -----------------------------------------------------------------------------
# Dataset
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=3, fig.height=2, fig.cap="Histogram of the Average Sleep Time of Students (in minutes)"----
sleep %>% 
  ggplot(aes(x = TotalSleepTime)) + 
  geom_histogram(bins = 25) + 
  labs(x = "Average Sleep Time (in minutes)",
       y = "Number of Students")


## ---- fig.width=3, fig.height=2, fig.cap="Histogram of the Student GPA for Semester Being Studied (out of 4.0)"----
sleep %>% 
  ggplot(aes(x = term_gpa)) + 
  geom_histogram(bins = 25) + 
  labs(x = "Student Term GPAs (out of 4.0)",
       y = "Number of Students")


## ---- fig.width=3, fig.height=2, fig.cap="Histogram of the Student Culmulative GPA (out of 4.0)"----
sleep %>% 
  ggplot(aes(x = cum_gpa)) + 
  geom_histogram(bins = 25) + 
  labs(x = "Student Culmulative GPAs (out of 4.0)",
       y = "Number of Students")


## ---- fig.width=3, fig.height=3, fig.cap="Scatterplot of Average Sleep Time and Student GPA for Semester Being Studied"----
sleep %>% 
  ggplot(aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point() + 
  labs(x = "Average Sleep Time (in minutes)",
       y = "Student Term GPAs (out of 4.0)")


## ---- fig.width=3, fig.height=3, fig.cap="Scatterplot of Average Sleep Time and Student's Culmulative GPA"----
sleep %>% 
  ggplot(aes(x = TotalSleepTime, y = cum_gpa)) + 
  geom_point() + 
  labs(x = "Average Sleep Time (in minutes)",
       y = "Student's Cumulative GPA (out of 4.0)")


## ---- fig.width=3, fig.height=3, fig.cap="Scatterplot of Average Sleep Time and Student's Culmulative GPA"----
sleep %>% 
  ggplot(aes(x = cum_gpa, y = term_gpa)) + 
  geom_point() + 
  labs(x = "Student's Cumulative GPA (out of 4.0) ",
       y = "Student Term GPAs (out of 4.0)")


## ---- include = FALSE---------------------------------------------------------
## SIMPLE LINEAR REGRESSION MODEL
sleep.lm <- lm(term_gpa ~ TotalSleepTime, data = sleep)

## RESIDUAL PLOT
sleep.residuals <- residuals(sleep.lm)

sleep %>% 
  ggplot(aes(x = TotalSleepTime, y = sleep.residuals)) + 
  geom_point() + 
  geom_hline(yintercept = 0, color = 'sandybrown') + 
  labs(x = "Avg Sleep Time", 
       y = "Residuals",
       title = "Residual Plot of Model")

## QQ PLOT
qqnorm(sleep.residuals)
qqline(sleep.residuals, col="red")


## ---- include = FALSE---------------------------------------------------------
## RESULTS FROM FITTING TO SIMPLE LINEAR REGRESSION MODEL
summary(sleep.lm)

## CI INTERVAL FOR BETA 1
beta1.ci <- confint(sleep.lm, level=0.95)
beta1.ci

hours2 <- 0.00198 * 120
hours2

