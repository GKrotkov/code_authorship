## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

# Install and load packages
library(readr)
library(ggplot2)
library(psych)
library(modelsummary)
library(moments)
library(knitr)
library(tidyverse)
library(gridExtra)
library(grid)


## ---- include=FALSE-----------------------------------------------------------
# Load data
sleep <- read_csv("~/Desktop/modern regression/cmu-sleep.csv")


## ---- include=FALSE-----------------------------------------------------------
# Add column for sleep time in hours
sleep$TotalSleepTime.Hours = sleep$TotalSleepTime/60

# Summary
sleeptime.sum = summary(sleep$TotalSleepTime.Hours)


## ---- fig.width=4, fig.height=2.5, fig.align='center', echo=FALSE, warning=FALSE----
# Histogram
sleeptime.hist = ggplot(sleep, aes(x=TotalSleepTime.Hours)) +
  geom_histogram(color="black", fill="#7caed6", bins=35, linewidth=0.2) +
  labs(x="Sleep Time in Hours", y="Frequency",
       title="Average Sleep Time in Hours in University Students",
       caption="Figure 1.") +
  scale_x_continuous(breaks = seq(0, max(sleep$TotalSleepTime.Hours), by=0.5)) +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.title = element_text(size = 10, hjust = 0.5))

# Add mean line
sleeptime.hist + geom_vline(aes( xintercept=median(TotalSleepTime.Hours)),
                            color="#f77f6d", linetype="dashed", size=0.5)


## ---- include=FALSE-----------------------------------------------------------
# Summary
curr.gpa = summary(sleep$term_gpa)
before.gpa = summary(sleep$cum_gpa)


## ---- fig.width=5, fig.height=3, echo=FALSE, fig.align='center'---------------
# Density plot before transformations
ggplot(sleep, aes(x=term_gpa, color="Current GPA")) +
      geom_density(linetype="solid") +
      geom_density(aes(x=cum_gpa, color="Previous Semester GPA"), linetype="solid") +
      labs(color="GPA", title="Before-transformation GPA Distribution",
           caption="Figure 2.") +
      xlab("Student GPA (out of 4.0)") +
      ylab("Density") +
      scale_color_manual(values = c("Current GPA"="#8cd4c8",
                                    "Previous Semester GPA"="#f77f6d")) +
      scale_x_continuous(breaks = seq(0, max(sleep$TotalSleepTime.Hours), by=0.5)) +
      theme(legend.text=element_text(size=7),
            legend.title=element_text(size=8),
            text=element_text(family="Times"),
            plot.title=element_text(hjust = 0.5))


## ---- include=FALSE-----------------------------------------------------------
# Before-transformation skewness
skew.term_gpa = skewness(sleep$term_gpa)
skew.cum_gpa = skewness(sleep$cum_gpa)

# Apply transformations
sleep$trans.term_gpa = 1/(max(sleep$term_gpa+1)-sleep$term_gpa)
sleep$trans.cum_gpa = 1/(max(sleep$cum_gpa+1)-sleep$cum_gpa)

# After-transformation skewness
skew.trans.term_gpa = skewness(sleep$trans.term_gpa)
skew.trans.cum_gpa = skewness(sleep$trans.cum_gpa)


## ---- fig.width=5, fig.height=3, echo=FALSE, fig.align='center'---------------
# Density plots after transformations
ggplot(sleep, aes(x=1/(max(term_gpa+1)-term_gpa), color="Current GPA")) +
      geom_density(linetype="solid") +
      geom_density(aes(x=1/(max(cum_gpa+1)-cum_gpa), color="Previous Semester GPA"), linetype="solid") +
      labs(color="GPA", title="After-transformation GPA Distribution",
           caption="Figure 3.") +
      xlab("Student GPA") +
      ylab("Density") +
      scale_color_manual(values = c("Current GPA"="#8cd4c8",
                                    "Previous Semester GPA"="#f77f6d")) +
    scale_x_continuous(breaks = seq(0, max(sleep$trans.term_gpa), by=0.1)) +
      theme(legend.text=element_text(size=7),
            legend.title=element_text(size=8),
            text=element_text(family="Times"),
            plot.title=element_text(hjust=0.5))


## ---- include=FALSE-----------------------------------------------------------
# Summary statistics
summary(sleep$trans.term_gpa)
summary(sleep$trans.cum_gpa)


## ---- echo=FALSE, fig.align='center', fig.width=5, fig.height=3---------------
# Normal QQ-plots, Before transformation
par(mfrow=c(1,2))
# term_gpa
qq.term_gpa = qqnorm(sleep$term_gpa, pch=1, frame=FALSE, main="term_gpa")
qq.term_gpa = qqline(sleep$term_gpa, col="#8cd4c8", lwd=2)
# cum_gpa
qq.cum_gpa = qqnorm(sleep$cum_gpa, pch=1, frame=FALSE, main="cum_gpa")
qq.cum_gpa = qqline(sleep$cum_gpa, col="#8cd4c8", lwd=2)


## ---- echo=FALSE, fig.align='center', fig.width=5, fig.height=3---------------
# Normal QQ-plots, After transformation
par(mfrow=c(1,2))
# term_gpa
qq.term_gpa = qqnorm(sleep$trans.term_gpa, pch=1, frame=FALSE, main="trans.term_gpa")
qq.term_gpa = qqline(sleep$trans.term_gpa, col="#8cd4c8", lwd=2)
# cum_gpa
qq.cum_gpa = qqnorm(sleep$trans.cum_gpa, pch=1, frame=FALSE, main="trans.cum_gpa")
qq.cum_gpa = qqline(sleep$trans.cum_gpa, col="#8cd4c8", lwd=2)


## ---- fig.width=5.5, fig.height=3.2, fig.align='center', echo=FALSE-----------
# Bivariate EDA (current, before)
ggplot(sleep, aes(x=TotalSleepTime.Hours, y=1/(max(term_gpa+1)-term_gpa) )) +
      geom_point(aes(color="Term GPA"), alpha = 0.5) +
      geom_point(aes(x=TotalSleepTime.Hours, y=1/(max(cum_gpa+1)-cum_gpa),
                     color="Current GPA"), alpha=0.5) +
      labs(color="GPA", caption="Figure 4.", title="GPA by Total Hours Slept") +
    scale_x_continuous(breaks = seq(0, max(sleep$TotalSleepTime.Hours), by=0.5)) +
      xlab("Hours of Sleep") +
      ylab("GPA") +
      theme(text=element_text(family="Times"),
            plot.title=element_text(hjust=0.5))


## ---- include=FALSE-----------------------------------------------------------
# Create linear model for both variables separately
# Use transformations in linear model
sleep.lm.term_gpa = lm(trans.term_gpa~TotalSleepTime.Hours, data=sleep)
summary(sleep.lm.term_gpa)

sleep.lm.cum_gpa = lm(trans.cum_gpa~TotalSleepTime.Hours, data=sleep)
summary(sleep.lm.cum_gpa)

sleep.lm.gpas = lm(trans.term_gpa~TotalSleepTime.Hours+trans.cum_gpa, data=sleep)
summary(sleep.lm.gpas)


## ---- echo=FALSE--------------------------------------------------------------
# Correlation
cor_term_gpa = cor(sleep$TotalSleepTime.Hours, sleep$trans.term_gpa)
cor_cum_gpa = cor(sleep$TotalSleepTime.Hours, sleep$trans.cum_gpa)
cor_gpas = cor(sleep$trans.term_gpa, sleep$trans.cum_gpa)

cor_data = data.frame(
  Variable = c("Sleep Hours vs. Current GPA", "Sleep Hours vs. Previous GPA", "Previous GPA vs. Current GPA"),
  Correlation = c(cor_term_gpa, cor_cum_gpa, cor_gpas)
)

# Create the table
kable(cor_data, caption="Figure 5. Correlations Between Variables", format="markdown")


## ---- echo=FALSE, message=FALSE, fig.width=5.5, fig.height=3, fig.align='center'----
# Hours slept and Previous GPA vs. Current GPA
sleep.residuals.cum = ggplot(data=sleep, aes(x=fitted(sleep.lm.gpas), y=resid(sleep.lm.gpas))) +
  geom_point(alpha=0.6, color="#f77f6d") +
  geom_smooth(method="loess", se=FALSE, linetype="dashed") +
  labs(x="Fitted Values", y="Residuals", caption="Figure 7.") +
  ggtitle("Residuals \n Cumulative GPA & Sleep Hours") +
  theme(text=element_text(family="Times"),
        plot.title=element_text(size=12, hjust=0.5))

# Hours slept vs. Current GPA
sleep.residuals.term = ggplot(data=sleep, aes(x=fitted(sleep.lm.term_gpa), y=resid(sleep.lm.term_gpa))) +
  geom_point(alpha=0.6, color="#f77f6d") +
  geom_smooth(method="loess", se=FALSE, linetype="dashed") +
  labs(x="Fitted Values", y="Residuals", caption="Figure 6.") +
  ggtitle("Residuals \n Sleep Hours") +
  theme(text=element_text(family="Times"),
        plot.title=element_text(size=12, hjust=0.5))

grid.arrange(sleep.residuals.term, sleep.residuals.cum, ncol=2)


## ---- echo=FALSE, options(scipen=999)-----------------------------------------
# Model sleep data
sleep.lm = data.frame(
  Predictor=c("Intercept", "Sleep Time in Hours", "Cumulative GPA", "Overall"),
  Estimate=c("0.045105",
             round(coef(sleep.lm.gpas)["TotalSleepTime.Hours"], 5),
             round(coef(sleep.lm.gpas)["trans.cum_gpa"], 5),
             "*"),
  Std_Error=c("0.044115",
              round(summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "Std. Error"], 5),
              round(summary(sleep.lm.gpas)$coef["trans.cum_gpa", "Std. Error"], 5),
              "*"),
  T_Value=c("1.022",
            round(summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "t value"],5),
            round(summary(sleep.lm.gpas)$coef["trans.cum_gpa", "t value"],5),
            "*"),
  P_Value=c("0.306969",
            summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "Pr(>|t|)"],
            summary(sleep.lm.gpas)$coef["trans.cum_gpa", "Pr(>|t|)"],
            "< 2.2e-16"))

# Create the table
kable(sleep.lm, caption="Figure 8. Linear Model Summary", format="markdown")


## ---- echo=FALSE, fig.width=4.5, fig.height=3.4, fig.align='center', message=FALSE----
# Multiple Linear Regression Model
sleep.gpa.lm = data.frame(
  Observed=sleep$trans.term_gpa,
  Predicted=predict(sleep.lm.gpas))

ggplot(sleep.gpa.lm, aes(x=Observed, y=Predicted)) +
  geom_point(alpha=0.5) +
  geom_smooth(method=lm, color="#f77f6d", fill="#8cd4c8") +
  labs(x="Predictor Variables (TotalSleepTime.Hours & trans.cum_gpa)",
       y="Current GPA (term_gpa)", caption="Figure 9.") +
  scale_x_continuous(breaks = seq(0, max(sleep$TotalSleepTime.Hours), by=0.5)) +
  ggtitle("Observed Variables vs. \n Predicted Current Semester GPA") +
  theme(text=element_text(family="Times"),
        axis.title=element_text(size=10),
        plot.title=element_text(size=12, hjust=0.5))



## ---- include=FALSE-----------------------------------------------------------
# Confidence interval
confint(sleep.lm.gpas, 'TotalSleepTime.Hours', level=0.95)


## ---- include=FALSE-----------------------------------------------------------
# Standardized linear model
hours.cum.std = lm(scale(trans.term_gpa)~scale(TotalSleepTime.Hours)+scale(trans.cum_gpa), data=sleep)
summary(hours.cum.std)

## ---- echo=FALSE--------------------------------------------------------------
# Model sleep data
sleep.lm.std = data.frame(
  Predictor=c("Sleep Time in Hours", "Cumulative GPA", "Overall", "Scaled Sleep Time Hours", "Scaled Cumulative GPA"),
  
  Estimate=c(round(coef(sleep.lm.gpas)["TotalSleepTime.Hours"], 5),
             round(coef(sleep.lm.gpas)["trans.cum_gpa"], 5),
             "*",
             "0.1037", "0.6817"),
  
  Std_Error=c(round(summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "Std. Error"], 5),
              round(summary(sleep.lm.gpas)$coef["trans.cum_gpa", "Std. Error"], 5),
              "*",
              "2.857e-02", "2.857e-02"),
  
  T_Value=c(round(summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "t value"],5),
            round(summary(sleep.lm.gpas)$coef["trans.cum_gpa", "t value"],5),
            "*",
            "3.628", "23.858"),
  
  P_Value=c(summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "Pr(>|t|)"],
            summary(sleep.lm.gpas)$coef["trans.cum_gpa", "Pr(>|t|)"],
            "< 2.2e-16",
            "0.000309", "< 2e-16" ))

# Create the table
kable(sleep.lm.std, caption="Figure 10. Linear Model Summary Wtih Standardized Estimates", format="markdown")


## ---- echo=FALSE--------------------------------------------------------------
less_sleep_effect = coef(sleep.lm.gpas)["TotalSleepTime.Hours"]*(-2)

less_sleep_df = data.frame(Effect=less_sleep_effect)

kable(less_sleep_df, caption="Figure 11.", format="markdown")


## ---- echo=FALSE--------------------------------------------------------------
# Confidence Interval
alpha = 0.05
t_crit = qt(1-alpha/2, df=631)
# Margin of error
se = summary(sleep.lm.gpas)$coef["TotalSleepTime.Hours", "Std. Error"]
moe = t_crit*se
# Lower and Upper bound
lower_bound = less_sleep_effect - moe
upper_bound = less_sleep_effect + moe

effect_ci = data.frame(Lower=lower_bound, Upper=upper_bound)
kable(effect_ci, caption="Figure 12.", format="markdown")

