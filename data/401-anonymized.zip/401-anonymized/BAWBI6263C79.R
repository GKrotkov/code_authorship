## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
df <- read.csv("cmu-sleep.csv")
library(ggplot2)


## -----------------------------------------------------------------------------
ggplot(data = df, aes(x = TotalSleepTime)) +
  geom_histogram(bins = 30, fill = "lightblue", 
                 color = "black") +
  labs(title = "Histogram of Total Sleep Time",
x = "Total Sleep Time (in minutes)",
    y = "Frequency")


## -----------------------------------------------------------------------------
summary(df$TotalSleepTime)


## -----------------------------------------------------------------------------
ggplot(data = df, aes(x = term_gpa)) +
  geom_histogram(bins = 30, fill = "lightblue", 
                 color = "black") +
labs(title = "Histogram of Term GPA",
    x = "Term GPA",
    y = "Frequency")


## -----------------------------------------------------------------------------
summary(df$term_gpa)


## -----------------------------------------------------------------------------
ggplot(data = df, aes(x = cum_gpa)) +
geom_histogram(bins = 30, fill = "lightblue", 
               color = "black") +
  labs(title = "Histogram of Cumulative GPA",
    x = "Cum GPA",
    y = "Frequency")


## -----------------------------------------------------------------------------
summary(df$cum_gpa)


## -----------------------------------------------------------------------------
ggplot(data = df, aes(x = TotalSleepTime, y = term_gpa)) +
geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +  
labs(title = "Scatterplot of TotalSleepTime vs. Term GPA",
    x = "Total Sleep Time (minutes)",
    y = "Term GPA")


## -----------------------------------------------------------------------------
ggplot(data = df, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(
    title = "Scatterplot of TotalSleepTime vs. Cumulative GPA",
    x = "Total Sleep Time (minutes)",
    y = "Cumulative GPA")


## -----------------------------------------------------------------------------
term_model <- lm(term_gpa ~ TotalSleepTime, data = df)
summary(term_model)


## -----------------------------------------------------------------------------
cum_model <- lm(cum_gpa ~ TotalSleepTime, data = df)
summary(cum_model)


## -----------------------------------------------------------------------------
r_squared1 <- summary(cum_model)$r.squared

r_squared2 <- summary(term_model)$r.squared

cat("R-squared for cum_gpa model:", r_squared1, "\n")
cat("R-squared for term_gpa model:", r_squared2, "\n")


## -----------------------------------------------------------------------------
ggplot(term_model, aes(x = .fitted, y = .resid)) +
  geom_point() +
geom_hline(yintercept = 0, linetype = "dashed", 
           color = "red") +
  labs(x = "Fitted Values", 
       y = "Residuals") +
  ggtitle("Residual Plot for Term GPA")


## -----------------------------------------------------------------------------
ggplot(cum_model, aes(x = .fitted, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", 
             color = "red") +
  labs(x = "Fitted Values", 
       y = "Residuals") +
  ggtitle("Residual Plot for Cumulative GPA")


## -----------------------------------------------------------------------------

ggplot(data = term_model, aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line(color = "red") +
  labs(title = "Q-Q Plot of Residuals for Term GPA", 
       x = "Theoretical Quantiles", 
       y = "Sample Quantiles")



## -----------------------------------------------------------------------------

ggplot(data = cum_model, aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line(color = "red") +
labs(title = "Q-Q Plot of Residuals for Cumulative GPA", 
     x = "Theoretical Quantiles", 
     y = "Sample Quantiles")


## -----------------------------------------------------------------------------
summary(term_model)

