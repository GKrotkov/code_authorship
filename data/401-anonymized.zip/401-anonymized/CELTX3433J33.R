## ----setup, include = FALSE---------------------------------------------------
library(knitr)
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(knitr)
library(alr4)
data("Rateprof")
library(ggplot2)


## ---- results = FALSE---------------------------------------------------------
library(knitr)
library(alr4)
data("Rateprof")
summary(Rateprof$gender)

## -----------------------------------------------------------------------------
t1 = read.table(text="159  207")
knitr::kable(t1, caption = "Gender Distribution", col.names = c("female", "male"))


## ---- results = FALSE---------------------------------------------------------
summary(Rateprof$pepper)

## -----------------------------------------------------------------------------
t1 = read.table(text="320  46")
knitr::kable(t1, caption = "Attractiveness Distribution", col.names = c("no", "yes"))


## ---- fig.width=6, fig.height=3, fig.cap="Gender Distribution and Attractiveness Distribution"----
par(mfrow = c(1, 2))
# Bar plot for gender distribution
barplot(table(Rateprof$gender), col = c("red", "blue"), xlab = "Gender", ylab = "Count")
# Bar plot for attractiveness distribution
barplot(table(Rateprof$pepper), col = c("red", "blue"), xlab = "Attractiveness", ylab = "Count")


## ---- results = FALSE---------------------------------------------------------
summary(Rateprof$easiness)


## -----------------------------------------------------------------------------
t1 = read.table(text="1.391   2.548   3.148   3.135   3.692   4.900")
knitr::kable(t1, caption = "Attractiveness Distribution", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- fig.width=8, fig.height=4, fig.cap="Histogram and Boxplot of Easiness Rating"----
par(mfrow = c(1, 2))
hist(Rateprof$easiness, col = "lightgreen", 
     xlab = "Easiness Rating", ylab = "Frequency")
boxplot(Rateprof$easiness, col = "lightgreen",  
        ylab = "Easiness Rating")


## ---- results = FALSE---------------------------------------------------------
summary(Rateprof$discipline)


## -----------------------------------------------------------------------------
t1 = read.table(text=" 134       66      103       63 ")
knitr::kable(t1, caption = "Discipline Distribution", col.names = c("Humanity", "Social Science", "STEM", "Pre-professional"))

## ---- fig.width=6, fig.height=3, fig.cap="Barplot of Discipline"--------------
# Bar plot for discipline distribution
barplot(table(Rateprof$discipline), col = "lightgoldenrodyellow",  xlab = "Discipline", ylab = "Count")



## ---- results = FALSE---------------------------------------------------------
summary(Rateprof$quality)


## -----------------------------------------------------------------------------
t1 = read.table(text=" 1.409   2.936   3.612   3.575   4.250   4.981 ")
knitr::kable(t1, caption = "Quality Rating Distribution", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- fig.width=8, fig.height=3, fig.cap="Histogram and boxplot of Quality"----
par(mfrow = c(1, 2))
# Histogram for easiness ratings
hist(Rateprof$quality, col = "pink", 
     xlab = "Quality", ylab = "Frequency")
boxplot(Rateprof$quality, col = "pink",  
        ylab = "Quality")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Gender vs. Quality Rating"----
plot(Rateprof$gender, Rateprof$quality, 
     xlab = "Gender", ylab = "Average Quality Rating", col = "brown")


## ---- fig.width=3, fig.height=2, fig.cap="Scatterplot of Professor's Quality Rating and Its Easiness Rating."----
library(ggplot2)
ggplot(data = Rateprof, aes(x = easiness,
                            y = quality)) +
  labs(x = "Professor's Easiness Rating", 
       y = "Professor's Quality Rating") +
  geom_point(color = "navy") +
  geom_smooth(method = lm, formula = y ~ x) +
  ggtitle("Relationship between Professor's Quality Rating and Its Easiness Rating")


## ---- fig.width=9, fig.height=4, fig.cap="Boxplot of Attractiveness vs. Quality Rating   &   Boxplot of Discipline vs. Quality Rating"----
par(mfrow = c(1, 2))
# Boxplot of Average Quality Rating vs. Attractiveness
plot(Rateprof$pepper, Rateprof$quality, 
     xlab = "Attractiveness (Chili Pepper Rating)", ylab = "Average Quality Rating", col = "orange")
# Boxplot of Average Quality Rating vs. Discipline
plot(Rateprof$discipline, Rateprof$quality, 
     xlab = "Discipline", ylab = "Average Quality Rating", col = "lavender")



## ---- include=FALSE-----------------------------------------------------------

rating_no_inter_lm <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

# Print a summary of the model
summary(rating_no_inter_lm)

rating_no_inter_lm_AIC <- AIC(rating_no_inter_lm)

print (rating_no_inter_lm_AIC)

rating_no_inter_lm_final <- step(rating_no_inter_lm, direction = "both", trace = 0)

summary(rating_no_inter_lm_final)

AIC(rating_no_inter_lm_final)

confint(rating_no_inter_lm_final)


## ---- include=FALSE-----------------------------------------------------------


# Fit the full and reduced models
rating_inter_full <- lm(quality ~ gender + pepper + discipline + easiness + 
                        easiness:gender + easiness:discipline, 
                      data = Rateprof)

rating_inter_reduced <- lm(quality ~ gender + pepper + discipline + easiness, 
                         data = Rateprof)

# Run the partial F-test
partial_f_test <- anova(rating_inter_reduced, rating_inter_full)
partial_f_test


## ---- fig.width=4, fig.height=3, fig.cap="Residual Plots"---------------------

# 3. Residuals vs. Easiness
plot(rating_no_inter_lm$residuals ~ Rateprof$easiness, xlab="Easiness", ylab="Residuals", main="Residuals vs. Easiness", col = "darkgreen")




## ----fig.width=6, fig.height=3, fig.cap="Normal Q-Q Plot and Cook's Distance"----
par(mfrow = c(1, 2))
qqnorm(residuals(rating_no_inter_lm))
qqline(residuals(rating_no_inter_lm), col = "red", lwd = 2)
rating_cookdistance = cooks.distance(rating_no_inter_lm)
plot(rating_cookdistance, pch = 19,  xlab = "Index", ylab = "Cook's Distance", col = "gold")


## ---- include=FALSE-----------------------------------------------------------
which.max(cooks.distance(rating_no_inter_lm))


## ---- fig.width=4, fig.height=3, fig.cap="Rregression Result Table."----------
# Creating a data frame with coefficient results
coefficient_table <- data.frame(
  Coefficient = c("(Intercept)", "gendermale", "pepperyes", "easiness"),
  Estimate = c(1.67028, 0.17364, 0.63741, 0.55064),
  Std_Error = c(0.15340, 0.06966, 0.10712, 0.04584),
  t_value = c(10.888, 2.493, 5.950, 12.012),
  Pr_greater_than_t = c("< 2e-16", 0.0131, "6.32e-09", "< 2e-16"),
  Significance = c("***", "*", "***", "***")
)

# Load required libraries
library(knitr)

# Print the coefficients table with significance stars
kable(coefficient_table, caption = "Rregression Result Table.",align = c("l", "c", "c", "c", "c"))
knitr::kable(confint(rating_no_inter_lm_final), digits = 5, caption = "Confidence interval of coefficients")


## ---- fig.width=4, fig.height=3, fig.cap="Analysis of Variance Table."--------

library(knitr)

# Create a data frame with the information
result_df <- data.frame(
  Res.Df = c(359, 355),
  RSS = c(154.60, 154.05),
  Df = c(" ", 4),
  `Sum of Sq` = c(" ", 0.54359),
  F = c(" ", 0.3132),
  `Pr(>F)` = c(" ", 0.8691)
)

# Print the result table
kable(result_df, format = "markdown", digits = 4, caption = "Analysis of Variance Table.")


