## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(ggplot2)
library(dplyr)
library(patchwork)
library(stargazer)
library(broom)


## -----------------------------------------------------------------------------

knitr::opts_chunk$set(echo = FALSE)
par(mfrow = c(1, 2))
par(cex=0.9)
hist(Rateprof$quality, prob = TRUE, xlab = "Quality Rating", main = "Fig 1: Distribution of Quality")
hist(Rateprof$easiness, prob = TRUE, xlab = "Easiness ", main = "Fig 2: Distirbution of Easiness")



## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

par(mfrow = c(1, 3))
par(cex=0.5)

barplot(table(Rateprof$gender),
        xlab = "Gender", ylab = "Count",
        main = "Fig 3: Bar Plot of Gender")
barplot(table(Rateprof$pepper),
        names = c("not attractive", "attractive"),
        xlab = "Attractiveness", ylab = "Count",
        main = "Fig 4: Bar plot of Attractiveness")
barplot(table(Rateprof$discipline),
        xlab = "Discipline", ylab = "Count",
        main = "Fig 5: Bar plot of Discipline")


## ----fig.width=4, fig.height=3------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(title = "Fig 6: Quality Rating vs Easiness")


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

# bar plots of categorical variables & quality rating
par(mfrow = c(1, 3))
par(cex=0.5)

boxplot(quality ~ gender, data = Rateprof,
        main = "Fig 7: Boxplot of Quality Rating & Gender")
boxplot(quality ~ pepper , data = Rateprof,
        xlab = "Professor is Attractive?",
        main = "Fig 8: Boxplot of Quality Rating & Attractiveness")
boxplot(quality ~ discipline, data = Rateprof,
        names = c("Hum", "soc-sci", "STEM", "pre-prof"),
        main = "Fig 9: Boxplot of Quality Rating & Discipline")



## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
par(mfrow = c(1, 3))
par(cex=0.5)

boxplot(easiness ~ gender, data = Rateprof,
        main = "Fig 11: Boxplot of Easiness & Gender")
boxplot(easiness ~ pepper , data = Rateprof,
        xlab = "Professor is Attractive?",
        main = "Fig 12: Boxplot of Easiness & Attractiveness")
boxplot(easiness ~ discipline, data = Rateprof,
        names = c("Hum", "soc-sci", "STEM", "pre-prof"),
        main = "Fig 13: Boxplot of Easiness & Discipline")



## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
fullmodel <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
reducedmodel <- lm(quality ~ gender + pepper + easiness, data = Rateprof)
fullmodel2 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) +
                easiness:factor(gender) + easiness:factor(discipline), 
               data = Rateprof)


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

p1 <- augment(fullmodel) |>
  ggplot(aes(x = easiness, y = .resid)) +
  geom_point() +
  geom_hline(yintercept=0, linetype="dashed", color= "blue") +
  labs(x = "Easiness", y = "Residual", title = "Fig 14: Residuals vs Easiness")

p2 <- augment(fullmodel) |>
  ggplot(aes(x = .fitted, y = .resid)) +
  geom_hline(yintercept=0, linetype="dashed", color="blue") +
  geom_point() +
  labs(x = "Fitted value", y = "Residual", title = "Fig 15: Residuals vs Fitted")

p1 | p2



## ----fig.width=4, fig.height=3------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

ggplot(augment(fullmodel), aes(sample = .resid)) + geom_qq() +
geom_qq_line(color="blue") +
labs(x = "Theoretical quantile", y = "Sample quantile",
     title = "Fig 16: Normal Q-Q Plot")


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
anova(reducedmodel, fullmodel)


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
anova(fullmodel,fullmodel2)

