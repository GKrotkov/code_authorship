## ----setup, include = FALSE, results='hide'-----------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----echo=F, results = 'hide', message = F------------------------------------
invisible(library(alr4))
library(ggplot2)
library(GGally)
library(gridExtra)
library(modelsummary)
invisible(library(sjPlot))
rprof.dt <- Rateprof


## ----echo = F-----------------------------------------------------------------
marrangeGrob(list(
  ggplot(rprof.dt, aes(x = gender)) + geom_bar(color = "black", fill = "pink") + labs(title = "Professor Gender Distribution"),
  ggplot(rprof.dt, aes(x = pepper)) + geom_bar(color = "black", fill = "red") + labs(title = "Professor Attractiveness Distribution"),
  ggplot(rprof.dt, aes(x = discipline)) + geom_bar(color = "black", fill = "purple") + labs(title = "Professor Disciplines Distribution"),
  ggplot(rprof.dt, aes(x = easiness)) + geom_histogram(bins = 30, color = "black", fill = "cyan") + labs(title = "Professor Easiness Distribution")
                  ), nrow = 2, ncol = 2)


## ----echo = F-----------------------------------------------------------------
ggplot(rprof.dt, aes(x = quality)) + geom_histogram(bins = 30, color = "black", fill = "green") + labs(title = "Professor Quality Distribution") 


## ----echo = F-----------------------------------------------------------------
ggpairs(rprof.dt, columns = c(1, 5, 6, 11, 8))


## ----echo = F-----------------------------------------------------------------
ggplot(rprof.dt, aes(x = pepper, y = quality)) + geom_boxplot() + labs(title = "Average Professor Quality Ratings vs Attractiveness Rating")


## ----echo = F-----------------------------------------------------------------
ggplot(rprof.dt, aes(x = easiness, y = quality)) + geom_point() + labs(title = "Average Professor Quality Rating vs Easiness Rating")


## ----echo = F-----------------------------------------------------------------
quality.interactions.lm <- lm(quality ~ easiness * (gender + discipline) + pepper, rprof.dt)
quality.lm <- lm(quality ~ easiness + gender + discipline + pepper, rprof.dt)
quality.lm.nodiscipline <- lm(quality ~ easiness + gender + pepper, rprof.dt)
#summary(quality.interactions.lm)


## -----------------------------------------------------------------------------
modelsummary(list("Base Model" = quality.lm, "Interaction Model" = quality.interactions.lm, "Reduced Model w/o Discipline" = quality.lm.nodiscipline), statistic = c("SE = {std.error}"))


## ----include = F--------------------------------------------------------------
mean(quality.lm$residuals)
head(sort(pf(cooks.distance(quality.lm), 6, 359), decreasing = T))


## ----fig.cap = "Residual Plots for Base Model", echo = F----------------------
residualPlots(quality.lm, pch = 18, tests = F, ylab = "residuals")


## ----echo = F-----------------------------------------------------------------
ggplot(quality.lm, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles", title = "Normal QQ plot of Base Model residuals")


## ----include = F--------------------------------------------------------------
mean(quality.interactions.lm$residuals)
head(sort(pf(cooks.distance(quality.interactions.lm), 10, 355), decreasing = T))


## ----fig.cap = "Residual Plots for Interaction Model"-------------------------
residualPlots(quality.interactions.lm, pch = 18, tests = F, ylab = "residuals")


## ----echo = F-----------------------------------------------------------------
ggplot(quality.interactions.lm, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles", title = "Normal QQ plot of Interaction Model residuals")


## ----include = F--------------------------------------------------------------
mean(quality.lm.nodiscipline$residuals)
head(sort(pf(cooks.distance(quality.lm.nodiscipline), 3, 362), decreasing = T))


## ----fig.cap = "Residual Plots for Model w/o Discipline"----------------------
residualPlots(quality.lm.nodiscipline, pch = 18, tests = F, ylab = "residuals")


## ----echo = F-----------------------------------------------------------------
ggplot(quality.lm.nodiscipline, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles", title = "Normal QQ plot of Model w/o Discipline residuals")


## ----include = F--------------------------------------------------------------
confint.lm(quality.lm)


## ----include = F--------------------------------------------------------------
anova(quality.lm, quality.interactions.lm)


## ----include = F--------------------------------------------------------------
summary(quality.lm)
anova(quality.lm.nodiscipline, quality.lm)
confint.lm(quality.lm)

