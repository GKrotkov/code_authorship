## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, message = FALSE---------------------------------------------
library(gridExtra)
library(grid)
library(ggplot2)
library(tidyverse)
library(modelsummary)
library(broom)
library(kableExtra)


## -----------------------------------------------------------------------------
sleepData = read.csv("cmu-sleep.csv")
sleepData$TotalSleepTime <- sleepData$TotalSleepTime/60


## ----fig.width=6, fig.height=6, fig.cap="Exploratory Data Analysis of Variables of Interest"----
par(mfrow = c(2, 2))
hist(sleepData$TotalSleepTime, main="Histogram of Total Sleep Time", xlab = "Average Hours of Sleep (hr)", col="dodgerblue3", breaks=15)
hist(sleepData$term_gpa, main="Histogram of Spring GPA", xlab = "GPA (out of 4.0)", col="steelblue", breaks=15)
hist(sleepData$cum_gpa, main="Histogram of Fall GPA", xlab = "GPA (out of 4.0)", col="slategray3", breaks=15)
plot(sleepData$TotalSleepTime, sleepData$term_gpa, main="GPA vs Sleep Scatterplot", col="steelblue", xlab = "Average Hours of Sleep (hr)", ylab = "GPA (out of 4.0)")


## -----------------------------------------------------------------------------
#spring
model1 <- lm(term_gpa ~ TotalSleepTime, data = sleepData)
# summary(model1)
modelsummary(list("Spring Term GPA" = model1),
             gof_map = c("r.squared", "nobs"), title = "Regressing Spring GPA against Average Total Sleep Time (Standard Error for Estimates in Parentheses)")


## ----fig.width=6, fig.height=6, fig.cap="Diagonstic plots from fitting Linear Regression of Spring Term GPA vs. Sleep Time"----
par(mfrow = c(2, 2))
plot(model1)


## -----------------------------------------------------------------------------
df <- tidy(model1, conf.int = TRUE)
knitr::kable(df, digits = 3, caption = "Additional Regression Model Estimates for Confidence Intervals and Hypothesis Testing")

