## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
df = read.csv("/Users/jeremynichols/Desktop/CMU/Junior/401/Data Exam 1/cmu-sleep.csv")
power3tgpa <- 3^(df$term_gpa)
power3cgpa <- 3^(df$cum_gpa)


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(df$TotalSleepTime, xlab = "Total Sleep Time (minutes)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(df$term_gpa, main = "Histogram of Term GPA", xlab = "Term GPA (out of 4.0)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(df$cum_gpa, main = "Histogram of Cumulative GPA", xlab = "Cumulative GPA (out of 4.0)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(power3tgpa, main = "Histogram of Transformed Term GPA", xlab = "3 ^ Term GPA (out of 81)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(power3cgpa, main = "Histogram of Transformed Cumulative GPA", xlab = "3 ^ Cumulative GPA (out of 81)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
plot(term_gpa ~ TotalSleepTime, data = df, ylab = "Term GPA (out of 4.0)", xlab = "Total Sleep Time (minutes)")


## ---- fig.width=4, fig.height=3-----------------------------------------------
plot(power3tgpa ~ TotalSleepTime, data = df, ylab = "3 ^ Term GPA (out of 81)", xlab = "Total Sleep Time (minutes)")


## ---- fig.width=4, fig.height=3-----------------------------------------------
q1model <- lm(power3tgpa ~ TotalSleepTime, data = df)
plot(fitted(q1model), residuals(q1model), ylab = "Residuals", xlab = "Fitted values")
#confint(q1model, level = 0.95)


## -----------------------------------------------------------------------------
#summary(q1model)
#tab_model(q1model)


## -----------------------------------------------------------------------------
confint(q1model, level = 0.95)
#table("Intercept: [9.75876103, 33.9925656]", "TotalSleepTime [0.03973962, 0.1002394]")


## -----------------------------------------------------------------------------
mean_tgpa <-mean(df$term_gpa)
#mean_tgpa
new_df <- data.frame(TotalSleepTime = df$TotalSleepTime - 120)
interval_df <- data.frame(log(predict(q1model, newdata = new_df, interval = "confidence", level=0.95), base = 3))
#interval_df
intervals <- c(mean(interval_df$lwr), mean(interval_df$fit), mean(interval_df$upr))
#intervals
#c(mean(interval_df$lwr) - 3.449598, mean(interval_df$fit) - 3.449598, mean(interval_df$upr)- 3.449598)
#cat("The average term gpa =", mean(df$term_gpa))
#t.test(mean_tgpa, mean(interval_df$fit), paired = TRUE)

#log((mean(df$TotalSleepTime) - 120)* 0.06999 + 21.87566, base = 3)


