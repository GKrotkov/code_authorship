## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## -----------------------------------------------------------------------------
library(tidyverse)
library(broom)
library(modelsummary)
library(stargazer)
library(alr4)
library(cowplot)
library(patchwork)
library(kableExtra)
library(xtable)


## -----------------------------------------------------------------------------
ratings <- Rateprof %>%
  select(gender, pepper, easiness, discipline, quality)


## ---- fig.width=6, fig.height=3,fig.cap="Barplots of Variables"---------------
# Univariate EDA, Barplots
bar1 <- ggplot(ratings, aes(x = gender)) +
  geom_bar() +
  labs(x = "Gender", y = "Frequency") +
  scale_x_discrete(labels = c("Female", "Male"))

bar2 <- ggplot(ratings, aes(x = pepper)) +
  geom_bar() +
  labs(x = "Pepper (If Instructor is Attractive)", y = "Frequency") +
  scale_x_discrete(labels = c("No", "Yes"))

bar1 | bar2

ggplot(ratings, aes(x = discipline)) +
  geom_bar() +
  labs(x = "Discipline", y = "Frequency") +
  scale_x_discrete(labels = c("Humanities", "Social Sciences", "STEM", "Professional Training"))


## ---- fig.width=6, fig.height=3, fig.cap="Histograms of Variables"------------
# Univariate EDA, Histograms
hist1 <- ratings %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(bins = 20) +
  labs(x = "Average Easiness Rating, from 1 to 5", y = "Frequency") +
  theme(plot.title = element_text(hjust = 0.5))

hist2 <- ratings %>%
  ggplot(aes(x = quality)) +
  geom_histogram(bins = 20) +
  labs(x = "Average Quality Rating, from 1 to 5", y = "Frequency") +
  theme(plot.title = element_text(hjust = 0.5))

hist1 | hist2


## ---- fig.cap="Boxplots of Quality Rating versus Variables"-------------------
# Bivariate EDA, Boxplots
par(mfrow = c(1,2))
boxplot(quality ~ gender, ylab = "Average Quality Rating", data = ratings, xlab = "Gender", 
        names = c("Female", "Male"), pch = 16)

boxplot(quality ~ pepper, ylab = "Average Quality Rating", data = ratings, xlab = "Is the Instructor Attractive?", 
        names = c("No","Yes"), pch = 16)

boxplot(quality ~ discipline, ylab = "Average Quality Rating", data = ratings, xlab = "Discipline", pch = 16)


## ---- fig.cap="Scatterplot of Quality Rating versus Easiness Rating",results='hide', warning=FALSE, message=FALSE----
# Bivariate EDA, Scatterplot
ratings %>%
  ggplot(aes(x = easiness, y = quality)) +
  labs(x = "Average Easiness Rating, from 1 to 5", y = "Average Quality Rating, from 1 to 5") +
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm")


## -----------------------------------------------------------------------------
# Build Full Model
ratings_model <- lm(quality ~ gender + pepper + easiness + discipline, data = ratings)
summary(ratings_model)

ratings_reduced_model <- lm(quality ~ gender + pepper + easiness, data = ratings)
summary(ratings_reduced_model)

ratings_full_model1 <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender, data = ratings)
summary(ratings_full_model1)

ratings_full_model2 <- lm(quality ~ gender + pepper + easiness + discipline + easiness:discipline, data = ratings)
summary(ratings_full_model2)

anova(ratings_reduced_model, ratings_model)

anova(ratings_model, ratings_full_model1)

anova(ratings_model, ratings_full_model2)




## -----------------------------------------------------------------------------
# Check assumptions
ggplot(augment(ratings_full_model1), aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted value", y = "Residual")

ggplot(augment(ratings_full_model1), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles")


## -----------------------------------------------------------------------------
modelsummary(list("Model 1" = ratings_model, "Model 2" = ratings_full_model1, "Model 3" = ratings_full_model2), gof_map = c("r.squared"), statistic = c("SE =    {std.error}", 
                           "t = {statistic}",
                           "p = {p.value}"), title = "Regression Output")


## -----------------------------------------------------------------------------
knitr::kable(tidy(anova(ratings_reduced_model, ratings_model)), digits = 2) 
knitr::kable(tidy(anova(ratings_model, ratings_full_model2)), digits = 2)

xtable(anova(ratings_reduced_model, ratings_model), caption = "Table 2")
xtable(anova(ratings_model, ratings_full_model2), caption = "Table 3")


## -----------------------------------------------------------------------------
confint(ratings_model, "gendermale", 0.95)
confint(ratings_model, "pepperyes", 0.95)
confint(ratings_model, "easiness", 0.95)

