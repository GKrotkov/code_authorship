## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----libraries----------------------------------------------------------------
library(rockchalk)


## ----EDA.LoadData-------------------------------------------------------------
df <- read.csv("cmu-sleep.csv")


## ----EDA.1var, fig.width=6,fig.height=6,fig.align='center', fig.cap="Histograms of the variables. TotalSleepTime is relatively normal and cumulative GPA and term GPA are heavily left skewed."----
par(mfrow=c(2,2))
hist(df$TotalSleepTime,
     xlab="Average Time Slept (minutes)",
     main = "TotalSleepTime",
     col="orange")

plot.new()

hist(df$cum_gpa,
     xlab="Cumulative GPAs (4.0)",
     main = "cum_gpa",
     col="orchid",
     breaks=seq(0,4,0.25))

hist(df$term_gpa,
     xlab="GPA of Term Studied (4.0)",
     main = "term_gpa",
     col="olivedrab3",
     breaks=seq(0,4,0.25))


## ----EDA.2var, fig.width=7.5,fig.height=7.5,fig.align='center', fig.cap="Pairs plot of the variables. Strong, positive, and linear relationship between term GPA and cumulative GPA. Weak, positive, and linear relationship between TotalSleepTime and term GPA, cumulative GPA."----
pairs(df[,c('TotalSleepTime', 'term_gpa', 'cum_gpa')])


## ----Methods.LMs--------------------------------------------------------------

lms <- list(lm(term_gpa ~ TotalSleepTime,
               data=df),
            lm(term_gpa ~ TotalSleepTime * cum_gpa,
               data=df))


## ----Methods.Residuals, fig.width=7.5,fig.height=3.5,fig.align='center', fig.cap="Residual Plots of the Linear Models. Both have unequal variances among the residuals."----
par(mfrow=c(1,2))

for (lm in lms)
{
  title = paste(summary(lm)['call'])
  plot(lm, which=1,
       pch=19,
       cex=0.5,
       caption="")
  title(paste("formula =\n", substring(title, 14, nchar(title)-12)),
        cex.main=0.9,
        line=0.7)
}

mtext('     Residuals vs Fitted', cex = 1.3, line=-2, outer=TRUE)


## ----Method.Cooks-------------------------------------------------------------
cooks.d1 <- cooks.distance(lms[[1]])
cooks.d2 <- cooks.distance(lms[[2]])


## ----Method.Cooks1------------------------------------------------------------
head(sort(pf(cooks.d1, length(lms[[1]]$coefficients), nrow(df) - length(lms[[1]]$coefficients)), decreasing=TRUE))


## ----Method.Cooks.2-----------------------------------------------------------
head(sort(pf(cooks.d2, length(lms[[2]]$coefficients), nrow(df) - length(lms[[2]]$coefficients)), decreasing=TRUE))


## ----Methods.QQ, fig.width=7.5,fig.height=3.5,fig.align='center', fig.cap="Q-Q Plots of the Linear Models"----
par(mfrow=c(1,2))
for (lm in lms)
{
  title = paste(summary(lm)['call'])
  plot(lm, which=2,
       pch=19,
       cex=0.5,
       caption="")
  title(paste("formula =\n", substring(title, 14, nchar(title)-12)),
        cex.main=0.9,
        line=0.7)
}

mtext('     Q-Q Residuals', cex = 1.3, line=-2, outer=TRUE)


## ----Results.1, fig.width=7.5,fig.height=7.5,fig.align='center', fig.cap="Scatterplot of Non-Interaction Linear Model."----
plot(df$TotalSleepTime,
     df$term_gpa,
     xlab="Average Time Slept (minutes_",
     ylab="Term GPA (/4.0)",
     main="Term GPA vs Average Time Slept",
     pch=19,
     cex=0.5)
abline(lms[[1]])

## ----Results.LM1.Summary------------------------------------------------------
summary(lms[[1]])


## ----Method.3D, fig.width=7.5,fig.height=7.5,fig.align='center', fig.cap="3D Plot Perspectives of the Linear Model with Interaction"----
par(mfrow=c(2,2), mar=c(1,1,1,1))
mcGraph3(df$TotalSleepTime, df$cum_gpa, df$term_gpa,
         interaction=TRUE, phi=15, theta=-45, drawArrows=FALSE)
mcGraph3(df$TotalSleepTime, df$cum_gpa, df$term_gpa,
         interaction=TRUE, phi=20, theta=0, drawArrows=FALSE)
mcGraph3(df$TotalSleepTime, df$cum_gpa, df$term_gpa,
         interaction=TRUE, phi=20, theta=-90, drawArrows=FALSE)
mcGraph3(df$TotalSleepTime, df$cum_gpa, df$term_gpa,
         interaction=TRUE, phi=90, theta=-90, drawArrows=FALSE)


## ----Results.LM2.Summary------------------------------------------------------
summary(lms[[2]])

