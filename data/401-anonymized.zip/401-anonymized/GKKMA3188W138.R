## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(dplyr)
library(tidyverse)


## ---- include = FALSE---------------------------------------------------------
sleep <- read.csv("cmu-sleep-2.csv")


## -----------------------------------------------------------------------------
sleep %>%
  ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 15, aes(y = after_stat(density))) +
  geom_density(col = "red") +
  labs(x = "Average nightly sleep (minutes)", y = "Density",
       title = "Fig. 1: Students' Average Nightly Sleep")


## -----------------------------------------------------------------------------
sleep %>%
  ggplot(aes(x = term_gpa))  +
  geom_histogram(binwidth = 0.1, aes(y = after_stat(density))) +
  geom_density(col = "red") +
  labs(x = "Grade point average for the relevant semester", y = "Density",
       title = "Fig. 2: Students' GPAs During Study Semester")


## -----------------------------------------------------------------------------
sleep %>%
  ggplot(aes(x = (term_gpa)^5))  +
  geom_histogram(bins = 30, aes(y = after_stat(density))) +
  geom_density(col = "red") +
  labs(x = "Grade point average for the relevant semester, to 5th power",
       y = "Density",
       title = "Fig. 3: Students' GPAs During Study Semester, Exp. Adjusted")


## -----------------------------------------------------------------------------
sleep %>%
  ggplot(aes(x = TotalSleepTime, y = term_gpa)) + geom_point() +
  labs(x = "Average nightly sleep (minutes)", y = "GPA for study semester",
       title = "Fig. 4: Student GPA by Avg. Sleep Time")


## -----------------------------------------------------------------------------
sleep %>%
  ggplot(aes(x = TotalSleepTime, y = (term_gpa)^5)) + geom_point() +
  labs(x = "Average nightly sleep (minutes)", 
       y = "GPA for study semester, to 5th power",
       title = "Fig. 5: Student GPA by Avg. Sleep Time")


## -----------------------------------------------------------------------------
sleep.mod <- lm((sleep$term_gpa)^5 ~ sleep$TotalSleepTime)


## ---- warning = FALSE---------------------------------------------------------
sleep %>%
  ggplot(aes(x = TotalSleepTime, y = (term_gpa)^5)) + 
  geom_point(alpha = 0.5) +
  geom_smooth(formula = y ~ x, method = "lm", level = 0.95) +
  labs(x = "Average Nightly Sleep (min)",
       y = "Transformed Term GPA (to fifth power)",
       title = "Fig. 6: Transformed GPA vs. Nightly Sleep \n
       With Regression Line")


## -----------------------------------------------------------------------------
resids <- resid(sleep.mod)
plot(fitted(sleep.mod), resids, xlab = "Average Nightly Sleep (min)", 
     ylab = "Residual of GPA^5", 
     main = "Fig. 7: Residual Plot of Adjusted GPA vs. Avg. Sleep")
abline(0,0)


## -----------------------------------------------------------------------------
sleep.mean <- mean(sleep$TotalSleepTime)
avgGPA <- (coef(sleep.mod)[1] + coef(sleep.mod)[2] * sleep.mean)^0.2
sleepyGPA <- (coef(sleep.mod)[1] + coef(sleep.mod)[2] * (sleep.mean-120))^0.2

