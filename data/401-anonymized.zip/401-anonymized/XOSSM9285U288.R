## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(tidyverse)
library(ggplot2)
library(patchwork)
library(broom)
library(VGAM)
library(GGally)
library(modelsummary)
library(alr4)
library(knitr)


## -----------------------------------------------------------------------------
#eda
data = alr4::Rateprof
head(data)
selected_columns = c("quality","easiness","raterInterest","gender","discipline","pepper")

#categorical
data %>%
    ggplot(aes(x = gender)) +
      geom_bar(fill = "blue", color = "black") +
      labs(title="Bar Chart of Gender")
data %>%
    ggplot(aes(x = discipline)) +
      geom_bar(fill = "blue", color = "black") +
      labs(title="Bar Chart of Discipline")
data %>%
    ggplot(aes(x = pepper)) +
      geom_bar(fill = "blue", color = "black") +
      labs(title="Bar Chart of Pepper")

#quantitative
data %>%
    ggplot(aes(x = quality)) +
      geom_histogram(bins = 30, fill = "blue", color = "black") +
      labs(title="Histogram of Quality")
data %>%
    ggplot(aes(x = easiness)) +
      geom_histogram(bins = 30, fill = "blue", color = "black") +
      labs(title="Histogram of Easiness")
data %>%
    ggplot(aes(x = raterInterest)) +
      geom_histogram(bins = 30, fill = "blue", color = "black") +
      labs(title="Histogram of Rater Interest")



## -----------------------------------------------------------------------------
#quality against: gender, attractiveness, easiness, discipline
data %>%
  ggplot(aes(x = quality, fill = gender)) +
  geom_histogram(position = "identity", alpha = 0.5) +
  labs(title="Histogram of Quality by Gender",x="Quality",y="Count")
data %>%
  ggplot(aes(x = quality, fill = gender)) +
  geom_density(alpha=0.5) + 
  labs(title="Density Plot of Quality by Gender",x="Quality",y="Density")

data %>%
  ggplot(aes(x = quality, fill = pepper)) +
  geom_histogram(position = "identity", alpha = 0.5) +
  labs(title="Histogram of Quality by Pepper",x="Quality",y="Count")
data %>%
  ggplot(aes(x = quality, fill = pepper)) +
  geom_density(alpha=0.5) + 
  labs(title="Density Plot of Quality by Pepper",x="Quality",y="Density")

data %>%
  ggplot(aes(y = quality, x = easiness)) +
  geom_point(color = "blue", size = 2) +
  labs(title="Scatterplot of Quality vs Easiness",y="Quality (1 to 5)",x="Easiness (1 to 5)")

data %>%
  ggplot(aes(x = quality)) +
  geom_histogram(fill = "blue") +
  facet_wrap(~ discipline) +
  ggtitle("Quality Distribution Across Disciplines") +
  xlab("Quality (1 to 5)") +
  ylab("Count")


## ----message=FALSE------------------------------------------------------------
data %>%
  select(quality, gender, pepper, easiness, discipline, clarity, helpfulness, raterInterest) %>%
  ggpairs()

data %>%
  ggplot(aes(y = quality, x = easiness, shape = gender, color = gender)) +
  geom_point(size = 2) +
  labs(
    title = "Scatterplot of Quality vs Easiness",
    y = "Quality (1 to 5)",
    x = "Easiness (1 to 5)",
    caption = "This scatterplot depicts a trend that describes a positive association between easiness and quality.\n Additionally, it looks like it would lend itself well to linear modeling."
  )

data %>%
  ggplot(aes(y = quality, x = easiness, shape = discipline, color = discipline)) +
  geom_point(size = 2) +
  labs(
    title = "Scatterplot of Quality vs Easiness",
    y = "Quality (1 to 5)",
    x = "Easiness (1 to 5)",
    caption = "This scatterplot depicts a trend that describes a positive association between easiness and quality.\n Additionally, it looks like it would lend itself well to linear modeling."
  )


## -----------------------------------------------------------------------------
#Model Selection

#anova(lm1, lm2)
lm3 = lm(quality ~ easiness + pepper + discipline + gender, data=data)
#summary(lm3)

lm7 = lm(quality ~ easiness + pepper + discipline + gender + easiness:discipline + easiness:gender, data=data)
#anova(lm4, lm7)

summary(lm7)
anova(lm3, lm7)

lm11 = lm(quality ~ easiness + pepper + discipline + gender + easiness:discipline + easiness:gender + clarity + helpfulness, data=data)


cookd = cooks.distance(lm7)
cookd[which(cookd==max(cookd))]
#summary(lm11)

## -----------------------------------------------------------------------------

ggplot(augment(lm7), aes(x = data$easiness,y =.resid))+
geom_point() +
labs(title = "Residual versus Easiness Quantitative Values Plot", x = "Easiness", y = "Residual",
     caption = "Very homoskedastic.")

ggplot(augment(lm7), aes(x = data$gender,y =.resid))+
geom_boxplot() +
labs(title = "Residual versus Gender Plot", x = "Gender", y = "Residual",
     caption = "Very homoskedastic.")
ggplot(augment(lm7), aes(x = data$pepper,y =.resid))+
geom_boxplot() +
labs(title = "Residual versus Pepper Plot", x = "Pepper", y = "Residual",
     caption = "Very homoskedastic.")
ggplot(augment(lm7), aes(x = data$discipline,y =.resid))+
geom_boxplot() +
labs(title = "Residual versus Discipline Plot", x = "Discipline", y = "Residual",
     caption = "Very homoskedastic.")


confint(lm7, 'easiness')
confint(lm7, 'pepperyes')


## -----------------------------------------------------------------------------
data %>%
    ggplot(aes(x = quality)) +
      geom_histogram(bins = 30, fill = "blue", color = "black") +
      labs(title="Histogram of Quality", x="Quality (1-5)", y="Count",
           caption="Slightly left-skewed distribution of quality in the data.")
data %>%
    ggplot(aes(x = easiness)) +
      geom_histogram(bins = 30, fill = "blue", color = "black") +
      labs(title="Histogram of Easiness", x="Easiness (1-5)", y="Count",
           caption="Very symmetric and normal-looking distribution.")


## -----------------------------------------------------------------------------
data %>%
  ggplot(aes(x = quality, fill = pepper)) +
  geom_density(alpha=0.5) + 
  labs(title="Density Plot of Quality by Pepper",x="Quality",y="Density",
       caption="Note the stark difference in dsitribution: attractive professors are more left skew\n and highly rated than unattractive professors who are more evenly rated.")


## -----------------------------------------------------------------------------
data %>%
  ggplot(aes(y = quality, x = easiness)) +
  geom_point(color = "blue", size = 2) +
  labs(title="Scatterplot of Quality vs Easiness",y="Quality (1 to 5)",x="Easiness (1 to 5)",
       caption="This scatterplot depicts a trend that describes a positive association between easiness and quality.\n Additionally, it looks like it would lend itself well to linear modeling.")



## -----------------------------------------------------------------------------
ggplot(augment(lm7),
aes(sample =.resid))+
geom_qq() + geom_qq_line() + 
  labs(title = "Normal Q-Q Plot", x = "Theoretical quantiles", y = "Sample quantiles",
       caption = "At both extremes, the sample quantiles are slightly under the line.\n This is suggestive of left-skewed data which we have.")

ggplot(augment(lm7), aes(x = .fitted,y =.resid))+
geom_point() +
labs(title = "Residual versus Fitted Values Plot", x = "Fitted value", y = "Residual",
     caption = "Note a slight amount of heteroskedasticity for the residuals for fitted values above 4.")


## -----------------------------------------------------------------------------
ggplot(augment(lm7), aes(x = data$gender,y =.resid))+
geom_boxplot() +
labs(title = "Residual versus Gender Plot", x = "Gender", y = "Residual",
     caption = "Centered around zero and very homoskedastic.")


## -----------------------------------------------------------------------------
kable(anova(lm3, lm7), format="markdown", caption = "Figure 1")


## -----------------------------------------------------------------------------
modelsummary(list("Model 1" = lm7), fmt = fmt_significant(2),
             gof_map = c("r.squared", "nobs", "rmse"), statistic = c("s.e. = {std.error}", "t = {statistic}", "p = {p.value}"), shape=term ~ model + statistic,
             title = "Figure 2")

