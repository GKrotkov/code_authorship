## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE,
                      fig.align = 'center', 
                      fig.height = 2.5,
                      fig.pos = 'H')


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(gridExtra)
library(modelsummary)
library(alr4)
library(GGally)
library(bestglm)


## ---- fig.cap = "Attractiveness plot"-----------------------------------------
ggplot(aes(x = factor(pepper)), data = Rateprof) + 
  geom_bar(aes(fill = factor(pepper))) + 
  labs(title = "Attractiveness of Professors", x = "Attractiveness", y = "Count", fill = "Attractiveness")


## ----  fig.cap = "Quality hist"-----------------------------------------------
ggplot(aes(x = quality), data = Rateprof) + 
  geom_histogram(bins = 18, fill = "bisque3") + 
  labs(title = "Average Quality of Class", x = "Average Quality", y = "Frequency")


## ----  fig.cap = "Discipline plot"--------------------------------------------
ggplot(aes(x = factor(discipline)), data = Rateprof) + 
  geom_bar(aes(fill = factor(discipline))) + 
  labs(title = "Discipline of Professor", x = "Discipline", y = "Count", fill = "Discipline")


## ---- fig.cap = "Gender plot"-------------------------------------------------
ggplot(aes(x = factor(gender)), data = Rateprof) + 
  geom_bar(aes(fill = factor(gender))) + 
  labs(title = "Gender of Instructors", x = "Gender", y = "Count", fill = "Gender")


## ----  fig.cap = "Easiness hist"----------------------------------------------
ggplot(aes(x = easiness), data = Rateprof) + 
  geom_histogram(bins = 20, fill = "darkseagreen3") + 
  labs(title = "Average Easiness of Class", x = "Average Easiness", y = "Frequency")


## ---- echo = FALSE, fig.cap = "Gender vs Quality"-----------------------------
ggplot(aes(x = factor(gender), y = quality), data = Rateprof) + 
  geom_boxplot(aes(fill = factor(gender))) + 
  labs(title = "Gender vs Quality in Instructors", x =  "Gender", y = "Quality", fill = "Gender")


## ---- echo = FALSE, fig.width = 2.5, fig.cap = "Easiness vs Quality"----------
ggplot(aes(x = easiness, y = quality), data = Rateprof) + 
  geom_point(color = "green") + 
  labs(title = "Average Easiness vs Quality", x = "Easiness", y = "Quality")


## ---- echo = FALSE, fig.height = 2.75,fig.width = 4,fig.cap = "Attractiveness vs Quality"----
ggplot(aes(x = factor(pepper), y = quality), data = Rateprof) + 
  geom_boxplot(fill = "green", 
               outlier.color = "red", outlier.fill = "red") + 
  labs(title = "Prof Attractiveness vs Quality", x =  "Attractiveness", y = "Quality")


## ---- echo = FALSE,fig.cap = "Discipline vs Quality"--------------------------
ggplot(aes(x = factor(discipline), y = quality), data = Rateprof) + 
  geom_boxplot(aes(fill = factor(discipline))) + 
  labs(title = "Prof Discipline vs Quality", x =  "Discipline", y = "Quality", fill = "Discipline")


## ---- include = FALSE---------------------------------------------------------
model = lm(quality ~ easiness*factor(gender)*factor(pepper)*factor(discipline), data = Rateprof)
finalmod = step(model, direction = "both", trace = 0)
summary(finalmod)


## ---- echo = FALSE, fig.width = 5, fig.height = 5, fig.cap = "Residual Plot"----
plot(finalmod, which = 1)


## ---- echo = FALSE, fig.width = 5, fig.height = 5, fig.cap = "QQ Plot"--------
plot(finalmod, which = 2)


## ---- include = FALSE---------------------------------------------------------
full_model = lm(quality ~ easiness*gender*discipline, data = Rateprof)
reduced_model = lm(quality ~ easiness, data = Rateprof)


## ---- echo = FALSE, fig.cap = "Coefficient Estimates"-------------------------
modelsummary(finalmod, statistic = c(
                           "std.error", 
                           "statistic",
                           "p.value"))


## ---- include = FALSE---------------------------------------------------------
anova(full_model, reduced_model)

