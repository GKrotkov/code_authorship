## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(dplyr)
library(ggplot2)
library(GGally)
library(patchwork)
library(kableExtra)
library(broom)
library(alr4)
data = Rateprof %>%
  select(gender, pepper, discipline, quality, easiness)


## -----------------------------------------------------------------------------
# create a table of summary statistics for the important variables
cols = c("Min.", "1st Qu.", "Median", "Mean", "3rd Qu.", "Max.")
rows = c("quality", "easiness")
qual = as.vector(summary(data$quality))
easy = as.vector(summary(data$easiness))
summaries = c(qual, easy)
tab = matrix(data=summaries, ncol=length(qual), byrow=TRUE)
colnames(tab) <- cols
rownames(tab) <- rows
tab <- round(tab, digits=2)
tab %>%
  kbl(booktabs = T,
      caption="Summary statistics of quality and easiness of class") %>%
  kable_classic(full_width=F, html_font="Cambria") %>%
  kable_styling(latex_options = "hold_position")


## ---- fig.height=4.5, fig.width=7, fig.align='center', fig.cap="Histograms and bar graphs of variables of interest."----
# plot individual histograms
par(mfrow=c(2, 3))
hist(data$quality, xlab="rating", main="Histogram of quality")
hist(data$easiness, xlab="rating", main="Histogram of easiness")
barplot(table(data$gender), main="Instructor gender", ylab="count")
barplot(table(data$pepper), main="Instructor attractive?", ylab="count")
barplot(table(data$discipline), main="Instructor discipline", ylab="count")
par(mfrow=c(1, 1))


## ---- message=FALSE, fig.cap="Pairs plots of variables of interest.", fig.height=4.5----
# create a pairs plot
ggpairs(data)


## ---- results=FALSE, echo=FALSE-----------------------------------------------
# fit a linear regression
reg = lm(quality ~ easiness + gender + pepper + discipline, data=data)
summary(reg)


## ---- results=FALSE, echo=FALSE-----------------------------------------------
# fit a linear regression
reg_red = lm(quality ~ easiness + gender + pepper + discipline, data=data)
reg_full = lm(quality ~ easiness*gender + pepper + easiness*discipline, data=data)
summary(reg_full)


## ---- fig.cap="Residuals plots of the variables of interest."-----------------
# create residual plots
p1 = ggplot(data=data, aes(x=easiness, y=reg$residuals)) +
  geom_point() +
  labs(x="Easiness", y="Residuals") +
  geom_hline(yintercept=0, color="red") +
  labs(title="residuals vs. easiness")
p2 = ggplot(data=data, aes(x=gender, y=reg$residuals)) +
  geom_boxplot() +
  labs(x="Gender", y="Residuals") +
  geom_hline(yintercept=0, color="red") +
  labs(title="residuals vs. gender")
p3 = ggplot(data=data, aes(x=pepper, y=reg$residuals)) +
  geom_boxplot() +
  labs(x="Pepper", y="Residuals") +
  geom_hline(yintercept=0, color="red") +
  labs(title="residuals vs. pepper")
p4 = ggplot(data=data, aes(x=discipline, y=reg$residuals)) +
  geom_boxplot() +
  labs(x="Discipline", y="Residuals") +
  geom_hline(yintercept=0, color="red") +
  labs(title="residuals vs. discipline")
p1 + p2 + p3 + p4 + plot_layout(ncol=2)


## ---- fig.cap="Residuals from the linear model, plotted against the fitted values. Homoskedasticity is violated. Zero conditional mean assumption holds.", fig.width=4, fig.height=3.5----
# residuals vs fitted
plot(reg, which=1, cex=0.75)


## ---- fig.cap="Q-Q plot. The normality assumption appears to hold.", fig.width=4, fig.height=3----
# create a Q-Q plot
ggplot(augment(reg), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles", title="Q-Q Plot")


## -----------------------------------------------------------------------------
# create table of linear regression output, along with CIs.
summary_table = tidy(reg)
summary_table <- cbind(summary_table, confint(reg)[, 1:2])
summary_table <- summary_table[, -1]
summary_table <- round(summary_table, digits=6)
colnames(summary_table)[c(3, 5, 6)] = c("t-statistic", "CI.Lower", "CI.Upper")
summary_table %>%
  kbl(booktabs = T,
      caption="Summary of linear regression") %>%
  kable_classic(full_width=F, html_font="Cambria") %>%
  kable_styling(latex_options = "hold_position")


## -----------------------------------------------------------------------------
# ANOVA test
anov = anova(reg_red, reg_full)
anov_tab = data.frame(Res.Df=anov$Res.Df, 
                      RSS=anov$RSS, 
                      DF=anov$Df, 
                      `Sum of Sq` =anov$`Sum of Sq`, 
                      F=anov$F, 
                      "Pr(>F)"=anov$`Pr(>F)`)
colnames(anov_tab)[6] = "Pr(>F)"
anov_tab %>%
  round(digits=6) %>%
  kbl(booktabs = T,
      caption="ANOVA Table") %>%
  kable_classic(full_width=F, html_font="Cambria") %>%
  kable_styling(latex_options = "hold_position")

