## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----



## ----table-simple, echo=FALSE, message=FALSE, warnings=FALSE, results='asis'----
require(pander)
panderOptions('table.split.table', Inf)
set.caption("Description of Relevant Variables")
my.data <- " 
Variable      | Description
 gender        | Gender of the instructor (factor with levels of female and male) 
 pepper        | Whether instructor seen as attractive. Students gave rating of yes or no and pepper represents the consesus (factor with levels yes and no)      
 discipline    | The discipline of the course (factor with levels for humanities, social sciences, stem, and professional training/pre-prof)      
 quality       | Average rating of the quality of the instructor (values between 1, worst, and 5, the best)      
 easiness      | Average rating of the easiness of the instructor's course (values between 1, worst, and 5, the best) 
 helpfulness      | Average rating of the helpfulness of the instructor's course (values between 1, worst, and 5, the best)      
 clarity      | Average rating of the clarity of the instructor's course (values between 1, worst, and 5, the best)      

"

df <- read.delim(textConnection(my.data),header=FALSE,sep="|",strip.white=TRUE,stringsAsFactors=FALSE)
names(df) <- unname(as.list(df[1,])) # put headers on
df <- df[-1,] # remove first row
row.names(df)<-NULL
pander(df, style = 'rmarkdown')


## ----include=FALSE------------------------------------------------------------
library(alr4)
library(patchwork)
data <- Rateprof
data$gender <- factor(data$gender)
data$pepper <- factor(data$pepper)
data$discipline <- factor(data$discipline)

df = data
table(df$discipline)
table(df$pepper)
table(df$gender)
median(df$quality)
median(df$easiness)


## ---- echo=FALSE, message=FALSE,figures-side, fig.show="hold", out.width="50%",warnings=FALSE,fig.cap="Distributions of Instructor's average quality, easiness,helpfulness, and clarity ratings.  All plots are roughly bell-shaped."----
library(alr4)
library(patchwork)
data <- Rateprof
data$gender <- factor(data$gender)
data$pepper <- factor(data$pepper)

library(ggplot2)
e1 <- ggplot(data, aes(x = easiness)) + 
	geom_histogram(binwidth = 1) + 
	labs(x = "Average Easiness Rating", y = "Frequency", title ="Average Easiness Ratings For Instructors")
e2 <- ggplot(data, aes(x = easiness)) + 
	geom_histogram(binwidth = 1) + 
  facet_wrap(vars(gender), scales = "free") +
	labs (x = "Average Easiness Rating")
q1 <- ggplot(data, aes(x = quality)) + 
	geom_histogram(binwidth = 1) + 
	labs(x = "Average Quality Rating", y = "Frequency", title ="Average Quality Ratings For Instructors")
q2 <- ggplot(data, aes(x = quality)) + 
	geom_histogram(binwidth = 1) + 
  facet_wrap(vars(gender), scales = "free") +
	labs (x = "Average Quality Rating")
h1 <- ggplot(data, aes(x = helpfulness)) + 
	geom_histogram(binwidth = 1) + 
	labs (x = "Average Helpfulness Rating", y = "Frequency", title ="Average Helpfulness Ratings For Instructors")

c1 <- ggplot(data, aes(x = clarity)) + 
	geom_histogram(binwidth = 1) + 
	labs (x = "Average Clarity Rating", y = "Frequency", title ="Average Clarity Ratings For Instructors")


q3 <- ggplot(data, aes(x = quality)) + 
	geom_histogram(binwidth = 1) + 
  facet_wrap(vars(pepper), scales = "free") +
	labs (x = "Average Quality Rating")
e3 <- ggplot(data, aes(x = easiness)) + 
	geom_histogram(binwidth = 1) + 
  facet_wrap(vars(pepper), scales = "free") +
	labs (x = "Average Easiness Rating")
q4<- ggplot(data, aes(x = quality)) + 
	geom_histogram(binwidth = 1) + 
  facet_wrap(vars(discipline), scales = "free") +
	labs (x = "Average Quality Rating")
e4 <- ggplot(data, aes(x = easiness)) + 
	geom_histogram(binwidth = 1) + 
  facet_wrap(vars(discipline), scales = "free") +
	labs (x = "Average Easiness Rating")

q1 
e1
h1
c1


## ----echo=FALSE, fig.cap="Distribution of Instructor's Average Quality Rating for Gender, Pepper, and Discipline variables. Plots revealed large difference in quality rating based upon assessment of attractiveness, but fairly consistent quality ratings across gender and discipline.", message=FALSE, warnings=FALSE,fig.width=7, fig.height=3----


library(ggplot2)
b1 <- ggplot(data, aes(x = discipline,y=quality)) + 
	geom_boxplot() + 
	labs (x = "Instructor Discipline", y = "Average Quality Rating")
b2 <- ggplot(data, aes(x = pepper, y=quality)) + 
	geom_boxplot() + 
	labs (x = "Instructor Attractive?", y = "Average Quality Rating")
b3 <- ggplot(data, aes(x = gender, y = quality)) + 
	geom_boxplot() + 
	labs (x = "Instructor Gender", y = "Average Quality Rating")
b1 | b2 | b3



## ----echo=FALSE, fig.cap="Relationship between easiness and quality ratings seems to be linear.  Additionally it seems attractiveness affects such a relationship", fig.show="hold", message=FALSE, out.width="55%", warnings=FALSE,error=FALSE,results='hide',fig.keep='all'----
s1 <- ggplot(data, aes(x = easiness, y = quality,color=pepper)) + 
	geom_point() +geom_smooth(method = "lm", linetype="solid", formula = y ~ x,se=FALSE ) 
	labs (x = "Average Easiness Rating", y = "Average Quality Rating",color="pepper")
	
s2 <- ggplot(data, aes(x = easiness, y = quality,color=gender)) + 
	geom_point() + geom_smooth(method = "lm", linetype="solid", formula = y ~ x ,se=FALSE) 
	labs (x = "Average Easiness Rating", y = "Average Quality Rating",color="gender")
s3 <- ggplot(data, aes(x = easiness, y = quality,color=discipline)) + 
	geom_point() + geom_smooth(method = "lm", linetype="solid", formula = y ~ x ,se=FALSE) 
	labs (x = "Average Easiness Rating", y = "Average Quality Rating",color="discipline")
s4 <- ggplot(data, aes(x = pepper, y = quality,)) + 
	geom_point() + 
	labs (x = "Average Pepper Rating", y = "Average Quality Rating")
s5 <- ggplot(data, aes(x = gender, y = quality,color=pepper)) + 
	geom_point() + 
	labs (x = "Average Pepper Rating", y = "Average Quality Rating", color="pepper")

s1
s2
s3

## ----echo=FALSE, fig.cap="Paired Plots which provide indication that quality rating is strongly linearly correlated with both helpfulness and clarity ratings", fig.show="hold", message=FALSE, out.width="55%", warnings=FALSE,error=FALSE,results='hide',fig.keep='all'----
library(GGally)
library(dplyr)
ggpairs(data,columns=c("quality", "helpfulness", "clarity", "easiness", "numYears","numRaters","numCourses"))


## ---- echo=FALSE, message=FALSE,fig.cap="Distance"----------------------------
fit <- lm(quality ~ factor(gender) + clarity+ factor(pepper) + factor(discipline) + easiness+helpfulness, data=data)
fit_easiness_pepper_int <- lm(quality ~  factor(gender) + clarity+factor(gender):clarity+ factor(pepper) + factor(discipline) + easiness+helpfulness, data=data)
lm.fit2=lm(quality ~ (factor(gender) + factor(pepper) + factor(discipline) + easiness+helpfulness+clarity)^2,data=data)
anova(fit, fit_easiness_pepper_int)
anova(lm.fit2)



## ---- echo=FALSE, message=FALSE,fig.cap="Distance"----------------------------
fit_pepper <- lm(quality ~ factor(gender) + factor(discipline) + easiness*factor(pepper), data=data)
summary(fit)
plot(c(1,5), c(1,5), xlab = "x", ylab = "y", asp = 1)
abline(fit, lwd = 2, col = 2)
library(broom)
head(augment(fit))
qqnorm(residuals(fit))
qqline(residuals(fit))
ggplot(augment(fit_pepper), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles")
ggplot(augment(fit), aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted value", y = "Residual")
ggplot(augment(fit), aes(x = easiness, y = .resid)) +
  geom_point() +
  labs(x = "Average Easiness Rating", y = "Residual")

ggplot(augment(fit), aes(x = .fitted, y = .cooksd)) +
  geom_point() +
  labs(x = "Fitted Value", y = "Cook's distance")

