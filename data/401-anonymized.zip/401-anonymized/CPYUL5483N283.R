## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
cmu_sleep = read.csv("cmu-sleep.csv")


## ---- fig.width=5, fig.height=4, fig.cap="Figure 1: Average time slept per night by students is distributed close to normally."----
hist(cmu_sleep$TotalSleepTime,
     main = "Average Time Slept per Night",
     xlab = "Minutes")


## ---- results = 'hide'--------------------------------------------------------
mean(cmu_sleep$TotalSleepTime)
sd(cmu_sleep$TotalSleepTime)
max(cmu_sleep$TotalSleepTime)
max(cmu_sleep$TotalSleepTime) / 60
min(cmu_sleep$TotalSleepTime)
min(cmu_sleep$TotalSleepTime) / 60


## ---- fig.width=5, fig.height=4, fig.cap="Figure 2: Students' current semester GPA has a clear left skew."----
hist(cmu_sleep$term_gpa,
     main = "Current Semester GPA",
     xlab = "On a scale of 0 to 4.0 units")


## ---- results = 'hide'--------------------------------------------------------
mean(cmu_sleep$term_gpa)
sd(cmu_sleep$term_gpa)


## ---- results = 'hide'--------------------------------------------------------
max(cmu_sleep$term_gpa)


## ---- results = 'hide'--------------------------------------------------------
term_gpa_shifted = 5.1 - cmu_sleep$term_gpa
cmu_sleep$term_gpa_log = log(term_gpa_shifted)


## ---- fig.width=5, fig.height=4, fig.cap="Figure 3: Students' transformed current semester GPA is more symmetric."----
hist(cmu_sleep$term_gpa_log,
     main = "Current Semester log(5.1 - GPA)",
     xlab = "On a scale of 0.095 to 1.63 log(units)")


## ---- results = 'hide'--------------------------------------------------------
mean(cmu_sleep$term_gpa_log)
sd(cmu_sleep$term_gpa_log)
max(cmu_sleep$term_gpa_log)
log(1.1)
log(5.1)


## ---- fig.width=5, fig.height=4, fig.cap="Figure 4: Students' cumulative GPA also has a left skew."----
hist(cmu_sleep$cum_gpa,
     main = "Cumulative GPA",
     xlab = "On a scale of 0 to 4.0 units")


## ---- results = 'hide'--------------------------------------------------------
mean(cmu_sleep$cum_gpa)
sd(cmu_sleep$cum_gpa)


## ---- fig.width=5, fig.height=4, fig.cap="Figure 5: Students' sleep per night appears to be correlated with their current semester GPA."----
plot(term_gpa_log ~ TotalSleepTime,
     data = cmu_sleep,
     main = "Average Time Slept per Night vs. Current Semester log(5.1 - GPA)",
     xlab = "Average time slept per night (minutes)",
     ylab = "Current semester log(5.1 - GPA) (log(units))")


## ---- fig.width=5, fig.height=4, fig.cap="Figure 6: Students' cumulative GPA also appears to be correlated with their current semester GPA."----
plot(term_gpa ~ cum_gpa,
     data = cmu_sleep,
     main = "Cumulative GPA vs. Current Semester GPA",
     xlab = "Cumulative GPA (units)",
     ylab = "Current semester GPA (units)")


## ---- results = 'hide'--------------------------------------------------------
sleep_lm = lm(term_gpa_log ~ TotalSleepTime,
              data = cmu_sleep)
summary(sleep_lm)


## ---- results = 'hide'--------------------------------------------------------
max(cmu_sleep$term_gpa)


## ---- results = 'hide'--------------------------------------------------------
term_gpa_shifted = 5.1 - cmu_sleep$term_gpa
cmu_sleep$term_gpa_log = log(term_gpa_shifted)


## ---- fig.width=5, fig.height=4, fig.cap="Figure 7: Independence, mean zero, and homoskedasticity assumptions are met when the predictor is average time slept per night."----
plot(sleep_lm,
     which = 1)


## ---- fig.width=5, fig.height=4, fig.cap="Figure 8: Normality assumption is met when the predictor is average time slept per night."----
plot(sleep_lm,
     which = 2)


## ---- results = 'hide'--------------------------------------------------------
summary(sleep_lm)


## ---- results = 'hide'--------------------------------------------------------
(coef(sleep_lm)[2] * -120)
(coef(sleep_lm)[2] * -120) + 0.0002058*(1.96)
(coef(sleep_lm)[2] * -120) - 0.0002058*(1.96)

