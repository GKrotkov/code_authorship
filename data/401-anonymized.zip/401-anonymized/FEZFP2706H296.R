## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
options(warn = -1)

# load in dataset
library(alr4)
data = Rateprof


## -----------------------------------------------------------------------------
#helper functions to create plots - reused from my HW6 submission
createHistogram = function(data, col_name) {
  hist(data[[col_name]], main = paste("Histogram of", col_name), xlab = col_name, ylab = "Frequency", col = "skyblue", border = "black")  
}

createBarPlot = function(data, col_name) {
  barplot(table(as.factor(data[[col_name]])), main = paste("Bar Plot of", col_name), xlab = col_name, ylab = "Frequency", col = "skyblue", border = "black", las=2)  
}

createBoxPlot = function(data, col_name) {
  boxplot(data[[col_name]], main = paste("Boxplot of", col_name))
}

resetLayout = function() {
  par(mfrow = c(1,1))
  }


## ---- fig.cap='Plots of distributions of predictor and response variables. Quality is fairly uniformly distributed from 3-5, with a tail from 1-3. Easiness appears almost perfectly normally distributed. A bit more than half of the instructors are male. The vast majority of professors are not considered to be attractive. And most instructors teach Humanities courses, but all disciplines are well-represented.'----
# allow plots to be displayed in a grid pattern
par(mfrow = c(2, 3))

createHistogram(data, "quality")
createHistogram(data, "easiness")
createBarPlot(data, "gender")
createBarPlot(data, "pepper")
createBarPlot(data, "discipline")

resetLayout()


## ---- fig.cap='Relationship between quality and easiness, along with residual plot. Easiness and quality are share a statistically significant positive correlation (p-value < 2.2e-16), which means that as classes get easier, quality score tends to increase. The residual plot also shows that the residuals are heteroskedastic, meaning that the normality assumptions of regression are satisfied.'----
# model of quality vs easiness
model = lm(quality ~ easiness, data = data)

# par(mfrow=c(1,2))

# scatterplot with line of best fit
plot(data$easiness, data$quality, main = "Scatterplot of Easiness vs. Quality", 
     xlab = "Easiness", ylab = "Quality")
abline(model, col = "red", lwd=2)



# add correlation to plot
correlation_test = cor.test(data$easiness, data$quality)
correlation = correlation_test$estimate
text(x = max(data$easiness)-0.4, y = min(data$quality)+0.2, 
     labels = paste("r =", round(correlation, 3)), col = "red")

# testing statistical significance of correlation
# correlation_test


## ---- message=FALSE, fig.cap = 'Pairs plot showing relationship between all variables. Most variables are not related. However, attractiveness does appear to be related to quality and easiness.'----
library(GGally)
library(dplyr)

suppressWarnings(
data |>
  dplyr::select(quality, easiness, gender, discipline, pepper) |>
  ggpairs(verbose=FALSE)
)
# t_test_result = t.test(quality ~ pepper, data=data)
# t_test_result
# 
# t_test_result2 = t.test(easiness ~ pepper, data=data)
# t_test_result2



## -----------------------------------------------------------------------------
suppressMessages(library(bestglm))

full_model = lm(quality ~ easiness*factor(pepper)*factor(discipline)*factor(gender), data=data)
# summary(full_model)

# print("------------------------------------")
# cat("AIC before bestglm():", extractAIC(full_model), "\n")


matrix = model.matrix(full_model, data=data)[,-1]
df = as.data.frame(matrix)
df$quality = data$quality
final_model_aic = bestglm(df, IC = "AIC")$BestModel
final_model_loocv = bestglm(df, IC = "LOOCV")$BestModel
# final_model = step(full_model, IC="AIC", direction="both")
# cat("AIC after bestglm():", extractAIC(final_model_aic), "\n")
# cat("AIC after bestglm():", extractAIC(final_model_loocv), "\n")

# print("------------------------------------")
# summary(final_model_aic)
# summary(final_model_loocv)


## -----------------------------------------------------------------------------
model2 = lm(quality ~ easiness + easiness:(factor(discipline) + factor(gender)), data=data)
# summary(model2)


## -----------------------------------------------------------------------------
# residuals
residuals = residuals(model)
predicted_values = predict(model)
plot(predicted_values, residuals, main = "Residual Plot", xlab = "Predicted Values", ylab = "Residuals")
abline(h = 0, col = "red", lty = 2, lwd=2)


## -----------------------------------------------------------------------------
# summary(final_model_aic)
# confint(final_model_aic)
# confint(final_model_loocv)
# confint(model2)

