## ----setup, include = FALSE---------------------------------------------------

knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(tidyverse)
library(gridExtra)
library(broom)


## ----message=TRUE, warning=TRUE-----------------------------------------------

q1 = Rateprof %>%
  ggplot(aes(x = gender)) +
  geom_bar() +
  labs(title = 'Distribution of Gender', x = 'Gender', y = 'Count')

q2 = Rateprof %>%
  ggplot(aes(x = pepper)) +
  geom_bar() +
  labs(title = 'Distribution of Attractiveness', x = 'Pepper', y = 'Count')

q3 = Rateprof %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(bins = 20) +
  labs(title = 'Distribution of Easiness', x = 'Easiness', y = 'Count')

q4 = Rateprof %>%
  ggplot(aes(x = discipline)) +
  geom_bar() +
  labs(title = 'Distribution of Discipline', x = 'Discipline', y = 'Count')

grid.arrange(q1, q2, q3, q4, ncol=2, nrow=2)


## ---- message=TRUE, warning=TRUE, paged.print=TRUE----------------------------

p1 = Rateprof %>%
  ggplot(aes(x = easiness, y = quality)) +
  geom_point() + 
  labs(title = "Quality Ratings by Easiness", x = "Easiness", y = "Quality Rating")
  
p2 = Rateprof %>%
  ggplot(aes(x = gender, y = quality)) +
  geom_boxplot() + 
  labs(title = "Quality Ratings by Gender", x = "Gender", y = "Quality Rating")

p3 = Rateprof %>%
  ggplot(aes(x = pepper, y = quality)) +
  geom_boxplot() + 
  labs(title = "Quality Ratings by Attractiveness", x = "Pepper", y = "Quality Rating")

p4 = Rateprof %>%
  ggplot(aes(x = discipline, y = quality)) +
  geom_boxplot() + 
  labs(title = "Quality Ratings by Discipline", x = "Discipline", y = "Quality Rating")

grid.arrange(p1, p2, p3, p4, ncol=2, nrow=2)


## -----------------------------------------------------------------------------

reduced_model <- lm(quality ~ gender + pepper + easiness + discipline, data=Rateprof)


## -----------------------------------------------------------------------------

par(mfrow=c(2,2))

plot(reduced_model)


## ---- fig.width=5, fig.height=3, fig.align='center'---------------------------

par(mfrow=c(1,1))

cooks_distance <- cooks.distance(reduced_model)

plot(cooks_distance, ylab="Cook's distance", type="h")


## -----------------------------------------------------------------------------

vif(reduced_model)


## -----------------------------------------------------------------------------

tidy(reduced_model) |>
  knitr::kable(booktabs = TRUE,
  col.names = c("Term", "Estimate", "SE", "t", "p"))


## -----------------------------------------------------------------------------

full_model_1 <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness, data=Rateprof)

full_model_2 <- lm(quality ~ gender + pepper + easiness + discipline + discipline:easiness, data=Rateprof)


## -----------------------------------------------------------------------------

knitr::kable(anova(reduced_model, full_model_1), caption = "Easiness:Gender Partial F-Test")

knitr::kable(anova(reduced_model, full_model_2), caption = "Easiness:Discipline Partial F-Test")

