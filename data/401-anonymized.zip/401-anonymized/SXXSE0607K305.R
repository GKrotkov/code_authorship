## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(readr)
library(dplyr)
library(tidyr)
library(broom)

data <- read_csv("cmu-sleep.csv")
#glimpse(data)

summary_stats <- data %>% 
  summarise(
    min_sleep = min(TotalSleepTime, na.rm = TRUE),
    max_sleep = max(TotalSleepTime, na.rm = TRUE),
    mean_sleep = mean(TotalSleepTime, na.rm = TRUE),
    min_gpa = min(term_gpa, na.rm = TRUE),
    max_gpa = max(term_gpa, na.rm = TRUE),
    mean_gpa = mean(term_gpa, na.rm = TRUE),
  )


## ----include = FALSE----------------------------------------------------------
print(paste("Sleep Duration - Min:", round(summary_stats$min_sleep,1), "Max:", round(summary_stats$max_sleep,1), "Mean:", round(summary_stats$mean_sleep,1)))
print(paste("Term GPA - Min:", round(summary_stats$min_gpa,2), "Max:", round(summary_stats$max_gpa,2), "Mean:", round(summary_stats$mean_gpa,1)))



## ----fig.width=4, fig.height=4------------------------------------------------

# Plotting the distributions of key variables
ggplot(data, aes(x = TotalSleepTime)) + 
  geom_histogram(binwidth = 30, fill = "blue", color = "black") +
  labs(title = "Distribution of Total Sleep Time", x = "Total Sleep Time (minutes)", y = "Count of Students") +
  theme_minimal()


## ----fig.width=4, fig.height=4------------------------------------------------

ggplot(data, aes(x = term_gpa)) + 
  geom_histogram(binwidth = 0.1, fill = "green", color = "black") +
  labs(title = "Distribution of Term GPA", x = "Term GPA", y = "Count of Students") +
  theme_minimal()


## ----fig.width=4, fig.height=4------------------------------------------------

ggplot(data, aes(x = cum_gpa)) + 
  geom_histogram(binwidth = 0.1, fill = "yellow", color = "black") +
  labs(title = "Distribution of Cumulative GPA", x = "Cumulative GPA", y = "Count of Students") +
  theme_minimal()



## ---- fig.width=4, fig.height=3, fig.cap="Relationship between Sleep Time and Term GPA."----
ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  geom_smooth(method = 'lm', formula = y ~ x, se = FALSE)
  labs(title = 'Relationship between Sleep Time and Term GPA',
       x = 'Total Sleep Time (minutes)',
       y = 'Term GPA') +
  theme_minimal()


## -----------------------------------------------------------------------------

model <- lm(term_gpa ~ TotalSleepTime, data = data)

coefficients <- coef(model)

intercept <- coefficients[1]
slope <- coefficients[2]
cat("Intercept (Expected GPA when sleep time is 0):", round(intercept, 3), "\n")
cat("Slope (Change in GPA for each additional minute of sleep):", round(slope, 3), "\n")

cat("\nInterpretation:\n")
cat("If a student had 0 minutes of sleep (a theoretical scenario), their 
    predicted GPA would be approximately", round(intercept, 3), ".\n")
cat("For every additional minute of sleep a student gets, their GPA is expected 
    to increase by approximately", round(slope, 4), "points. This means that 
    for every additional hour of sleep a student gets, their GPA is expected to 
    increase by", round(slope*60, 3), "points\n")


## -----------------------------------------------------------------------------
residuals_df <- data.frame(fitted = model$fitted.values, residuals = model$residuals)
ggplot(data = residuals_df, aes(x = fitted, y = residuals)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(title = "Residuals vs Fitted", x = "Fitted values", y = "Residuals") +
  theme_minimal()



## -----------------------------------------------------------------------------
qqnorm(model$residuals, main = "Q-Q Plot of Residuals")
qqline(model$residuals)


## ---- include = FALSE---------------------------------------------------------
summary_info <- summary(model)

sleep_coef <- summary_info$coefficients["TotalSleepTime", "Estimate"]
sleep_std_error <- summary_info$coefficients["TotalSleepTime", "Std. Error"]
sleep_t_value <- summary_info$coefficients["TotalSleepTime", "t value"]

ci_lower <- sleep_coef - (2.06 * sleep_std_error) 
ci_upper <- sleep_coef + (2.06 * sleep_std_error)

p_value <- summary_info$coefficients["TotalSleepTime", "Pr(>|t|)"]

cat("The 95% confidence interval for the sleep coefficient is [", ci_lower, ", ", ci_upper, "].\n")
cat("The p-value for the significance of the sleep coefficient is ", p_value, ".\n")


