## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
plot(dist ~ speed, data = cars,
     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## -----------------------------------------------------------------------------
library(alr4)
?Rateprof


## -----------------------------------------------------------------------------
summary(Rateprof[,c(1,5,6,8,11)])


## -----------------------------------------------------------------------------
par(mfrow = c(2,2))
barplot(table(Rateprof$gender), xlab = "gender", ylab = "count", col = "blue")
barplot(table(Rateprof$pepper), xlab = "attractiveness", ylab = "count", col = "red")
barplot(table(Rateprof$discipline), xlab = "discipline", ylab = "count", col = "green")


## -----------------------------------------------------------------------------
par(mfrow = c(2,2))
hist(Rateprof$quality, xlab = "quality", ylab = "count")
hist(Rateprof$easiness, xlab = "easiness", ylab = "count")


## -----------------------------------------------------------------------------
par(mfrow = c(1,2))
boxplot(quality ~ gender, data = Rateprof, xlab = "gender", ylab = "quality (rating between 1 to 5)")
boxplot(quality ~ pepper, data = Rateprof, xlab = "attractiveness", ylab = "quality (rating between 1 to 5)")
boxplot(quality ~ discipline, data = Rateprof, xlab = "discipline", ylab = "quality (rating between 1 to 5)")
plot(Rateprof$easiness,Rateprof$quality, xlab = "easiness (rating between 1 to 5)", ylab = "quality (rating between 1 to 5)", col = "black", pch = 20)


## -----------------------------------------------------------------------------
pairs(quality ~ gender + pepper + discipline + easiness, data = Rateprof)


## -----------------------------------------------------------------------------
model = lm(quality ~ easiness + factor(gender) + factor(discipline) + easiness:gender + easiness: discipline, data = Rateprof)
summary(model)


## -----------------------------------------------------------------------------
library(ggplot2)
library(broom)


## -----------------------------------------------------------------------------

plot(fitted(model), residuals(model),
     main = "Residual Vs Fitted Plot",
     xlab = "fitted",
     ylab = "residuals",
     col = "black",
     pch = 20)
abline(h=0, col = "red")
panel.smooth(fitted(model), residuals(model), col.smooth = "blue")

ggplot(augment(model), aes(x = .fitted, y = .cooksd)) +
  ggtitle("Cook's Distance") + 
  geom_point() +
  labs(x = "Fitted Value", y = "Cook's distance")

plot(Rateprof[,11], model$residuals,
     main = "Residual Plot of easiness", 
     xlab = colnames(Rateprof)[11],
     ylab = "residuals",
     col = "black",
     pch = 20)
abline(h=0, col = "red")

boxplot(model$residuals ~ Rateprof[,1], 
        main = "Residual Plot of gender",
        xlab = colnames(Rateprof)[1],
        ylab = "residuals")

boxplot(model$residuals ~ Rateprof[,6], 
        main = "Residual Plot of discipline",
        xlab = colnames(Rateprof)[6],
        ylab = "residuals")

qqnorm(model$residuals)
qqline(model$residuals)


## -----------------------------------------------------------------------------
fullmodel <- lm(quality ~ easiness + factor(gender) + factor(discipline) + easiness:gender + easiness: discipline, data = Rateprof)

reducedmodel <- lm(quality ~ easiness + factor(gender) + factor(discipline),  
                   data = Rateprof)

anova(reducedmodel, fullmodel)


## -----------------------------------------------------------------------------
library(bestglm)


## -----------------------------------------------------------------------------
fullmod = lm(quality ~ easiness + gender + discipline + easiness:gender + easiness:discipline, data = Rateprof, x = T)

str(Rateprof)

temp = data.frame(cbind(fullmod$x[,-1],Rateprof$quality))

temp$quality <- Rateprof$quality

bestloocv = bestglm(temp, IC="LOOCV")
bestloocv

