## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(tidyverse)


## -----------------------------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")
#names(sleep)


## ---- fig.cap="Distribution of the sleep time variable.", fig.width=5, fig.height=4----
#I wrote this function, but for another class I am currently taking which is 36315
getFDBinwidth <- function(x) {
  # the IQR is
	IQR(x)
	# number of observations
	n <- length(x)
	# thus, the binwidth is
	h <- 2 * IQR(x) / n^(1/3)
	return(h)
}

ggplot(data = sleep, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = getFDBinwidth(sleep$TotalSleepTime), fill = "darkred") +
  xlab("Total Sleep Time (in hours)") +
  ylab("Count") +
  labs(title = "Distribution of Total Sleep Time")


## ---- fig.cap="Distribution of Term GPA's from term of study.", fig.width=5, fig.height=4----
ggplot(data = sleep, aes(x = term_gpa)) +
  geom_histogram(binwidth = getFDBinwidth(sleep$term_gpa), fill = "red") +
  xlab("Current term GPA") +
  ylab("Count") +
  labs(title = "Distribution of Total Sleep Time")


## ---- fig.cap= "Cumulative GPA distribution prior to term of study.", fig.width=5, fig.height=4----
ggplot(data = sleep, aes(x = cum_gpa)) +
  geom_histogram(binwidth = getFDBinwidth(sleep$cum_gpa), fill = "black") +
  xlab("Cumulative GPA") +
  ylab("Count") +
  labs(title = "Distribution of Total Sleep Time")


## ---- fig.cap="Sleep time compared with GPA.", fig.width=7, fig.height=4------
ggplot(data = sleep, aes(x = TotalSleepTime)) +
  geom_point(aes(y = term_gpa, color = "term gpa")) +
  geom_point(aes(y = cum_gpa, color = "cumulative gpa")) +
  scale_color_manual(values = c("term gpa" = "red", "cumulative gpa" = "black")) +
  xlab("Total Sleep Time (in hours)") +
  ylab("Grade Point Average") +
  labs(title = "Sleep Time vs GPA")


## ---- fig.cap="Sleep time compared with Term GPA, fit with a linear regression line.", fig.width=7, fig.height=4----
ggplot(data = sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(color = "red") +
  geom_smooth(method = "lm") +
  xlab("Total Sleep Time (in hours)") +
  ylab("Grade Point Average") +
  labs(title = "Sleep Time vs Term GPA")

term_mod <- lm(term_gpa ~ TotalSleepTime, data = sleep)
#summary(term_mod)
#confint(term_mod)


## ---- fig.cap="Sleep time compared with Cumulative GPA, fit with a linear regression line.", fig.width=7, fig.height=4----
ggplot(data = sleep, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point(color = "black") +
  geom_smooth(method = "lm") +
  xlab("Total Sleep Time (in hours)") +
  ylab("Grade Point Average") +
  labs(title = "Sleep Time vs Cumulative GPA")

cum_mod <- lm(cum_gpa ~ TotalSleepTime, data = sleep)
#summary(cum_mod)
#confint(cum_mod)


## ---- fig.cap="Residuals of linear model of Sleep time compared with Term GPA.", fig.width=7, fig.height=4----
ggplot(data = sleep, aes(x = TotalSleepTime, y = residuals(term_mod))) +
  geom_point(color = "red") +
  geom_line(aes(y = 0))


## ---- fig.cap="Residuals of linear model of Sleep time compared with Cumulative GPA.", fig.width=7, fig.height=4----
ggplot(data = sleep, aes(x = TotalSleepTime, y = residuals(cum_mod))) +
  geom_point() +
  geom_line(aes(y = 0))

