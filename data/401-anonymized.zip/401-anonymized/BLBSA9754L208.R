## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(dplyr)
library(alr4)
library(ggplot2)
library (dplyr)
library (GGally)
data(Rateprof)


## ---- fig.width=5, fig.height=3, fig.cap="Histogram of Average Course Ratings"----
Rateprof %>%
ggplot(aes(x= quality)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Average Course Ratings (on a scale from 1-5)", y = "Frequency")


## -----------------------------------------------------------------------------
summary(Rateprof$quality)


## ---- fig.width=5, fig.height=3, fig.cap="Histogram of Average Easiness Rating"----
Rateprof %>%
ggplot(aes(x= easiness)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Average Easiness Rating (on a scale from 1-5)", y = "Frequency")


## ---- fig.width=5, fig.height=3, fig.cap="Bar Plot of Gender"-----------------
ggplot(Rateprof, aes(x = gender)) +
  geom_bar(color = "black", fill = "lightblue") +
  labs(title = "Frequency of gender", x = "Gender", y = "Frequency")


## ---- fig.width=5, fig.height=3, fig.cap="Histogram of Average Easiness Rating"----
ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(color = "black", fill = "lightblue") +
  labs(title = "Frequency of Attractiveness", x = "Voted as Attractive", y = "Frequency")


## ---- fig.width=5, fig.height=3, fig.cap="Bar Plot of Gender"-----------------
ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(color = "black", fill = "lightblue") +
  labs(title = "Frequency of the different disciplines", x = "discipline", y = "Frequency")


## ---- fig.width=5, fig.height=3, fig.cap="Boxplot of Gender vs Average Quality"----
boxplot(quality~gender,data=Rateprof, main="Boxplot of Gender vs Average Quality",
   xlab="Gender of Professor", ylab="Average Quality of Course (in a scale of 1-5)")


## ---- fig.width=5, fig.height=3, fig.cap="Boxplot of Attractiveness vs Average Quality"----
boxplot(quality~pepper,data=Rateprof, main="Boxplot of Attractiveness vs Average Quality",
   xlab="Attractiveness of Professor", ylab="Average Quality of Course (on a scale from 1-5)")


## ---- fig.width=5, fig.height=3, fig.cap="Scatterplot of Easiness vs Average Quality"----
Rateprof %>%
ggplot(aes(x=easiness, y= quality)) +
  geom_point()+
labs(x = "Average Easiness Rating (on a scale from 1-5)", y = "Average Quality of Course (on a scale from 1-5)",)


## ---- fig.width=5, fig.height=3, fig.cap="Boxplot of Discipline of Course vs Average Quality"----
boxplot(quality~discipline,data=Rateprof, main="Boxplot of Discipline of Course vs Average Quality",
   xlab="Discipline of Course", ylab="Average Quality of Course")


## -----------------------------------------------------------------------------
step_function = step(lm(quality ~ gender + pepper + easiness*discipline, data = Rateprof), direction = "both", trace = 0)
names (step_function$coefficients)


## -----------------------------------------------------------------------------
model = lm(quality ~ gender + pepper + easiness, data = Rateprof)


## -----------------------------------------------------------------------------
model_2 = lm(quality ~ gender + easiness, data = Rateprof)


## -----------------------------------------------------------------------------
model_3 = lm(quality ~ gender + pepper, data = Rateprof)


## -----------------------------------------------------------------------------
model_4 = lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)


## -----------------------------------------------------------------------------
model_5a = lm(quality ~ gender + pepper + easiness + easiness:gender, data = Rateprof)
model_5b = lm(quality ~ gender + pepper + easiness + easiness:discipline, data = Rateprof)


## ---- fig.width=5, fig.height=3, fig.cap="Model 1 Residual Plot"--------------
plot(model, which = 1,)


## ---- fig.width=5, fig.height=3,fig.cap="Model 1 Normal Q-Q Plot"-------------
plot(model, which = 2,)


## ---- fig.width=5, fig.height=3, fig.cap="Model 4 Residual Plot"--------------
plot(model_4, which = 1,)


## ---- fig.width=5, fig.height=3,fig.cap="Model 4 Normal Q-Q Plot"-------------
plot(model_4, which = 2,)


## ---- fig.width=5, fig.height=3, fig.cap="Model 5 Residual Plot"--------------
plot(model_5a, which = 1,)


## ---- fig.width=5, fig.height=3,fig.cap="Model 5 Normal Q-Q Plot"-------------
plot(model_5a, which = 2,)


## -----------------------------------------------------------------------------
summary(model)


## -----------------------------------------------------------------------------
confint(model)


## -----------------------------------------------------------------------------
anova (model_4, model)


## -----------------------------------------------------------------------------
anova (model_5a, model)


## -----------------------------------------------------------------------------
anova(model_5b, model)

