## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(patchwork)


## ---- echo=FALSE, results="hide"----------------------------------------------
data <- read.csv("cmu-sleep (1).csv")
dim(data) # rows, columns


## ----echo=FALSE, results="hide"-----------------------------------------------
summary(data$TotalSleepTime)


## ----echo=FALSE, results="hide"-----------------------------------------------
summary(data$term_gpa)


## ----echo=FALSE, results="hide"-----------------------------------------------
summary(data$cum_gpa)


## ----echo=FALSE, results="hide"-----------------------------------------------
# Check for missing values
any(is.na(data$TotalSleepTime))
any(is.na(data$term_gpa))
any(is.na(data$cum_gpa))


## ----echo=FALSE, results='hide'-----------------------------------------------
g1 <- ggplot(data, aes(x = TotalSleepTime)) +
  geom_histogram(fill = "lightblue", color = "black") +
  labs(title = "Distribution of Total Sleep Time", x = "Total Sleep Time (minutes)", 
       y = "Count")

g2 <- ggplot(data, aes(x = term_gpa)) +
  geom_histogram(fill = "lightpink", color = "black") +
  labs(title = "Distribution of Term GPA", x = "Term GPA", y = "Count")

g3 <- ggplot(data, aes(x = cum_gpa)) +
  geom_histogram(fill = "orange", color = "black") +
  labs(title = "Distribution of Cumulative GPA", x = "Cumulative GPA", y = "Count")


## ---- echo=FALSE, fig.width=4, fig.height=3, warning=FALSE, message = FALSE----
g1


## ----echo=FALSE, warning=FALSE, message = FALSE, fig.width=7, fig.height=5----
g2 | g3


## ---- fig.width=7, fig.height=5-----------------------------------------------
g4 <- ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  labs(title = "Total Sleep Time vs. Term GPA", x = "Total Sleep Time (minutes)", y = "Term GPA")

g5 <- ggplot(data, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
  labs(title = "Total Sleep Time vs. Cumulative GPA", x = "Total Sleep Time (minutes)", y = "Cumulative GPA")

g4 | g5


## ----fig.width=4, fig.height=3, echo=FALSE------------------------------------
# check for outliers
ggplot(data, aes(x = 1, y = TotalSleepTime)) +
  geom_boxplot() +
  labs(title = "Boxplot of Total Sleep Time")


## ---- fig.width=5, fig.height=4, echo=FALSE-----------------------------------
ggplot(data, aes(x = TotalSleepTime, y = term_gpa, color = cum_gpa)) +
  geom_point() +
  labs(title = "Term GPA by Sleep Time and Cumulative GPA")


## ---- results='hide'----------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)


## ---- results='hide'----------------------------------------------------------
summary(model)


## ---- results='hide'----------------------------------------------------------
confint(model, level = 0.95)


## ----fig.width=7, fig.height=5, echo=FALSE------------------------------------
#par(mfrow=c(1,2))
plot(model, which=1:2)


## ---- results='hide'----------------------------------------------------------
data$log_TotalSleepTime <- log(data$TotalSleepTime)


## ---- results='hide'----------------------------------------------------------
log_model <- lm(term_gpa ~ log_TotalSleepTime + cum_gpa, data = data)


## ---- results='hide'----------------------------------------------------------
summary(log_model)


## ---- results='hide'----------------------------------------------------------
confint(log_model, level = 0.95)


## -----------------------------------------------------------------------------
par(mfrow=c(1,1))
plot(log_model, which=1:2)


## ---- echo=FALSE, results='hide'----------------------------------------------
new_data <- data.frame(TotalSleepTime = mean(data$TotalSleepTime) - 120, cum_gpa = mean(data$cum_gpa))
predicted_gpa <- predict(model, newdata = new_data)
predicted_gpa_interval <- predict(model, newdata = new_data, interval = "prediction")

# Display the predicted GPA
print(predicted_gpa)
print(predicted_gpa_interval)

