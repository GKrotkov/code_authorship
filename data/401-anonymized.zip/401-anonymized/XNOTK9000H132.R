## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(tidyverse)
library(gridExtra)
data = read.csv("cmu-sleep.csv")


## ---- fig.width=10, fig.height=3.5, fig.cap="Histograms for Each Variable"----
# Create individual histograms

histogram1 <- data %>% ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(bins = 30, fill = "lightblue", color = "navy") +
  ggtitle("Distribution of `TotalSleepTime`") +
  xlab("Total sleep time (minutes)") +
  ylab("Frequency") +
  theme(title = element_text(size = 12, hjust = 0.5),
        axis.title.x = element_text(size = 11.5),
        axis.title.y = element_text(size = 11.5),
        axis.text = element_text(size = 10))

histogram2 <- data %>% ggplot(aes(x = term_gpa)) +
  geom_histogram(bins = 30, fill = "lightblue", color = "navy") +
  ggtitle("Distribution of `term_gpa`") +
  xlab("Student's term GPA (out of 4.0)") +
  ylab("Frequency") +
  theme(title = element_text(size = 12, hjust = 0.5),
        axis.title.x = element_text(size = 11.5),
        axis.title.y = element_text(size = 11.5),
        axis.text = element_text(size = 10))

histogram3 <- data %>% ggplot(aes(x = cum_gpa)) +
  geom_histogram(bins = 30, fill = "lightblue", color = "navy") +
  ggtitle("Distribution of `cum_gpa`") +
  xlab("Student's cumulative GPA (out of 4.0)") +
  ylab("Frequency") +
  theme(title = element_text(size = 12, hjust = 0.5),
        axis.title.x = element_text(size = 11.5),
        axis.title.y = element_text(size = 11.5),
        axis.text = element_text(size = 10))

# Arrange the histograms in two rows
grid.arrange(histogram1, histogram2, histogram3, ncol = 3)


## ----table1, results='asis'---------------------------------------------------
library(knitr)

# Calculate summaries for each variable
summary_total_sleep_time <- summary(data$TotalSleepTime)
summary_term_gpa <- summary(data$term_gpa)
summary_cum_gpa <- summary(data$cum_gpa)

# Create a data frame with the summaries
summary_df <- data.frame(
  Variable = c("TotalSleepTime", "term_gpa", "cum_gpa"),
  Min = c(summary_total_sleep_time["Min."], summary_term_gpa["Min."], summary_cum_gpa["Min."]),
  Q1 = c(summary_total_sleep_time["1st Qu."], summary_term_gpa["1st Qu."], summary_cum_gpa["1st Qu."]),
  Median = c(summary_total_sleep_time["Median"], summary_term_gpa["Median"], summary_cum_gpa["Median"]),
  Mean = c(summary_total_sleep_time["Mean"], summary_term_gpa["Mean"], summary_cum_gpa["Mean"]),
  Q3 = c(summary_total_sleep_time["3rd Qu."], summary_term_gpa["3rd Qu."], summary_cum_gpa["3rd Qu."]),
  Max = c(summary_total_sleep_time["Max."], summary_term_gpa["Max."], summary_cum_gpa["Max."])
)

# Display the data frame as a table using kable
kable(summary_df, digits = 2, caption = "Summary Statistics")


## ---- fig.width=2.8, fig.height=2, fig.cap="Histogram for difference between term and cumulative GPA"----
data %>% ggplot(aes(x = term_gpa-cum_gpa)) +
  geom_histogram(bins = 30, fill = "lightblue", color = "navy") +
  ggtitle("Distribution for GPA Difference") +
  xlab("Difference between Term and Cumulative GPA") +
  ylab("Frequency") +
  theme(title = element_text(size = 8, hjust = 0.5),
        axis.title.x = element_text(size = 8),
        axis.title.y = element_text(size = 8),
        axis.text = element_text(size = 8))


## ---- message=FALSE, fig.width=4, fig.height=1.9, fig.cap="Scatterplot of GPA Difference vs. Total Sleep Time"----
data %>% ggplot(aes(x = TotalSleepTime, y = term_gpa-cum_gpa)) +
  geom_point(color = "blue", size = 0.6, alpha = 0.5) +
  geom_smooth(method="lm", color="red", linewidth=0.5, se=FALSE) +
  ggtitle("Relationship b/w GPA Difference and Total Sleep Time") +
  xlab("Total sleep time (minutes)") +
  ylab("GPA Difference") +
  theme(title = element_text(size = 8, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 8),
        axis.text = element_text(size = 8))


## -----------------------------------------------------------------------------
lm <- lm(term_gpa-cum_gpa ~ TotalSleepTime, data=data)


## ---- fig.width=8, fig.height=3, fig.cap="Diagnosis plots for the linear regression model"----
fitted_vals <- fitted(lm)
residuals <- residuals(lm)

par(mfrow=c(1,2))

# Residual plot
plot(fitted_vals, residuals, 
     cex = 0.5,
     main="Residuals vs Fitted Values",
     xlab="Fitted Values",
     ylab="Residuals")
abline(h=0, col="red", lty=2)

# Normal Q-Q Plot
qqnorm(residuals, 
       main="Normal Q-Q Plot",
       xlab="Theoretical Quantiles",
       ylab="Sample Quantiles")
qqline(lm$residuals)


## ---- message=FALSE, include=FALSE--------------------------------------------
summary(lm)


## ----table2, results='asis'---------------------------------------------------
summary_table <- coef(summary(lm))
conf_level <- 0.95
conf_intervals <- confint(lm, level = conf_level)
combined_summary <- cbind(summary_table, conf_intervals)

# Convert the combined summary to a table using kable
kable(combined_summary, digits = 5, 
      caption = "Linear Model Coefficients and Confidence Intervals")

