## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(ggplot2)
library(dplyr)
initial <- read.csv('/Users/rasikadronamraju/Desktop/Carnegie Mellon/SENIOR FALL <3/401/cmu-sleep.csv')
data <- transform(initial, TotalSleepTime = TotalSleepTime/60)


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$TotalSleepTime, breaks = 25, main = 'Histogram Total Sleep Time', xlab='Average Sleep Time (in hours)')


## ---- fig.width=4, fig.height=3-----------------------------------------------
qqnorm(data$TotalSleepTime, main = 'Normal Q-Q Plot of Total Sleep Time')


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$term_gpa, breaks = 25, main = 'Histrogram of Semester GPA', xlab='GPA (out of 4.0)')


## ---- include  = FALSE--------------------------------------------------------
qqnorm(data$term_gpa)


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$cum_gpa, breaks = 25, main = 'Histrogram of Cumulative GPA', xlab='GPA (out of 4.0)')


## ---- include  = FALSE--------------------------------------------------------
qqnorm(data$cum_gpa)


## ---- echo = FALSE------------------------------------------------------------
plot(x=data$TotalSleepTime,y=data$term_gpa,
     main= "Total Sleep Time v.s. Semester GPA", xlab = "Average Sleep Time (in hours)",
     ylab="GPA (out of 4.0)")
abline(lm(data$term_gpa~data$TotalSleepTime))


## ---- echo = FALSE------------------------------------------------------------
plot(x=data$TotalSleepTime,y=data$cum_gpa,
     main= "Total Sleep Time v.s. Cumulative GPA", xlab = "Average Sleep Time (in minutes)",
     ylab="GPA (out of 4.0)")
abline(lm(data$cum_gpa~data$TotalSleepTime))


## ---- results = FALSE---------------------------------------------------------
term_mod <- lm(term_gpa ~ TotalSleepTime, data=data)


## ---- results = FALSE---------------------------------------------------------
summary(term_mod)


## ---- results = FALSE---------------------------------------------------------
confint(term_mod)

## ---- include = FALSE---------------------------------------------------------
plot(term_mod, which = 1)


## ---- include = FALSE---------------------------------------------------------
plot(term_mod, which = 2)


## ---- results = FALSE---------------------------------------------------------
unit_mod <- lm(term_gpa ~ TotalSleepTime + term_units , data=data)


## ---- results = FALSE---------------------------------------------------------
summary(unit_mod)


## ---- results = FALSE---------------------------------------------------------
confint(unit_mod)


## ---- include = FALSE---------------------------------------------------------
plot(unit_mod, which = 1)


## ---- include = FALSE---------------------------------------------------------
plot(unit_mod, which = 2)


## ---- results = FALSE---------------------------------------------------------
cum_mod <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data=data)


## ---- results = FALSE---------------------------------------------------------
summary(cum_mod)


## ---- results = FALSE---------------------------------------------------------
confint(cum_mod)


## ---- results = FALSE---------------------------------------------------------
0.07845*2*-1


## ---- echo = FALSE------------------------------------------------------------
plot(cum_mod, which = 1)


## ---- echo = FALSE------------------------------------------------------------
plot(cum_mod, which = 2)

