## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(alr4)


## ---- message=FALSE, include=FALSE--------------------------------------------
library(ggplot2)
library(patchwork)
data = Rateprof[,c("gender","discipline","pepper","easiness","quality")]
aug_data = Rateprof[,c("gender","discipline","pepper","easiness","quality")]
aug_data[,c("quality")] = sqrt(5-aug_data[,c("quality")])

labels <- c("Gender", "Discipline",
            "Attractiveness", "Easiness (1 to 5)",
            "Quality (1 to 5)", "Aug Quality (0 to ~2)")


## ---- message=FALSE, fig.width=6, fig.height=2.3, fig.cap="Counts of professor quality ratings. On the left, it is shown that the quality ratings are left skewed. To adjust for this, an augmentation is applied to yield the more normal augmented quality ratings shown on the right."----

g1 <- ggplot(data) + geom_histogram(aes(x = quality)) + labs(x = labels[5], y = "Count")

g2 <- ggplot(aug_data) + geom_histogram(aes(x = quality)) + labs(x = labels[6], y = "Count")

g1 | g2


## ---- message=FALSE, fig.width=10, fig.height=4, fig.cap="On the left are the counts for professor gender, and on the right are the counts for professor discipline. In both cases, the distributions appear relatively even among each option."----
#Layout adapted  from HW6 solutions

par(mfrow = c(1, 2))

barplot(table(data$gender), names = c("Female", "Male"), xlab = "Gender", ylab = "Count")

barplot(table(data$discipline), names = c("Hum", "Soc", "STEM", "Pre-Prof"), xlab = "Discipline", ylab = "Count")


## ---- message=FALSE, fig.width=4, fig.height=2.5, fig.cap="Counts for the professor pepper (attractiveness) ratings. There are a much larger number of unattractive professors compared to attractive professors, which could result in the attractive professors skewing model results."----
#Layout adapted  from HW6 solutions

barplot(table(data$pepper), names = c("Not Attractive", "Attractive"), xlab = "Attractiveness", ylab = "Count")


## ---- message=FALSE, fig.width=3, fig.height=2.5, fig.cap="Counts for the average easiness rating for professors. The distribution appears normal with a mean of approximately 3 units."----

ggplot(data) + geom_histogram(aes(x = `easiness`)) + labs(x = labels[4], y = "Count")


## ---- message=FALSE, fig.width=10, fig.height=4, fig.cap="Comparisons of gender, discipline, and attractiveness against augmented professor quality ratings. The plots within each box plot for gender and discipline appear similar, while the two boxes within the set of attractiveness box plots have different means and ranges. This could be due to the large differnce in the number of samples between attractive and unattractive professors."----
#Layout adapted from HW6 solutions

par(mfrow = c(1, 3))

boxplot(quality ~ gender, ylab = labels[6], data = aug_data, xlab = labels[1], names = c("Female","Male"), pch = 16)

boxplot(quality ~ discipline, ylab = labels[6], data = aug_data, xlab = labels[2], names=c("Hum", "Soc", "STEM", "Pre-Prof"), pch = 16)

boxplot(quality ~ pepper, ylab = labels[6], data = aug_data, xlab = labels[3], names=c("Not Attractive", "Attractive"), pch = 16)


## ---- message=FALSE, fig.width=3, fig.height=2.5, fig.cap="A plot comparing average professor easiness scores against the adjusted professor quality scores. There appears to be a negative linear relationship, meaning there is likely a positive association betewen professor easiness scores and quality scores."----

ggplot(aug_data) + aes(x = easiness, y = quality) + geom_point() + labs(x = labels[4], y = labels[6])



## ---- message=FALSE, fig.width=12, fig.height=3.5, fig.cap="The distribution of different genders, disciplines, and attractiveness scsores on the relationship btween easiness and quality scores. There is an even spread of different values for gender and discipline, but for attractiveness there are fewer data points for attractive professors that are near the bottom, forming an unclear relationship."----

#How to change legend labels: https://statisticsglobe.com/change-legend-labels-of-ggplot2-plot-in-r

g1 <- ggplot(aug_data,
aes(x = easiness, y = quality,
color = gender)) + geom_point() +
labs(x = labels[4], y = labels[6], color = "Gender") + 
scale_color_manual(labels = c("Female", "Male"),
                     values = c("red", "blue"))


g2 <- ggplot(aug_data,
aes(x = easiness, y = quality,
color = discipline)) + geom_point() +
labs(x = labels[4], y = labels[6], color = "Discipline") + 
  scale_color_manual(labels = c("Hum", "Soc", "STEM", "Pre-Prof"),
                     values = c("red", "green", "blue", "purple"))


g3 <- ggplot(aug_data,
aes(x = easiness, y = quality,
color = pepper)) + geom_point() +
labs(x = labels[4], y = labels[6], color = "Attractiveness") + 
  scale_color_manual(labels = c("Not Attractive", "Attractive"),
                     values = c("red", "blue"))

g1 | g2 | g3



## ---- message=FALSE, include=FALSE--------------------------------------------
fit_full <- lm(quality ~ factor(gender) + factor(discipline) + easiness*factor(pepper), data = aug_data)


## ---- message=FALSE, fig.width=10, fig.height=3.5, fig.cap="Comparing the fitted values of the model against their respective residuals. When using no interactions, there appears to be heteroskedasticity in lower fitted values. When using an interaction for easiness and attractiveness, the heteroskedasticity heavily decreases."----
fit_noInt <- lm(quality ~ factor(gender) + factor(discipline) + easiness+factor(pepper), data = aug_data)

library(broom)
g1 <- ggplot(augment(fit_noInt), aes(x = .fitted, y = .resid)) + geom_point() + labs(x = "Fitted value", y = "Residual")

g2 <- ggplot(augment(fit_full), aes(x = .fitted, y = .resid)) + geom_point() + labs(x = "Fitted value", y = "Residual")

g1 | g2


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="A normal Q-Q plot for the augmented model. The points fitting a line signals the residuals follow a normal distribution."----
qqnorm(residuals(fit_full)) 
qqline(residuals(fit_full))


## ---- message=FALSE, fig.width=3, fig.height=2.5, fig.cap="The Cook's distances of the easiness scores for the augmented model. Since no value is above 1, there doesn't appear to be any influential outliers."----
augment(fit_full) |> ggplot(aes(x = easiness, y = .cooksd)) + geom_point() +
labs(x = labels[4], y = "Cook's Distance")



## ---- message=FALSE, include=FALSE--------------------------------------------
#diff = sqrt(5-q-a) - sqrt(5-q) 
#=> 5-q-a = diff^2 + 2diffsqrt(5-q) + 5-q
#=> a = -diff^2 - 2*diff*sqrt(5-q)

diff1 = -0.27
diff1^2
2*diff1

diff2 = -0.09
diff2^2
2*diff2

diff3 = -0.7
diff3^2
2*diff3




## ---- message=FALSE, fig.width=5, fig.height=3.5, fig.cap="Table showing the estimates, standard errors, t-statistics, and corresponding p-values for each of the coefficients for the model."----
#Adapted from instructor note on Piazza
library(broom)

knitr::kable(tidy(fit_full), col.names = c('Coefficient', 'Estimate', 'Std. Error', 't-statistic', 'p-value'), caption = "Table showing the estimates, standard errors, t-statistics, and corresponding p-values for each of the coefficients for the model.")


## ---- message=FALSE, include=FALSE--------------------------------------------
confint(fit_full, "factor(gender)male", level = 0.95)
confint(fit_full, "factor(discipline)STEM", level = 0.95)
confint(fit_full, "easiness", level = 0.95)
confint(fit_full, "factor(pepper)yes", level = 0.95)


## ---- message=FALSE, include=FALSE--------------------------------------------

fit_discInt <- lm(quality ~ factor(gender) + factor(discipline):easiness + easiness + factor(pepper) + factor(discipline) + easiness:factor(pepper), data = aug_data)

fit_gendInt <- lm(quality ~ factor(discipline) + factor(gender):easiness + easiness + factor(pepper) + factor(gender) + easiness:factor(pepper), data = aug_data)

a_discInt = anova(fit_full, fit_discInt)
a_gendInt = anova(fit_full, fit_gendInt)

#Adapted from instructor note on Piazza
library(xtable)
print(xtable(a_discInt))
print(xtable(a_gendInt))


