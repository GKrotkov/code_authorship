## ---- message=FALSE-----------------------------------------------------------
#libraries
library(alr4)
library(ggplot2)
library(dplyr)
library(gridExtra)
library(modelsummary)


## ---- echo=FALSE, results="hide"----------------------------------------------
ratings = Rateprof
data(ratings)
head(ratings)

summary(ratings$quality)

summary(ratings$easiness)

summary(ratings$gender)

summary(ratings$pepper)

summary(ratings$discipline)


## ---- message=FALSE, fig.cap="Figure 1: Distribution of Quality variable"-----
ggplot(ratings, aes(x = quality)) +
  geom_histogram(fill = "deeppink2", color = "black") +
  labs(x = "Quality (1 to 5)", y = "Count", 
       title = "Distribution of quality ratings")


## ---- echo=FALSE, fig.cap="Figure 2: Variables Distribution Plots"------------

ratings$attractive = ifelse(ratings$pepper == "yes", "Attractive", 
                             "Not Attractive")
attrac_colors = c("Attractive" = "pink", "Not Attractive" = "lightblue")

plot_gender = ggplot(ratings, aes(x = gender, fill = gender)) +
  geom_bar() +
  labs(title = "Dist. of Professor by Gender")

plot_attractive = ggplot(ratings, aes(x = attractive, fill = attractive)) +
  geom_bar() +
  scale_fill_manual(values = attrac_colors) +
  labs(title = "Dist. of Professor Attractiveness")

plot_easiness = ggplot(ratings, aes(x = easiness)) +
  geom_histogram(binwidth = 0.4, fill = "goldenrod", color = "black") +
  labs(title = "Dist. of Easiness")

plot_discipline = ggplot(ratings, aes(x = discipline, fill = discipline)) +
  geom_bar() +
  labs(title = "Dist. of Professor Discipline")

grid.arrange(plot_gender, plot_attractive, plot_easiness, plot_discipline, 
             ncol = 2)


## ---- echo=FALSE, fig.cap="Figure 3: Quality vs. Other variables plots"-------

ratings$attractive = ifelse(ratings$pepper == "yes", "Attractive", 
                            "Not Attractive")

q_Gender = ggplot(ratings, aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() +
  labs(title = "Quality vs. Gender")

q_Attractive = ggplot(ratings, aes(x = attractive, y = quality, fill = attractive)) +
  geom_boxplot() +
  labs(title = "Quality vs. Attractiveness")

q_Easiness = ggplot(ratings, aes(x = easiness, y = quality, color = gender)) +
  geom_point(aes(color = gender)) + 
  labs(title = "Quality vs. Easiness",
       x = "easiness",
       y = "quality") 

q_Discipline = ggplot(ratings, aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() +
  labs(title = "Quality vs. Discipline")

grid.arrange(q_Gender, q_Attractive, q_Easiness, q_Discipline, ncol = 2)


## ---- echo=FALSE, fig.cap="Figure 4: Easiness vs. Other variables plots"------

ratings$attractive = ifelse(ratings$pepper == "yes", "Attractive", "Not Attractive")

eas_Gender = ggplot(ratings, aes(x = gender, y = easiness, fill = gender)) +
  geom_boxplot() +
  labs(title = "Easiness vs. Gender")

eas_Attractive = ggplot(ratings, aes(x = attractive, y = easiness, fill = attractive)) +
  geom_boxplot() +
  labs(title = "Easiness vs. Attractiveness")

eas_Discipline = ggplot(ratings, aes(x = discipline, y = easiness, fill = discipline)) +
  geom_boxplot() +
  labs(title = "Easiness vs. Discipline")

grid.arrange(eas_Gender, eas_Attractive, eas_Discipline, ncol = 2)


## ---- echo=FALSE, fig.cap="Figure 5: QQ plots"--------------------------------

full_model = lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = ratings)

par(mfrow = c(2,2))

linearity = plot(full_model$fitted.values, full_model$residuals, main = "Residuals vs Fitted", xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "red", lty = 2)

qq_plot = qqnorm(full_model$residuals); qqline(full_model$residuals)

cook_dist = plot(full_model, which = c(4))


## ---- results='hide', echo=FALSE----------------------------------------------
reduced_model = lm(quality ~ gender + pepper + easiness + discipline, data = ratings)
summary(reduced_model)

confint(reduced_model, level = 0.95)


## ---- results='hide', echo=FALSE----------------------------------------------
full_model = lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = ratings)
summary(full_model)

confint(full_model, level = 0.95)


## ---- results='hide', echo=FALSE----------------------------------------------
reduced_model$aic = AIC(reduced_model)
full_model$aic = AIC(full_model)
modelsummary(list("Reduced Model" = reduced_model, "Full Model" = full_model),
             stars = TRUE, 
             gof_omit = "R2 Adj.|BIC|Log.Lik.|RMSE")


## ---- results='hide', echo=FALSE----------------------------------------------
anova(reduced_model, full_model)

