## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
options(warn=-1)
knitr::opts_chunk$set(echo = FALSE)


## ----include = FALSE----------------------------------------------------------
library(alr4)


## ---- fig.width=3, fig.height=2, fig.cap="Counts for gender"------------------
library(gridExtra)
m=nrow(Rateprof[Rateprof$gender=='male',])
f=nrow(Rateprof[Rateprof$gender=='female',])
x <- data.frame(row.names=c('male','female'))
x[1,1]=m
x[2,1]=f
colnames(x) = c('count')
grid.table(x)


## ---- fig.width=3, fig.height=2, fig.cap="Counts for attractiveness "---------
library(gridExtra)
m=nrow(Rateprof[Rateprof$pepper=='yes',])
f=nrow(Rateprof[Rateprof$pepper=='no',])
x <- data.frame(row.names=c('yes','no'))
x[1,1]=m
x[2,1]=f
colnames(x) = c('count')
grid.table(x)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of easiness"--------------
hist(Rateprof$easiness,main='histogram of average of rating easiness',xlab='easiness')


## ---- fig.width=3, fig.height=2, fig.cap="Counts for discipline "-------------
library(gridExtra)
m=nrow(Rateprof[Rateprof$discipline=='Hum',])
f=nrow(Rateprof[Rateprof$discipline=='SocSci',])
a=nrow(Rateprof[Rateprof$discipline=='STEM',])
b=nrow(Rateprof[Rateprof$discipline=='Pre-prof',])
x <- data.frame(row.names=c('Humanity','Social Science',"STEM","professional training"))
x[1,1]=m
x[2,1]=f
x[3,1]=a
x[4,1]=b
colnames(x) = c('count')
grid.table(x)



## ---- fig.width=4, fig.height=3, fig.cap="Histogram of quality rating"--------
hist(Rateprof$quality,main='histogram of average of quality rating',xlab='quality rating')


## ---- fig.width=4, fig.height=3, fig.cap="boxplot between gender and quality rating"----
library(ggplot2)
ggplot(data=Rateprof)+geom_boxplot(aes(x=gender,y=quality))



## ---- fig.width=4, fig.height=3, fig.cap="boxplot between attractiveness and quality rating"----
ggplot(data=Rateprof)+geom_boxplot(aes(x=pepper,y=quality))+xlab('Attractiveness')


## ---- fig.width=4, fig.height=3, fig.cap="plot between easiness and quality rating"----
plot(Rateprof$easiness,Rateprof$quality,xlab='average rating of easiness',ylab='average rating of quality rating',main='easiness vs uality rating')


## ---- fig.width=4, fig.height=3, fig.cap="boxplot between discipline and quality rating"----
ggplot(data=Rateprof)+geom_boxplot(aes(x=discipline,y=quality))


## ---- fig.width=4, fig.height=3, fig.cap="coefficients",error=FALSE-----------
library(modelsummary)
f=lm(quality~easiness*gender+easiness*discipline+pepper,data=Rateprof)
modelsummary(f)


## ---- fig.width=5, fig.height=4, fig.cap="t-value and p-value "---------------
x <- data.frame(row.names=c('easiness','gendermale',"disciplineSocSci","disciplineSTEM","disciplinePre-prof","pepperyes(attractive)","easiness:gendermale","easiness:disciplineSocSci","easiness:disciplineSTEM ","easiness:disciplinePre-prof"))

x[1,1]=summary(f)$coefficients[24]
x[2,1]=summary(f)$coefficients[25]
x[3,1]=summary(f)$coefficients[26]
x[4,1]=summary(f)$coefficients[27]
x[5,1]=summary(f)$coefficients[28]
x[6,1]=summary(f)$coefficients[29]
x[7,1]=summary(f)$coefficients[30]
x[8,1]=summary(f)$coefficients[31]
x[9,1]=summary(f)$coefficients[32]
x[10,1]=summary(f)$coefficients[33]

x[1,2]=summary(f)$coefficients[35]
x[2,2]=summary(f)$coefficients[36]
x[3,2]=summary(f)$coefficients[37]
x[4,2]=summary(f)$coefficients[38]
x[5,2]=summary(f)$coefficients[39]
x[6,2]=summary(f)$coefficients[40]
x[7,2]=summary(f)$coefficients[41]
x[8,2]=summary(f)$coefficients[42]
x[9,2]=summary(f)$coefficients[43]
x[10,2]=summary(f)$coefficients[44]

colnames(x) = c('t-value',"p-value")
grid.table(x)


## ----include=FALSE------------------------------------------------------------
step(f,trace=FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="QQ plot"----------------------------
k=lm(formula = quality ~ easiness + gender + pepper, data = Rateprof)


## ----fig.width=4, fig.height=3, fig.cap="QQ plot"-----------------------------
qqnorm(residuals(k))
qqline(residuals(k))


## ---- fig.width=4, fig.height=3, fig.cap="residual plot"----------------------
plot(residuals(k))


## ---- fig.width=5, fig.height=4, fig.cap="t-value and p-value "---------------
x <- data.frame(row.names=c('easiness','gendermale',"pepperyes(attractive)"))

x[1,1]=summary(k)$coefficients[10]
x[2,1]=summary(k)$coefficients[11]
x[3,1]=summary(k)$coefficients[12]


x[1,2]=summary(k)$coefficients[14]
x[2,2]=summary(k)$coefficients[15]
x[3,2]=summary(k)$coefficients[16]


colnames(x) = c('t-value',"p-value")
grid.table(x)

