## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
knitr::opts_chunk$set(warning = FALSE)
knitr::opts_chunk$set(message = FALSE)


## -----------------------------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(alr4)
library(broom)
data = alr4::Rateprof
data = data[c('quality', 'gender', 'pepper' , 'easiness', 'discipline')]


## ---- fig.width=3, fig.height=2.5, fig.cap="Barplot of Gender"----------------
ggplot(data, aes(x = gender))+geom_bar(fill = "#73e0f4")+labs(x = "Gender", y = "Density")+theme_dark()


## ---- fig.width=3, fig.height=2.5, fig.cap="Barplot of Pepper"----------------
ggplot(data, aes(x = pepper))+geom_bar(fill = "#ff8d53")+labs(x = "Pepper", y = "Density")+theme_dark()


## ---- fig.width=3, fig.height=2.5, fig.cap="Histogram of Easiness"------------
ggplot(data, aes(x = easiness))+geom_histogram(fill = "#FDC4F4", binwidth = 0.15)+labs(x = "Easiness", y = "Density")+theme_dark()



## ---- fig.width=3, fig.height=2.5, fig.cap="Barplot of Discipline"------------
ggplot(data, aes(x = discipline))+geom_bar(fill = "#EEEF95")+labs(x = "Discipline", y = "Density")+theme_dark()



## ---- fig.width=3, fig.height=2.5, fig.cap="Histogram of quality"-------------
ggplot(data, aes(x = quality))+geom_histogram(fill = "#5EE8C3")+labs(x = "Quality", y = "Density")+theme_dark()



## ---- fig.width=3, fig.height=2.5, fig.cap="Histogram of Squared Quality"-----
data$sqquality = data$quality^2

ggplot(data, aes(x = sqquality))+geom_histogram(fill = "#5EE8C3")+labs(x = "Quality", y = "Density")+theme_dark()



## ---- fig.width=5, fig.height=4, fig.cap="Bar plot of Squared Quality v.s. Gender"----
ggplot(data, aes(x=gender, y = sqquality, fill = gender))+geom_boxplot(color = "#73e0f4")+labs(x = "Gender", y = "Squared Quality")+theme_dark()



## ---- fig.width=5, fig.height=4, fig.cap="Bar plot of Squared Quality v.s. Pepper"----
ggplot(data, aes(x=pepper, y = sqquality, fill = pepper))+geom_boxplot(color = "#ff8d53")+labs(x = "Pepper", y = "Squared Quality")+theme_dark()



## ---- fig.width=5, fig.height=4, fig.cap="Scatter Plot of Squared Quality v.s. Easiness"----
ggplot(data, aes(x=easiness, y = sqquality))+geom_point(color = "#FDC4F4")+labs(x = "Easiness", y = "Squared Quality")+theme_dark()+geom_smooth(method = 'lm', color = "#5EE8C3")



## ---- fig.width=5, fig.height=4, fig.cap="Bar plot of Squared Quality v.s. Discipline"----
ggplot(data, aes(x=discipline, y = sqquality, fill = discipline))+geom_boxplot(color = "#EEEF95")+labs(x = "Discipline", y = "Squared Quality")+theme_dark()



## ---- fig.width=5, fig.height=4, fig.cap="residuals v.s. Squared Quality"-----
fit = lm(sqquality ~ easiness + factor(gender) + factor(pepper) + factor(discipline) + easiness:factor(gender) + easiness:factor(pepper) + easiness: factor(discipline), data)
ggplot(augment(fit), aes(x=.fitted, y = .resid))+geom_point(color = "#FDC4F4", size = 0.5)+labs(x = "Squared Quality", y = "residuals") +theme_dark()+geom_smooth(method = "lm", linetype = 'dashed', color = "#5EE8C3")


## ---- fig.width=5, fig.height=4, fig.cap="Q-Q Plot of multi-linear regression model"----
qqnorm(fit$residuals)
qqline(fit$residuals, datax = FALSE, distribution = qnorm, col = "#5EE8C3")


## -----------------------------------------------------------------------------
rf = lm(sqquality ~ easiness + factor(gender) + factor(pepper) + factor(discipline), data)

anova(rf, fit)


## -----------------------------------------------------------------------------
summary(rf)
confint(rf)

