## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
library(dplyr)
library(tidyverse)
data <- read.csv("cmu-sleep.csv")


## ---- fig.cap="brief look at data"--------------------------------------------
head(data)


## ---- fig.cap="Distribution of Relevant Variables"----------------------------
library(ggplot2)

hist(data$TotalSleepTime, col="navy", main="Distr of Total Sleep Tme",
     xlab="TotalSleepTime (mins)", ylab="Freq", breaks=30)
hist(data$term_gpa, col="navy", main="Distr of Term GPA",
     xlab="Term GPA(on a 4.0 scale)", ylab="Freq", breaks=30)
hist(data$cum_gpa, col="navy", main="Distr of Cumulative GPA",
     xlab="Cumulative GPA(on a 4.0 scale)", ylab="Freq", breaks=30)


## ---- fig.cap="Total sleep time vs term_gpa"----------------------------------
plot(data$term_gpa,data$TotalSleepTime, main ="TotalSleepTime(mins) vs Term GPA", xlab="term_gpa", 
     ylab="TotalSleepTime(mins)")

## ---- fig.cap="Total sleep time vs cum_gpa"-----------------------------------
plot(data$cum_gpa,data$TotalSleepTime, main ="TotalSleepTime(mins) vs Cumulative GPA", xlab="cum_gpa", 
     ylab="TotalSleepTime(mins")


## ---- fig.cap="linear model"--------------------------------------------------
ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
geom_point() +
geom_smooth(method = "lm") + # linear model plotted on top
labs(x = "Total Sleep Time(mins)", y = "term gpa")




## ----fig.cap="log transformed model"------------------------------------------
ggplot(data, aes(x = log(TotalSleepTime), y = term_gpa)) +
geom_point() +scale_x_log10()+
geom_smooth(method = "lm") + # linear model plotted on top
labs(x = "Total Sleep Time(mins)", y = "term gpa")



## -----------------------------------------------------------------------------
#Model fit to Least Squares
data_fit <- lm(term_gpa ~ TotalSleepTime, data = data)
coef(data_fit)
coef(data_fit)["TotalSleepTime"]



## -----------------------------------------------------------------------------
b0 = coef(data_fit)[1]
b1 = coef(data_fit)[2]



## -----------------------------------------------------------------------------
CI <- confint(data_fit, level=0.95)
CI


## -----------------------------------------------------------------------------
avggpa<- mean(data$term_gpa)
avggpa
avggpa -  b1*120
b1*120

