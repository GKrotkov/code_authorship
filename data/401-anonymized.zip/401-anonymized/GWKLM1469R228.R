## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----download csv, include = FALSE--------------------------------------------
#just setup
knitr::opts_chunk$set(warning = TRUE, message = TRUE)
library(insight)
library(ggplot2)
library(broom)
library(patchwork)
library(psych) 
require(gridExtra)
df <- read.csv('/Users/kaelamarsheck/Desktop/401/data_exam_1/cmu-sleep.csv')
#import any necessary packages


## ----eda, include = FALSE-----------------------------------------------------
nrow(df)
summary(df)


## ----eda Total Sleep Time, echo=FALSE-----------------------------------------
formatted = describe(df$TotalSleepTime, fast=TRUE)
rownames(formatted) <-  c("Total Sleep Time")
  
sleepTimePlot<-ggplot(df, aes(x=TotalSleepTime)) + 
  geom_histogram(color="black", fill="white", binwidth = 10)+ ggtitle("Figure 1A: Histogram and Table of Total Sleep Time") +
  xlab("Total Sleep Time (minutes)") + ylab("Number of Students") 
sleepTimePlot       
knitr::kable(formatted, align = 'c' )


## ----eda Term GPA, echo=FALSE-------------------------------------------------
formatted = describe(df$term_gpa, fast=TRUE)
rownames(formatted) <-  c("Term GPA")

termGPAPlot<-ggplot(df, aes(x=term_gpa)) + 
  geom_histogram(color="black", fill="white",binwidth = .1)+ ggtitle("Figure 1B: Histogram and Table of Term GPA") +
  xlab("Term GPA (out of 4.0)") + ylab("Number of Students")

termGPAPlot
knitr::kable(formatted, align = 'c' ) 


## ----eda Cumulative GPA, echo=FALSE-------------------------------------------
formatted = describe(df$cum_gpa, fast=TRUE)
rownames(formatted) <-  c("Cumulative GPA")
        
cumGPAPlot<-ggplot(df, aes(x=cum_gpa)) + 
  geom_histogram(color="black", fill="white",binwidth = .1)+ ggtitle("Figure 1C: Histogram and Table of Cumulative GPA") +
  xlab("Cumulative GPA (out of 4.0)") + ylab("Number of Students")
 
cumGPAPlot      
knitr::kable(formatted, align = 'c' )


## ----plots, echo=FALSE--------------------------------------------------------

#plot the predictor(sleep time) vs the response variable(GPAs)
sleepVtermGPA <- ggplot(df, aes(x = TotalSleepTime, y = term_gpa)) +
    geom_point()+ ggtitle("Figure 2A: Total Sleep Time vs Term GPA") +
  xlab("Total Sleep Time (minutes)") + ylab("Term GPA (out of 4.0)")+  theme(plot.title = element_text(size = 10))

sleepVcumGPA <- ggplot(df, aes(x = TotalSleepTime, y = cum_gpa)) +
    geom_point()+ ggtitle("Figure 2B: Total Sleep Time vs Cumulative GPA") +
  xlab("Total Sleep Time (minutes)") + ylab("Cumulative GPA (out of 4.0)")+ theme(plot.title = element_text(size = 10))



#take log of x value
logSleepVTermGPA <- ggplot(df, aes(x = log(TotalSleepTime), y = term_gpa)) +
    geom_point()+ ggtitle("Figure 2c: Logged Total Sleep Time vs Term GPA") +
  xlab("Logged Total Sleep Time (minutes)") + ylab("Term GPA (out of 4.0)")+ theme(plot.title = element_text(size = 10))

#take log of x value
logSleepVLoggedTermGPA <- ggplot(df, aes(x = log(TotalSleepTime), y = log(term_gpa))) +
    geom_point()+ ggtitle("Figure 2D: Logged Sleep Time vs Logged Term GPA") +
  xlab("Logged Total Sleep Time (minutes)") + ylab("Term GPA (out of 4.0)")+  theme(plot.title = element_text(size = 10))


grid.arrange(sleepVtermGPA, sleepVcumGPA, ncol=2)
grid.arrange(logSleepVTermGPA, logSleepVLoggedTermGPA, ncol=2)




## ----fits, include = FALSE----------------------------------------------------
cumFit <- lm(cum_gpa ~TotalSleepTime, data= df)
termFit <- lm(term_gpa ~ TotalSleepTime, data = df)
#loggedTermFit <- lm(term_gpa ~ log(TotalSleepTime), data = df)


## ----outliers, echo=FALSE-----------------------------------------------------
#cook's dist
augment(termFit) |>
ggplot(aes(x = TotalSleepTime, y = .cooksd)) +
geom_point() +
labs(x = "Total Sleep Time (mins)", y = "Cook's distance", title = "Figure 3: Cook's Distance")



## ----other plots, echo=FALSE--------------------------------------------------
b <- ggplot(df, aes(x = Zterm_units_ZofZ, y = term_gpa)) +
    geom_point()+ ggtitle("Figure 4A: Study Group vs Term GPA") +
  xlab("Units") + ylab("Term GPA (out of 4.0)")+theme(plot.title = element_text(size = 10))


#take log of x value
c <- ggplot(df, aes(x = midpoint_sleep, y = term_gpa)) +
    geom_point()+ ggtitle("Figure 4B: Sleep Midpoint vs Term GPA") +
  xlab("Midpoint of Bedtime (minutes)") + ylab("Term GPA (out of 4.0)")+theme(plot.title = element_text(size = 10))
grid.arrange(b, c, ncol=2)



## ----term log residual analysis, echo=FALSE-----------------------------------

#take log of x value


#plot residuals against total sleep time
res <- augment(termFit) |>
ggplot(aes(x = df$TotalSleepTime, y = .resid)) +
geom_point() + ggtitle("Figure 5A: Residuals vs Total Sleep Time")+
labs(x = "Total Sleep Time (min)",
y = "Residual Values") + theme(plot.title = element_text(size = 8))

#qq plot of normal term fit
qq <- ggplot(augment(termFit),
aes(sample = .resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical Quantiles", y = "Sample Quantiles")+ ggtitle("Figure 5B: QQ Plot for Term GPA Regession")+ theme(plot.title = element_text(size = 10))

grid.arrange(res, qq, ncol=2)


## ----term summary, echo=FALSE, message=FALSE----------------------------------
sleepVTermGPA <- ggplot(df, aes(x = TotalSleepTime, y = term_gpa)) +
    geom_point() + geom_smooth(method=lm)+ ggtitle("Figure 6: Total Sleep Time vs Term GPA Regression and Values") +
  xlab("Total Sleep Time (minutes)") + ylab("Term GPA (out of 4.0)")
sleepVTermGPA
x <-tidy(summary(termFit))
knitr::kable(x, align = 'c' )




## ----confint, include = FALSE-------------------------------------------------
confint(termFit, level =0.95)
 0.0019846 * 2 * 60


