## -----------------------------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")
View(sleep)


## -----------------------------------------------------------------------------
custom_break <- seq(0,4, by =0.25)
hist(sleep$TotalSleepTime, main = "Histogram of The Student's Average Time Spent on Sleep Each Night", xlab = "The amount of time spent on sleep in minutes", ylab = "Frequency")
hist(sleep$term_gpa, breaks = custom_break, main = "Histogram of The Student's GPA During The Study Conducted Semester", xlab = "The Student's GPA (out of 4.0)", ylab = "Frequency")
axis(1, at = seq(0, 4, by = 0.5), labels = seq(0, 4, by = 0.5))
hist(sleep$cum_gpa, breaks = custom_break, main = "Histogram of The Student's GPA Prior The Study Conducted Semester", xlab = "The Student's GPA (out of 4.0)", ylab = "Frequency")
axis(1, at = seq(0, 4, by = 0.5), labels = seq(0, 4, by = 0.5))


## -----------------------------------------------------------------------------

library(ggplot2)
ggplot(sleep, aes(x= TotalSleepTime, y = term_gpa))+
       geom_point()+ geom_smooth(method="lm")+
       labs(title ="Relationship between Sleeping Time and the GPA of the study conducted semester", x = "Time spent on sleep", y = "GPA")


## -----------------------------------------------------------------------------
sleep_linear1 <- lm(term_gpa ~ TotalSleepTime, data=sleep)
summary(sleep_linear1)

.0019 * 120
plot(sleep_linear1)
qqnorm(sleep_linear1$residuals)
qqline(sleep_linear1$residuals)


## -----------------------------------------------------------------------------
confint(sleep_linear1)


