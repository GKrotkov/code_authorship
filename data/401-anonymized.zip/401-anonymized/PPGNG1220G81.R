## ---- message=FALSE, echo=FALSE-----------------------------------------------
# Load libraries and data set
library(tidyverse)
library(ggplot2)
data = read.csv("/Users/crosbydavidson/Downloads/cmu-sleep.csv")


## ---- echo=FALSE, message=FALSE, fig1, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig1}Histogram of Total Sleep Time"----
# Univariate Analysis of Total Sleep Time
ggplot(data, aes(x=TotalSleepTime)) + 
  geom_histogram(color="black", fill="lightblue") +
  labs(title="Histogram of Total Sleep Time", x="Total Sleep Time (Minutes)", y="Count")


## ---- echo=FALSE, message=FALSE, fig2, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig2}Histogram of Term GPA"----
# Univariate Analysis of Term GPA
ggplot(data, aes(x=term_gpa)) + 
  geom_histogram(color="black", fill="lightblue") +
  labs(title="Histogram of Term GPA", x="Term GPA (4.0 Scale)", y="Count")


## ---- echo=FALSE, message=FALSE, fig3, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig3}Histogram of Cumulative GPA"----
# Univariate Analysis of Cumulative GPA
ggplot(data, aes(x=cum_gpa)) + 
  geom_histogram(color="black", fill="lightblue") +
  labs(title="Histogram of Cumulative GPA", x="Cumulative GPA (4.0 Scale)", y="Count")


## ---- echo=FALSE, message=FALSE, fig4, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig4}Scatter Plot of Term GPA vs. Total Sleep Time"----
# Bivariate Analysis of Total Sleep Time and Term GPA
ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point() +
  labs(title="Term GPA vs. Total Sleep Time", x="Total Sleep Time (Minutes)", 
       y="Term GPA (4.0 Scale)") +
  geom_smooth(method="lm")


## ---- include=FALSE, message=FALSE--------------------------------------------
# Define linear model
model = lm(data$term_gpa ~ data$TotalSleepTime)


## ---- echo=FALSE, message=FALSE, fig5, fig.width=4, fig.height=4, fig.cap="\\label{fig:fig5}Q-Q Plot of Residuals"----
# Create Q-Q Plot of Residuals
ggplot(data, aes(sample=resid(model))) + geom_qq() + geom_qq_line(color="blue") +
  labs(title="Normal Q-Q Plot (Residuals)", x="Theoretical Quantities",
       y="Observed Quantities")


## ---- echo=FALSE, message=FALSE, fig6, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig6}Scatter Plot of Residuals vs. Total Sleep Time"----
ggplot(data, aes(x=TotalSleepTime, y=resid(model))) + geom_point() +
  geom_hline(yintercept = 0, color="blue") +
  labs(title="Residuals vs. Total Sleep Time", x="Total Sleep Time (minutes)",
       y="Residuals")

