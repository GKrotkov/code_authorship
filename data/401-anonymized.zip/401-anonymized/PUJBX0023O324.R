## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(GGally)
library(alr4)
library(car)


## ---- include = FALSE---------------------------------------------------------
data(Rateprof)
head(Rateprof)


## -----------------------------------------------------------------------------
hist(Rateprof$quality, main="Distribution of Quality Ratings", xlab="Quality Rating")



## -----------------------------------------------------------------------------
par(mfrow = c(2, 2))

hist(Rateprof$easiness, main="Distribution of easiness", xlab="easiness")
barplot(table(Rateprof$gender))
barplot(table(Rateprof$pepper))
barplot(table(Rateprof$discipline))


## -----------------------------------------------------------------------------
par(mfrow = c(2, 2))
plot(Rateprof$quality, Rateprof$easiness, main="Quality vs. Easiness", xlab="Quality Rating", ylab="Easiness Rating")
boxplot(quality ~ gender, data=Rateprof, main="Quality Ratings by Gender")
boxplot(quality ~ pepper, data=Rateprof, main="Quality Ratings by Attractiveness")
boxplot(quality ~ discipline, data=Rateprof, main="Quality Ratings by Discipline")



## -----------------------------------------------------------------------------

fit <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + 
                  factor(gender)*easiness + factor(discipline)*easiness, 
          data = Rateprof)


qqnorm(residuals(fit))
qqline(residuals(fit))


## -----------------------------------------------------------------------------
plot(fitted(fit), residuals(fit))
abline(h=0, col="red")


## ----include=FALSE------------------------------------------------------------
vif(fit,type = 'predictor')



## ---- include=FALSE-----------------------------------------------------------
model_summary <- summary(fit)
model_anova <- anova(fit)
print(model_summary)


## ---- include=FALSE-----------------------------------------------------------
conf_int <- confint(fit, level = 0.95)[c("easiness", "factor(pepper)yes"), ]

print(conf_int)


