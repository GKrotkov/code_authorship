## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, echo=FALSE-----------------------------------------------
library(alr4)
library(bestglm)
library(ggplot2)
library(GGally)
library(DescTools)
library(modelsummary)


## ---- fig.width=4, fig.height=3, fig.cap="Gender count"-----------------------
ggplot(Rateprof, aes(x=as.factor(gender))) + geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7) ) + xlab("Gender") + ggtitle("Count for gender")


## ---- fig.width=4, fig.height=3, fig.cap="Attractiveness count "--------------
ggplot(Rateprof, aes(x=as.factor(pepper))) + geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7)) + xlab("Attractive (binary)") + ggtitle("Attractiveness count")


## ---- fig.width=4, fig.height=3, fig.cap="Course easiness histogram.", echo=FALSE----
m_mean = mean(Rateprof$easiness)
m_med = median(Rateprof$easiness)
m_sd = sd(Rateprof$easiness)
hist(Rateprof$easiness, main="Histogram for easiness", xlab="Easiness (1-5 scale)") 


## ---- fig.width=4, fig.height=3, fig.cap="Course disciplines count"-----------
ggplot(Rateprof, aes(x=as.factor(discipline))) + geom_bar(color="blue", fill=rgb(0.1,0.4,0.5,0.7) ) + xlab("Discipline") + ggtitle("Count for disciplines")


## ---- fig.width=4, fig.height=3, fig.cap="Course quality histogram", echo=FALSE----
q_mean = mean(Rateprof$quality)
q_med = median(Rateprof$quality)
q_sd = sd(Rateprof$quality)
hist(Rateprof$quality, main="Histogram for quality", xlab="Quality (1-5 scale)")


## ---- message=FALSE, fig.cap="Pairwise relationships"-------------------------
ggpairs(Rateprof[c("gender","pepper","easiness","discipline", "quality")])



## -----------------------------------------------------------------------------
m = lm(quality ~ easiness + easiness*gender + easiness*pepper + discipline*easiness, data=Rateprof[c("gender","pepper","easiness","discipline", "quality")])


## ---- fig.cap="Diagnostic plots"----------------------------------------------
par(mfrow=c(2,2))
plot(m, caption="Diagnostics")


## ---- message=FALSE, echo=FALSE-----------------------------------------------
#summary(m)


## ---- message=FALSE, echo=FALSE-----------------------------------------------
m2 = lm(quality ~ easiness + discipline + easiness*gender + easiness*pepper, data=Rateprof[c("gender","pepper","easiness","discipline", "quality")])
m3 = lm(quality ~ easiness + gender + easiness*pepper + discipline*easiness, data=Rateprof[c("gender","pepper","easiness","discipline", "quality")])

#modelsummary(list("Model 1" = m, "Model 2" = m2, "Model 3" = m3), gof_map = c("r.squared", "nobs"))
#anova(m2,m)
#anova(m3,m)



## ---- echo=FALSE--------------------------------------------------------------
finalm = step(m, direction = "both", trace = 0)
#summary(finalm)
#confint(finalm)

