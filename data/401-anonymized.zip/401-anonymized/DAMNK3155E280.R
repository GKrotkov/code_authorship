## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(alr4)


## ---- include=TRUE------------------------------------------------------------

data <- Rateprof
rel_data <- data[, c("quality", "gender", "pepper", "easiness", "discipline")]

head(rel_data)


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(quality)) + 
  geom_histogram(binwidth=0.2, fill="azure", color="black") + 
  labs(title="Histogram of instructor average quality ratings",
       x="Quality (scale from 1 to 5)", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(gender)) + 
  geom_bar(fill="azure", color="black") + 
  labs(title="Distribution of instructor gender",
       x="Gender", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(pepper)) + 
  geom_bar(fill="azure", color="black") + 
  labs(title="Distribution of instructor attractiveness consensus",
       x="Attractive", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(easiness)) + 
  geom_histogram(binwidth=0.2, fill="azure", color="black") + 
  labs(title="Histogram of average easiness of instructor's course",
       x="Easiness (scale of 1 to 5)", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(discipline)) + 
  geom_bar(fill="azure", color="black") + 
  labs(title="Distribution of instructor discipline",
       x="Discipline", 
       y="Count") +
  theme_minimal()


## ---- include=TRUE------------------------------------------------------------
ggplot(data, aes(x = gender, y = quality)) +
  geom_boxplot(fill="azure") +
  labs(title = "Average quality ratings by instructor gender", x = "Gender", y = "Quality (scale from 1 to 5)") +
  theme_minimal()


## ---- include=TRUE------------------------------------------------------------
ggplot(data, aes(x = pepper, y = quality)) +
  geom_boxplot(fill="azure") +
  labs(title = "Average quality ratings by attractiveness consensus", x = "Attractive", y = "Quality (scale from 1 to 5)") +
  theme_minimal()


## ---- include=TRUE, fig.width=6, fig.height=3---------------------------------
ggplot(data, aes(x = easiness, 
                  y = quality)) +
  geom_point(alpha=0.45) +
  labs(x = "Easiness (scale from 1 to 5)",
       y = "Quality (scale from 1 to 5)",
       title = "Scatterplot of average quality vs easiness") +
  theme_minimal()


## ---- include=TRUE------------------------------------------------------------
ggplot(data, aes(x = discipline, y = quality)) +
  geom_boxplot(fill="azure") +
  labs(title = "Average Quality by Discipline", x = "Discipline", y = "Quality (scale from 1 to 5)") +
  theme_minimal()


## -----------------------------------------------------------------------------
fit <- lm(quality ~ gender + easiness * pepper + discipline + easiness:gender + easiness:discipline, data = rel_data)
red_fit <- lm(quality ~ gender + easiness * pepper + discipline, data = rel_data)

summary(fit)


## -----------------------------------------------------------------------------
anova(red_fit, fit)


## -----------------------------------------------------------------------------
summary(red_fit)


## -----------------------------------------------------------------------------
confint(red_fit, "(Intercept)", level=0.95)


## -----------------------------------------------------------------------------
confint(red_fit, "easiness", level=0.95)


## -----------------------------------------------------------------------------
confint(red_fit, "pepperyes", level=0.95)


## -----------------------------------------------------------------------------
confint(red_fit, "disciplineSTEM", level=0.95)


## -----------------------------------------------------------------------------
confint(red_fit, "gendermale", level=0.95)


## -----------------------------------------------------------------------------
confint(red_fit, "easiness:pepperyes", level=0.95)


## ---- fig.width=6, fig.height=3-----------------------------------------------
plot(red_fit, which = 1)


## ---- fig.width=6, fig.height=3-----------------------------------------------
plot(red_fit, which = 2)

