## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse) 
library(ggplot2) 
library(dplyr)
library(modelsummary)
library(broom)
library(conflicted)
conflict_prefer("filter", "dplyr")
conflict_prefer("lag", "dplyr")


## ---- include = FALSE---------------------------------------------------------
sleep <- read_csv("/Users/lilyy/Downloads/cmu-sleep.csv", show_col_types = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Total Sleep Time Histogram"---------
hist((sleep$TotalSleepTime), main = "Histogram of Total Sleep Time", xlab="Minutes", ylab="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Term GPA Histogram"-----------------
hist((sleep$term_gpa), main = "Histogram of Term GPA", xlab="GPA (out of 4.0)", ylab="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Cumulative GPA Histogram"-----------
hist((sleep$cum_gpa), main = "Histogram of Cumulative GPA", xlab="GPA (out of 4.0)", ylab="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Sleep time vs term GPA"-------------
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + xlab("Total Sleep Time (minutes)") + ylab("Term GPA (out of 4.0)") + labs(title="Total Sleep Time vs Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Sleep time vs exponentiated term GPA"----
ggplot(sleep, aes(x = TotalSleepTime, y = 2^(term_gpa))) + geom_point() + xlab("Total Sleep Time (minutes)") + ylab("Exponentiated Term GPA (out of 16.0)") + labs(title="Total Sleep Time vs Exponentiated Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Residual Plot"----------------------
exp <- 2^(sleep$term_gpa)
lin_reg <- lm(exp ~ sleep$TotalSleepTime, data = sleep)

resid <- data.frame(Observation = sleep$TotalSleepTime, Residuals = residuals(lin_reg))

ggplot(resid, aes(x = Observation, y = Residuals)) + geom_point() + labs(x = "Total Sleep Time (minutes)", y = "Residuals") + ggtitle("Scatterplot of Residuals vs Total Sleep Time")


## ---- fig.width=4, fig.height=3, fig.cap="QQ plot"----------------------------
qqnorm(lin_reg$residuals)
qqline(lin_reg$residuals)


## ---- include = FALSE---------------------------------------------------------
exp <- 2^(sleep$term_gpa)
lin_reg <- lm(exp ~ sleep$TotalSleepTime, data = sleep)
modelsummary(list("Sleep vs GPA Model" = lin_reg))
summary(lin_reg)


## ---- include = FALSE---------------------------------------------------------
confint(lin_reg, level = 0.95)


## ---- fig.width=4, fig.height=3, fig.cap="Cumulative GPA vs Term GPA"---------

ggplot(resid, aes(x = sleep$cum_gpa, y = sleep$term_gpa)) + geom_point() + labs(x = "Cumulative GPA (out of 4.0)", y = "Term GPA (out of 4.0)") + ggtitle("Scatterplot of Cumulative GPA vs Term GPA")

