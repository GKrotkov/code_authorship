## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message = FALSE---------------------------------------------------------
library(alr4)
library(ggplot2)
library(jtools)
library(bestglm)
library(broom)


## ---- message = FALSE---------------------------------------------------------
df <- Rateprof


## ---- fig.width=6, fig.height=3, fig.cap="Histogram of Quality"---------------
ggplot(df, aes(x = quality)) + 
  geom_histogram(colour = 1, binwidth = 0.5) +
  labs(x = "Quality", y = "Frequency") + xlim(1,5)


## ---- fig.width=6, fig.height=3, fig.cap="Histogram of (Quality)^2"-----------
ggplot(df, aes(x = quality^(2))) + 
  geom_histogram(colour = 1, binwidth = 2.5) +
  labs(x = "(Quality)^2", y = "Frequency")


## ---- fig.width=6, fig.height=3, fig.cap="Histogram of Gender"----------------
ggplot(df, aes(x = gender)) + 
  geom_bar(colour = 1) +
  labs(x = "Gender", y = "Frequency")


## ---- fig.width=6, fig.height=3, fig.cap="Histogram of Pepper"----------------
ggplot(df, aes(x = pepper)) + 
  geom_bar(colour = 1) +
  labs(x = "Attractiveness", y = "Frequency")


## ---- fig.width=6, fig.height=3, fig.cap="Histogram of Discipline"------------
ggplot(df, aes(x = discipline)) + 
  geom_bar(colour = 1) +
  labs(x = "Discipline", y = "Frequency")


## ---- fig.width=6, fig.height=3, fig.cap="Histogram of Easiness"--------------
ggplot(df, aes(x = easiness)) + 
  geom_histogram(colour = 1, binwidth = 0.5) +
  labs(x = "Easiness", y = "Frequency") + xlim(1,5)


## ---- fig.width=6, fig.height=3, fig.cap="Boxplot of Quality vs. Gender"------
ggplot(df, aes(x = gender, y = (quality)^2)) + 
  geom_boxplot(colour = 1) +
  labs(x = "Gender", y = "Quality")


## ---- fig.width=6, fig.height=3, fig.cap="Boxplot of Quality vs. Pepper"------
ggplot(df, aes(x = pepper, y = (quality)^2)) + 
  geom_boxplot(colour = 1) +
  labs(x = "Attractiveness", y = "Quality")


## ---- fig.width=6, fig.height=3, fig.cap="Boxplot of Quality vs. Discipline"----
ggplot(df, aes(x = discipline, y = (quality)^2)) + 
  geom_boxplot(colour = 1) +
  labs(x = "Discipline", y = "Quality")


## ---- fig.width=6, fig.height=3, fig.cap="Scatterplot of Quality vs. Easiness"----
ggplot(df, aes(x = easiness, y = (quality)^2)) + 
  geom_point(colour = 1) +
  labs(x = "Easiness", y = "Quality")


## ---- fig.width=6, fig.height=3, fig.cap="Boxplot of Quality vs. Easiness by Gender"----
modelEasinessGender <- lm((quality)^2 ~ easiness + easiness:gender, data = df)

ggplot(df, aes(x = easiness, y = (quality)^2, color = gender)) + 
  geom_point() +
  geom_abline(intercept = modelEasinessGender$coefficients[1], slope = modelEasinessGender$coefficients[2], color = "pink") + 
  geom_abline(intercept = modelEasinessGender$coefficients[1], slope = modelEasinessGender$coefficients[2] + modelEasinessGender$coefficients[3], color = "turquoise") +
  labs(x = "Easiness", y = "Quality")


## ---- fig.width=6, fig.height=3, fig.cap="Boxplot of Quality vs. Easiness by Discipline"----
modelEasinessDiscipline <- lm((quality)^2 ~ easiness + easiness:discipline, data = df)

ggplot(df, aes(x = easiness, y = (quality)^2, color = discipline)) + 
  geom_point() + 
  geom_abline(intercept = modelEasinessDiscipline$coefficients[1], slope = modelEasinessDiscipline$coefficients[2], color = "pink") + 
  geom_abline(intercept = modelEasinessDiscipline$coefficients[1], slope = modelEasinessDiscipline$coefficients[2] + modelEasinessDiscipline$coefficients[3], color = "green") +
  geom_abline(intercept = modelEasinessDiscipline$coefficients[1], slope = modelEasinessDiscipline$coefficients[2] + modelEasinessDiscipline$coefficients[4], color = "turquoise") +
  geom_abline(intercept = modelEasinessDiscipline$coefficients[1], slope = modelEasinessDiscipline$coefficients[2] + modelEasinessDiscipline$coefficients[5], color = "purple") +
  labs(x = "Easiness", y = "Quality")


## -----------------------------------------------------------------------------
modelFull <- lm((quality)^2 ~ gender + pepper + discipline + easiness, data = df)
summ(modelFull)


## -----------------------------------------------------------------------------
modelReduced <- lm((quality)^2 ~ gender + pepper + easiness, data = df)
modelAdd <- lm((quality)^2 ~ gender + pepper + easiness + easiness:gender + easiness:discipline, data = df)

anova(modelReduced,modelAdd)


## -----------------------------------------------------------------------------
summ(modelReduced)


## ---- fig.width = 6, fig.height = 3, fig.cap = "Scatterplot of Residuals vs Fitted Value"----
ggplot(augment(modelReduced), aes(x = .fitted, y = .resid)) + 
  geom_point(colour = 1) + 
  labs(x = "Fitted value", y = "Residual")


## ---- fig.width = 6, fig.height = 3, fig.cap = "QQ plot"----------------------
ggplot(augment(modelReduced), aes(sample = .resid)) + 
  geom_qq() + 
  geom_qq_line() + 
  labs(x = "Theoretical quantiles", y = "Sample quantiles")

