## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
#libraries
library(alr4)
library(tidyverse)
library(broom)
library(modelsummary)
library(gridExtra)
ratings <- Rateprof


## ---- message=FALSE, fig.width=4, fig.height=4--------------------------------
# histogram of quality (#1)
ratings %>%
  ggplot(aes(x = quality)) +
  geom_histogram(fill = "chartreuse4", binwidth = 0.2, color = "black") +
  labs(x = "Quality Rating (from 1 to 5)", y = "Count", title = "Histogram of Quality")


## ---- message=FALSE-----------------------------------------------------------
# table of gender (#2)
table(ratings$gender)


## ---- message=FALSE-----------------------------------------------------------
# table of attractiveness (#3)
table(ratings$pepper)


## ---- message=FALSE, fig.width=4, fig.height=4--------------------------------
# histogram of easiness (#4)
ratings %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(fill = "palevioletred4", binwidth = 0.20, color = "black") +
  labs(x = "Easiness Rating (from 1 to 5)", y = "Count", title = "Histogram of Easiness")


## ---- message=FALSE, fig.width=4, fig.height=4--------------------------------
# bar graph of discipline (#5)
ratings %>%
  ggplot(aes(x = discipline)) +
  geom_bar(fill = "royalblue4") +
  labs(y = "Count", x = "Discipline", title = "Distribution of Discipline")


## ---- message = FALSE, fig.width=4, fig.height=4------------------------------
# plot of quality vs. gender (#6)
ratings %>%
  ggplot(aes(x = gender, y = quality)) + 
  geom_boxplot(aes(fill = gender)) + 
  labs(x = "Gender", y = "Quality (from 1 to 5)", title = "Quality vs. Gender")


## ---- message = FALSE, fig.width=4, fig.height=4------------------------------
# plot of quality vs. attractiveness (#7)
ratings %>%
  ggplot(aes(x = pepper, y = quality)) + 
  geom_boxplot(aes(fill = pepper)) + 
  labs(x = "Attractiveness", y = "Quality (from 1 to 5)", title = "Quality vs. Attractiveness")


## ---- message = FALSE, fig.width=4, fig.height=4------------------------------
# plot of quality vs. easiness (#8)
ratings %>%
  ggplot(aes(x = easiness, y = quality)) + 
  geom_point() + 
  labs(x = "Easiness", y = "Quality (from 1 to 5)", title = "Quality vs. Easiness")


## ---- message = FALSE, fig.width=4, fig.height=4------------------------------
# plot of quality vs. discipline (#9)
ratings %>%
  ggplot(aes(x = discipline, y = quality)) + 
  geom_boxplot(aes(fill = discipline)) + 
  labs(x = "Discipline", y = "Quality (from 1 to 5)", title = "Quality vs. Discipline")


## ---- message = FALSE, fig.width=4, fig.height=4------------------------------
# easiness vs quality grouped by gender (#10)
ratings %>%
  ggplot(aes(y = quality, x = easiness)) +
  geom_point(aes(color = gender)) + 
  labs(x = "Easiness", y = "Quality", title = "Easiness vs. Quality, grouped by Gender") +
  facet_wrap(~gender)


## ---- message = FALSE, fig.width=4, fig.height=4------------------------------
# easiness vs quality grouped by discipline (#11)
ratings %>%
  ggplot(aes(y = quality, x = easiness)) +
  geom_point(aes(color = discipline)) + 
  labs(x = "Easiness", y = "Quality", title = "Easiness vs. Quality, grouped by Discipline") +
  facet_wrap(~discipline)


## -----------------------------------------------------------------------------
fullregr <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = ratings)


## -----------------------------------------------------------------------------
redmod1 <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender, data = ratings)
redmod2 <- lm(quality ~ gender + pepper + easiness + discipline + easiness:discipline, data = ratings)


## -----------------------------------------------------------------------------
par(mfrow = c(2,2))
residplot <- ggplot(augment(fullregr), aes(x = .fitted, y = .resid)) +
  geom_point(color = "tomato3") +
  geom_hline(yintercept = 0, color = "blue") +
  labs(x = "Fitted Values", y = "Residuals")

qqplot <- ggplot(augment(fullregr), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles")

grid.arrange(residplot, qqplot, nrow = 1)


## -----------------------------------------------------------------------------
ratingsconfint <- confint(fullregr)
ratings.table <- data.frame(
  Coefficient = rownames(ratingsconfint),
  Lower_Bound = ratingsconfint[, 1],
  Upper_Bound = ratingsconfint[, 2]
)
#ratings.table


## -----------------------------------------------------------------------------
anova(fullregr, redmod1)
anova(fullregr, redmod2)
#modelsummary(list("Model 1" = fullregr, "Model 2" = redmod1, "Model 3" = redmod2),
             #gof_map = c("r.squared", "nobs"))

