## ----message=FALSE,include = FALSE--------------------------------------------
library(tidyverse)
library(alr4)


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Barplot of Instructor's Gender"----
barplot(table(Rateprof$gender), xlab = "Instructor's Gender", ylab = "Count")


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Barplot of Instructor's Attractiveness"----
barplot(table(Rateprof$pepper), xlab = "Instructor's Attractiveness", ylab = "Count")


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Histogram of Average Easiness Rating "----
hist(Rateprof$easiness, xlab = "Average Easiness Rating", main ="")


## ----echo = FALSE, fig.width=6, fig.height=3, fig.cap= "Barplot of Instructor's Discipline"----
barplot(table(Rateprof$discipline), xlab = "Instructor's Discipline", ylab = "Count")


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Histogram of Average Quality Rating"----
hist(Rateprof$quality, xlab = "Average Quality Rating", main ="")


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Scatterplot of Average Quality Rating vs Average Easiness Rating"----
plot(y = Rateprof$quality, x = Rateprof$easiness, xlab = "Average Easiness Rating", ylab = "Average Quality Rating", main ="")


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Boxplot of Average Quality Rating vs Instructor's Gender"----
boxplot(Rateprof$quality~Rateprof$gender, xlab = "Instructor's Gender", ylab = "Average Quality Rating")


## ----echo = FALSE, fig.width=4, fig.height=3, fig.cap= "Boxplot of Average Quality Rating vs Instructor's Attractiveness"----
boxplot(Rateprof$quality~Rateprof$pepper, xlab = "Instructor's Attractiveness", ylab = "Average Quality Rating")


## ----echo = FALSE, fig.width=6, fig.height=3, fig.cap= "Boxplot of Average Quality Rating vs Instructor's Discipline"----
boxplot(Rateprof$quality~Rateprof$discipline, xlab = "Instructor's Discipline", ylab = "Average Quality Rating")


## ----  echo = FALSE,  fig.width=4, fig.height=3, fig.cap="Residual Plot of Average Easiness Rating vs Residuals for Reduced Model"----
lm <- lm(data = Rateprof, log(quality)~gender+pepper+discipline+easiness)
residuals <- residuals(lm)
plot(Rateprof$easiness, residuals, xlab = "Average Easiness Rating", ylab = "Residuals")


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Residual Plot of Fitted Values vs Residuals for Reduced Model"----
fitted_values <- predict(lm)
plot(fitted_values, residuals, xlab = "Fitted Values", ylab = "Residuals")



## ----  echo = FALSE, fig.width=4, fig.height=3, fig.cap="Normal Q-Q Plot for Reduced Model"----
qqnorm(residuals)
qqline(residuals, col = "red")


## ---- message=FALSE, echo=FALSE-----------------------------------------------
library(broom)
library(kableExtra)
kable(tidy(lm),caption = "Reduced Model Estimates")


## ---- message = FALSE, echo=FALSE---------------------------------------------
sum <- confint(lm)
kable(sum, 
      format = "markdown", 
      caption = "95% Confidence Intervals for Reduced Model Estimates") 


## ---- include = FALSE---------------------------------------------------------
cooksd <- cooks.distance(lm)

# Set the threshold values
f_threshold_high <- qf(0.50, 6,359)

sum(cooksd >= f_threshold_high)


## ---- echo=FALSE--------------------------------------------------------------
lm2 <- lm(data = Rateprof, log(quality)~gender+pepper+discipline+easiness + easiness:discipline + gender:easiness)
kable(tidy(lm2),caption = "Full Model Estimates")


## ---- echo = FALSE, fig.width=4, fig.height=3, fig.cap="Residual Plot of Fitted Values vs Residuals for Full Model"----
fitted_values2 <- predict(lm2)
residuals2 <- residuals(lm2)
plot(fitted_values2, residuals2, xlab = "Fitted Values", ylab = "Residuals")



## ----  echo = FALSE, fig.width=4, fig.height=3, fig.cap="Normal Q-Q Plot for Reduced Model"----
qqnorm(residuals2)
qqline(residuals2, col = "red")


## ----  echo=FALSE-------------------------------------------------------------
lm2 <- lm(data = Rateprof, log(quality)~gender+pepper+discipline+easiness + easiness:discipline + gender:easiness)
kable(anova(lm, lm2),caption = "ANOVA Test Between Reduced and Full Model")

