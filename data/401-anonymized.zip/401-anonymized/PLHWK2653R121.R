## ----EDA initial, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

data <- read.csv("cmu-sleep.csv")
head(data)

library(ggplot2)
library(patchwork)

ggplot(data, aes(x = TotalSleepTime/60)) +
  geom_histogram() +
  labs(x = "Total Sleep Time (hours)", 
       y = "Count", 
       caption = "Figure 1.  Frequency of Total Sleep Time")

ggplot(data, aes(x = term_gpa)) + 
  geom_histogram() +
  labs(x = "Term GPA (out of 4.0)", 
       y = "Count", 
       caption = "Figure 2.  Frequency of Term GPA")

ggplot(data, aes(x = cum_gpa)) + 
  geom_histogram() +
  labs(x = "Cumulative GPA (out of 4.0)", 
       y = "Count", 
       caption = "Figure 3.  Frequency of Cumulative GPA")

mean_tst <- (mean(data$TotalSleepTime))/60
median_tst <- (median(data$TotalSleepTime)) /60

median_term_gpa = median(data$term_gpa)
mean_term_gpa = mean(data$term_gpa)

median_cum_gpa = median(data$cum_gpa)
mean_cum_gpa = mean(data$cum_gpa)




## ----EDA init log, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

ggplot(data, aes(x = term_gpa)) + 
  geom_histogram() +
  scale_x_log10() + 
  labs(x = "Log Term GPA (out of 4.0)", 
       y = "Count", 
       caption = "Figure 4.  Frequency of Log Term GPA")

ggplot(data, aes(x = cum_gpa)) + 
  geom_histogram() +
  scale_x_log10() +
  labs(x = "Log Cumulative GPA (out of 4.0)", 
       y = "Count", 
       caption = "Figure 5.  Frequency of Log Cumulative GPA")



## ----EDA boxplots, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

term_box_plot = boxplot(data$term_gpa,
                        ylab = "Term GPA (out of 4.0)", 
                        main = "Figure 6.  Boxplot of Term GPA")

sleep_box_plot = boxplot(data$TotalSleepTime / 60,
                         ylab = "Total Sleep Time (hours)",
                         main = "Figure 7.  Boxplot of Total Sleep Time")




## ----EDA removing outliers, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

#find Q1, Q3, and interquartile range for values in column termGPA
term_Q1 <- quantile(data$term_gpa, .25)
term_Q3 <- quantile(data$term_gpa, .75)
term_IQR <- IQR(data$term_gpa)

sleep_Q1 <- quantile(data$TotalSleepTime, .25)
sleep_Q3 <- quantile(data$TotalSleepTime, .75)
sleep_IQR <- IQR(data$TotalSleepTime)

#only keep rows in dataframe that have values within 1.5*IQR of Q1 and Q3
no_outliers <- subset(data, data$term_gpa> (term_Q1 - 1.5*term_IQR) & data$term_gpa< (term_Q3 + 1.5*term_IQR) & data$TotalSleepTime> (sleep_Q1 - 1.5*sleep_IQR) & data$TotalSleepTime< (sleep_Q3 + 1.5*sleep_IQR))

#view row and column count of new data frame
dim(no_outliers)

# now let's try making our plots without these outliers...
ggplot(no_outliers, aes(x = term_gpa)) + 
  geom_histogram() +
  labs(x = "Term GPA (out of 4)", 
       y = "Count", 
       caption = "Figure 8.  Frequency of Term GPA without outliers")

ggplot(no_outliers, aes(x = TotalSleepTime/60)) + 
  geom_histogram() +
  labs(x = "Total Sleep Time (hours)", 
       y = "Count", 
       caption = "Figure 9.  Frequency of Total Sleep Time without outliers")




## ----EDA scatter, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

ggplot(no_outliers, aes(x = TotalSleepTime/60, y = term_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(x = "Total Sleep Time (hours)",
       y = "Term GPA",
       caption = "Figure 10.  Total Sleep Time versus Term GPA")



## ----Methods lm, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

model <- lm(term_gpa ~ I(TotalSleepTime/60), data = no_outliers)
summary(model)

b1_est <- coef(summary(model))[, "Estimate"][2]
b1_est

confidence <- confint(model, level=0.95)
confidence

lower_bd <- confidence[,"2.5 %"][2]
lower_bd

upper_bd <- confidence[,"97.5 %"][2]
upper_bd

t_stat <- coef(summary(model))[, "t value"][2]
t_stat

p_val <- coef(summary(model))[, "Pr(>|t|)"][2]
p_val

degf <- summary(model)$df[2]
degf



## ----Methods Cooks, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

library(broom)
head(augment(model))

g1 <- augment(model) |> 
  ggplot(aes(x = `I(TotalSleepTime/60)`, y = .cooksd)) +
  geom_point() +
  labs(x = "Total Sleep Time (hours)",
       y = "Cook's Distance",
       caption = "Figure 11.  Cook's Distance using Total Sleep Time")

g2 <- augment(model) |> 
  ggplot(aes(x = term_gpa, y = .cooksd)) +
  geom_point() +
  labs(x = "Term GPA (out of 4.0)",
       y = "Cook's Distance",
       caption = "Figure 12.  Cook's Distance using Term GPA")

g1 | g2



## ----Methods Residual, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

augment(model) |> 
  ggplot( aes(x = `I(TotalSleepTime/60)`, y = .resid)) +
  geom_point() +
  geom_hline(yintercept=0) + 
  labs(x = "Total Sleep Time (hours)", 
       y = "Residual",
       caption = "Figure 13.  Residual plot after fitting to the model")



## ----Methods QQ Plot, echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----

ggplot(augment(model),
       aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles",
       y = "Sample quantiles",
       caption = "Figure 14.  QQ Plot of Residuals following fititng to the model.")


