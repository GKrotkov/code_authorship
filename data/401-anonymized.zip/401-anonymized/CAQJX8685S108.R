## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----  include = FALSE--------------------------------------------------------
df <- read.csv("cmu-sleep.csv", header=TRUE, stringsAsFactors = FALSE)


## ---- fig.width=5, fig.height=4, fig.cap = "Term GPA Histogram"---------------
hist(df$term_gpa, main = "Term GPA Histogram", xlab = "Term GPA")


## ---- fig.width=5, fig.height=4, fig.cap = "Cumulative GPA Histogram"---------
hist(df$cum_gpa, main = "Cumulative GPA Histogram", xlab = "Cumulative GPA")


## ---- fig.width=5, fig.height=4, fig.cap="Average Sleep Time Histogram"-------
hist(df$TotalSleepTime, main = "Average Sleep Time Histogram", xlab = "Average Sleep Time (minutes)")


## ---- fig.width=5, fig.height=4, fig.cap="Term GPA vs Average Night Sleep Time"----
plot(df$TotalSleepTime, df$term_gpa, main = "Term GPA vs Average Night Sleep Time", xlab = "Average Sleep Time (minutes)", ylab = "Term GPA")


## ---- fig.width=5, fig.height=4, fig.cap="Cumulative GPA vs Average Night Sleep Time"----
plot(df$TotalSleepTime, df$cum_gpa, main = "Cumulative GPA vs Average Night Sleep Time", xlab = "Average Sleep Time (minutes)", ylab = "Cumulative GPA")


## ---- include = FALSE---------------------------------------------------------
myLM = lm(term_gpa ~ TotalSleepTime + cum_gpa, data = df)
summary(myLM)


## ---- fig.width=5, fig.height=4, fig.cap="Residual Fits"----------------------
res = resid(myLM)
plot(fitted(myLM), res, main = "Residual Fits", xlab = "fitted values", ylab = "Residuals")
abline(0, 0)


## ---- fig.width=5, fig.height=4, fig.cap="Normal Q-Q Plot"--------------------
qqnorm(res)
qqline(res)

