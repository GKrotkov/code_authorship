## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=4, fig.cap="Distribution of Total Sleep Time of Students"----
library(ggplot2)
sleep <- read.csv("C:\\Users\\raega\\Downloads\\cmu-sleep.csv")
ggplot(sleep, aes(x=TotalSleepTime))+geom_histogram(binwidth=10, color="black",fill="gray")+geom_vline(aes(xintercept=mean(TotalSleepTime)),linewidth=1)+labs(x="Total Sleep Time (minutes)", y="Count")


## ---- include=FALSE-----------------------------------------------------------
summary(sleep$TotalSleepTime)
sd(sleep$TotalSleepTime)


## ---- fig.height=4, fig.width=4, fig.cap="Distribution of Student's GPAs out of 4.0 while being Studied"----
ggplot(sleep, aes(x=term_gpa))+geom_histogram(binwidth=0.05,color="black",fill="gray")+geom_vline(aes(xintercept=mean(term_gpa)),linewidth=1)+labs(x="Student's GPA while Studied (out of 4.0)",y="Count")


## ---- include=FALSE-----------------------------------------------------------
summary(sleep$term_gpa)
sd(sleep$term_gpa)


## ---- fig.width=4, fig.height=4, fig.cap="Distribution of Students' GPAs out of 4.0 before being Studied"----
ggplot(sleep,aes(x=cum_gpa))+geom_histogram(binwidth=0.05,color="black",fill="gray")+geom_vline(aes(xintercept=mean(cum_gpa)),linewidth=1)+labs(x="Student's GPA before being Studied (out of 4.0)", y="Count")


## ---- include=FALSE-----------------------------------------------------------
summary(sleep$cum_gpa)
sd(sleep$cum_gpa)


## ---- fig.width=4, fig.height=4, fig.cap="Each Student's GPA for their Average Total Amount of Sleep"----
ggplot(sleep, aes(x=TotalSleepTime, y=term_gpa))+geom_point(size=1)+labs(x="Total Sleep Time (minutes)",y="Student's GPA while Studied (out of 4.0)")


## ---- fig.width=4, fig.height=4, fig.cap="Each Student's GPA for their Average Total Amount of Sleep"----
ggplot(sleep, aes(x=TotalSleepTime, y=cum_gpa))+geom_point(size=1)+labs(x="Total Sleep Time (minutes)",y="Student's GPA before being Studied (out of 4.0)")


## ---- fig.width=4, fig.height=4, fig.cap="Residual Plot from the Fitted Line"----
sleep_fit <- lm(sleep$term_gpa ~ sleep$TotalSleepTime)
res <- resid(sleep_fit)
ggplot(sleep_fit, aes(x=.fitted,y=.resid))+geom_point()+geom_hline(yintercept=0)+labs(x="Average Total Amount of Sleep", y="Residual")


## ---- include=FALSE-----------------------------------------------------------
summary(sleep_fit)
confint(sleep_fit, level=0.95)

