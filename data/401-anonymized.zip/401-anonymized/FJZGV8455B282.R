## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
Dataset = Rateprof
library(ggplot2)
library(GGally)
library(dplyr)
library(modelsummary)



## ---- fig.width=3, fig.height=3, fig.cap="Histogram of Easiness."-------------
hist(Dataset$easiness,
     xlab = "Average easiness rating, between 1 to 5, 5 for best", main = "Histogram of Easiness")


## ---- fig.width=3, fig.height=3, fig.cap="Histogram of Quality."--------------
hist(Dataset$quality,
     xlab = "Average quality rating, between 1 to 5, 5 for best", main = "Histogram of Quality")


## ----fig.width=3, fig.height=3, fig.cap="Scatter plot between Quality and Easiness."----
plot(Dataset$quality ~ Dataset$easiness, 
     xlab= "Average easiness rating", 
     ylab = "Average quality rating", 
     main = "Quality VS Easiness")



## ----fig.width=3, fig.height=3, fig.cap="Boxplot between Quality and Gender."----
boxplot(Dataset$quality ~ Dataset$gender,
        col='steelblue',
        main='Box plot of quality for different gender',
        xlab='Gender',
        ylab='Quality') 


## ----fig.width=3, fig.height=3, fig.cap="Boxplot between Quality and Pepper."----
boxplot(Dataset$quality ~ Dataset$pepper,
        col='steelblue',
        main='Box plot of quality for different pepper',
        xlab='Attractiveness',
        ylab='Quality') 




## ----fig.width=3, fig.height=3, fig.cap="Boxplot between Quality and Discipline."----

boxplot(Dataset$quality ~ Dataset$discipline,
        col='steelblue',
        main='Box plot of quality for different disciplines',
        xlab='Discipline',
        ylab='Quality') 



## -----------------------------------------------------------------------------
model = lm(quality~factor(gender)+factor(pepper)+factor(discipline)+easiness,data = Dataset)

model_all = lm(quality~gender+pepper+easiness*discipline+easiness:gender,data = Dataset)
model_red = lm(quality~gender+pepper+discipline+easiness,data = Dataset)
anova(model_red,model_all)



## ----fig.width=3, fig.height=3,fig.cap="Multivaraite regression model"--------
model = lm(quality~factor(gender)+factor(pepper)+factor(discipline)+easiness,data = Dataset)

modelsummary(list("Multivaraite regression model" = model))



## ----fig.width=4, fig.height=3------------------------------------------------
plot(model)

