## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(warning = FALSE, echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library("alr4")
data <- Rateprof


## -----------------------------------------------------------------------------

library(ggplot2)
library(gridExtra)

plot1 <- ggplot(data, aes(x = pepper, fill = pepper)) +
  geom_bar() +
  labs(title = "Attractiveness of Professors", x = "Attractiveness", y = "Frequency") +
  theme(legend.position = "none")

plot2 <- ggplot(data, aes(x = gender, fill = gender)) +
  geom_bar() +
  labs(title = "Gender of Professors", x = "Gender", y = "Frequency") +
  theme(legend.position = "none")

plot3 <- ggplot(data, aes(x = discipline, fill = discipline)) +
  geom_bar() +
  labs(title = "Discipline of class", x = "Discipline", y = "Frequency") +
  theme(legend.position = "none")

plot4 <- ggplot(data, aes(x = easiness, fill = easiness)) +
  geom_histogram(binwidth = 0.5) + 
  labs(title = "Easiness of class", x = "Easiness", y = "Frequency") +
  theme(legend.position = "none")

grid.arrange(plot1, plot2, plot3, plot4, ncol = 2, nrow = 2)



## -----------------------------------------------------------------------------
ggplot(data, aes(x = quality, fill = quality)) +
  geom_histogram(binwidth = 0.5) + 
  labs(title = "Quality of class", x = "Quality", y = "Frequency") +
  theme(legend.position = "none")


## ---- message=FALSE-----------------------------------------------------------
library(GGally)
library(dplyr)


data |>
  select(pepper, gender, 
         discipline, easiness, quality) |>
  
  ggpairs()


## -----------------------------------------------------------------------------
model <- lm(quality ~ pepper + gender + discipline + easiness + easiness:gender + 
    easiness:discipline, data = Rateprof)


## -----------------------------------------------------------------------------
plot(fitted(model), residuals(model), xlab = "Fitted Values", ylab = "Residuals", main = "Residuals of Model vs. Fitted Values")


## -----------------------------------------------------------------------------
qqnorm(residuals(model))
qqline(residuals(model))


## -----------------------------------------------------------------------------
summary(model)


## ---- results = 'hide'--------------------------------------------------------
confint(model)


## ---- results = 'hide'--------------------------------------------------------
reduced_model1 <- lm(quality ~ pepper + gender + easiness + easiness:gender + easiness:discipline, data = Rateprof)
anova(reduced_model1, model)


## ---- results = 'hide'--------------------------------------------------------
reduced_model2 <- lm(quality ~ pepper + gender + discipline + easiness + easiness:gender, data = Rateprof)
anova(reduced_model2, model)


