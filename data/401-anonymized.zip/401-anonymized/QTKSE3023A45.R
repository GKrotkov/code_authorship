## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library("ggplot2")
library("cowplot")
library(broom)
library(dplyr)


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
# Continuous variables layout matrix (first 2 plots)
layout_continuous <- matrix(c(1, 2), nrow = 1, ncol = 2, byrow = TRUE)

# Set up the layout for continuous variables
layout(layout_continuous)

# Plot the histograms for continuous variables
hist(Rateprof$quality, xlab = "Quality", main = "Fig 1. Histogram: Quality Ratings")
hist(Rateprof$easiness, xlab = "Easiness", main = "Fig 2. Histogram: Class Easiness")


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
par(cex.axis = 0.8)

# Categorical variables layout matrix (last 3 plots)
par(mfrow = c(2, 2))

# Plot the barplots for categorical variables
barplot(table(Rateprof$pepper), names = c("No", "Yes"), 
        xlab = "Is the professor attractive?", ylab = "Count", 
        main = "Fig 3. Barplot: Professor Attractiveness")
barplot(table(Rateprof$gender), names = c("Female", "Male"), 
        xlab = "Gender", ylab = "Count", 
        main = "Fig 4. Barplot: Professor Gender")
barplot(table(Rateprof$discipline), 
        names = c("Hum", "SocSci", "STEM", "Pre-prof"), 
        xlab = "Discipline", ylab = "Count", 
        main = "Fig 5. Barplot: Professor Discipline")


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

scatter1 <- ggplot(data = Rateprof, aes(x=easiness, y=quality))+
  geom_point(aes(color=gender)) + 
  geom_smooth(formula = y ~ x, method ='lm')
scatter2 <- ggplot(data = Rateprof, aes(x=easiness, y=quality))+
  geom_point(aes(color=discipline)) + 
  geom_smooth(formula = y ~ x, method ='lm')

cowplot::plot_grid(scatter1, scatter2, labels = "AUTO", ncol=1)


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
# Set up the layout for the first three graphs
par(mfrow = c(1, 3))
par(cex.axis = 0.7)

boxplot(quality ~ gender, data = Rateprof,
        names = c("Females", "Males"),
        ylab = "Quality score",
        xlab = "Gender",
        main = "Fig 6. Quality and Gender")

boxplot(quality ~ pepper, data = Rateprof,
        names = c("Not attractive", "Attractive"),
        ylab = "Quality score",
        xlab = "Attractiveness",
        main = "Fig 7. Quality and Attractiveness")

boxplot(quality ~ discipline, data = Rateprof,
        names = c("Hum", "SSci", "STEM", "P-prof"),
        ylab = "Quality score",
        xlab = "Discipline",
        main = "Fig 8. Quality and Discipline")


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
par(mfrow = c(1, 2))
par(cex.axis = 0.8)
par(cex.main = 0.95)

boxplot(easiness ~ gender, data = Rateprof,
        names = c("Females", "Males"),
        ylab = "Easiness score",
        xlab = "Gender",
        main = "Fig 9. Boxplot: Easiness and Gender")

boxplot(easiness ~ discipline, data = Rateprof,
        names = c("Hum", "SocSci", "STEM", "Pre-prof "),
        ylab = "Easiness score",
        xlab = "Discipline",
        main = "Fig 10. Boxplot: Easiness and Discipline")


## -----------------------------------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
reg_full <- lm(quality ~ easiness + gender +  pepper + discipline, data = Rateprof)

p1 <- augment(reg_full) |>
ggplot(aes(x = easiness, y = .resid)) +
geom_point() +
geom_hline(yintercept=0, linetype="dashed", color="red") +
labs(x = "Easiness", y = "Residual")

p2 <- augment(reg_full) |>
ggplot(aes(x = .fitted, y = .resid)) +
 geom_hline(yintercept=0, linetype="dashed", color="red") +
geom_point() +
labs(x = "Fitted values", y = "Residual")

cowplot::plot_grid(p1, p2, labels = c("C","D"))


## -----------------------------------------------------------------------------
p3 <- ggplot(data=Rateprof, aes(sample=residuals(reg_full))) +
  geom_qq_line(color="red", linewidth=1) +
  geom_qq() +
  ggtitle("Normal Q-Q Plot") + 
  xlab("Theoretical Quantiles") +
  ylab("Sample Quantiles") +
  theme(plot.caption = element_text(hjust = 0, size = 10, margin = margin(t = 10)))

cowplot::plot_grid(p3, labels = c("E"))

