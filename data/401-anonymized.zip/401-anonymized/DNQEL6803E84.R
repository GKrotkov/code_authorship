## ----setup, include = FALSE---------------------------------------------------
library(GGally)
library(alr4)
library(dplyr)
library(ggplot2)
library(broom)

# Quality Rating and Discipline * 
ggplot(Rateprof, aes(x = discipline, y = quality)) + geom_boxplot() + 
  labs( x = "Discipline", y = "Average Quality Rating (1 to 5)") + 
  ggtitle("Histogram Quality Rating by Discipline" )
# gender, attractiveness, ease, discipline 

# Quality Rating and Pepper *
ggplot(Rateprof, aes(x = pepper, y = quality)) + geom_boxplot() + 
  labs( x = "Attractive", y = "Instructor Attractiveness (Yes or No)") + 
  ggtitle("Histogram Quality Rating by Instructor Attractiveness" )

# Quality Rating and Gender *
ggplot(Rateprof, aes(x = gender, y = quality)) + geom_boxplot() + 
  labs( x = "Attractive", y = "Instructor Gender (female or male)") + 
  ggtitle("Histogram Quality Rating by Instructor Gender" )

# Quality Rating and Ease *
ggplot(Rateprof, aes(x = easiness, y = quality)) + geom_point() + 
  labs( x = "Easiness", y = "Average Quality Rating (1 to 5)") + 
  ggtitle("Scatterplit of Course Easiness vs Quality Rating" )

# Easiness *
ggplot(Rateprof, aes(x = easiness)) + geom_histogram() + 
  labs( x = "Easiness (1 to 5)", y = "Count") + 
  ggtitle("Histogram of Course Easiness" )

# Quality Rating - *
ggplot(Rateprof, aes(x = quality)) + geom_histogram() + 
  labs( x = "Quality (1 to 5)", y = "Count") + 
  ggtitle("Histogram of Average Quality Rating " ) 

knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
full_fit <- lm(quality ~ factor(gender) + factor(pepper) + factor(discipline) + easiness, data = Rateprof)
summary(full_fit)
confint(full_fit)
f_full_model <- lm(quality ~ easiness + factor(gender) + factor(discipline), data = Rateprof)
f_partial_model <- lm(quality ~ easiness, data = Rateprof)

anova(f_partial_model, f_full_model)
cookd <- cooks.distance(full_fit)
sorted <- sort(pf(cookd, 4, 360), decreasing = TRUE)



## ----include = FALSE, eval = FALSE--------------------------------------------
## 
## Rateprof |>
##   select(gender, pepper, discipline, easiness, quality) |>
##   ggpairs()
## #full_fit_2 <- lm(quality ~ factor(gender) + factor(pepper) + factor(discipline) + easiness, data = Rateprof)
## 


## ---- include = FALSE, eval = FALSE-------------------------------------------
## # plot the residuals
## augment(full_fit)
## 
## # residual plot for linear regression model
## ggplot(full_fit, aes(x = easiness,  y = .resid)) + geom_point() +
##   labs(x = "Total Sleep Time", y = "residuals") +
##   ggtitle("Residuals for Linear Regression Model")
## 
## resids <- resid(full_fit)
## 
## 


## ----echo=FALSE, fig.cap="Histogram of Average Quality Rating on a scale from 1, worst, to 5, best.", fig.height=3, fig.width=4----

ggplot(Rateprof, aes(x = quality)) + geom_histogram(bins = 20) + 
  labs( x = "Quality (1 to 5)", y = "Count") + 
  ggtitle("Histogram of Average Quality Rating " ) 


## ----echo=FALSE, fig.cap="Scatterplot of course easiness against average quality rating. One can see a positive linear relationship between the variables. Average quality rating and easiness are from 1, worst, to 5, best.", fig.height=3, fig.width=4----
ggplot(Rateprof, aes(x = easiness, y = quality)) + geom_point() + 
  labs( x = "Easiness Rating (1 to 5)", y = "Average Quality Rating (1 to 5)") + 
  ggtitle("Scatterplot of Course Easiness vs Quality Rating" )



## ----echo=FALSE, fig.cap="Histogram of course easiness which appears normally distributed. Easiness is from 1, worst, to 5, best.", fig.height=3, fig.width=4----

ggplot(Rateprof, aes(x = easiness)) + geom_histogram(bins = 20) + 
  labs( x = "Easiness (1 to 5)", y = "Count") + 
  ggtitle("Histogram of Course Easiness" )



## ----echo=FALSE, fig.cap="Boxplot of average quality rating by pepper attractiveness indicator. There are outliers for yes along with a higher average quality with the yes indicator.", fig.height=3, fig.width=4----
ggplot(Rateprof, aes(x = pepper, y = quality)) + geom_boxplot() + 
  labs( x = "Attractive", y = "Instructor Attractiveness (Yes or No)") + 
  ggtitle("Histogram Quality Rating by Instructor Attractiveness" )


## ----echo=FALSE, fig.width = 3, fig.height = 2.5, fig.cap="Boxplot of Instructor Discipline against average course quality. We see the same distribution for all disciplines and no outliers. Average quality rating is from 1, worst, to 5, best."----

par(mfrow = c(1, 2))
ggplot(Rateprof, aes(x = discipline, y = quality)) + geom_boxplot() + 
  labs( x = "Discipline", y = "Average Quality Rating (1 to 5)") + 
  ggtitle("Quality by Discipline" ) + labs( caption = "Figure 5.1")

ggplot(Rateprof, aes(x = gender, y = quality)) + geom_boxplot() + 
  labs( x = " Instructor Gender", y = "Average Quality Rating (1 to 5)") + 
  ggtitle("Quality by Gender" ) + labs(caption = "Figure 5.2")

#mtext("my caption", side=1, outer=TRUE, adj=0)


## ---- fig.width = 3.5, fig.height = 3, fig.cap = "Q-Q Plot for residuals of the full model. We see slightly heavy tails for the response, though we believe it is reasonable to proceed and assume approximately normal."----
resids <- resid(full_fit)
qqnorm(resids)


## ---- fig.width = 3.5, fig.height = 3, fig.cap = "Residual plot for variable easiness. There are no apparent patterns in the residuals. There is an equal quantity of points above and below the horizontal axis. We conclude no issues."----

# residual plot for linear regression model
ggplot(full_fit, aes(x = easiness,  y = .resid)) + geom_point() + 
  labs(x = "Easiness (1 to 5)", y = "Residuals") + 
  ggtitle("Residuals for Linear Model")

