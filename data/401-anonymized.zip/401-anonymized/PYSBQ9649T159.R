## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)


## ---- include = FALSE---------------------------------------------------------
data = read.csv("cmu-sleep.csv")


## ---- include = FALSE---------------------------------------------------------
nrow(data)
ncol(data)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Total Sleep Time"------
hist(data$TotalSleepTime, breaks = "Scott",
     main = NULL,
     xlab = "Average Time of Sleep Each Night (in minutes)")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of GPAs during Study"-----
hist(data$term_gpa, breaks = "Scott",
     main = NULL,
     xlab = "GPA (out of 4.0) for Classes took during Study")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of GPAs before Study"-----
hist(data$cum_gpa, breaks = "Scott",
     main = NULL,
     xlab = "GPA (out of 4.0) for Classes took before Study")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot between GPA versus Total Sleep Time"----
ggplot(data = data, aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point() + 
  labs(x = "Average Time of Sleep Each Night (in minutes)",
       y = "GPA (out of 4.0) for Classes took during Study")


## -----------------------------------------------------------------------------
library(modelsummary)
data.lm <- lm(term_gpa ~ TotalSleepTime, data)
lm.estimates <- get_estimates(data.lm)
lm.estimates <- subset(lm.estimates, select = -c(s.value,group))
knitr::kable(lm.estimates, digits = 5)


## ---- fig.width=4, fig.height=3, fig.cap="Plot of residuals versus the predictor"----
qqplot(x = data$TotalSleepTime, y = residuals(data.lm),
       main = NULL,
       xlab = "Average Time of Sleep Each Night (in minutes)",
       ylab = "Residuals")
qqline(residuals(data.lm))


## ---- fig.width=4, fig.height=3, fig.cap="Q-Q Plot of Residuals"--------------
qqnorm(residuals(data.lm),
       main = NULL,
       xlab = "Theoretical Quantiles",
       ylab = "Observed Quantiles")
qqline(residuals(data.lm))


## -----------------------------------------------------------------------------
cookd <- cooks.distance(data.lm)
f_percentile.50 <-qf(0.5, df1 = 2, df2 = 632)
influential_points <- which(cookd > f_percentile.50)

