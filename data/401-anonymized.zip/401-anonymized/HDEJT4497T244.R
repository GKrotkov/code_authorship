## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
setwd("/Users/keertananarayanan/Desktop/401/data2")
library(modelsummary)
library(vtable)
library(sandwich)
library(alr4)
library(bestglm)
library(car)
library(ggplot2)
library(xtable)
library(dplyr)


## ---- include = FALSE---------------------------------------------------------
?Rateprof
rateprof <- Rateprof


## ---- fig.cap="Summary Statistics of Easiness Variable"-----------------------
rateprof$Easiness <- as.numeric(rateprof$easiness)
rateprof$Quality <- as.numeric(rateprof$quality)
st(rateprof, vars = c('Easiness', 'Quality'))


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of Mean Easiness Scores"----
hist(rateprof$Easiness, breaks=50, xlab = "Easiness (1 = Worst, 5 = Best)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of Mean Quality Scores"----
hist(rateprof$Quality, breaks=50, xlab = "Quality (1 = Worst, 5 = Best)", ylab = "Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Attractiveness Distribution"--------

barplot(table(rateprof$pepper), names = c("No", "Yes"),
xlab = "Rated As Attractive?", ylab = "Count")

## ---- fig.width=4, fig.height=3, fig.cap="Gender Distribution"----------------

barplot(table(rateprof$gender), names = c("Female", "Male"),
xlab = "Gender", ylab = "Count")


## ---- fig.width=4, fig.height=3, fig.cap="Discipline Distribution"------------

barplot(table(rateprof$discipline), names = c("Hum", "SocSci", "STEM", "PreProf"), xlab = "Discipline", ylab = "Count")


## ---- fig.cap="Pairs Plot of Quality and Independent Variables"---------------
 pairs(Quality ~ gender + discipline + pepper + Easiness,
      data = rateprof, pch = 16, cex = 0.7)


## ---- fig.width=3, fig.height=4, fig.cap="Quality Distribution by Gender"-----
boxplot(Quality ~ gender, ylab = "Quality", data = rateprof,
xlab = "Gender", names = c("Female", "Male"),
pch = 16)


## ---- fig.width=3, fig.height=4, fig.cap="Quality Distribution by Discipline"----
boxplot(Quality ~ discipline, ylab = "Quality", data = rateprof,
xlab = "Discipline", names = c("Hum", "SocSci", "STEM", "PreProf"), pch = 16)


## ---- fig.width=3, fig.height=4, fig.cap="Quality Distribution by Attractiveness"----
boxplot(Quality ~ pepper, data = rateprof, c("No", "Yes"),
xlab = "Rated As Attractive?", ylab = "Quality", pch = 16)


## ---- fig.width=3, fig.height=4, fig.cap="Quality vs. Easiness"---------------
plot(Quality ~ Easiness, data=rateprof)


## -----------------------------------------------------------------------------
min_pep_ease <- min(rateprof$Easiness[rateprof$pepper == "yes"])


## ---- fig.width=3, fig.height=4, fig.cap="Quality vs. Easiness, Colored by Attractiveness"----
ggplot(
  data = rateprof,
  mapping = aes(x = Easiness, y = Quality, color = pepper)
) +
  geom_point() + geom_smooth(method = "lm") + geom_label(data=subset(rateprof, Easiness == min_pep_ease),
            aes(Easiness,Quality,label=round(Easiness, 2)))



## -----------------------------------------------------------------------------
rateprof$pepper_dum <- ifelse(rateprof$pepper == "no", 0, 1)


## -----------------------------------------------------------------------------
model1 <- lm(Quality ~ gender + pepper_dum + discipline + Easiness, data=rateprof)


## ---- fig.cap="Results from Full Model"---------------------------------------
modelsummary(
  list("Full Model" = model1), 
        vcov = "robust",
        statistic = c('statistic','p.value', 'conf.int'), 
        gof_map=c("r.squared","nobs"), 
        fmt = 5, 
        output = "gt",
        notes = list('The first paranthesis contains the t-statistic, the second parathesis contains the p-value, and the three paranthesis contains the 95 percent confidence interval.'))


## -----------------------------------------------------------------------------
redgen <- lm(Quality ~ pepper + discipline + Easiness + gender + Easiness:gender, data=rateprof)
reddisc <- lm(Quality ~ gender + pepper + Easiness + discipline + Easiness:discipline, data=rateprof)


## ---- fig.cap="Results from Tested Models for Gender and Discipline Effects"----
modelsummary(
  list("Full Model" = model1, 
       "Gender:Easiness" = redgen, 
       "Gender:Discipline" = reddisc), 
        vcov = "robust",
        statistic = c("t = {statistic} (p = {p.value})", 'conf.int'), 
        gof_map=c("r.squared","nobs", "aic"), 
        fmt = 5, 
        output = "gt",
        notes = list('The second row contains the t-statistic with the corresponding p-value, and the third row contains the 95 percent confidence interval.'))


## -----------------------------------------------------------------------------
pepper_noint <- lm(Quality ~ gender + pepper + Easiness, data=rateprof)
pepper_int <- lm(Quality ~ gender + pepper + Easiness + Easiness:pepper, data=rateprof)


## ---- fig.cap="Results from Tested Models"------------------------------------
modelsummary(
  list("Gender + Attractiveness + Easiness" = pepper_noint, "Gender + Attractiveness + Easiness + Easiness:Pepper" = pepper_int), 
        vcov = "robust",
        statistic = c("t = {statistic} (p = {p.value})", 'conf.int'), 
        gof_map=c("r.squared","nobs", "aic"), 
        fmt = 5, 
        output = "gt",
        notes = list('The second row contains the t-statistic with the corresponding p-value, and the third row contains the 95 percent confidence interval.'))


## ---- fig.cap="F-Test Result when Omitting Interaction"-----------------------
kable(anova(pepper_noint, pepper_int))


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Residual Values vs. Fitted Values"----
plot(pepper_int, which=1)


## ---- fig.width=4, fig.height=3, fig.cap="QQ Plot of Residual Values vs. Fitted Values"----
plot(pepper_int, which=2)


## ---- fig.width=4, fig.height=3, fig.cap="Cook's Distance of Residual Values vs. Fitted Values"----
plot(pepper_int, which=4)

