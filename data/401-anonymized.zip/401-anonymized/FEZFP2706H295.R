## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

options(warn = -1)

data = read.csv("cmu-sleep.csv")
head(data)


## -----------------------------------------------------------------------------
hist(data$TotalSleepTime, main = "Average Sleep per Night", xlab = "Time (minutes)", col = "green")


## -----------------------------------------------------------------------------
par(mfrow = c(1,2))
xlim = c(0,4)
ylim=c(0,350)
hist(data$term_gpa, main = "Spring Term GPA", xlab = "GPA (out of 4.0)", col = "red", breaks=8, xlim=xlim, ylim=ylim)
hist(data$cum_gpa, main = "Fall Term GPA", xlab = "GPA (out of 4.0)", col = "blue", breaks=8, xlim=xlim, ylim=ylim)


## -----------------------------------------------------------------------------
hist(data$term_gpa - data$cum, main = "Change in GPA from Fall to Spring Term", xlab = "GPA (out of 4.0)", col = "purple")


## -----------------------------------------------------------------------------
plot(data$TotalSleepTime, data$term_gpa, main = "Spring Term GPA vs Average Sleep per Night", xlab = "Average Sleep per Night (minutes)", ylab = "Spring Term GPA (out of 4.0)", col = "blue")


## -----------------------------------------------------------------------------
data$term_units_scaled <- ifelse(data$cohort %in% c("uw1", "uw2"), data$term_units * 3, data$term_units)

par(mfrow = c(1,2))
plot(data$term_units_scaled, data$term_gpa, main = "Spring Term GPA vs Units Taken", xlab = "Units Taken", ylab = "Spring Term GPA (out of 4.0)", col = "red")
plot(data$term_units_scaled, data$TotalSleepTime, main = "Amount of Sleep vs Units Taken", xlab = "Units Taken", ylab = "Average Sleep per Night (minutes)", col = "purple")


## -----------------------------------------------------------------------------
sleep_means = aggregate(data$TotalSleepTime, by = list(data$cohort), FUN = mean)
colnames(sleep_means) = c("Cohort", "Mean Sleep Hours")
gpa_means = aggregate(data$term_gpa, by = list(data$cohort), FUN = mean)
colnames(gpa_means) = c("Cohort", "Mean GPA")
cohort_means = merge(sleep_means, gpa_means, by = "Cohort")

#I asked ChatGPT how to display my data.frame as a table, which is where I got my below code from.
suppressWarnings({
  library(grid)
  library(gtable)
  library(gridExtra)
})
table_grob = tableGrob(cohort_means, rows=NULL)
grid.draw(table_grob)


## -----------------------------------------------------------------------------
#converting the data from minutes to hours
data$TotalSleepTimeHours = data$TotalSleepTime/60

plot(data$TotalSleepTimeHours, data$term_gpa, main = "Spring Term GPA vs Average Sleep per Night", xlab = "Average Sleep per Night (hours)", ylab = "Spring Term GPA (out of 4.0)", col = "blue")

model = lm(term_gpa ~ TotalSleepTimeHours, data = data)
# summary(model)
# coefficients(model)
abline(model, col="red", lwd=3)
legend("bottomright", legend = "Regression Line", col = "red", lwd = 3)
# print(conf_interval)


## -----------------------------------------------------------------------------
residuals = resid(model)

plot(data$TotalSleepTimeHours, residuals, main = "Residuals between Fitted Line and Data",
     xlab = "Average Sleep per Night (hours)", ylab = "GPA Residuals")
abline(h = 0, col = "red")


## -----------------------------------------------------------------------------
qqnorm(residuals, main="Normal Q-Q Plot for GPA Residuals")
qqline(residuals)


## -----------------------------------------------------------------------------
conf_interval_99 = confint(model, level = 0.99)
# conf_interval_99


## -----------------------------------------------------------------------------
hours <- data.frame(TotalSleepTimeHours = c(6,8))
prediction_interval <- predict(model, newdata = hours, interval = "prediction", level = 0.99)
# print(prediction_interval)

fit_values <- prediction_interval[, "fit"]
# difference <- fit_values[2] - fit_values[1]
# print(difference)


