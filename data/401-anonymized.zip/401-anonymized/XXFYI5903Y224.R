## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
# Load packages and libraries
setwd("/Users/aditimannem/Library/Mobile Documents/com~apple~CloudDocs/36-401")
sleep <- read.csv("cmu-sleep.csv")
library(kableExtra)


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
hist(sleep$TotalSleepTime, breaks=20, main = "Figure 1: Histogram of Total Sleep Time", xlab = "Total Sleep Time (minutes)")


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
hist(sleep$cum_gpa, breaks=20, main = "Figure 2: Histogram of Cumulative GPA", xlab = "Cumulative GPA (Out of 4 units)")


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
hist(sleep$term_gpa, breaks = 20, main = "Figure 3: Histogram of Term GPA", xlab = "Term GPA (Out of 4 units)")


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
plot(sleep$TotalSleepTime, sleep$term_gpa, xlab = "Total Sleep Time (minutes)", ylab = "Term GPA (units)", main = "Figure 4: Term GPA vs. Total Sleep Time")


## ---- include=TRUE------------------------------------------------------------
model_lin = lm(sleep$term_gpa ~ sleep$TotalSleepTime)
# summary(model_lin)
coefficients(model_lin)
confint(model_lin)

