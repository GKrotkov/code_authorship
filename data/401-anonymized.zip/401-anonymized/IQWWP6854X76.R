## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(ggplot2)
library(alr4)
data("Rateprof")
suppressMessages(library(alr4))



## -----------------------------------------------------------------------------
library(broom)


## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The barplot of the professor attractive or not", message=FALSE----
ggplot(Rateprof,aes(x=pepper))+geom_bar()+labs(title="Barplot of the professor attractive or not ",x="The professor attractive or not")


## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The barplot of gender of the professor", message=FALSE----
ggplot(Rateprof,aes(x=gender))+geom_bar()+labs(title="Barplot of gender of the professor ",x="The gender of the professor")


## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The barplot of discipline of the professor", message=FALSE----
ggplot(Rateprof,aes(x=discipline))+geom_bar()+labs(title="Barplot of discipline of the professor ",x="The discipline of the professor")


## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The histogram of easiness level of the professor", message=FALSE----
ggplot(Rateprof,aes(x=easiness))+geom_histogram()+labs(title="Historgram of easiness of the professor ",x="The easiness level of the professor")


## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The Histogram of quality rating of the professor", message=FALSE----
ggplot(Rateprof,aes(x=quality))+geom_histogram()+labs(title="Historgram of quality rating of the professor ",x="The quality rating of the professor")


## -----------------------------------------------------------------------------
Rateprof$quality_squared<-Rateprof$quality^2



## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The Histogram of squared quality rating of the professor", message=FALSE----
ggplot(Rateprof,aes(x=quality_squared))+geom_histogram()+labs(title="Historgram of squared quality rating of the professor ",x="The squared quality rating of the professor")


## ---- fig.width=4, fig.height=3, fig.show='asis', fig.cap="The Pairplot of the variables", message=FALSE----
Rate <- Rateprof[, c("quality_squared", "pepper", "gender", "discipline", "easiness")]
library(GGally)
ggpairs(data=Rate,
columns=c("quality_squared", "pepper", "gender", "discipline", "easiness"),
        title="The Pairplot of the variables")


## -----------------------------------------------------------------------------
modelQuality<-lm(data=Rateprof, quality_squared ~ pepper + gender + discipline + easiness + gender:easiness + discipline:easiness)


## ---- fig.width=7, fig.height=4, fig.show='asis', fig.cap="Residuals vs. Fitted Values and Normal Q-Q Plot", message=FALSE----
residuals_df <- data.frame(
  Fitted_Values = predict(modelQuality),
  Residuals = resid(modelQuality)
)
plot1 <- ggplot(residuals_df, aes(x = Fitted_Values, y = Residuals)) +
  geom_point(alpha = 0.7) +
  geom_hline(yintercept = 0,linetype = "dashed", color = "red") +
  labs(title = "Residuals vs. Fitted Values", x = "Fitted Values", y = "Residuals")

res <- residuals(modelQuality)
plot2 <- ggplot() +
  geom_qq(aes(sample= res)) +
  geom_qq_line(aes(sample = res)) +
  labs(title = "Normal Q-Q Plot")
library(gridExtra)
grid.arrange(plot1,plot2, ncol = 2)



## ----fig.width=4, fig.height=3, fig.cap="Cook's Distance plot", message=FALSE----
cook_distance <- cooks.distance(modelQuality)
plot(cook_distance, pch=19,main="Cook's Distance Plot", xlab="Observation Index", ylab="Cook's Distance")
abline(h = 4/length(cook_distance), col="red", lty=2)



## -----------------------------------------------------------------------------
library(modelsummary)

full_model<- lm(quality_squared ~ pepper+ gender + discipline + easiness + gender:easiness + discipline:easiness, data = Rateprof)
reduced_model <- lm(quality_squared ~ pepper + gender + discipline + easiness, data = Rateprof)
anova_result <- anova(reduced_model,full_model)
library(xtable)
#print(xtable(anova_result))




## ----fig.width=4, fig.height=3, fig.cap="Summary table of the regression model", message=FALSE----
model_summary <- summary(modelQuality)
coefficients_table <- data.frame(
  Estimate = model_summary$coefficients[, 1],
  `Std. Error` = model_summary$coefficients[, 2],
  `t value` = model_summary$coefficients[, 3],
  `Pr(>|t|)` = model_summary$coefficients[, 4],
  `2.5 %` = model_summary$coefficients[, 1] - 1.96 * model_summary$coefficients[, 2],
  `97.5 %` = model_summary$coefficients[, 1] + 1.96 * model_summary$coefficients[, 2]
)
library(knitr)

kable(coefficients_table,format = "markdown",title = "Table 1: summary table for t test",digits = c(3, 3, 3, 3, 3, 3),col.names= c("Estimate", "Std. Error", "t value", "Pr(>|t|)", "2.5 %", "97.5 %"))

