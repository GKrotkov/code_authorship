## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE--------------------------------------------------------------
library(ggplot2)

sleep <- read.csv("cmu-sleep.csv")
#head(sleep, 10)


## ---- echo = FALSE------------------------------------------------------------
h1 <- ggplot(sleep, aes(x = TotalSleepTime)) +
geom_histogram(fill = "cornflowerblue", color = "black") +
labs(x = "Total Sleep Time", title = "Total Sleep Time Histogram")

h2 <- ggplot(sleep, aes(x = term_gpa)) +
geom_histogram(fill = "lightpink", color = "black") +
labs(x = "Term gpa (out of 4.0)", title = "Term GPA Histogram")

h3 <- ggplot(sleep, aes(x = cum_gpa)) +
geom_histogram(fill = "lightblue", color = "black") +
labs(x = "Cumulative gpa (out of 4.0)", title = "Cumulative GPA Histogram") 

h1
h2
h3


## ---- echo = FALSE------------------------------------------------------------
p1 <- ggplot(sleep, aes(y = TotalSleepTime,
x = term_gpa)) +
geom_point() +
labs(y = "Total sleep time (minutes per night)",
x = "Term GPA (out of 4.0)",
title = "Term GPA with Total Sleep Time")

p2 <- ggplot(sleep, aes(y = TotalSleepTime,
x = cum_gpa)) +
  
geom_point() +
labs(y = "Total sleep time (minutes per night)",
x = "Cumulative GPA (out of 4.0)",
title = "Cumulative GPA with Total Sleep Time")

p3 <- ggplot(sleep, aes(y = TotalSleepTime,
x = cum_gpa)) +
  
geom_point() +
scale_x_log10() +
labs(y = "Total sleep time (minutes per night)",
x = "Log Cumulative GPA (out of 4.0)",
title = "Log Cumulative GPA with Total Sleep Time")

p1 
p2 
p3



## ---- echo = FALSE------------------------------------------------------------
library(modelsummary)
sleep_fit <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)
modelsummary(list("Model 1" = sleep_fit),
             gof_map = c("r.squared", "nobs"))


## ---- echo = FALSE------------------------------------------------------------
sleep$ReducedSleepTime <- sleep$TotalSleepTime - 120
sleep_fit_reduced <- lm(term_gpa ~ ReducedSleepTime + cum_gpa, data = sleep)
modelsummary(list("Model 2" = sleep_fit_reduced),
             gof_map = c("r.squared", "nobs"))


## ---- echo= FALSE-------------------------------------------------------------
model_q3 <- lm(term_gpa ~ TotalSleepTime + cum_gpa + daytime_sleep + study + demo_gender + term_units, data = sleep)
modelsummary(list("Model 3" = model_q3),
             gof_map = c("r.squared", "nobs"))


## ---- echo = FALSE------------------------------------------------------------
modelsummary(list("Model 1" = sleep_fit, "Model 2" = sleep_fit_reduced, 
                  "Model 3" = model_q3),
             gof_map = c("r.squared", "nobs"))

