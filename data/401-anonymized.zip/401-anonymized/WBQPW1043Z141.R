## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
data <- read.csv("/Users/elinjang/Downloads/cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
plot(dist ~ speed, data = cars,
     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## -----------------------------------------------------------------------------
mean(data$TotalSleepTime)
median(data$TotalSleepTime)
sd(data$TotalSleepTime)
quantile(data$TotalSleepTime)

## -----------------------------------------------------------------------------
mean(data$term_gpa)
median(data$term_gpa)
sd(data$term_gpa)
quantile(data$term_gpa)


## -----------------------------------------------------------------------------
mean(data$cum_gpa)
median(data$cum_gpa)
sd(data$cum_gpa)
quantile(data$cum_gpa)

## -----------------------------------------------------------------------------
model1 <- lm(term_gpa ~ TotalSleepTime, data)
summary(model1)

## -----------------------------------------------------------------------------
model2 <- lm(cum_gpa ~ TotalSleepTime, data)
summary(model2)

## -----------------------------------------------------------------------------
model3 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data)
summary(model3)
confint(model3)

## -----------------------------------------------------------------------------
model4 <- lm(cum_gpa ~ TotalSleepTime + term_gpa, data)
summary(model4)


## -----------------------------------------------------------------------------
model5 <- lm(term_gpa ~ cum_gpa,data)
summary(model5)

## -----------------------------------------------------------------------------


