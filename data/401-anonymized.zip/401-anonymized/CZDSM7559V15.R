## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(GGally)
library(bestglm)
library(alr4)
library(gridExtra)

data <- Rateprof


## ----message=FALSE, fig.cap="Gender Information"------------------------------
plot1 <- ggplot(data,aes(x = gender)) +
  geom_bar() +
  scale_x_discrete(labels = c("Female", "Male")) +
  labs(title = "Professor's Gender",
       x = "Gender",
       y = "Count")

plot2 <- ggplot(data, aes(x = gender, y = quality)) +
  geom_boxplot() + scale_x_discrete(labels = c("Female", "Male")) +
  labs(x = "Gender", y = "Quality") +
  ggtitle("Gender vs Quality")

plot3 <- ggplot(data, aes(x=quality)) + geom_histogram(binwidth = 0.5, fill = "skyblue", color = "black", alpha = 0.8) +
  labs(title = "Histogram of Quality", x = "Quality", y = "Frequency")

grid.arrange(plot1, plot2, plot3, nrow = 1)


## ----message=FALSE, fig.cap="Attractiveness Information"----------------------
plot1 <- ggplot(data,aes(x = pepper)) +
  geom_bar() +
  scale_x_discrete(labels = c("No", "Yes")) +
  labs(title = "Professor vs. Attractiveness",
       x = "Attractive",
       y = "Count")

plot2 <- ggplot(data, aes(x = pepper, y = quality)) +
  geom_boxplot() + scale_x_discrete(labels = c("No", "Yes")) +
  labs(x = "Attractive", y = "Quality") +
  ggtitle("Attractiveness vs Quality")

grid.arrange(plot1, plot2, nrow = 1)


## ----message=FALSE, fig.cap="Easiness Information"----------------------------
plot1 <- ggplot(data, aes(x=easiness)) + geom_histogram(binwidth = 0.5, fill = "skyblue", color = "black", alpha = 0.8) +
  labs(title = "Histogram of Easiness", x = "Easiness", y = "Frequency")

plot2 <- ggplot(data, aes(x = easiness, y = quality)) +
  geom_point(color = "blue", size = 3, alpha = 0.6) +
  labs(title = "Easiness vs Quality", x = "Easiness", y = "Quality")

plot3 <- ggplot(data, aes(x = gender, y = easiness)) +
  geom_boxplot() + scale_x_discrete(labels = c("Female", "Male")) +
  labs(x = "Gender", y = "Easiness") +
  ggtitle("Gender vs Easiness")

grid.arrange(plot1, plot2, plot3, nrow = 1)


## ---- message=FALSE, fig.cap="Discipline Information"-------------------------
plot1 <- ggplot(data,aes(x = discipline)) +
  geom_bar() +
  scale_x_discrete(labels = c("Hum", "SocSci", "STEM", "Pre-prof")) +
  labs(title = "Professor's Discipline",
       x = "Discipline",
       y = "Count")

plot2 <- ggplot(data, aes(x = discipline, y = easiness)) +
  geom_boxplot() + scale_x_discrete(labels = c("Hum", "SocSci", "STEM", "Pre-prof")) +
  labs(x = "Discipline", y = "Easiness") +
  ggtitle("Discipline vs Easiness")

plot3 <- ggplot(data, aes(x = discipline, y = quality)) +
  geom_boxplot() + scale_x_discrete(labels = c("Hum", "SocSci", "STEM", "Pre-prof")) +
  labs(x = "Discipline", y = "Quality") +
  ggtitle("Discipline vs Quality")

grid.arrange(plot1, plot2, plot3, nrow = 1)


## ----message=FALSE, fig.cap="Pairs Plot of all variables"---------------------
data |>
dplyr::select(gender, pepper, easiness, discipline, quality,) |> ggpairs()


## ---- include=FALSE-----------------------------------------------------------
model <- lm(quality ~ gender + pepper + discipline + easiness + gender:easiness + discipline:easiness, data=data)
summary(model)
confint(model)

final_model <- step(model, trace=0)

summary(final_model)
extractAIC(final_model)


## ---- fig.cap="Residuals Plots"-----------------------------------------------
plot1 <- ggplot(data, aes(x = easiness , y = residuals(model))) +
  geom_point() +
  xlab("Easiness") +
  ylab("Residuals") +
  ggtitle("Residuals vs Easiness")

plot2 <- ggplot(data, aes(x = discipline , y = residuals(model))) +
  geom_point() + scale_x_discrete(labels = c("Hum", "SocSci", "STEM", "Pre-prof")) +
  xlab("Discipline") +
  ylab("Residuals") +
  ggtitle("Residuals vs Discipline")

plot3 <- ggplot(data, aes(x = pepper , y = residuals(model))) +
  geom_point() + scale_x_discrete(labels = c("No", "Yes")) +
  xlab("Attractive") +
  ylab("Residuals") +
  ggtitle("Residuals vs Attractive")

plot4 <- ggplot(data, aes(x = gender , y = residuals(model))) +
  geom_point() + scale_x_discrete(labels = c("Female", "Male")) +
  xlab("Gender") +
  ylab("Residuals") +
  ggtitle("Residuals vs Gender")

residuals <- residuals(model)
fitted_values <- fitted(model)

# Create a data frame for ggplot
residual_data <- data.frame(Fitted_Values = fitted_values, Residuals = residuals)


plot5 <- ggplot(residual_data, aes(x = Fitted_Values, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  xlab("Fitted Values") +
  ylab("Residuals") +
  ggtitle("Residuals vs Fitted Values")

grid.arrange(plot1, plot2, plot3, plot4, plot5, nrow = 2)


## ---- fig.cap="Diagnostic Plots"----------------------------------------------
par(mfrow = c(1, 2))
plot(model, which=2)
plot(model, which=4)

