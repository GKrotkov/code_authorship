## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
rm(list = ls())
setwd('/Users/nikhilpatel/70208_Datafiles/')
library(alr4)
head(Rateprof)
table(Rateprof$pepper)
nrow(Rateprof)


## ---- fig.width=8, fig.height=3, fig.cap="Histograms/Boxplots of Gender, attractiveness vote, quality rating, easiness rating, and discipline. The histogram for easiness is symmetric and realtively normally distributed. It's centered at a median of 3.148 and doesn't have any outliers (because the scale is bounded between 1 and 5). The histogram for quality is slightly skewed to the left and doesn't have any outliers (because the scale is bounded between 1 and 5), and is centered at a median of 3.612. The histogram for gender shows a somewhat even gender balance, with 159 female professors and 207 male professors. The histogram for discipline also shows a generally even number of professors in each discipline. The histogram of attractiveness shows that only a small proportion of professors were voted as attractive. However, there are still a large number of professors that were voted as attractive (46 professors)."----
par(mfrow = c(2, 3))
hist(Rateprof$quality, prob = TRUE, xlab = "Quality", main = "")
hist(Rateprof$easiness, prob = TRUE, xlab = "Easiness", main = "")
barplot(table(factor(Rateprof$pepper)), xlab = "Attractiveness", ylab = "Count")
barplot(table(factor(Rateprof$gender)), xlab = "Gender", ylab = "Count")
barplot(table(factor(Rateprof$discipline)), xlab = "Discipline", names = c("Hum", "SocSci", "Stem", "PreProf"), ylab = "Count")


## ---- fig.width=8, fig.height=4, fig.cap="Pairs plot with gender, attractiveness, quality, easiness, and discipline The scatter plots (Figure 2) do not reveal much evidence for concern about whether a linear model is suited for the data. We see a moderate positive linear association between quality and easiness, and we don't see any missing or extreme values for the categorical variables."----
pairs(quality ~  easiness + pepper + gender + discipline, data = Rateprof)


## ---- fig.width=8, fig.height=2.5, fig.cap="Boxplots of attractiveness, discipline, and gender against quality. Although we see a relatively similar variability and centers for quality across discipline and gender, we do see a difference in the median and variability for quality between attractiveness. In particular, teachers voted as attractive have a a median quality rating of about 4.5 and a much smaller spread than the median of 3.5 for professors not voted as attractive."----
par(mfrow = c(1, 3))
boxplot(quality ~ discipline, ylab = "Quality (1-5)", data = Rateprof, names = c("Hum", "SocSci", "Stem", "PreProf"), xlab = "Discipline")
boxplot(quality ~ gender, ylab = "Quality (1-5)", data = Rateprof, xlab = "Gender")
boxplot(quality ~ pepper, ylab = "Quality (1-5)", data = Rateprof, xlab = "Attractiveness")


## ---- fig.width=8, fig.height=2.5, fig.cap="Quality vs. Easiness faceted by discipline. We don't see a large change in the relationship between easiness and quality due to discipline."----
library(ggplot2)
ggplot(Rateprof, aes(x = easiness, y = quality)) +
geom_point() +
facet_wrap(vars(discipline), scales = "free") +
labs(x = "Easiness (1-5)",
y = "Quality (1-5)")


## ---- fig.width=8, fig.height=1.5, fig.cap="Quality vs. Easiness faceted by gender. We don't see a large change in the relationship between easiness and quality due to gender."----
library(ggplot2)
ggplot(Rateprof, aes(x = easiness, y = quality)) +
geom_point() +
facet_wrap(vars(gender), scales = "free") +
labs(x = "Easiness (1-5)",
y = "Quality (1-5)")


## ---- fig.width=8, fig.height=2.65, fig.cap="Diagnostic plot for model A. We see 0 mean on the residuals. We see constant variance on the plot with easiness, but we do see a narrowing in variance of the residuals for the fitted values as the fitted values get larger. However, this shape is very slight and may be explaned by the lesser amount of points on higher fitted values, so we have relatively constant variance and uncorrelated residuals."----
library(broom)
library(alr4)
modelA <- lm(formula = quality ~ pepper + easiness + discipline + gender, data = Rateprof)
augmented_table = augment(modelA)
Rateprof$resid = augmented_table$.resid

par(mfrow = c(1, 2))
plot(Rateprof$easiness, augmented_table$.resid, xlab = "Easiness", ylab = "Residuals")
plot(augmented_table$.fitted, augmented_table$.resid, xlab = "Fitted Value", ylab = "Residuals")


## ---- fig.width=8, fig.height=2.65, fig.cap="Diagnostic plot for model E. Our assumptions for 0 mean, uncorrelated residuals, and constant variance generally hold."----
library(broom)
library(alr4)

modelE <- lm(formula = quality ~ pepper + discipline + gender*easiness, data = Rateprof)
augmented_table = augment(modelE)
Rateprof$resid = augmented_table$.resid

par(mfrow = c(1, 2))
plot(Rateprof$easiness, augmented_table$.resid, xlab = "Easiness", ylab = "Residuals")
plot(augmented_table$.fitted, augmented_table$.resid, xlab = "Fitted Value", ylab = "Residuals")


## ---- fig.width=8, fig.height=2.65, fig.cap="Diagnostic plot for model F. Our assumptions for 0 mean, uncorrelated residuals, and constant variance generally hold."----
library(broom)
library(alr4)
modelF <- lm(formula = quality ~ pepper + gender + discipline*easiness, data = Rateprof)

augmented_table = augment(modelF)
Rateprof$resid = augmented_table$.resid

par(mfrow = c(1, 2))
plot(Rateprof$easiness, augmented_table$.resid, xlab = "Easiness", ylab = "Residuals")
plot(augmented_table$.fitted, augmented_table$.resid, xlab = "Fitted Value", ylab = "Residuals")


## ---- fig.width=8, fig.height=2, fig.cap="We don't see any large outliers when looking at Cook's distance for model A."----
ggplot(augment(modelA), aes(x = .fitted, y = .cooksd)) +
geom_point() +
labs(x = "Fitted value", y = "Cook's distance")


## ---- include=FALSE-----------------------------------------------------------
modelA <- lm(formula = quality ~ pepper + easiness + discipline + gender, data = Rateprof)
modelB <- lm(formula = quality ~ pepper + easiness + discipline, data = Rateprof)
modelC <- lm(formula = quality ~ pepper + easiness + gender, data = Rateprof)
modelD <- lm(formula = quality ~ discipline + easiness + gender, data = Rateprof)
modelE <- lm(formula = quality ~ pepper + discipline + gender*easiness, data = Rateprof)
modelF <- lm(formula = quality ~ pepper + gender + discipline*easiness, data = Rateprof)


## ---- include = FALSE---------------------------------------------------------
summary(modelA)
confint(modelA)
qt(0.975, 359)


## ---- include = FALSE---------------------------------------------------------
anova(modelB, modelA)
critical_f <- qf(0.95, 1, 359)
critical_f
summary(modelB)


## ---- include = FALSE---------------------------------------------------------
anova(modelC, modelA)
critical_f <- qf(0.95, 3, 359)
critical_f
summary(modelA)


## ---- include = FALSE---------------------------------------------------------
anova(modelD, modelA)
critical_f <- qf(0.95, 1, 359)
critical_f
summary(modelA)


## ---- include = FALSE---------------------------------------------------------
anova(modelA, modelE)
critical_f <- qf(0.95, 1, 358)
critical_f
summary(modelE)


## ---- include = FALSE---------------------------------------------------------
anova(modelA, modelF)
critical_f <- qf(0.95, 3, 356)
critical_f
summary(modelF)

