## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Normally distribured, no strong skew"----
data = read.csv("cmu-sleep.csv")
hist(data$TotalSleepTime, xlab="Average Time Spent Asleep Per Night (Minutes)", main="Histogram of Average Sleep Time")


## ---- fig.width=4, fig.height=3, fig.cap="Peak at maximum value, strong left skew"----
hist(data$term_gpa, xlab="Term GPA (out of 4.0)", main="Histogram of Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Weak positive correlation, unclear linearity"----
plot(data$TotalSleepTime, data$term_gpa, xlab="Average Time Spent Asleep Per Night (Minutes)", ylab = "Term GPA (out of 4.0)", main="Scatterplot of Sleep Time vs GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Roughly normal, slight right skew"----
transformed_gpa = 3^data$term_gpa
hist(transformed_gpa, xlab=" Transformed GPA (out of 3^4.0)", main="Histogram of Transformed GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Positively associated, roughly linear"----
plot(data$TotalSleepTime, transformed_gpa, xlab="Average Time Spent Asleep Per Night (Minutes)", ylab = "Transformed GPA (out of 3^4.0)", main="Scatterplot of Sleep Time vs GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Assumptions fulfilled"--------------
model = lm(transformed_gpa ~ data$TotalSleepTime)
plot(data$TotalSleepTime, residuals(model), xlab = "Average Sleep Time (Minutes)", ylab = "Residuals", main = "Residuals vs Average Sleep Time")

