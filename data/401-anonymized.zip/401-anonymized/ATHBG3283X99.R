## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
library(gridExtra)

library(alr4)
prof.df <- Rateprof


## ---- echo=FALSE, fig.cap="Looking at the continuous variables, the distribution of instructor quality training shows that the response variable is not evenly centered, but is moderately left skewed and has a median of 3.61. In comparison, the distribution of instructor easiness may be normally distributed and is more evenly centered with median around 3.15."----
plotTheme <- theme(text = element_text(size=10))

p1 <- ggplot(prof.df, aes(x=quality)) + geom_histogram(bins=30) +
  labs(x="Quality Rating", title="Histogram of Instructor Quality") +
  plotTheme
p2 <- ggplot(prof.df, aes(x=easiness)) + geom_histogram(bins=30) +
  labs(x="Easiness Rating", title="Histogram of Instructor Easiness") +
  plotTheme
grid.arrange(p1,p2,ncol=2)


## ---- include=FALSE-----------------------------------------------------------
gender <- data.frame(nrow(prof.df[prof.df$gender=="female",]),
                     nrow(prof.df[prof.df$gender=="male",]))
colnames(gender) <- c("Female", "Male")

pepper <- data.frame(nrow(prof.df[prof.df$pepper=="yes",]),
                     nrow(prof.df[prof.df$pepper=="no",]))
colnames(pepper) <- c("Attractive", "Not Attractive")

discipline <- data.frame(nrow(prof.df[prof.df$discipline=="Hum",]),
                         nrow(prof.df[prof.df$discipline=="SocSci",]),
                         nrow(prof.df[prof.df$discipline=="STEM",]),
                         nrow(prof.df[prof.df$discipline=="Pre-prof",]))
colnames(discipline) <- c("Humanities","Social Science","STEM","Pre-Professional")


## ---- echo=FALSE, fig.cap="The boxplot of instructor quality by gender does not show a notable difference in quality ratings based on gender - both male and female show similar centers and spreads. However, the boxplot of instructor quality by attractiveness rating indicates there might be a relationship between the response and attractiveness. The median quality rating for attractive professors is greater than the 3rd quartile of the ratings for unattractive professors, though with much smaller range than the ratings for unattractive professors. There are two low quality rating outliers for attractive professors. Boxplots of quality by discipline show similar ranges and centers for all four reported disciplines. Lastly, the plot of quality vs easiness shows that there may be a moderate positive linear relationship between the response variable and easiness."----
p3 <- ggplot(prof.df, aes(x=gender, y=quality)) + geom_boxplot() + 
  labs(x="Gender", title="Instructor Quality by Gender", y="Quality Rating") + plotTheme
p4 <- ggplot(prof.df, aes(x=pepper, y=quality)) + geom_boxplot() +
  labs(x="Attractiveness Rating", title="Instructor Quality by Attractiveness", y="Quality Rating") + plotTheme
p5 <- ggplot(prof.df, aes(x=discipline, y=quality)) + geom_boxplot() +
  labs(x="Discipline", title="Instructor Quality by Discipline", y="Quality Rating") + plotTheme
p6 <- ggplot(prof.df, aes(x=easiness, y=quality)) + geom_point() +
  labs(x="Easiness Rating", y="Quality Rating", title="Instructor Quality vs Easiness") + plotTheme
grid.arrange(p3,p4,p5,p6,ncol=2)


## ---- echo=FALSE, fig.cap="Additional bivariate analysis shows that the relationship between quality and easiness may differ for some of the categorical variables. While the plots of quality vs easiness by gender and by discipline do not show different relationships, the plot segmented by attractiveness suggests that instructors rated as attractive may impact the slope and intercept of the relationship between the two continuous variables."----
p7 <- ggplot(prof.df, aes(x=easiness, y=quality, color=gender)) + geom_point()
p8 <- ggplot(prof.df, aes(x=easiness, y=quality, color=pepper)) + geom_point() + labs(color="attractive")
p9 <- ggplot(prof.df, aes(x=easiness, y=quality, color=discipline)) + geom_point()
grid.arrange(p7,p8,p9,ncol=1)


## ---- include=FALSE-----------------------------------------------------------
#Model 1
#testing pepper and pepper interaction
model0 <- lm(quality ~ easiness, data=prof.df)
model1 <- lm(quality ~ easiness*pepper, data=prof.df)
anova(model0, model1)
extractAIC(model1)


## ---- include=FALSE-----------------------------------------------------------
#Model 2
#testing significance of gender
model2 <- lm(quality ~ easiness*pepper + gender, data=prof.df)
anova(model1, model2)
extractAIC(model2)


## ---- include=FALSE-----------------------------------------------------------
#Model 3
#testing significance of discipline
model3 <- lm(quality ~ easiness*pepper + discipline, data=prof.df)
anova(model1, model3)
extractAIC(model3)


## ---- include=FALSE-----------------------------------------------------------
#Final Model
prof.lm <- lm(quality ~ easiness*pepper + gender, data=prof.df)


## ---- echo=FALSE, fig.cap="The plot of residuals vs fitted shows that the errors have roughly mean zero and constant variance. The variance is slightly lower for high fitted values but is not enough to suggest issues in the distribution of the errors, although we might want to be careful in interpretting predictions for large fitted values."----
ggplot(prof.lm, aes(x=.fitted,y =.resid)) + geom_point() + geom_hline(yintercept=0) + labs(title="Residuals vs Fitted")


## ---- echo=FALSE--------------------------------------------------------------
qqplot <- ggplot(prof.lm, aes(sample=.resid)) + stat_qq() + stat_qq_line() + labs(title="Normal Q-Q Plot of Residuals", x="Theoretical Quantiles", y="Sample Quantiles")
plot(qqplot)


## -----------------------------------------------------------------------------
cooksd <- cooks.distance(prof.lm)
cook6 <- data.frame(head(sort(cooksd, decreasing=TRUE), 6))
names(cook6)[1] <- "Cook's Distances"
cook6$"Percentile" <- head(sort(pf(cooksd, 6, 360), decreasing = TRUE), 6)
knitr::kable(cook6, digits = 4, row.name=FALSE,caption = "Top 6 Cook's Distance Data Points")

