## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- start, include = FALSE--------------------------------------------------
library(alr4)
library(dplyr)
library(tidyr)
library(car)
library(ggplot2)


data("Rateprof")

?Rateprof


## ---- mfrow=c(2, 2), fig.width=3.5, fig.height=2.8, fig.cap="Univariate EDA"----
# Quality Rating Distribution
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(binwidth = 0.5, fill = "blue", color = "black", alpha = 0.7) +
  labs(title = "Quality Rating Distribution", x = "Quality Rating", y = "Frequency") +
  theme_minimal()

# Distribution of Gender
ggplot(Rateprof, aes(x = gender, fill = gender)) +
  geom_bar() +
  labs(title = "Distribution of Gender", x = "Gender", y = "Count") +
  theme_minimal()

# Distribution of Pepper Ratings
ggplot(Rateprof, aes(x = pepper, fill = pepper)) +
  geom_bar() +
  labs(title = "Distribution of Pepper Ratings", x = "Pepper Rating", y = "Count") +
  theme_minimal()

# Distribution of Easiness
ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = 0.5, fill = "blue", color = "black", alpha = 0.7) +
  labs(title = "Distribution of Easiness", x = "Easiness", y = "Frequency") +
  theme_minimal()

# Distribution of Discipline
ggplot(Rateprof, aes(x = discipline, fill = discipline)) +
  geom_bar() +
  labs(title = "Distribution of Discipline", x = "Discipline", y = "Count") +
  theme_minimal()


## ---- mfrow=c(2, 2), fig.width=3.5, fig.height=2.8, fig.cap="Bivariate EDA"----
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(title = "Quality vs Easiness", x = "Easiness Rating", y = "Quality Rating")

ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot() +
  labs(title = "Quality vs Gender", x = "Gender", y = "Quality Rating")

ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot() +
  labs(title = "Quality vs Discipline", x = "Discipline", y = "Quality Rating") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot() +
  labs(title = "Quality vs Attractiveness", x = "Attractiveness", y = "Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Linear Regression Model of Quality vs Easiness", comment=FALSE, echo=FALSE, message=FALSE----
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, linetype = "solid", color = "blue") +
  labs(title = "Linear Regression Model of Quality vs Easiness", x = "Easiness", y = "Quality") +
  theme_minimal()


## ---- model, include=FALSE, echo=FALSE----------------------------------------
model <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

summary(model)

vif(model)

# interaction model
interaction_model <- lm(quality ~ pepper + gender + easiness * discipline + easiness:gender, data = Rateprof)

summary(interaction_model)

anova(interaction_model, model)

coefficients <- coef(model)

print(coefficients)


## ----ci1, include=FALSE-------------------------------------------------------

# CI
conf_int_model <- confint(model, level = 0.95)
conf_int_interaction_model <- confint(interaction_model, level = 0.95)

cat("\n95% Confidence Intervals for the original model:\n")
print(conf_int_model)

cat("\n95% Confidence Intervals for the interaction model:\n")
print(conf_int_interaction_model)


df_numerator <- 4 
df_denominator <- 359  
F_statistic <- 0.3132  
alpha <- 0.05

critical_value_lower <- qf(alpha / 2, df_numerator, df_denominator, lower.tail = FALSE)
critical_value_upper <- qf(1 - alpha / 2, df_numerator, df_denominator, lower.tail = FALSE)

ci_lower <- (F_statistic * df_denominator) / (df_numerator * critical_value_upper)
ci_upper <- (F_statistic * df_denominator) / (df_numerator * critical_value_lower)

cat("95% Confidence Interval:", ci_upper, "-", ci_lower, "\n")


## ---- fig.width=3, fig.height=2.3, fig.cap="Residual Analysis"----------------
residuals_model <- resid(model)

plot(model)


## ---- fig.width=6, fig.height=4, fig.cap="Model Summary value 1", echo=FALSE, message=FALSE----
model_multiple <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
p_values <- summary(model_multiple)$coefficients

p_value_table <- data.frame(p_values)

knitr::kable(p_value_table)

model_multiple2 <- lm(quality ~ pepper + gender + easiness * discipline + easiness:gender, data = Rateprof)
p_values2 <- summary(model_multiple2)$coefficients

p_value_table2 <- data.frame(p_values2)

knitr::kable(p_value_table2)

