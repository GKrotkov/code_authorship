## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
cmu_sleep = read.csv("cmu-sleep.csv")
library(tidyverse)


## ---- fig.cap= "Distribution of TotalSleepTime"-------------------------------
ggplot(data = cmu_sleep, aes(x = TotalSleepTime)) + geom_histogram(color = "black",fill= "darkgreen", binwidth = 10) + labs(x = "Average Nightly Sleep (Minutes)", y = "Frequency", title = "Histogram of TotalSleepTime") + scale_x_continuous(breaks= seq(0, 600, 60))+ geom_vline(data=cmu_sleep, aes(xintercept=mean(TotalSleepTime)),linetype="dashed")


## ---- fig.cap= "Distribution of cum_gpa"--------------------------------------
ggplot(data = cmu_sleep, aes(x = cum_gpa)) + geom_histogram(color = "black",fill= "darkgreen", binwidth = .1) + labs(x = "Cumulative GPA", y = "Frequency", title = "Histogram of cum_gpa") + scale_x_continuous(breaks= seq(0, 4, .2)) + geom_vline(data=cmu_sleep, aes(xintercept=mean(cum_gpa)),linetype="dashed")


## ----fig.cap= "Distribution of term_gpa"--------------------------------------
ggplot(data = cmu_sleep, aes(x = term_gpa)) + geom_histogram(color = "black",fill= "darkgreen", binwidth = .1) + labs(x = "Term GPA", y = "Frequency", title = "Histogram of term_gpa") + scale_x_continuous(breaks= seq(0, 4, .2))+ geom_vline(data=cmu_sleep, aes(xintercept=mean(term_gpa)),linetype="dashed")


## ---- fig.cap= "Scatterplot of Term GPA vs Total Sleep Time"------------------
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + labs(x = "Total Sleep Time (minutes)", y = "Term GPA", title="Term GPA vs Total Sleep Time")


## ---- fig.cap= "Scatterplot of log(Term GPA) vs Total Sleep Time"-------------
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = (log(term_gpa)))) + geom_point() + labs(x = "Total Sleep Time (minutes)", y = "Term GPA", title = "log(Term GPA) vs Total Sleep Time")


## ---- fig.cap = "Scatterplot of Term GPA - Cumulative GPA vs Total Sleep Time"----
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = (term_gpa - cum_gpa))) + geom_point() + labs(x = "Total Sleep Time (minutes)", y = "Term GPA", title = "Term GPA - Cumulative GPA vs Total Sleep Time")


## ---- include = FALSE---------------------------------------------------------
model1 = lm(term_gpa ~ TotalSleepTime, data = cmu_sleep)
model2 = lm((term_gpa-cum_gpa) ~ TotalSleepTime, data = cmu_sleep)
model3 = lm(log(term_gpa) ~ TotalSleepTime, data = cmu_sleep)
summary(model2)
confint(model2)


## ---- fig.cap= "Residuals vs Fitted Values"-----------------------------------
ggplot(data = NULL, aes(x = fitted(model2), y = resid(model2))) + geom_point() + labs(x = "Fitted Values", y = "Residual Values", title = "Residuals vs Fitted Values")


## ---- fig.cap = "Residuals Squared vs. Fitted Values"-------------------------
ggplot(data = NULL, aes(x = fitted(model2), y = resid(model2)^2)) + geom_point() +labs(x = "Fitted Values", y = "Residual Values", title = "Residuals Squared vs. Fitted Values")


## ---- fig.cap = "Linear Regression overlayed (Term GPA - Cumulative GPA) vs Total Sleep Time"----
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = (term_gpa-cum_gpa))) + geom_point() + geom_smooth(method='lm', color = "darkgreen", se=FALSE, formula=y~x) + labs(x = "Total Sleep Time", y = "Term GPA - Cumulative GPA")

