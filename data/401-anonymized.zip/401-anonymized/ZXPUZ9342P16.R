## ----setup, include=FALSE-----------------------------------------------------
# load in libraries and read in dataset
knitr::opts_chunk$set(echo = FALSE, warnings = FALSE, messages = FALSE)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(readr)
library(broom)
library(modelsummary)
library(kableExtra)
study = read_csv("C:/Users/AB/Desktop/college/fall 2023/regression/cmu-sleep.csv")

# changes sleep time to be in terms of hours not minutes
study$TotalSleepTime = study$TotalSleepTime/60
nrow(study)


## ---- fig.width=3.5, fig.height=3, message = FALSE----------------------------
# histogram of TotalSleepTime
ggplot(study, aes(x = TotalSleepTime)) +
  geom_histogram(fill = "light blue") +
  labs(title = "Distribution of Total Sleep Time", 
       x = "Total Time Slept (hours)",
       y = "Count",
       caption = "Figure 1") + 
  geom_vline(aes(xintercept = median(TotalSleepTime)))


## ---- fig.width=3.5, fig.height=3, message = FALSE----------------------------
# histogram of term gpa
ggplot(study, aes(x = term_gpa)) +
  geom_histogram(fill = "light blue") +
  labs(title = "Distribution of Term GPA", 
       x = "Term GPAs",
       y = "Count",
       caption = "Figure 2") + 
  geom_vline(aes(xintercept = median(term_gpa)))


## ---- fig.width=3.5, fig.height=3, message = FALSE----------------------------
# histogram of cumulative gpa
ggplot(study, aes(x = cum_gpa)) +
  geom_histogram(fill = "light blue") +
  labs(title = "Distribution of Cumulative GPAs", 
       x = "Cumulative GPAs",
       y = "Count",
       caption = "Figure 3") + 
  geom_vline(aes(xintercept = median(cum_gpa)))


## ---- fig.width=3.5, fig.height=3, message=FALSE------------------------------
# scatterplot of sleep vs. term_gpa
par(mfrow = c(2, 1))
ggplot(study, aes (x = TotalSleepTime, y = term_gpa)) +
  geom_point(color = "light blue") +
  labs(title = "Total Sleep Time vs. Term GPAs",
       x = "Total Time Slept (hours)",
       y = "Term GPA",
       caption = "Figure 4") +
  geom_smooth(method = lm)


## ---- fig.width=3.5, fig.height=3, message=FALSE, include = FALSE-------------
# scatterplot of sleep vs. term_gpa
ggplot(study, aes (x = TotalSleepTime, y = log(term_gpa))) +
  geom_point(color = "light blue") +
  labs(title = "Total Sleep Time vs. Term GPAs",
       x = "Total Time Slept (hours)",
       y = "Log Transformation of Term GPA",
       caption = "Figure 5") +
  geom_smooth(method = lm)


## ---- fig.width=3.5, fig.height=3, message=FALSE------------------------------
# scatterplot of sleep vs. cum_gpa
par(mfrow = c(2, 1))
ggplot(study, aes (x = TotalSleepTime, y = cum_gpa)) +
  geom_point(color = "light blue") +
  labs(title = "Total Sleep Time vs. Cumulative GPAs",
       x = "Total Time Slept (hours)",
       y = "Cumulative GPA",
       caption = "Figure 5") +
  geom_smooth(method = lm)


## ---- fig.width=3.5, fig.height=3, message=FALSE, include = FALSE-------------
# scatterplot of sleep vs. cum_gpa
ggplot(study, aes (x = TotalSleepTime, y = log(cum_gpa))) +
  geom_point(color = "light blue") +
  labs(title = "Total Sleep Time vs. Cumulative GPAs",
       x = "Total Time Slept (hours)",
       y = "Log Transformation of Cumulative GPA",
       caption = "Figure 7") +
  geom_smooth(method = lm)



## -----------------------------------------------------------------------------
# fitting the linear regression models and extracting their residuals and fits
model1 = lm(term_gpa ~ TotalSleepTime, data = study)
model2 = lm(cum_gpa ~ TotalSleepTime, data = study)
resids1 = resid(model1)
resids2 = resid(model2)
fits1 = fitted(model1)
fits2 = fitted(model2)


## ---- fig.height= 3-----------------------------------------------------------
# making the residual vs. fits plots for model evaluation 
plot(fits1, resids1, ylab = "Fitted Values (Term GPA)", xlab = "Residuals", 
     main = "Residuals vs. Fits: Model 1",
     sub = "Figure 6")
abline(0, 0, col = "red")
plot(fits2, resids2, ylab = "Fitted Values (Cumulative GPA)", xlab = "Residuals", 
     main = "Residuals vs. Fits: Model 2",
     sub = "Figure 7")
abline(0, 0, col = "red")


## ---- fig.height= 3-----------------------------------------------------------
# constructing q-q plots
qqnorm(resid(model1), main = "Figure 8 Normal Q-Q: Residuals From Model 1")
qqline(resid(model1), col = "red") 
qqnorm(resid(model2), main = "Figure 9 Normal Q-Q: Residuals From Model 2")
qqline(resid(model2), col = "red")


## -----------------------------------------------------------------------------
# analysis for model 1: Term GPA ~ Total Sleep Time
df1 = tidy(model1)
knitr::kable(df1, digits = 4, caption = "Coefficients for Model 1") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")


## ---- include = FALSE---------------------------------------------------------
summary(model1)
sum(resid(model1)^2)/(nrow(study) - 2)
confint(model1)


## -----------------------------------------------------------------------------
# analysis for model 2: Cumulative GPA ~ Total Sleep Time
df2 = tidy(model2)
knitr::kable(df2, digits = 4, caption = "Coefficients for Model 2") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")


## ---- include = FALSE---------------------------------------------------------
summary(model2)
sum(resid(model2)^2)/(nrow(study) - 2)
confint(model2)


## ---- include = FALSE---------------------------------------------------------
# prediction for q2
study_new = study
study_new$TotalSleepTime = study_new$TotalSleepTime - 2
model3 = lm(term_gpa ~ TotalSleepTime, data = study_new)
model4 = lm(cum_gpa ~ TotalSleepTime, data = study_new)


## ---- include = FALSE---------------------------------------------------------
summary(model3)
sum(resid(model3)^2)/(nrow(study_new) - 2)
confint(model3)


## -----------------------------------------------------------------------------
df3 = tidy(model3)
knitr::kable(df3, digits = 4, caption = "Coefficients for Model 3") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")


## ---- include = FALSE---------------------------------------------------------
summary(model4)
sum(resid(model4)^2)/(nrow(study_new) - 2)
confint(model4)


## -----------------------------------------------------------------------------
df4 = tidy(model4)
knitr::kable(df4, digits = 4, caption = "Coefficients for Model 4") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")


## ---- fig.width=3.5, fig.height=3, message=FALSE------------------------------
# scatterplot of term_gpa vs. cum_gpa for q3
ggplot(study, aes (x = term_gpa, y = cum_gpa)) +
  geom_point(color = "light blue") +
  labs(title = "Term GPAs vs. Cumulative GPAs",
       x = "Term GPA",
       y = "Cumulative GPA",
       caption = "Figure 10") +
  geom_smooth(method = lm)

