## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
data <- read.csv("cmu-sleep.csv")
library(ggplot2) 
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
ggplot(data, aes(x=TotalSleepTime)) +
  geom_histogram(binwidth=10,color="black")+ 
  labs(
    title = "Histogram of Total Sleep Time",
    xlab="Total Sleep Time (hours)",
    ylab="Frequency"
)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
ggplot(data, aes(x=term_gpa)) +
  geom_histogram(binwidth=0.1, color="black")+ 
  labs(
    title = "Histogram of Term GPA being studied",
    xlab = "Term GPA",
    ylab = "Frequency"
)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
ggplot(data, aes(x=cum_gpa)) +
  geom_histogram(binwidth=0.1, color="black") + 
  labs(
    title = "Histogram of GPA before being studied",
    xlab = "Cumulative GPA",
    ylab = "Frequency"
)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point() +
  labs(
    title = "Scatter Plot of Total Sleep Time and Term GPA",
    xlab = "Total Sleep Time",
    ylab = "Term GPA"
)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
ggplot(data, aes(x=cum_gpa, y=term_gpa)) +
  geom_point() +
  labs(
    title = "Scatter Plot of Cumulative GPA Time and Term GPA",
    xlab = "Cumulative GPA",
    ylab = "Term GPA"
)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
lmModel <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data=data)
fitted_values <- fitted(lmModel)
residuals_values <- residuals(lmModel)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
plot_data <- data.frame(Fitted = fitted_values, Residuals = residuals_values)
ggplot(plot_data, aes(x=Fitted, y=Residuals)) +
  geom_point() + 
  geom_hline(yintercept=mean(residuals_values)) +
  ggtitle("Residuals vs. Fitted") +
  xlab("Fitted values") +
  ylab("Residuals") 
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
qqnorm(residuals(lmModel))
qqline(residuals(lmModel))
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
lmModel <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data=data)
#summary(lmModel)
#summary_model <- summary(lmModel) 
#summary_model$coefficients
interval <- confint(lmModel, "TotalSleepTime", level=0.95)
knitr::opts_chunk$set(echo = FALSE)

