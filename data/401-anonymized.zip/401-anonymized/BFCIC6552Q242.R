## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## ---- include=FALSE, message=FALSE--------------------------------------------
library(dplyr)
library(ggplot2)
library(latex2exp)
library(modelsummary)

# Import dataset
cmu.sleep <- read.csv("~/Desktop/Stats/Data\ Exam\ 1/cmu-sleep.csv")


## ---- out.width="50%", message=FALSE------------------------------------------
# Histogram of term GPAs
title <- ggtitle("Frequency of term GPAs")
xlabel <- xlab("Student term GPA (out of 4.0)")
ylabel <- ylab("Frequency")
ggplot(data = cmu.sleep, aes(x = term_gpa)) + 
  geom_histogram(binwidth=0.05) + title + xlabel + ylabel +
  labs(caption = "Figure 1: Term GPA is left skewed") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))

title <- ggtitle("Frequency of exponential term GPAs")
xlabel <- xlab("Exponential term GPA")
ylabel <- ylab("Frequency")
ggplot(data = cmu.sleep, aes(x = exp(term_gpa))) + 
  geom_histogram() + title + xlabel + ylabel +
  labs(caption = "Figure 2: Exponential GPA appears more normal") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))


## ---- out.width="50%", message=FALSE------------------------------------------
# Histogram of cumulative GPAs
title <- ggtitle("Frequency of cumulative GPAs")
xlabel <- xlab("Student cumulative GPA (out of 4.0)")
ylabel <- ylab("Frequency")
ggplot(data = cmu.sleep, aes(x = cum_gpa)) + 
  geom_histogram(binwidth=0.05) + title + xlabel + ylabel +
  labs(caption = "Figure 3: Cumulative GPA has left skew distribution") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))

title <- ggtitle("Frequency of exponential cumulative GPAs")
xlabel <- xlab("Exponential cumulative GPA")
ylabel <- ylab("Frequency")
ggplot(data = cmu.sleep, aes(x = exp(cum_gpa))) + 
  geom_histogram() + title + xlabel + ylabel +
  labs(caption = "Figure 4: Exponential GPA appears more normal") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))


## ---- out.width="50%", message=FALSE------------------------------------------
# Histogram of average sleep times
title <- ggtitle("Frequency of average sleep times")
xlabel <- xlab("Average sleep time (minutes)")
ylabel <- ylab("Frequency")
ggplot(data = cmu.sleep, aes(x = TotalSleepTime)) + 
  geom_histogram(binwidth=10) + title + xlabel + ylabel +
  labs(caption = "Figure 5: Average sleep times is normal distribution") +   
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))


## ---- out.width="50%"---------------------------------------------------------
# Term GPA and average sleep time
title <- ggtitle("Term GPA versus average sleep time")
xlabel <- xlab("Average sleep time (minutes)")
ylabel <- ylab("Term GPA (out of 4.0)")
ggplot(data = cmu.sleep, aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point() + title + xlabel + ylabel +
  labs(caption = "Figure 6: Unclear term GPA and sleep time association") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 17))

# Exponential GPA and average sleep time
title <- ggtitle("Exponential term GPA versus average sleep time")
xlabel <- xlab("Average sleep time (minutes)")
ylabel <- ylab("Exponential term GPA")
ggplot(data = cmu.sleep, aes(x = TotalSleepTime, y = exp(term_gpa))) + 
  geom_point() + title + xlabel + ylabel +
  labs(caption = "Figure 7: Exponential term GPA is more obviously linear") +   
  theme(title = element_text(size = 15), plot.caption = element_text(size = 17))


## ---- out.width="50%"---------------------------------------------------------
# Exponential term GPA and exponential cumulative GPA
title <- ggtitle("Exponential term GPA versus exponential cumulative GPA")
xlabel <- xlab("Exponential cumulative GPA (out of 4.0)")
ylabel <- ylab("Exponential term GPA (out of 4.0)")
ggplot(data = cmu.sleep, aes(x = exp(cum_gpa), y = exp(term_gpa))) + 
  geom_point() + title + xlabel + ylabel +
  labs(caption = "Figure 8: Apparent linear association") +   
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))


## -----------------------------------------------------------------------------
model <- lm(formula = (exp(term_gpa) ~ TotalSleepTime + exp(cum_gpa)), data = cmu.sleep)
model.summary <- summary(model)
coefs <- model.summary$coefficients
df <- as.data.frame(coefs)
knitr::kable(df, digits = 2, col.names = c("Estimate", "Std. Error", "t value", "Pr(>|t|)"),
             caption="Model Summary")


## ---- out.width="70%", warning=FALSE, message=FALSE---------------------------
title <- ggtitle("Exponential term GPA versus average sleep time")
xlabel <- xlab("Average sleep time (minutes)")
ylabel <- ylab("Exponential Term GPA")
ggplot(data = cmu.sleep, aes(x = TotalSleepTime, y = exp(term_gpa), color = exp(cum_gpa))) + 
  geom_point() + geom_abline(intercept = -0.75, slope = 0.03) +
  title + xlabel + ylabel + labs(caption = "Figure 9: Fitted model for term GPA versus average sleep") +
  theme(plot.caption = element_text(size = 12))

## ---- out.width="50%"---------------------------------------------------------
title <- ggtitle("Residuals versus fitted values")
xlabel <- xlab("Fitted values")
ylabel <- ylab("Residuals")
ggplot(data = model, aes(x = model$fitted.values,
                                  y = model$residuals)) +
  geom_point() + title + xlabel + ylabel + labs(caption = "Figure 10: Residuals appear linear, homoskedastic") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 20))

qqnorm(model$residuals)
qqline(model$residuals)

