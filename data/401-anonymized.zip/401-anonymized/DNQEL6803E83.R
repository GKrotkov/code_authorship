## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----include = FALSE----------------------------------------------------------

library(ggplot2)
library(broom)

# all plots are listed in this section, then copied to the respective locaation 
# for the actual report

# access the data 
ds <- read.csv("cmu-sleep.csv")
head(ds)

ggplot(ds, aes(x = TotalSleepTime)) + geom_histogram() +
    labs(x = "Total Sleep Time (minutes)", y = "Counts") + 
    ggtitle("Total Sleep Time Counts") 

ggplot(ds, aes(x = term_gpa)) +  geom_histogram() +
    labs(x = "Term GPA (out of 4.0)", y = "Counts") + 
    ggtitle("Term GPA Count")

term_gpa_2 <- ds$term_gpa ** (3)


ggplot(ds, aes(x = term_gpa_2)) +  geom_histogram() +
    labs(x = "Term GPA (out of 4.0)", y = "Counts") + 
    ggtitle("Term GPA Count")

# cubic transformation term GPA vs 
ggplot(ds, aes(x = TotalSleepTime, y = term_gpa_2)) + geom_point() +
    labs(x = "Total Sleep Time (minutes)", y = "Term GPA (out of 4.0)") + 
    ggtitle("Total Sleep Time vs Term GPA") 

# fit linear regression model for cubic transformation
data_fit <- lm(I(term_gpa ^ 3)  ~ TotalSleepTime, data = ds)

cookd <- cooks.distance(data_fit)
sorted <- sort(pf(cookd, 2, 632), decreasing = TRUE)

summary(data_fit)
confint(data_fit)

# plot the residuals 
augment(data_fit)

# residual plot for linear regression model
ggplot(data_fit, aes(x = TotalSleepTime,  y = .resid)) + geom_point() + 
  labs(x = "Total Sleep Time", y = "residuals") + 
  ggtitle("Residuals for Linear Regression Model")


# plot of cumGPA and termGPA
ggplot(data = ds, aes(TotalSleepTime, term_gpa)) + 
     geom_point(aes(x = TotalSleepTime, y = term_gpa), color = alpha('red')) + 
     geom_point(aes(x = TotalSleepTime, y = cum_gpa), color = alpha('blue') ) + 
     labs(x = "Total Sleep Time in Minutes", y = "GPA (4.0 scale)")




## ---- fig.width=3.5, fig.height=2.75, fig.cap="Counts of Average Sleep for students over a semester", fig.pos = "!h"----
ggplot(ds, aes(x = TotalSleepTime)) + geom_histogram(bins = 40) +
    labs(x = "Total Sleep Time (minutes)", y = "Counts") +  
    ggtitle("Total Sleep Time Counts")


## ---- fig.width=3.5, fig.height=2.75, fig.cap="Counts of GPA for students for semester of interest."----
ggplot(ds, aes(x = term_gpa)) +  geom_histogram(bins = 40) +
    labs(x = "Term GPA (out of 4.0)", y = "Counts") +  
    ggtitle("Term GPA Count")


## ---- fig.width=3.5, fig.height=2.75, fig.cap="Counts of GPA for students for semester of interest with cubic transformation."----
ggplot(ds, aes(x = term_gpa_2)) +  geom_histogram(bins = 30) +
    labs(x = "Term GPA Cubed (GPA^3 units)", y = "Counts") + 
    ggtitle("Term GPA With Cubic Transformation Count")


## ---- fig.width=3.5, fig.height=2.75, fig.cap="Scatter plot of Total Sleep Time vs Term GPA (with cubic transformation applied). One can see an approximate positive linear relationship."----
ggplot(ds, aes(x = TotalSleepTime, y = term_gpa_2)) + geom_point() +
    labs(x = "Total Sleep Time (minutes)", y = "Term GPA (out of 4.0) with cubic transformation") + 
    ggtitle("Total Sleep Time vs Term GPA") 


## ---- fig.width=3.5, fig.height=2.75, fig.cap="Total Sleep Time plotted against GPA. Term GPA is shown in Red and cumulative GPA is shown in Blue."----
# plot 
ggplot(data = ds, aes(TotalSleepTime, term_gpa)) + 
     geom_point(aes(x = TotalSleepTime, y = term_gpa), color=alpha('red')) + 
     geom_point(aes(x = TotalSleepTime, y = cum_gpa),  color=alpha('blue') ) + 
     labs(x = "Total Sleep Time in Minutes", y = "GPA (4.0 scale)")


## ---- fig.width=3.5, fig.height=2.75, fig.cap="Residual plot for Total Sleep Time (minutes). Linear Regression model used term_GPA as response and Total Sleep Time as predictor variable. One can see that there appear to be no general trends in the residuals."----
ggplot(data_fit, aes(x = TotalSleepTime,  y = .resid)) + geom_point() + 
  labs(x = "Total Sleep Time (minutes)", y = "residuals") + 
  ggtitle("Residuals for Linear Regression Model")

