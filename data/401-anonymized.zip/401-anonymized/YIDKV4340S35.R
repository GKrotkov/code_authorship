## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
suppressMessages(library(alr4))
suppressMessages(data("Rateprof"))
suppressMessages(library(ggplot2))
suppressMessages(library(dplyr))
suppressMessages(library(gridExtra))
suppressMessages(library(GGally))
suppressMessages(library(gridExtra))


## ---- fig.width=8, fig.height=4.5, fig.cap="Overview of variable distributions."----
plot1 <- ggplot(Rateprof, aes(x = gender)) +
  geom_bar() +
  labs(title = "Distribution of Gender", x = "Gender", y = "Count")

plot2 <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar() +
  labs(title = "Distribution of Instructor's Attractiveness", x = "Attractive", y = "Count")

plot3 <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = .25, color = "grey") +
  labs(x = "Average Easiness (1-5)", y = "Count") +
  ggtitle("Distribution of Average Easiness of Courses")

plot4 <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar() +
  labs(title = "Distribution of Discipline.", x = "Discipline.", y = "Count")

grid.arrange(plot1, plot2, plot3, plot4, ncol = 2)


## ---- fig.width=4, fig.height=3, fig.cap="Over view of instructors' average quality ratings (from 1 to 5)."----
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(binwidth = .25, color = "grey") +
  labs(x = "Average quality (1-5)", y = "Count") +
  ggtitle("Distribution of Average Quality Rating")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Pairs plot showing relationships between all related variables"----
Rateprof %>%
    select(quality, gender, pepper, easiness, discipline) %>%
    ggpairs()


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between average quality rating and easiness."----
ggplot(Rateprof, aes(x = easiness, y = quality, color = discipline, shape = gender)) +
  geom_point(alpha = .75) +
  labs(x = "Average easiness (1-5)", y = "Average quality (1-5)") +
  ggtitle("Average quality vs. Average Easiness")


## ---- message=FALSE, fig.width=8, fig.height=6--------------------------------
model_full <- lm(quality ~ easiness + gender + pepper + discipline, data = Rateprof)


## ---- message=FALSE, fig.width=8, fig.height=6, fig.cap="Residuals against each of the predictors"----
residuals_df <- data.frame(
  Residuals = residuals(model_full),
  Discipline = Rateprof$discipline,
  Gender = Rateprof$gender,
  Pepper = Rateprof$pepper
)

plot1 <- ggplot(data = data.frame(Easiness = Rateprof$easiness, Residuals = residuals(model_full))) +
  geom_point(aes(x = Easiness, y = Residuals), alpha = .75) +
  labs(title = "Residuals vs. Easiness", x = "Easiness", y = "Residuals")

plot2 <- ggplot(residuals_df, aes(x = Gender, y = Residuals)) +
  geom_boxplot() +
  labs(title = "Residuals vs. Gender", x = "Gender", y = "Residuals")

plot3 <- ggplot(residuals_df, aes(x = Pepper, y = Residuals)) +
  geom_boxplot() +
  labs(title = "Residuals vs. Attractiveness", x = "Attractiveness", y = "Residuals")

plot4 <- ggplot(residuals_df, aes(x = Discipline, y = Residuals)) +
  geom_boxplot() +
  labs(title = "Residuals vs. Discipline", x = "Discipline", y = "Residuals")

# Arrange plots into a 2x2 grid
grid.arrange(plot1, plot2, plot3, plot4, ncol = 2)



## ---- message=FALSE, fig.width=8, fig.height=4, fig.cap="Q-Q plots of each of the predictors"----
easiness <- Rateprof$easiness

plot1 <- ggplot(data.frame(Easiness = easiness), aes(sample = Easiness)) +
  stat_qq(alpha = .75) +
  stat_qq_line() +
  labs(title = "Q-Q Plot for Easiness", x = "Theoretical Quantiles", y = "Sample Quantiles") 

plot2 <- ggplot(residuals_df, aes(sample = Residuals, color = Gender)) +
  stat_qq() +
  stat_qq_line() +
  labs(title = "QQ-Plot of Residuals by Gender", x = "Theoretical Quantiles", y = "Sample Quantiles") 

plot3 <- ggplot(residuals_df, aes(sample = Residuals, color = Pepper)) +
  stat_qq() +
  stat_qq_line() +
  labs(title = "QQ-Plot of Residuals by Attractiveness", x = "Theoretical Quantiles", y = "Sample Quantiles") 

plot4 <- ggplot(residuals_df, aes(sample = Residuals, color = Discipline)) +
  stat_qq() +
  stat_qq_line() +
  labs(title = "QQ-Plot of Residuals by Discipline", x = "Theoretical Quantiles", y = "Sample Quantiles") 

grid.arrange(plot1, plot2, plot3, plot4, ncol = 2)



## ---- message=FALSE, fig.width=8, fig.height=2.5, fig.cap="Residual against fitted values,Q-Q plot against fitted values and Cook's distance"----
residuals <- residuals(model_full)
fitted_values <- fitted(model_full)
cooksd <- cooks.distance(model_full)

residuals_df <- data.frame(Residuals = residuals, FittedValues = fitted_values)

plot1 <- ggplot(data = data.frame(FittedValues = fitted(model_full), Residuals = residuals(model_full))) +
  geom_point(aes(x = FittedValues, y = Residuals)) +
  labs(title = "Residuals vs. Fitted Values", x = "Fitted Values", y = "Residuals")

plot2 <- ggplot(residuals_df, aes(sample = Residuals)) +
  stat_qq(alpha = .75) +
  stat_qq_line() +
  labs(title = "Q-Q Plot for Fitted Values", x = "Theoretical Quantiles", y = "Sample Quantiles")

plot3 <- ggplot(data.frame(Observation = seq_along(cooksd), CooksDistance = cooksd), aes(x = Observation, y = CooksDistance)) +
  geom_point(shape = 20) +
  geom_hline(yintercept = 4/(length(cooksd) - length(coef(model_full))), linetype = "dashed", color = "red") +
  labs(title = "Cook's Distance Plot", x = "Observation", y = "Cook's Distance")

grid.arrange(plot1, plot2, plot3, ncol = 3)


## ---- message=FALSE, fig.width=8, fig.height=2.5------------------------------
model_no_gender <- lm(quality ~ easiness + pepper + discipline, data = Rateprof)
gender_res <- anova(model_no_gender, model_full)


## ---- message=FALSE, fig.width=8, fig.height=2.5------------------------------
model_no_pepper <- lm(quality ~ easiness + gender + discipline, data = Rateprof)
pepper_res <- anova(model_no_pepper, model_full)


## ---- message=FALSE, fig.width=8, fig.height=2.5------------------------------
model_no_discipline <- lm(quality ~ easiness + pepper + gender, data = Rateprof)
discipline_res<-anova(model_no_discipline, model_full)


## ---- message=FALSE, fig.width=8, fig.height=2.5------------------------------
model_no_easiness <- lm(quality ~ gender + pepper + discipline, data = Rateprof)
easiness_res <- anova(model_no_easiness, model_full)


## ---- message=FALSE, fig.width=4, fig.height=2--------------------------------
library(modelsummary)
library(knitr)

model <- lm(quality ~ easiness * gender * discipline + pepper, data = Rateprof)
anova_table <- anova(model)

p_values <- anova_table[, "Pr(>F)"]
degrees_of_freedom <- anova_table[, "Df"]
f_statistics <- anova_table[, "F value"]

result_df <- data.frame(
  Predictor = rownames(anova_table),
  Degrees_of_Freedom = degrees_of_freedom,
  F_Statistic = f_statistics,
  P_Value = p_values
)

kable(result_df, format = "markdown", 
      col.names = c("Predictor", "Degrees of Freedom", "F-Statistic", "P-Value"),
      caption = "ANOVA table for interaction model")


## ---- message=FALSE, fig.width=8, fig.height=2.5------------------------------
model_final <- lm(quality ~ easiness + pepper + gender, data = Rateprof)


## ---- message=FALSE, fig.width=4, fig.height=3--------------------------------
modelsummary(list("Model Final" = model_final),
             gof_map = c("Estimate"), caption = "Significance table for associations")

