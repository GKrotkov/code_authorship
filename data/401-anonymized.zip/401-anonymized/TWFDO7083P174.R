## ---- echo=FALSE,message=FALSE------------------------------------------------
library(knitr)
library(kableExtra)
library(alr4)
knitr:: kable(head(Rateprof), align="lccrr", caption="Head of Dataset") %>%
                kable_styling(latex_options="scale_down")


## ----echo=FALSE,fig.width = 5, fig.height=4, fig.cap="Distribution of predictors"----
par(mfrow = c(2, 3))
hist(Rateprof$quality, main = "Histogram of Quality Rating of 
     the instructor", 
                       xlab = "Average quality rating of the instructor",cex.main=0.7)
hist(Rateprof$easiness, main = "Histogram of Easiness Rating", 
                       xlab = "Average easiness rating",cex.main=0.7)
barplot(table(Rateprof$gender), main = "Distribution of Gender",cex.main=0.7)
barplot(table(Rateprof$pepper), main = "Distribution of Attractiveness of 
        the instructor",cex.main=0.7)
barplot(table(Rateprof$discipline), main = "Distribution of Discipline",cex.main=0.7)


## ---- echo=FALSE,message=FALSE,fig.width = 4, fig.height=3, fig.cap="Pairs Plot between variables"----
library(GGally)
library(dplyr)
Rateprof |>
  select(quality, gender, pepper, easiness, discipline) |>
  ggpairs()+theme(axis.text = element_text(size = 5))


## ----echo=FALSE, message=FALSE,fig.width = 4, fig.height=3,fig.cap="Residual plots of first fitted model"----
y_transformed =(Rateprof$quality)**2.6 
fit1<- lm(y_transformed~gender+log(easiness)+pepper+discipline, data=Rateprof)
library(broom)
ggplot(augment(fit1),aes(x=.fitted, y=.resid))+
  geom_point()+
  labs(main="Residual plot of fitted model",x="Fitted Value",y="Residual")


## ----echo=FALSE, message=FALSE, fig.cap="Residual plots for each predictor"----
library(ggpubr)
pep_res <-ggplot(augment(fit1),aes(x=Rateprof$pepper, y=.resid))+
          geom_boxplot()+
          labs(main="Residual plot of pepper",x="Pepper",y="Residual")
gen_res <-ggplot(augment(fit1),aes(x=Rateprof$gender, y=.resid))+
          geom_boxplot()+
          labs(main="Residual plot of gender",x="Gender",y="Residual")
eas_res <-ggplot(augment(fit1),aes(x=Rateprof$easiness, y=.resid))+
          geom_point()+
          labs(main="Residual plot of easiness",x="Easiness",y="Residual")
discipline_res <-ggplot(augment(fit1),aes(x=Rateprof$discipline, y=.resid))+
          geom_boxplot()+
          labs(main="Residual plot of easiness",x="Easiness",y="Residual")
ggarrange(pep_res, gen_res, eas_res,discipline_res, ncol=2, nrow=2)


## ---- echo=FALSE, fig.width = 4, fig.height=3, fig.cap="Normal QQ plot of the fitted model"----
ggplot(augment(fit1),aes(sample=.resid))+
  geom_qq()+
  geom_qq_line()+
  labs(main="Normal QQ plot of fitted model",x="Theoretical quantities",y="Residual")


## ---- echo=FALSE, fig.cap="Summary of regression with all four predictors"----
library(modelsummary)
modelsummary(fit1, title="Multivariate linear regression model with all predictors Summary ", output="kableExtra", shape = term ~ model + statistic) %>%
  kable_styling(font_size=10)


## ---- echo=FALSE--------------------------------------------------------------
reduced_fit1 <- lm(y_transformed~gender+log(easiness)+pepper, data=Rateprof)
#anova(reduced_fit1, fit1)


## ---- echo=FALSE, fig.cap="Confidence interval of fitted model with all four predictors"----
knitr::kable(confint(fit1, level=0.95), caption="Confidence interval of fitted model with all four predictors")%>%
  kable_styling(font_size=10)


## ---- echo=FALSE--------------------------------------------------------------
full_fit2 <- lm(y_transformed~gender+log(easiness)+pepper+discipline + log(easiness):gender, data=Rateprof)


## ---- echo=FALSE,fig.width = 1, fig.height=2, fig.cap="Summary of multivariate regression with interaction between gender and easiness"----
library(modelsummary)
modelsummary(full_fit2, title="Summary of multivariate regression with interaction between gender and easiness",output="kableExtra",shape = term ~ model + statistic) %>%
  kable_styling(font_size=10)


## ---- echo=FALSE--------------------------------------------------------------
full_fit3 <- lm(y_transformed~gender+log(easiness)+pepper+discipline + log(easiness):discipline, data=Rateprof)
#anova(fit1, full_fit3)


## ---- echo=FALSE,fig.width = 4, fig.height=3,fig.cap="Residual plot of second fitted model"----
library(broom)
ggplot(augment(full_fit2),aes(x=.fitted, y=.resid))+
  geom_point()+
  labs(main="Residual plot of fitted model",x="Fitted Value",y="Residual")


## ---- echo=FALSE,fig.width = 4, fig.height=3,fig.cap="Normal QQ plot of second fitted model"----
ggplot(augment(full_fit2),aes(sample=.resid))+
  geom_qq()+
  geom_qq_line()+
  labs(main="Normal QQ plot of fitted model",x="Theoretical quantities",y="Residual")


## ---- echo=FALSE,fig.width = 4, fig.height=3,fig.cap="Residual plot of third fitted model"----
#fit1<- lm(quality~gender+easiness+pepper+discipline, data=Rateprof)
library(broom)
ggplot(augment(full_fit3),aes(x=.fitted, y=.resid))+
  geom_point()+
  labs(main="Residual plot of fitted model",x="Fitted Value",y="Residual")


## ---- echo=FALSE,fig.width = 4, fig.height=3,fig.cap="Normal QQ plot of third fitted model"----
ggplot(augment(full_fit3),aes(sample=.resid))+
  geom_qq()+
  geom_qq_line()+
  labs(main="Normal QQ plot of fitted model",x="Theoretical quantities",y="Residual")


## ----echo=FALSE,fig.cap="Scatterplot between log(easiness) and quality"-------
plot(log(Rateprof$easiness), Rateprof$quality, xlab = "log(easiness)", ylab = "Average quality rating")

