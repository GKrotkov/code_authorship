## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
# LIBRARIES
library(alr4)
library(tidyverse)
library(corrplot)
library(car)

# DATASET
data("Rateprof")


## ---- include = FALSE---------------------------------------------------------
# DATASET INFORMATION
colnames(Rateprof)


## ---- include = FALSE---------------------------------------------------------
head(Rateprof)


## ---- include = FALSE---------------------------------------------------------
summary(Rateprof)


## ---- include = FALSE---------------------------------------------------------
str(Rateprof)


## ---- include = FALSE---------------------------------------------------------
?Rateprof


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Bar Chart of Gender"----
Rateprof %>% 
  ggplot(aes(x = gender)) + 
  geom_bar(fill = 'cornflowerblue') + 
  labs(x = "Gender",
       y = "Count") + 
  theme_minimal()


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Bar Chart of Instructor Attractiveness"----
Rateprof %>% 
  ggplot(aes(x = pepper)) + 
  geom_bar(fill = 'cornflowerblue') + 
  labs(x = "Instructor Attractive",
       y = "Count") +
  theme_minimal()

## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Bar Chart of Disicplines"----
Rateprof %>% 
  ggplot(aes(x = discipline)) +
  geom_bar(fill = "cornflowerblue") + 
  labs(x = "Discipline",
       y = "Count") +
  theme_minimal()


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Histogram of Average Easiness Rating"----
Rateprof %>% 
  ggplot(aes(x = easiness)) + 
  geom_histogram(bins = 20, fill = 'cornflowerblue') + 
  labs(x = "Average Easiness Rating (1-5 scale)",
       y = "Count") +
  theme_minimal()


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Histogram of Average Quality Rating"----
Rateprof %>% 
  ggplot(aes(x = quality)) + 
  geom_histogram(bins = 20, fill = 'cornflowerblue') + 
  labs(x = "Average Quality Rating (1-5 scale)",
       y = "Count") +
  theme_minimal()


## ---- fig.width = 4, fig.height = 4, fig.align='center', fig.cap="Scatterplot of Average Easiness Rating and Average Quality Rating by Gender, Facetted By Discipline"----
Rateprof %>% 
  ggplot(aes(x = easiness, y = quality)) + 
  geom_point(aes(color = gender)) + 
  facet_wrap(~ discipline) + 
  labs(x = "Average Easiness Rating (1-5 scale)",
       y = "Average Quality Rating (1-5 scale)") +
  theme_minimal()

## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Box Plot of Average Quality Rating by Gender"----
Rateprof %>% 
  ggplot(aes(x = gender, y = quality)) + 
  geom_boxplot(fill = 'cornflowerblue') + 
  labs(x = "Gender",
       y = "Quality") +
  theme_minimal()


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap="Box Plot of Average Quality Rating by Instructor Attractiveness"----
Rateprof %>% 
  ggplot(aes(x = pepper, y = quality)) + 
  geom_boxplot(fill = 'cornflowerblue') + 
  labs(x = "Professor Attractiveness",
       y = "Quality") +
  theme_minimal()


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap = "Box Plot of Average Quality Rating by Discipline"----
Rateprof %>% 
  ggplot(aes(x = discipline, y = quality)) + 
  geom_boxplot(fill = 'cornflowerblue') + 
  labs(x = "Discipline",
       y = "Quality") +
  theme_minimal()


## ---- fig.width = 3, fig.height = 3, fig.align='center', fig.cap = "Box Plot of Average Easiness Rating by Discipline"----
Rateprof %>% 
  ggplot(aes(x = discipline, y = easiness)) + 
  geom_boxplot(fill = 'cornflowerblue') + 
  labs(x = "Discipline",
       y = "Course Easiness") +
  theme_minimal()


## ---- include = FALSE---------------------------------------------------------
# MULTI LINEAR REGRESSION MODEL
rateprof_model <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = Rateprof)

# SUMMARY OF MODEL
summary(rateprof_model)

## ---- include = FALSE---------------------------------------------------------
## RESIDUAL PLOT
residuals_df <- data.frame(
  Fitted = fitted(rateprof_model),
  Residuals = resid(rateprof_model)
)

residuals_df %>% 
ggplot(aes(x = Fitted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Fitted Values", y = "Residuals", title = "Residual Plot") +
  theme_minimal()


## ---- include = FALSE---------------------------------------------------------
# QQ PLOT
qqnorm(residuals_df$Residuals)
qqline(residuals_df$Residuals, col="red")


## ---- include = FALSE---------------------------------------------------------
# T-tests
coef(summary(rateprof_model))

# F-test
anova(rateprof_model)

# Confidence intervals for the model coefficients
confint(rateprof_model)

