## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(ggplot2)
library(stargazer)
require(gridExtra)


## ---- message=FALSE, fig.width=6.5, fig.height=5, fig.cap="Distribution of the variables studied in this analysis."----
# bar graph for gender
gender1 = discipline = ggplot(data = Rateprof) +
    geom_bar(aes(x = gender), colour = "black", fill = "#458cff")

# bar graph for pepper
pepper1 = discipline = ggplot(data = Rateprof) +
    geom_bar(aes(x = pepper), colour = "black", fill = "#458cff")

# histogram for easiness
easiness1 = ggplot(data = Rateprof) +
    geom_histogram(aes(x = easiness), colour = "black", fill = "#458cff")

# bar graph for discipline
discipline1 = ggplot(data = Rateprof) +
    geom_bar(aes(x = discipline), colour = "black", fill = "#458cff")

# bar graph for quality
quality1 = ggplot(data = Rateprof) +
    geom_histogram(aes(x = quality), colour = "black", fill = "#458cff")

# arrange multiple graphs in one image
grid.arrange(gender1, pepper1, easiness1, discipline1, quality1, ncol=2)


## ---- message=FALSE, fig.width=6.5, fig.height=5, fig.cap="Box plots and scatter plot of the explanatory variables against the quality rating."----
# boxplot for gender to quality
gender2 = ggplot(data = Rateprof, aes(x = gender, y = quality)) + 
  geom_boxplot(fill='#458cff', color="black")

# boxplot for pepper to quality
pepper2 = ggplot(data = Rateprof, aes(x = pepper, y = quality)) + 
  geom_boxplot(fill='#458cff', color="black")

# scatter plot for easiness to quality
easiness2 = ggplot(data = Rateprof, mapping = aes(x = easiness, y = quality)) + 
  geom_point(color = "black") +
  labs(x = "Easiness Rating (1-5 scale)", y = "Quality Rating (1-5 scale") 

# boxplot for discipline to quality
discipline2 = ggplot(data = Rateprof, aes(x = discipline, y = quality)) + 
  geom_boxplot(fill='#458cff', color="black")

# arrange multiple graphs in one image
grid.arrange(gender2, pepper2, easiness2, discipline2, ncol=2)


## ---- include=FALSE-----------------------------------------------------------
# multiple linear regression model (no interaction)
modelY = lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
summary(modelY)

# anova model (interaction)
modelZ = aov(quality ~ gender + pepper + easiness + discipline + easiness*gender + easiness*discipline, data = Rateprof)
summary(modelZ)


## ---- include = FALSE---------------------------------------------------------
library(modelsummary)
library(tinytex)
stargazer(modelY, type = "latex")


## ---- fig.width=4, fig.height=3, fig.cap="Quantile-normal plot of the residuals from the multiple linear regression model."----
res = residuals(modelY)
fits = fitted(modelY)
qqnorm(res)
qqline(res)


## ---- fig.width=4, fig.height=3, fig.cap="Residual vs. Fit plot."-------------
plot(fits, res)
abline(h=0)


## ---- include=FALSE-----------------------------------------------------------
library(xtable)
print(xtable(modelZ))

