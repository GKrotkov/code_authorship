## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
library(tidyverse)
head(Rateprof)


## ---- fig.cap= "Distribution of Gender of Professors at USND at Hoople.", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = gender)) +
  geom_bar(fill = "purple") +
  labs(title = "Distribution of Gender", x = "Gender", y = "Frequency")


## ---- fig.cap= "Distribution of Attractiveness of Professors at USND at Hoople.", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = pepper)) +
  geom_bar(fill = "darkred") +
  labs(title = "Distribution of Attractiveness", x = "Attractiveness", y = "Frequency")


## ---- fig.cap= "Distribution of Average Easiness Rating of Professors at USND at Hoople.", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = easiness)) +
  geom_histogram(fill = "darkgreen") +
  labs(title = "Distribution of Average Easiness Rating", x = "Average Easiness Rating", y = "Frequency")


## ---- fig.cap= "Distribution of Professors' Discipline at USND at Hoople.", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = discipline)) +
  geom_bar(fill = "orange") +
  labs(title = "Distribution of Professors' Discipline", x = "Discipline", y = "Frequency")


## ---- fig.cap= "Distribution of Average Quality Rating of Professors at USND at Hoople.", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = quality)) +
  geom_histogram(fill = "royalblue") +
  labs(title = "Distribution of Average Quality Rating", x = "Average Quality Rating", y = "Frequency")


## ---- fig.cap= "Boxplot of Average Quality Rating against Gender.", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot(fill = "purple") +
  labs(title = "Quality vs Gender", x = "Gender", y = "Average Quality Rating")


## ---- fig.cap= "Boxplot of Average Quality Rating against Professors' Attractiveness", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "darkred") +
  labs(title = "Quality vs Attractiveness", x = "Attractiveness", y = "Average Quality Rating")


## ---- fig.cap= "Scatterplot of Average Quality Rating against Average Easiness Rating", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = easiness, y = quality)) +
  geom_point(color = "darkgreen") +
  labs(title = "Quality vs Easiness", x = "Average Easiness Rating", y = "Average Quality Rating")


## ---- fig.cap= "Boxplot of Average Quality Rating against Professors' Discipline", fig.width=5, fig.height=4----
ggplot(data = Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "orange") +
  labs(title = "Quality vs Discipline", x = "Discipline", y = "Average Quality Rating")


## -----------------------------------------------------------------------------
full.model <- lm(quality ~ easiness + gender + discipline + easiness*pepper + easiness*gender + easiness*discipline, data = Rateprof)

reduced.model <- lm(quality ~ easiness + easiness*pepper + gender + discipline, data = Rateprof)

summary(full.model)
summary(reduced.model)


## -----------------------------------------------------------------------------
anova(reduced.model, full.model)


## -----------------------------------------------------------------------------
confint(reduced.model, parm = "(Intercept)")


## -----------------------------------------------------------------------------
confint(reduced.model, parm = "easiness")


## -----------------------------------------------------------------------------
confint(reduced.model, parm = "pepperyes")


## -----------------------------------------------------------------------------
confint(reduced.model, parm = "gendermale")


## -----------------------------------------------------------------------------
confint(reduced.model, parm = "disciplineSTEM")


## -----------------------------------------------------------------------------
confint(reduced.model, parm = "easiness:pepperyes")


## -----------------------------------------------------------------------------
plot(reduced.model, which=1)

