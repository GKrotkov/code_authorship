## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE, message = FALSE----------------------------------------
library(tidyverse)
library(ggplot2)
library(alr4)
data("Rateprof")


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Average rating for quality of teaching of each proffesor. The distribution is slightly left-skewed with a center around 3.6."----
Rateprof %>%
  ggplot(aes(x = quality)) +
  geom_histogram(fill = "lavender", color = "black", bins = 30) +
  labs(title = "Histogram of Average Rating for Quality of Teaching",
       x = "Average Rating for Quality",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 3, fig.height = 3, echo = FALSE, fig.cap = "Average rating for easiness of each professor's class. The distribution is roughly Normal with a center around 3.1."----
Rateprof %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(fill = "darkseagreen1", color = "black", bins = 30) +
  labs(title = "Histogram of Average Rating for Easiness of Each Professor's Class",
       x = "Average Rating for Easiness of Each Professor's Class",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Gender of each professor. The distribution is roughly equal with slightly more professors that are male."----
Rateprof %>%
  ggplot(aes(x = gender)) +
  geom_bar(fill = "mistyrose", color = "black") +
  labs(title = "Bar Plot of Gender of Each Professor",
       x = "Gender of Each Professor",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Attractiveness of each professor according to the chili pepper rating. The distribution is heavily skewed towards most professors being rated as unattractive."----
Rateprof %>%
  ggplot(aes(x = pepper)) +
  geom_bar(fill = "lightcyan", color = "black") +
  labs(title = "Bar Plot of Attractiveness (according to the Chili Pepper Rating)",
       x = "Attractiveness (according to the Chili Pepper Rating)",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Academic discipline of each professor. The distribution across disciplines are roughly equal with slightly more professors in Humanities."----
Rateprof %>%
  ggplot(aes(x = discipline)) +
  geom_bar(fill = "lightgoldenrodyellow", color = "black") +
  labs(title = "Bar Plot of Academic Discipline",
       x = "Academic Discipline",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Average rating for easiness for each professor's class vs. their quality of teaching. There is a potential linear relationship, but the points are very widespread."----
Rateprof %>%
  ggplot(aes(x = easiness, y = quality)) +
  geom_point(color = "lightblue")  +
  labs(title = "Scatterplot of Average Rating for Easiness of Each Professor's Class vs. Quality of Teaching",
       x = "Average Rating for Easiness of Each Professor's Class",
       y = "Quality of Teaching") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Gender of each professor vs. their quality of teaching. There doesn't seem to be evidence of any linear relationship."----
Rateprof %>%
  ggplot(aes(x = gender, y = quality)) +
  geom_jitter(color = "lightblue")  +
  labs(title = "Scatterplot of Gender of Each Professor vs. Quality of Teaching",
       x = "Gender of Each Professor",
       y = "Quality") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Attractiveness of each professor vs. their quality of teaching. There doesn't seem to be evidence of any linear relationship."----
Rateprof %>%
  ggplot(aes(x = pepper, y = quality)) +
  geom_jitter(color = "lightblue")  +
  labs(title = "Scatterplot of Attractiveness (according to Chili Pepper Rating) vs. Quality of Teaching",
       x = "Attractiveness (according to Chili Pepper Rating)",
       y = "Quality") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 4, fig.height = 3, echo = FALSE, fig.cap = "Academic discipline of each professor vs. their quality of teaching. There doesn't seem to be evidence of any linear relationshop."----
Rateprof %>%
  ggplot(aes(x = discipline, y = quality)) +
  geom_jitter(color = "lightblue")  +
  labs(title = "Scatterplot of Academic Discipline vs. Quality of Teaching",
       x = "Academic Discipline",
       y = "Quality") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- include = FALSE---------------------------------------------------------
summary(Rateprof$quality)
summary(Rateprof$easiness)
summary(Rateprof$gender)
summary(Rateprof$pepper)
summary(Rateprof$discipline)


## ---- include = FALSE---------------------------------------------------------
model = lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = Rateprof)
durbinWatsonTest(model)


## ---- fig.width = 3, fig.height = 3, echo = FALSE, fig.cap = "Residuals vs Fits Plot. There is no evidence of heteroskedasticity,."----
plot(fitted(model), residuals(model), pch = 16, xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0)


## ---- fig.width = 3, fig.height = 3, echo = FALSE, fig.cap = "Quantile-normal plot. There is no violation of the Normality assumption or errors."----
qqnorm(residuals(model))
qqline(residuals(model))


## ---- include = FALSE---------------------------------------------------------
summary(model)
confint(model)

