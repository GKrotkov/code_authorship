## ----global_options, echo=FALSE, include = TRUE-------------------------------
knitr::opts_chunk$set(fig.pos = 'H')



## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(warning=FALSE, message=FALSE)
knitr::opts_chunk$set(echo = FALSE)



## ---- echo = FALSE------------------------------------------------------------
cmu_sleep.df = read.csv("C:/Users/riyup/OneDrive/Documents/cmu-sleep.csv")
library(ggplot2, warn.conflicts = FALSE)
library(psych, warn.conflicts = FALSE)


## ---- fig.width=4, fig.height=3, fig.show='hold', fig.cap="Distribution of the average time a student slept each night, excluding naps."----
hist(cmu_sleep.df$TotalSleepTime,
     xlab = "Sleep Time (minutes)", ylab = "Frequency", main = "Distribution of Total Sleep Time")


## ----echo=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of the students' GPA for the classes taken in their spring semester."----
hist(cmu_sleep.df$term_gpa,
     xlab = "Student's GPA (out of 4.0)", ylab = "Frequency", main = "Distribution of Current Term GPA")


## ---- echo=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of the students' GPA for the classes taken in their Fall semester", fig.align = "center", out.extra=""----
hist(cmu_sleep.df$cum_gpa,
     xlab = "Student's GPA (out of 4.0)", ylab = "Frequency", main = "Distribution of Past Semester GPA")


## ---- echo=FALSE--------------------------------------------------------------
summary = describe(cmu_sleep.df[, c("TotalSleepTime", "cum_gpa","term_gpa")], fast=TRUE)
knitr::kable(summary, digits = 2)


## ---- echo=FALSE, fig.width=4, fig.height=3, fig.cap="Students' current term GPA at each total sleep time", fig.align = "center", out.extra = ""----

ggplot2::ggplot(data = cmu_sleep.df, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + geom_smooth(method = "lm") + labs(title = "Current Term GPA vs Total Sleep Time", y = "Current Term GPA (out of 4.0)", x = "Sleep Time (in minutes)")



## ---- echo=FALSE, fig.width=4, fig.height=3, fig.cap="Students' current term GPA at each past semester student GPA value", fig.align = "center", out.extra = ""----

ggplot2::ggplot(data = cmu_sleep.df, aes(x = cum_gpa, y = term_gpa)) + geom_point() + geom_smooth(method = "lm") + labs(title = "Current Term GPA vs Past Semester GPA", y = "Current Term GPA (out of 4.0)", x = "Past Semester GPA (out of 4.0)")



## ---- echo=FALSE,out.width="49%",out.height="49%",fig.show='hold',fig.align='center', fig.cap="Residuals plotted against predictor variables."----

#Code help to fit two plots side by side: Stack overflow. (2022). Retrieved from https://stackoverflow.com/questions/61546003/knitr-rmarkdown-figures-side-by-side-with-a-single-caption #

cmu_sleep.lm = lm(term_gpa ~ TotalSleepTime + cum_gpa, data = cmu_sleep.df)

ggplot2::ggplot(data = cmu_sleep.df, aes(x = TotalSleepTime, y = cmu_sleep.lm$residuals)) + geom_point() + geom_hline(yintercept = 0) + labs(title = "Residuals vs Total Sleep Time", y = "Residuals", x = "Sleep Time (minutes)")


ggplot2::ggplot(data = cmu_sleep.df, aes(x = cum_gpa, y = cmu_sleep.lm$residuals)) + geom_point() + geom_hline(yintercept = 0) + labs(title = "Residuals vs Past Semester GPA", y = "Residuals", x = "Past Semester GPA (out of 4.0)")



## ---- echo=FALSE,out.width="49%",out.height="49%",fig.show='hold',fig.align='center', fig.cap="Residuals plotted against predictor variables."----

cmu_sleep.lm2 = lm(term_gpa ~ TotalSleepTime, data = cmu_sleep.df)

ggplot2::ggplot(data = cmu_sleep.df, aes(x = TotalSleepTime, y = cmu_sleep.lm2$residuals)) + geom_point() + geom_hline(yintercept = 0) + labs(title = "Residuals vs Total Sleep Time", y = "Residuals", x = "Sleep Time (minutes)")


ggplot2::ggplot(data = cmu_sleep.df, aes(x = cum_gpa, y = cmu_sleep.lm2$residuals)) + geom_point() + geom_hline(yintercept = 0) + labs(title = "Residuals vs Past Semester GPA", y = "Residuals", x = "Past Semester GPA (out of 4.0)")



## ----echo = FALSE, fig.width=3.5, fig.height=2.5, fig.cap="Normal Q-Q Plot to assess normality of residuals"----

qqnorm(residuals(cmu_sleep.lm), ylab="Residuals")
qqline(residuals(cmu_sleep.lm))



## ---- echo=FALSE--------------------------------------------------------------
library(broom)
library(knitr)
out <- tidy(cmu_sleep.lm)
kable(out)

