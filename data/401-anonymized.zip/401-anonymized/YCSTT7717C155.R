## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(ggplot2)
library(knitr)
library(GGally)
library(broom)
data(Rateprof)


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Approximatly normal histogram of professor quality ratings"----
ratingbw = 0.25
ggplot (Rateprof, aes(quality)) + geom_histogram(binwidth=ratingbw) + stat_function(fun=function(x) dnorm(x, mean=mean(Rateprof$quality), sd=sd(Rateprof$quality)) * ratingbw * length(Rateprof$quality), color="red") + labs(x="Professor Quality Ratings", y="Frequency", title="Histogram of Professor Quality Ratings")


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Approximatly normal histogram of professor helpfulness ratings"----
ggplot (Rateprof, aes(helpfulness)) + geom_histogram(binwidth=ratingbw) + stat_function(fun=function(x) dnorm(x, mean=mean(Rateprof$helpfulness), sd=sd(Rateprof$helpfulness)) * ratingbw * length(Rateprof$helpfulness), color="red") + labs(x="Professor Helpfulness Ratings", y="Frequency", title="Histogram of Professor Helpfulness Ratings")


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Approximatly normal histogram of professor clarity ratings"----
ggplot (Rateprof, aes(clarity)) + geom_histogram(binwidth=ratingbw) + stat_function(fun=function(x) dnorm(x, mean=mean(Rateprof$clarity), sd=sd(Rateprof$clarity)) * ratingbw * length(Rateprof$clarity), color="red") + labs(x="Professor Clarity Ratings", y="Frequency", title="Histogram of Professor Clarity Ratings")


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Approximatly normal histogram of professor rater interest ratings"----
ggplot (Rateprof, aes(raterInterest)) + geom_histogram(binwidth=ratingbw) + stat_function(fun=function(x) dnorm(x, mean=mean(Rateprof$raterInterest), sd=sd(Rateprof$raterInterest)) * ratingbw * length(Rateprof$raterInterest), color="red") + labs(x="Rater Interest", y="Frequency", title="Histogram of Rater Interest")


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Approximatly normal histogram of professor easiness ratings"----
#hist(Rateprof$easiness, xlab="Professor Easiness Ratings", main="Histogram of Professor Easiness Ratings")
ggplot (Rateprof, aes(easiness)) + geom_histogram(binwidth=ratingbw) + stat_function(fun=function(x) dnorm(x, mean=mean(Rateprof$easiness), sd=sd(Rateprof$easiness)) * ratingbw * length(Rateprof$easiness), color="red") + labs(x="Professor Easiness Ratings", y="Frequency", title="Histogram of Professor Easiness Ratings")


## -----------------------------------------------------------------------------
table_gender = table(Rateprof$gender)
table_pepper = table(Rateprof$pepper)
table_discipline = table(Rateprof$discipline)
kable(data.frame(Gender = c("**Female**", "**Male**", "", ""), `Gender Count` = c(as.vector(table_gender), "", ""), Attractiveness = c("**No**", "**Yes**", "", ""), `Attractive Count` = c(as.vector(table_pepper), "", ""), Discipline = c("**Humanities**", "**Social Science**", "**STEM**", "**Pre-professional**"), `Discipline Count` = as.vector(table_discipline), check.names=FALSE), caption="Table of categorical variable distributions")


## ---- fig.align='center', fig.width=5, fig.height=2.5, fig.cap="Seemingly small difference of professor gender in quality ratings"----
ggplot(Rateprof, aes(x=gender, y=quality)) + geom_boxplot(notch=FALSE) + labs(x="Professor Gender", y="Quality Ratings", title="Professor Quality versus Gender") + scale_x_discrete(labels=c("Female", "Male"))


## ---- fig.align='center', fig.width=5, fig.height=2.5, fig.cap="large difference of professor atractiveness in quality ratings"----
ggplot(Rateprof, aes(x=pepper, y=quality)) + geom_boxplot(notch=FALSE) + labs(x="Professor Attractiveness", y="Quality Ratings", title="Professor Quality versus Attractiveness") + scale_x_discrete(labels=c("No", "Yes"))


## ---- fig.align='center', fig.width=5, fig.height=3.25, fig.cap="Varying means of professor quality ratings based on discipline"----
ggplot(Rateprof, aes(x=discipline, y=quality)) + geom_boxplot(notch=FALSE) + labs(x="Professor Discipline", y="Quality Ratings", title="Professor Quality versus Discipline") + scale_x_discrete(labels=c("Humanities", "Social Science", "STEM", "Pre-professional"))


## ---- fig.align='center', fig.width=5, fig.height=3, fig.cap="Visible postive relationship between professor quality and many continuous predictors"----

ggpairs(Rateprof[, c("quality", "easiness", "helpfulness", "clarity", "raterInterest")], columnLabels = c("Quality", "Easiness", "Helpfullness", "Clarity", "Rater Interest"))


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Small impact of professor gender in professor easiness ratings"----
ggplot(Rateprof, aes(x=gender, y=easiness)) + geom_boxplot(notch=FALSE) + labs(x="Professor Gender", y="Easiness Rating", title="Professor Easiness versus Gender") + scale_x_discrete(labels=c("Female", "Male"))


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Relatively large differences in professor easiness ratings because of changes in discipline"----
ggplot(Rateprof, aes(x=discipline, y=easiness)) + geom_boxplot(notch=FALSE) + labs(x="Professor Discipline", y="Easiness Rating", title="Professor Easiness versus Discipline") + scale_x_discrete(labels=c("Humanities", "Social Science", "STEM", "Pre-professional"))


## -----------------------------------------------------------------------------
model1 = lm(quality~easiness + pepper + raterInterest + gender + discipline, data=Rateprof)

model2 = lm(quality~easiness + easiness:gender + easiness:discipline, data=Rateprof)

model3 = lm(quality~easiness + easiness:discipline, data=Rateprof)

model4 = lm(quality~easiness + easiness:gender, data=Rateprof)


## ---- message=FALSE, fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Nonlinearity and heteroskedasticity in Model 1 residuals."----
mod1.df = augment(model1, Rateprof)
ggplot(mod1.df, aes(.fitted, .resid)) + geom_point() + geom_smooth(method="lm", se=FALSE) + labs(x="Fitted Values", y = "Residuals", title="Residuals versus Fitted Values")


## ---- fig.align='center', fig.width=5, fig.height=2.75, fig.cap="approximately normal distribution of Model 1 residuals"----
ggplot(mod1.df, aes(sample=.resid)) + stat_qq() + stat_qq_line() + labs(x="Theoretical Values", y="Observed Values", title="Residual QQ Plot")


## ---- results='hide', message=FALSE, fig.align='center', fig.width=5, fig.height=2.75, fig.cap="Non significant Cook's Distances (No distances are above threshold)."----
ggplot(mod1.df, aes(1:366, .cooksd)) + geom_point() + geom_hline(yintercept = df(0.5, 2, length(mod1.df)-2), linetype = "dashed", color = "red") + labs(x="Observation Number", y="Cook's Distance", title="Cook's Distance versus Observation")


## ---- message=FALSE-----------------------------------------------------------
values = coef(summary(model1))[1:5,]
rownames(values) = c("$\\hat{\\beta}_\\text{Intercept}$", "$\\hat{\\beta}_\\text{Easiness}$", "$\\hat{\\beta}_\\text{Attractive}$", "$\\hat{\\beta}_\\text{Rater Interest}$", "$\\hat{\\beta}_\\text{Male Gender}$")
#, "$\\hat{\\beta}_\\text{Social Science Discipline}$", "$\\hat{\\beta}_\\text{STEM Discipline}$", "$\\hat{\\beta}_\\text{Pro-professional Discipline}$"
kable(values, digits=4, escape=FALSE, caption = "Table of Model 1 $\\hat{\\beta}$ estimates", padding=20)

## ---- results='hide'----------------------------------------------------------
anova(model1)
confint(model1, c("easiness", "pepperyes", "raterInterest", "disciplineSocSci", "disciplineSTEM", "disciplinePre-prof"))


## ---- results='hide'----------------------------------------------------------
anova(model3, model2)
anova(model4, model2)

