## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
data <- read.csv("/Users/emrealptuna/Downloads/cmu-sleep.csv")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$TotalSleepTime, xlab = "Total Sleep Time (in minutes)", ylab = 
       "Frequency", main = "Total Sleep Time Histogram")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$term_gpa, xlab = "Term GPA (out of 4.0)", ylab = 
       "Frequency", main = "Term GPA histogram")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$cum_gpa, xlab = "Cumulative GPA (out of 4.0)", ylab = 
       "Frequency", main = "Cumulative GPA histogram")


## ---- fig.width=4, fig.height=3-----------------------------------------------
plot(data$term_gpa ~ data$TotalSleepTime, 
     main = "Term GPA vs. Total Sleep Time", 
     xlab = "Total Sleep Time (minutes)", 
     ylab = "Term GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3-----------------------------------------------
plot(exp(data$term_gpa) ~ data$TotalSleepTime, 
     main = "Exp Term GPA vs. Total Sleep Time", 
     xlab = " Total Sleep Time (in minutes)", 
     ylab = "Exp of Term GPA (out of exp(4.0))")


## -----------------------------------------------------------------------------
linear = lm(exp(data$term_gpa) ~ data$TotalSleepTime)


## ---- fig.width=4, fig.height=3-----------------------------------------------
plot(residuals(linear) ~ data$TotalSleepTime,
     main = "Residuals vs. Total Sleep Time", 
     xlab = "Total Sleep Time (in minutes)", 
     ylab = "Residuals of Term GPA (out of exp(4.0))")


## ---- fig.width=4, fig.height=3-----------------------------------------------
qqnorm(residuals(linear))
qqline(residuals(linear))


## -----------------------------------------------------------------------------
summary(linear)


## -----------------------------------------------------------------------------
confint(linear)

