## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
library(dplyr)
library(alr4)
library(gridExtra)


## -----------------------------------------------------------------------------
data("Rateprof", package = "alr4")
# Features: (Ex. gender, department)
# Important Rating Variables:
# pepper: whether students voted that the professor is physically attractive
# quality: the average quality rating of the instructor
# average ratings for helpfulness, clarity, and easiness
# We also have interest, meaning how interested the students were in the topic of the course

# Research Question: how quality ratings are associated with:
# 1. Gender
# 2. Attractiveness
# 3. Easiness of the class
# 4. Discipline
# Is the relationship between easiness and quality rating depend on the instructor's gender and discipline?
# predict quality rating, which associations are statistically significant and test the Vice Provost's suspicion (if yes, how big they are?)

gender.table <- table(Rateprof$gender)
gender.percentages <- prop.table(gender.table) * 100
pepper.table <- table(Rateprof$pepper)
pepper.percentages <- prop.table(pepper.table) * 100
discipline.table <- table(Rateprof$discipline)
discipline.percentages <- prop.table(discipline.table) * 100

continuous <- select(Rateprof, quality, easiness)
knitr::kable(rbind(as.table(summary(continuous), as.table(mean(continuous)))),
             caption ='Mean/Median/Quantile Statistics of Continuous Variables')

knitr::kable(gender.percentages, caption = "Summary of Gender", col.names = c("", "Percentage"))

knitr::kable(pepper.percentages, caption = "Summary of Attractiveness", col.names = c("", "Percentage"))

knitr::kable(discipline.percentages, caption = "Summary of Discipline", col.names = c("Discipline", "Percentage"))


## ---- fig.width=10, fig.height=3, fig.align='center', fig.cap="Histogram and Box Plot of Professor's Quality Rating."----
par(mfrow = c(1, 2))
hist(Rateprof$quality, xlab = "Quality Rating", 
     main = "Distribution of Professor's Quality Rating")

boxplot(Rateprof$quality, ylab = "Quality Rating", 
     main = "Distribution of Professor's Quality Rating")


## ---- fig.width=10, fig.height=3, fig.align='center', fig.cap="Bar Plot of Professor's Gender and Attractiveness, Respectively."----
p1 <- ggplot(Rateprof, aes(x = gender, fill = gender)) +
  geom_bar() +
  theme_minimal()

p2 <- ggplot(Rateprof, aes(x = pepper, fill = pepper)) +
  geom_bar() +
  labs(x = "Attractiveness") +
  theme_minimal()

grid.arrange(p1, p2, ncol=2)


## ---- fig.width=10, fig.height=3, fig.align='center', fig.cap="Bar Plot and Box Plot and Box Plot of Professor's Easiness Rating."----
par(mfrow = c(1, 2))
hist(Rateprof$easiness, xlab = "Easiness Rating", 
     main = "Distribution of Professor's Easiness Rating")

boxplot(Rateprof$easiness, ylab = "Easiness Rating", 
     main = "Distribution of Professor's Easiness Rating")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Bar Plot of Professor's Discipline."----
ggplot(Rateprof, aes(x = discipline, fill = discipline)) +
  geom_bar() +
  labs(x = "Discipline") +
  theme_minimal()


## ---- fig.width=10, fig.height=3, fig.align='center', fig.cap="Boxplot of Professor's Quality Rating and Attractiveness by Gender."----
p3 <- ggplot(Rateprof, aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() +
  labs(x = "Gender",
       y = "Quality Rating") + 
  ggtitle("Professor's Quality Rating Separated by Gender") +
  theme_minimal()

p4 <- ggplot(Rateprof, aes(x = pepper, y = quality, fill = pepper)) +
  geom_boxplot() +
  labs(x = "Attractiveness",
       y = "Quality Rating") + 
  ggtitle("Professor's Quality Rating Separated by Attractiveness") +
  theme_minimal()

grid.arrange(p3, p4, ncol=2)


## ---- fig.width=10, fig.height=3, fig.align='center', fig.cap="Scatterplot of Professor's Quality Rating and Its Easiness Rating."----
p5 <- ggplot(data = Rateprof, aes(x = easiness,
                            y = quality)) +
  labs(x = "Professor's Easiness Rating", 
       y = "Professor's Quality Rating") +
  geom_point(color = "navy") +
  ggtitle("Relationship between Professor's Quality Rating and Its Easiness Rating")

p6 <- ggplot(data = Rateprof, aes(x = easiness,
                            y = quality)) +
  labs(x = "Professor's Easiness Rating", 
       y = "Professor's Quality Rating") +
  geom_point(color = "navy") +
  geom_smooth(method = lm, formula = y ~ x) +
  ggtitle("Relationship between Professor's Quality Rating and Its Easiness Rating")

grid.arrange(p5, p6, ncol=2)


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Boxplot of Professor's Quality Rating by Discipline."----
ggplot(Rateprof, aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() +
  labs(x = "Discipline",
       y = "Quality Rating") + 
  ggtitle("Professor's Quality Rating Separated by Discipline") +
  theme_minimal()


## ---- include=FALSE-----------------------------------------------------------
rate.fit <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data = Rateprof)


## ---- include=FALSE-----------------------------------------------------------
rate.int.fit <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + easiness:factor(gender) + easiness:factor(discipline), data = Rateprof)


## ---- include=FALSE-----------------------------------------------------------
cookd <- cooks.distance(rate.fit)
which.max(cookd)


## ---- fig.width=12, fig.height=3, fig.align='center', fig.cap="Cook's Distance, Residual Plot, and Normal Q-Q Plot."----
par(mfrow = c(1, 3))
plot(cookd, pch=21, bg='lightblue', ylab="Cook's distance")

res.log.y <- residuals(rate.fit)
res.log.x <- Rateprof$easiness
plot(x=res.log.x, y=res.log.y, pch = '.', 
     main = "Residuals vs Easiness Rating", 
     xlab = "Easiness Rating",
     ylab = "Residuals")
abline(lm(res.log.y~res.log.x), col='blue', lty=2)

qqnorm(residuals(rate.fit))
qqline(residuals(rate.fit), col="red")


## ---- include=FALSE-----------------------------------------------------------
summary(rate.fit)
AIC(rate.fit)

rate.fit.final <- step(rate.fit, direction = "both", trace = 0)
summary(rate.fit.final)
AIC(rate.fit.final)

## -----------------------------------------------------------------------------
fit.table <- data.frame(
  Coefficient = c("(Intercept)", "factor(gender)male", "factor(pepper)yes", "easiness"),
  Estimate = c(1.67028, 0.17364, 0.63741, 0.55064),
  Std.Error = c(0.15340, 0.06966, 0.10712, 0.04584),
  t.value = c(10.888, 2.493, 5.950, 12.012),
  Pr_greater_than_t = c("< 2e-16", 0.0131, "6.32e-09", "< 2e-16"),
  Significance = c("***", "*", "***", "***")
)

knitr::kable(fit.table, caption = "Multiple Linear Regression Results.", align = c("l", "c", "c", "c", "c"))
knitr::kable(confint(rate.fit.final), digits = 6, caption = "Confidence Intervals for Coefficients.")


## ---- include=FALSE-----------------------------------------------------------
anova(rate.fit, rate.int.fit)

## -----------------------------------------------------------------------------
int.table <- data.frame(
  Res.Df = c(359, 355),
  RSS = c(154.60, 154.05),
  Df = c("", 4),
  Sum_of_Sq = c("", 0.54359),
  F_Stat = c("", 0.3132),
  Pr_greater_than_F = c("", 0.8691)
)

knitr::kable(int.table, caption = "Anova Partial F-test Results.", align = c("l", "c", "c", "c", "c"))

