## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, warning=FALSE--------------------------------------------
library(alr4)
library(ggplot2)
library(dplyr)
library(car)
library(modelsummary)
library(knitr)


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = 0.1, fill = "green", color = "black") +
  ggtitle("Figure 1: Histogram of Easiness Ratings") +
  xlab("Easiness Rating") +
  ylab("Frequency")

ggplot(Rateprof, aes(x = gender)) +
  geom_bar(fill = "orange", color = "black") +
  ggtitle("Figure 2: Distribution of Gender") +
  xlab("Gender") +
  ylab("Frequency")

ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill = "purple", color = "black") +
  ggtitle("Figure 3: Distribution of Discipline") +
  xlab("Discipline") +
  ylab("Frequency")

ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(fill = "steelblue") +
  labs(title = "Figure 4: Count of Professors by Attractiveness (Pepper Rating)",
       x = "Attractiveness (Pepper Rating)", y = "Count")

ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(binwidth = 0.1, fill = "pink", color = "black") +
  ggtitle("Figure 5: Histogram of Quality Ratings") +
  xlab("Quality Rating") +
  ylab("Frequency")


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point(alpha = 0.6, color = "red") +
  ggtitle("Figure 6: Quality Rating vs Easiness") +
  xlab("Easiness") +
  ylab("Quality Rating")

ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot(fill = "lightblue", color = "black") +
  ggtitle("Figure 7: Quality Rating by Gender") +
  xlab("Gender") +
  ylab("Quality Rating")

ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "lightgreen", color = "black") +
  ggtitle("Figure 8: Quality Rating by Discipline") +
  xlab("Discipline") +
  ylab("Quality Rating")

ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot(fill = "salmon") +
  labs(title = "Figure 9: Quality Rating by Attractiveness (Pepper Rating)",
       x = "Attractiveness (Pepper Rating)", y = "Quality Rating")


## -----------------------------------------------------------------------------
Rateprof$pepper_numeric <- ifelse(Rateprof$pepper == "yes", 1, 0)

Rateprof$gender <- as.factor(Rateprof$gender)
Rateprof$discipline <- as.factor(Rateprof$discipline)

model1 <- lm(quality ~ pepper_numeric + easiness + gender + discipline, data = Rateprof)

plot(model1$fitted.values, resid(model1))
abline(h = 0, col = "red")
title("Figure 10: Residual vs Fitted Plot for Model1")

qqnorm(model1$residuals)
qqline(model1$residuals)

model2 <- lm(quality ~ easiness * gender + easiness * discipline, data = Rateprof)

plot(model2$fitted.values, resid(model2))
abline(h = 0, col = "red")
title("FIgure 11: Residual vs Fitted Plot for Model2")
# 
qqnorm(model2$residuals)
qqline(model2$residuals)

modelsummary(list("Model 1" = model1, "Model 2" = model2),
             gof_map = c("r.squared", "nobs"))


vif_values1 <- vif(model1)
vf_df1 <- data.frame(vif_values1)

suppressMessages({
  vif_values2 <- vif(model2, type = "predictor")
})
vf_df2 <- data.frame(vif_values2)

knitr::kable(vf_df1, caption = "Variance Inflation Factors")
knitr::kable(vf_df2, caption = "Variance Inflation Factors")


## -----------------------------------------------------------------------------
anova_model <- anova(model1, model2)
anova_df <- data.frame(anova_model)

