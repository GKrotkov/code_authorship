## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## -----------------------------------------------------------------------------
#install.packages("ggplot2")
library(ggplot2)
library(dplyr)

## -----------------------------------------------------------------------------
sleep_data <- read.csv("cmu-sleep.csv")

## -----------------------------------------------------------------------------
#head(sleep_data)


## -----------------------------------------------------------------------------
selected_data <- sleep_data %>% select(TotalSleepTime, cum_gpa, term_gpa)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the Sleep Time variable"----
ggplot(sleep_data, aes(x=TotalSleepTime)) + 
  geom_histogram() + 
  labs(title="Total Sleep Time", x="Sleep Time (in minutes)")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the Cumulative GPA variable"----
ggplot(sleep_data, aes(x=cum_gpa)) + 
  geom_histogram() + 
  labs(title="Cumulative GPA", x="GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the Term GPA variable."----
ggplot(sleep_data, aes(x=term_gpa)) + 
  geom_histogram(bins = 30) + 
  labs(title="Term GPA", x="GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot comparing Total Sleep Time to Cumulative GPA"----
ggplot(sleep_data, aes(x=TotalSleepTime, y=cum_gpa)) + 
  geom_point() + 
  labs(title="Total Sleep Time vs Cumulative GPA", x="Sleep Time (in minutes)", y="Cumulative GPA") 


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot comparing Term GPA to Total Sleep Time"----
ggplot(sleep_data, aes(x=TotalSleepTime, y=term_gpa)) + 
  geom_point() + 
  labs(title="Total Sleep Time vs Term GPA", x="Sleep Time (in minutes)", y="Term GPA") 


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot comparing Term GPA to Cumulative GPA"----
ggplot(sleep_data, aes(x=cum_gpa, y=term_gpa)) + 
  geom_point() + 
  labs(title="Cumulative GPA vs Term GPA", x="Cumulative GPA", y="Term GPA") 


## ---- fig.width=4, fig.height=3, fig.cap="QQ plot for the residuals of model1"----
model1 <- lm(term_gpa ~ TotalSleepTime, data = sleep_data)
qqnorm(residuals(model1))
qqline(residuals(model1))


## ---- fig.width=4, fig.height=3, fig.cap="QQ plot for the residuals of model1"----
model2 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep_data)
qqnorm(residuals(model2))
qqline(residuals(model2))


## ---- fig.width=4, fig.height=3, fig.cap="Residuals vs Fitted values plot for model2"----
plot(predict(model2), residuals(model2), 
     ylab="Residuals", xlab="Fitted values", 
     main="Residuals vs Fitted Values")
abline(h=0)


## -----------------------------------------------------------------------------
hist(residuals(model2), main="Histogram of Residuals", xlab="Residuals",breaks = 20)


## -----------------------------------------------------------------------------
conf_interval <- confint(model2, "TotalSleepTime", level = 0.95)
print(conf_interval)

## -----------------------------------------------------------------------------
summary(model2)


## -----------------------------------------------------------------------------
sleep_coefficient <- coef(model2)["TotalSleepTime"]
expected_gpa_effect <- sleep_coefficient * (120)
print(expected_gpa_effect)

