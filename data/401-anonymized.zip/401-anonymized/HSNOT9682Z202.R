## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(dplyr)
library(gridExtra)
library(tinytex)
library(bestglm)


## ---- message=FALSE-----------------------------------------------------------
summary(Rateprof[c("quality", "easiness")])


## ---- message=FALSE-----------------------------------------------------------
# Univariate EDA for Quality
hist_quality = ggplot(Rateprof, aes(x=quality)) +
  geom_histogram(binwidth=0.5, fill="skyblue", color="black") +
  labs(title="Distribution of Quality", x="Quality", y="Frequency")

# Univariate EDA for Easiness
hist_ease = ggplot(Rateprof, aes(x=easiness)) +
  geom_histogram(binwidth=0.5, fill = "skyblue", color="black") +
  labs(title="Distribution of Easiness Ratings", x="Easiness Rating", y="Frequency")

grid.arrange(hist_quality, hist_ease, ncol=2)


## ---- message=FALSE-----------------------------------------------------------
# Univariate EDA for Gender
boxplot1 = ggplot(Rateprof, aes(x=gender)) + geom_bar(fill="lightblue", col="black") +
  labs(title="Distribution of Professors by Gender", x="Gender", y="Frequency")

# Univariate EDA for Attractiveness (pepper)
boxplot2 = ggplot(Rateprof, aes(x=pepper)) + geom_bar(fill="lightblue", col="black") +
  labs(title="Distribution of Attractiveness Ratings", x="Attractiveness", y = "Frequency")

# Univariate EDA for Discipline
boxplot3 = ggplot(Rateprof, aes(x=discipline)) + geom_bar(fill="lightblue", col="black") +
  labs(title="Distribution of Professors by Discipline", x="Discipline", y="Frequency")

grid.arrange(boxplot1, boxplot2, boxplot3, ncol=3)


## ---- message=FALSE-----------------------------------------------------------
# Scatterplot for Quality vs Gender
scatterplot1 = ggplot(Rateprof, aes(x=gender, y=quality, fill=gender)) + 
  geom_boxplot() +
  labs(title="Quality vs Gender", x="Gender", y="Quality Rating")

# Scatterplot for Quality vs Attractiveness (pepper)
scatterplot2 = ggplot(Rateprof, aes(x=pepper, y=quality, fill=pepper)) +
  geom_boxplot() +
  labs(title="Quality vs Attractiveness", x="Attractiveness", y="Quality Rating")

# Scatterplot for Quality vs Easiness
scatterplot3 = ggplot(Rateprof, aes(x=easiness, y=quality)) + geom_point() +
  geom_smooth(method="lm", se=FALSE, color="blue") +
  labs(title="Quality vs Easiness", x="Easiness Rating", y="Quality Rating")

# Scatterplot for Quality vs Discipline
scatterplot4 = ggplot(Rateprof, aes(x=discipline, y=quality, fill=discipline)) +
  geom_boxplot() +
  labs(title="Quality vs Discipline", x="Discipline", y="Quality Rating") +
  theme(axis.text.x=element_text(angle=45, hjust=1))  # Rotate x-axis labels for better readability

grid.arrange(scatterplot1, scatterplot2, scatterplot3, scatterplot4, ncol=2)


## ---- message=FALSE-----------------------------------------------------------
ggplot(Rateprof, aes(x=easiness, y=quality, color=gender, shape=discipline)) +
  geom_point() +
  geom_smooth(method="lm", se=FALSE, aes(group=1), color="blue") +
  labs(title="Quality vs Easiness with Regression Line", x="Easiness Rating", y="Quality Rating")


## -----------------------------------------------------------------------------
model = lm(quality ~ gender + pepper + easiness + discipline + gender:pepper + discipline:pepper + easiness:pepper, data=Rateprof)

# Assumption Checking
par(mfrow = c(2, 2))
plot(model, 1)
plot(model, 2)
plot(model, 4)
plot(model, 5)


## ---- message=FALSE-----------------------------------------------------------
library(car)
# vif(model, type='predictor')
vif(lm(quality ~ gender + pepper + easiness + discipline, data=Rateprof))


## -----------------------------------------------------------------------------
dummy_vars = model.matrix(~ gender + pepper + discipline - 1, data=Rateprof)
cor(cbind(Rateprof[, c("quality", "easiness")], dummy_vars))


## -----------------------------------------------------------------------------
# Model Interpretation
summary(model)


## -----------------------------------------------------------------------------
confint(model, level=0.95)


## ---- message=FALSE-----------------------------------------------------------
Rateprof_subset = subset(Rateprof, select=c(gender, pepper, easiness, discipline))
Rateprof_subset$quality = Rateprof$quality
best_model = bestglm(Rateprof_subset, IC="AIC")
best_model


## -----------------------------------------------------------------------------
AIC(model)
AIC(best_model$BestModel)

