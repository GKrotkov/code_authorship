## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE,
                      fig.align = 'center', 
                      fig.height = 2.5,
                      fig.pos = 'H')


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(gridExtra)
library(modelsummary)
library(alr4)
library(GGally)
library(bestglm)

df = Rateprof


## ---- fig.cap = "Gender EDA"--------------------------------------------------
ggplot(aes(x = factor(gender)), data = df) + 
  geom_bar(aes(fill = factor(gender))) + 
  labs(title = "Gender Distribution", x = "Gender", y = "Count", fill = "Gender")


## ---- fig.cap = "Attractiveness EDA"------------------------------------------
ggplot(aes(x = factor(pepper)), data = df) + 
  geom_bar(aes(fill = factor(pepper))) + 
  labs(title = "Attractiveness Distribution", x = "Attractiveness", y = "Count", fill = "Attractiveness")


## ----  fig.cap = "Easiness EDA"-----------------------------------------------
ggplot(aes(x = easiness), data = df) + 
  geom_histogram(bins = 20, fill = "darkseagreen3") + 
  labs(title = "Average Easiness of Class", x = "Average Easiness", y = "Frequency")


## ----  fig.cap = "Discipline EDA"---------------------------------------------
ggplot(aes(x = factor(discipline)), data = df) + 
  geom_bar(aes(fill = factor(discipline))) + 
  labs(title = "Discipline Distribution", x = "Discipline", y = "Count", fill = "Discipline")


## ----  fig.cap = "Quality EDA"------------------------------------------------
ggplot(aes(x = quality), data = df) + 
  geom_histogram(bins = 18, fill = "coral") + 
  labs(title = "Average Quality of Class", x = "Average Quality", y = "Frequency")


## ---- echo = FALSE, fig.width = 2.5, fig.cap = "Easiness vs Quality"----------
ggplot(aes(x = easiness, y = quality), data = df) + 
  geom_point(color = "purple") + 
  labs(title = "Easiness vs Quality", x = "Avg Easiness", y = "Avg Quality") + 
  theme_bw()


## ---- echo = FALSE, fig.cap = "Gender vs Quality"-----------------------------
ggplot(aes(x = factor(gender), y = quality), data = df) + 
  geom_boxplot(aes(fill = factor(gender)), alpha = 0.2) + 
  labs(title = "Prof Gender vs Quality", x =  "Gender", y = "Quality", fill = "Gender")


## ---- echo = FALSE, fig.height = 2.75,fig.width = 4,fig.cap = "Attractiveness vs Quality"----
ggplot(aes(x = factor(pepper), y = quality), data = df) + 
  geom_boxplot(fill = "blue", alpha = 0.2,
               notch = TRUE, notchwidth = 0.8, 
               outlier.color = "red", outlier.fill = "red", outlier.size = 3) + 
  labs(title = "Prof Attractiveness vs Quality", x =  "Attractiveness", y = "Quality")


## ---- echo = FALSE,fig.cap = "Discipline vs Quality"--------------------------
ggplot(aes(x = factor(discipline), y = quality), data = df) + 
  geom_boxplot(aes(fill = factor(discipline)), alpha = 0.2,
               notch = TRUE, notchwidth = 0.8) + 
  labs(title = "Prof Discipline vs Quality", x =  "Discipline", y = "Quality", fill = "Discipline")


## ---- include = FALSE---------------------------------------------------------
model = lm(quality ~ easiness*gender*pepper*discipline, data = df)
finalmod = step(model, direction = "both", trace = 0)


## ---- echo = FALSE, fig.width = 6, fig.height = 4, fig.cap = "Residual Plot for Final Model"----
plot(finalmod, which = 1)


## ---- echo = FALSE, fig.width = 6, fig.height = 4, fig.cap = "QQ Plot for Final Model"----
plot(finalmod, which = 2)


## ---- include = FALSE---------------------------------------------------------
full = lm(quality ~ easiness*gender*discipline, data = df)
red = lm(quality ~ easiness, data = df)


## ---- echo = FALSE, fig.cap = "Model Estimates. Values in parentheses are standard errors."----
modelsummary(finalmod, statistic = c("conf.int",
                           "standard error = {std.error}", 
                           "t = {statistic}",
                           "p = {p.value}"), gof_map = c("r.squared", "nobs"))


## ---- include = FALSE---------------------------------------------------------
anova(red, full)

