## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## -----------------------------------------------------------------------------
library(modelsummary)


## -----------------------------------------------------------------------------
cmu.sleep <- read.csv("/Users/aanikaschueler/Desktop/cmu-sleep.csv")


## -----------------------------------------------------------------------------
library(ggplot2)


## -----------------------------------------------------------------------------
ggplot(cmu.sleep, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 30, fill = "seagreen2", color = "black") +
  labs(title = "Histogram of Total Sleep Time", x = "Total Sleep Time (minutes)", y = "Frequency")


## -----------------------------------------------------------------------------
ggplot(cmu.sleep, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.2, fill = "turquoise1", color = "black") +
  labs(title = "Histogram of Term GPA", x = "Term GPA (4.0 scale)", y = "Frequency")


## -----------------------------------------------------------------------------
ggplot(cmu.sleep, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.2, fill = "violetred", color = "black") +
  labs(title = "Histogram of Cumulative GPA", x = "Cumulative GPA (4.0 scale)", y = "Frequency")


## -----------------------------------------------------------------------------
ggplot(cmu.sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(aes(color = "coral2")) +
  labs(title = "Scatterplot of Term GPA vs. Total Sleep Time", x = "Total Sleep Time (minutes)", y = "Term GPA (4.0 scale)")


## -----------------------------------------------------------------------------
linmod <- lm(term_gpa ~ TotalSleepTime, data = cmu.sleep)
modelsummary(list("Simple Linear Regression Model" = linmod),
             gof_map = c("r.squared", "nobs"))


## -----------------------------------------------------------------------------
plot(linmod, which = 1)


## -----------------------------------------------------------------------------
plot(linmod, which = 2)


## -----------------------------------------------------------------------------
t.test(cmu.sleep$TotalSleepTime)

