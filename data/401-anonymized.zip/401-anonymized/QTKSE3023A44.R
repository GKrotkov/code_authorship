## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
cmu <- read.csv("cmu-sleep.csv") 
library("ggplot2")
library("cowplot")
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.height=3------------------------------------------------------------
ggplot(data = cmu, aes(x=TotalSleepTime)) + 
  xlab("Average sleep per night (minutes)") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) +
  labs(title = "[Observed Semester] Student's average time asleep per night", 
       tag = "Fig. 1") 

knitr::opts_chunk$set(echo = FALSE)


## ---- fig.height=3------------------------------------------------------------
ggplot(data = cmu, aes(x=term_gpa)) + 
  xlab("Student's GPA, out of 4.0") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) +
  labs(title = "[Observed Semester] Student's GPA for classes taken", 
       tag = "Fig. 2") 

knitr::opts_chunk$set(echo = FALSE)


## ---- fig.height=3------------------------------------------------------------
ggplot(data = cmu, aes(x=cum_gpa)) + 
  xlab("Student's GPA, out of 4.0") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) + 
  labs(title = "[Prior Semesters] Student's GPA for classes taken", 
       tag = "Fig. 3") 

knitr::opts_chunk$set(echo = FALSE)


## ---- fig.height = 4----------------------------------------------------------
ggplot(data = cmu, aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point() +
  geom_smooth(formula = y ~ x, method ='lm') +
  xlab("Average student's sleep per night, in minutes") +
  ylab("Student's GPA, out of 4.0") +
  labs(title = "[Observed Sem.] Student's GPA vs. Average Sleep / Night", 
       tag = "Fig. 4")

knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
power_0 <- ggplot(data = cmu, aes(x=log(term_gpa))) + 
  xlab("Student's GPA, out of 4.0") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) + 
  labs(title = "[Observed Sem.] Student's log(GPA)") + theme(plot.title = element_text(size=12))

power_1 <- ggplot(data = cmu, aes(x=log(cum_gpa))) + 
  xlab("Student's GPA, out of 4.0") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) + 
  labs(title = "[Prior Sem.] Student's log(GPA)") + theme(plot.title = element_text(size=12))

power_2 <- ggplot(data = cmu, aes(x=term_gpa^2)) + 
  xlab("Student's GPA, out of 4.0") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) + 
  labs(title = "[Observed Sem.] Student's GPA^2") + theme(plot.title = element_text(size=12))

power_3 <- ggplot(data = cmu, aes(x=term_gpa^3)) + 
  xlab("Student's GPA, out of 4.0") +
  ylab("Frequency") +
  geom_histogram(color="black", fill="gray", bins=20) + 
  labs(title = "[Observed Sem.] Student's GPA^3") + theme(plot.title = element_text(size=12))

cowplot::plot_grid(power_0, power_1, power_2, power_3, labels = "AUTO")
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.height=3------------------------------------------------------------
ggplot(data = cmu, aes(x=cum_gpa, y=term_gpa)) +
  geom_point() +
  geom_smooth(formula = y ~ x, method ='lm') +
  xlab("[Prior] GPA, out of 4.0") +
  ylab("[Observed] GPA, out of 4.0") +
  labs(title = "[Observed Sem.] Student's GPA vs. [Prior Sem.] Student's GPA",  
       tag = "Fig. 5") 

knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
fit1 <- lm(term_gpa ~ TotalSleepTime, data = cmu)
fit2 <- lm(term_gpa ~ cum_gpa + TotalSleepTime, data = cmu)
summary(fit1)
summary(fit2)
confint(fit1, level=0.95)
confint(fit2, level=0.95)


## ---- fig.height=3------------------------------------------------------------
#Model 1
resid1 <- ggplot(fit1, aes(x = .fitted, y = .resid)) + 
  geom_point() +
  geom_hline(yintercept = 0) + 
  ggtitle("Model 1 Residuals vs Fitted") +
  ylab("Residuals") + 
  xlab("Fitted Values")

qq1 <- ggplot(fit1, aes(sample = .resid)) +
  stat_qq() +
  stat_qq_line() +
  ggtitle("Model 1 Normal QQ Plot") +
  xlab("Theoretical Quantiles") +
  ylab("Sample Quantiles")

cowplot::plot_grid(resid1, qq1, labels = c("E", "F"))
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.height=3------------------------------------------------------------
# Model 2 
resid2 <- ggplot(fit2, aes(x = .fitted, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  ggtitle("Model 2 Residuals vs Fitted") +
  ylab("Residuals") + 
  xlab("Fitted Values")

qq2 <- ggplot(fit2, aes(sample = .resid)) +
  stat_qq() +
  stat_qq_line() +
  ggtitle("Model 2 Normal QQ Plot") +
  xlab("Theoretical Quantiles") +
  ylab("Sample Quantiles")

cowplot::plot_grid(resid2, qq2, labels =  c("G", "H"))
knitr::opts_chunk$set(echo = FALSE)

