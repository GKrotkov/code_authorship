## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
#libraries
library(GGally) # necessary for the ggpairs() function
library(dplyr)
library(ggplot2)
library(gridExtra)
library(broom)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
head(Rateprof)


## ----fig.cap="Histogram distributions for all relevant variables in Rateprof"----
quality_hist <- qplot(quality, 
                      data = Rateprof,
                      xlab = "Avg. quality rating",
                      ylab = "Frequency")

pepper_hist <- qplot(pepper, 
                     data = Rateprof, 
                     xlab = "Attractive indicator (yes for attractive, no for not)", 
                     ylab = "Frequency")


gender_hist <- qplot(gender, 
                     data = Rateprof, 
                     xlab = "Gender", 
                     ylab = "Frequency")


easiness_hist <- qplot(easiness, 
                     data = Rateprof, 
                     xlab = "Avg. easiness rating (1 = very difficult, 5 = very easy)", 
                     ylab = "Frequency")

discipline_hist <- qplot(discipline, 
                     data = Rateprof, 
                     xlab = "Discipline", 
                     ylab = "Frequency")

grid.arrange(quality_hist, pepper_hist, gender_hist, easiness_hist, discipline_hist, nrow = 3)



## ---- fig.cap="Scatterplot of avg. easiness rating Vs. avg quality rating"----
plot(x=Rateprof$easiness,
     y=Rateprof$quality,
     xlab = "Average easiness rating",
     ylab = "Average quality rating")


## ---- echo = FALSE, fig.width=4, fig.height=4, fig.cap="box"------------------
ggplot(Rateprof, aes(x=pepper, y=easiness)) + 
  geom_boxplot() + xlab("Attractiveness (yes = attractive, no = not attractive)") + 
  ylab("Average easiness rating (1 = difficult, 5 = easy)")


## ---- echo = FALSE------------------------------------------------------------
full_quality_fit <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data=Rateprof)


## ---- echo = FALSE, fig.width=4, fig.height=4, fig.cap="Plot of fitted residuals (showing heteroskedasticity)"----
ggplot(augment(full_quality_fit), aes(x = .fitted, y = .resid)) +
geom_point() +
labs(x = "Fitted value", y = "Residual")


## ---- echo = FALSE, fig.width=4, fig.height=4, fig.cap="QQ plot for residuals of full model. Indicates that distribution of residuals are slightly more heavy tailed than a normal"----
ggplot(augment(full_quality_fit), aes(sample = .resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical quantiles", y = "Sample quantiles")


## ---- include = FALSE---------------------------------------------------------
# CREATING FULL AND REDUCED MODELS
no_dis <- lm(quality ~ gender + pepper + easiness + gender:easiness + discipline:easiness, data=Rateprof)

no_dis_eas <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness, data=Rateprof)


## ---- include = FALSE---------------------------------------------------------
basic <- lm(quality ~ gender + pepper + easiness, data=Rateprof)
summary(basic)


## ---- include = FALSE---------------------------------------------------------
#discipline significant
summary(full_quality_fit)

## ---- include = FALSE---------------------------------------------------------
confint(full_quality_fit)


## ---- echo = FALSE------------------------------------------------------------
anova(no_dis, full_quality_fit)


## ---- include = FALSE---------------------------------------------------------
anova(full_quality_fit, no_dis_eas)


## ---- eval = FALSE------------------------------------------------------------
## quality_basic <- lm(quality ~ easiness + gender + pepper, data = Rateprof)
## summary(quality_basic)
## confint(quality_basic)

