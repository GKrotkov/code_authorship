## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message = FALSE---------------------------------------------------------
library(ggplot2)
library(modelsummary)
library(GGally) 
library(dplyr)
library(broom)
library(ggcorrplot)
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Average Time Slept per Night"----
ggplot(data = sleep, aes(x = TotalSleepTime)) +
  geom_histogram(fill = "darkgrey", binwidth = 20) + 
  labs(title = "Students' Average Time Slept per Night") + 
  geom_vline(xintercept = mean(sleep$TotalSleepTime), alpha = 0.8) + 
  xlab("Average Time Slept per Night (minutes)") +
  ylab("Count")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Students' Spring Semester GPA"----
ggplot(data = sleep, aes(x = term_gpa)) +
  geom_histogram(fill = "darkgrey", binwidth = 0.25) + 
  geom_vline(xintercept = mean(sleep$term_gpa), alpha = 0.8) + 
  labs(title = "Students' Spring Semester GPA") + 
  xlab("Spring Semester GPA (out of 4.0)") +
  ylab("Count")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Average Time Slept per Night vs Semester GPA"----
ggplot(data = sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(size = 1, alpha = 0.5, color = "deepskyblue3") + 
  labs(title = "Average Time Slept per Night vs \nSemester GPA") + 
  xlab("Average Time Slept per Night (minutes)") +
  ylab("Spring Semester GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Students' Cumulative Semester GPA"----
ggplot(data = sleep, aes(x = cum_gpa)) +
  geom_histogram(fill = "darkgrey", binwidth = 0.25) + 
  geom_vline(xintercept = mean(sleep$cum_gpa), alpha = 0.8) + 
  labs(title = "Students' Cumulative Semester GPA") + 
  xlab("Cumulative Semester GPA (out of 4.0)") +
  ylab("Count")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Students' Cumulative GPA vs Semester GPA"----
ggplot(data = sleep, aes(x = cum_gpa, y = term_gpa)) +
  geom_point(size = 1, alpha = 0.5, color = "deepskyblue3") + 
  labs(title = "Students' Semester GPA vs \nCumulative GPA") + 
  xlab("Cumulative GPA (out of 4.0)") +
  ylab("Spring Semester GPA (4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Average Time Slept per Night vs. Cumulative GPA"----
ggplot(data = sleep, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point(size = 1, alpha = 0.5, color = "deepskyblue3") + 
  labs(title = "Students' Cumulative GPA vs. Average \nTime Slept per Night ") + 
  xlab("Average Time Slept per Night (minutes)") +
  ylab("Cumulative GPA (4.0)")


## -----------------------------------------------------------------------------
cor(sleep$TotalSleepTime, sleep$cum_gpa)


## -----------------------------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)


## ----  fig.width=4, fig.height=3, fig.cap="Cook's Distance for Observations in Model"----
augment(model) %>% 
  ggplot(aes(x = TotalSleepTime, y = .cooksd)) +
  geom_point(size = 1) +
  labs(x = "Average Time Slept per Night (minutes)", y = "Cook's distance")


## -----------------------------------------------------------------------------
new_data <- augment(model) %>% 
  filter(.cooksd < 0.15)


## -----------------------------------------------------------------------------
model <- new_data %>% 
  lm(term_gpa ~ TotalSleepTime + cum_gpa, data = .)


## ---- fig.width=4, fig.height=3, fig.cap="Quantile-Quantile plot of Residuals for Assumptions"----
qqnorm(residuals(model))
qqline(residuals(model))


## ---- fig.width=4, fig.height=3, fig.cap="Residual Plot against Time Slept for Assumptions"----
ggplot(augment(model), aes(x = TotalSleepTime, y = .resid)) +
  geom_point(size = 1) +
  labs(x = "Average Time Slept per Night (minutes)", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Residual Plot against Cumulative GPA for Assumptions"----
ggplot(augment(model), aes(x = cum_gpa, y = .resid)) +
  geom_point(size = 1) +
  labs(x = "Cumulative GPA (out of 4.0)", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Table of Coefficients and information from Model"----
modelsummary(list("Linear Model" = model),
             gof_map = c("r.squared", "nobs"), 
             title = "Table 1 of Coefficients and information from Model")


## -----------------------------------------------------------------------------
# to calculate p-value for hypothesis test
t.val <- 3.57016
theoretical.t <- qt(1 - 0.05/2, 629)
t.val > theoretical.t # reject the null
p.val <- pt(t.val, 629, lower.tail = FALSE)

