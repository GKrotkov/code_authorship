## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(broom)
library(ggplot2)
setwd("~/Downloads/")
df <- read.csv('cmu-sleep.csv')


## ----fig.cap= 'Distribution of Average Amount of Sleep per Day. Distribution is approximately normal.'----
hist(df$TotalSleepTime, xlab="Average amount of sleep per day (min)",main="")


## ----fig.cap= 'Distribution of Term GPA of Students. Distribution is highly skewed to the left.'----
hist(df$term_gpa, xlab="Term GPA of Student (out of 4)", main="")


## ----fig.cap= 'Distribution of Logarithms of Term GPA of Students. Distribution is still highly skewed to the left'----
hist(log(df$term_gpa), xlab="Logarithm of Term GPA of Student", main="")


## ----fig.cap= 'Distribution of Cumulative GPA of Students. Distribution is highly skewed to the left'----
hist(df$cum_gpa, xlab="Cumulative GPA of Student (out of 4)", main="")


## ---- fig.cap='Distribution of Cumulative GPA vs Term GPA. Strong linear relationship can be observed.'----
plot(df$cum_gpa, df$term_gpa, xlab="Cumulative GPA (out of 4)", ylab="Term GPA (out of 4)", main="")


## ---- fig.cap='Distribution of Amount of Sleep vs Term GPA. Linear relationship is weak due to bias.'----
plot(df$TotalSleepTime,df$term_gpa, xlab="Average Amount of Sleep (min)", ylab="Term GPA (out of 4)", main="")


## -----------------------------------------------------------------------------
lin_mod <- lm(term_gpa ~ cum_gpa+TotalSleepTime, data=df)


## ---- fig.cap='Residual Plot for Cumulative GPA. No evidence of nonlinearity or heteroskedasticity'----
plot(df$cum_gpa,resid(lin_mod), xlab="Cumulative GPA", ylab="Residuals of Model", main="")


## ---- fig.cap='Residual Plot for Average Sleep Time. No evidence of nonlinearity or heteroskedasticity'----
plot(df$TotalSleepTime,resid(lin_mod), xlab="Average Sleep Time (min)", ylab="Residuals of Model", main="")


## ---- fig.cap='Cooks distances for Average Sleep Time.'-----------------------
augment(lin_mod) |>
ggplot(aes(x = TotalSleepTime, y = .cooksd)) +
geom_point() +
labs(x = "Average Sleep Time (min)", y = "Cook's distance")


## ---- fig.cap='Cooks distances for Cumulative GPA'----------------------------
augment(lin_mod) |>
ggplot(aes(x = cum_gpa, y = .cooksd)) +
geom_point() +
labs(x = "Cumulative GPA", y = "Cook's distance")


## ---- fig.cap='Q-Q Plot for Error Distribution. Distribution does not form a straight line.'----
qqnorm(resid(lin_mod))
qqline(resid(lin_mod))

