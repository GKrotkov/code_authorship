## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
options(warn=-1)
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep=read.csv("C:/Users/32536/Desktop/36401/cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 1"---------------------------
hist(sleep$term_gpa,xlab = "term GPA (out of 4.0)", main = "Histogram of term GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 2"---------------------------
hist(sleep$cum_gpa,xlab = "cmu GPA (out of 4.0)", main = "Histogram of cmu GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3"---------------------------
hist(sleep$TotalSleepTime,xlab = "Average sleeping time (minute)", main = "Histogram of Sleeping time(minute)")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 4"---------------------------
plot(sleep$TotalSleepTime,sleep$term_gpa,ylab="term GPA (out of 4.0)",xlab = "Average sleeping time (minute)",main="term GPA VS average sleeping time")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 5"---------------------------
hist((sleep$term_gpa)^4,xlab = "power 4 term GPA (out of 4.0)", main = "Histogram of (term GPA)^4 (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 6"---------------------------
plot(sleep$TotalSleepTime,(sleep$term_gpa)^4,ylab="power 4 term GPA (out of 4.0)",xlab = "Average sleeping time (minute)",main="power 4 term GPA VS sleeping time")


## -----------------------------------------------------------------------------
fit=lm((term_gpa)^4~TotalSleepTime,data=sleep)


## -----------------------------------------------------------------------------
sum=summary(fit)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 7"---------------------------
qqnorm(residuals(fit))
qqline(residuals(fit))


## ----error=FALSE--------------------------------------------------------------
library(modelsummary)

modelsummary(fit)


## -----------------------------------------------------------------------------
t=sum$coefficients[6]
p=sum$coefficients[8]
data <- matrix(c(t,p))
colnames(data) <- c('value')
rownames(data) <- c('t-value','p-value')
as.table(data)


## -----------------------------------------------------------------------------
inter=sum$coefficients[1]
value=function(x){
  (x*120*(x+inter)^(-0.75))/4
}


## -----------------------------------------------------------------------------
CI=confint(fit,level=0.95)
f=value(sum$coefficients[2])
low=value(CI[2])
high=value(CI[4])


## -----------------------------------------------------------------------------
data <- matrix(c(low,f,high))
colnames(data) <- c('value')
rownames(data) <- c('low','fitted','high')
as.table(data)

