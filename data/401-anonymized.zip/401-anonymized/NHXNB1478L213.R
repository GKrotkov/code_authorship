## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
dataset <- read.csv("cmu-sleep.csv")
better <- dataset[dataset$cum_gpa < dataset$term_gpa,]
worse <- dataset[dataset$cum_gpa > dataset$term_gpa,]


## ---- echo=FALSE, fig.height=4, fig.width=2.7, fig.cap="Figure 2. Univariate EDA for Cumulative GPA, Term GPA and Total Sleep Time."----
hist(dataset$cum_gpa,
     main = "Term GPA", 
     xlab="term GPA (score out of 4)",
     cex.main=0.8, cex.axis=0.7, cex.lab=0.7)


hist(dataset$term_gpa,
     main = "Cumulative GPA", 
     xlab="cumulative GPA (score out of 4)",
     cex.main=0.8, cex.axis=0.7, cex.lab=0.7)


hist(dataset$TotalSleepTime,
     main = "Total Sleep Time histogram", 
     xlab="total sleep time (minutes/night)",
     cex.main=0.8, cex.axis=0.7, cex.lab=0.7)


## ---- echo=FALSE, fig.show="hold", fig.height=4, fig.width=5, out.width="50%"----
ggplot(data=dataset, aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point() +
  #ggtitle("Sleep Time and Term GPA Scatter plot") +
  labs(x="sleep time (minutes/night)", y="term GPA (/4)")

ggplot(data=dataset, aes(x=TotalSleepTime, y=exp(term_gpa))) +
  geom_point() +
  #ggtitle("Sleep Time and Term GPA Scatter plot") +
  labs(x="sleep time (minutes/night)", y="exponentiated term GPA (/exp(4)")
       
ggplot(data=dataset, aes(x=cum_gpa, y=term_gpa)) +
  geom_point() +
  #ggtitle("Cumulative GPA and Term GPA Scatter plot") +
  labs(x="cumulative GPA (/4)", y="term GPA (/4)")

ggplot(data=dataset, aes(x=cum_gpa, y=TotalSleepTime)) +
  geom_point() +
  #ggtitle("Cumulative GPA and Sleep Time") +
  labs(x="cumulative GPA (/4)", y="sleep time (minutes/night)")


## ---- echo=FALSE--------------------------------------------------------------
fit1 <- lm(term_gpa ~ TotalSleepTime, data=dataset)
cookd <- cooks.distance(fit1)
top5 <- tail(sort(cookd), 5)

## ---- echo=FALSE--------------------------------------------------------------
fit2 <- lm(TotalSleepTime ~ term_gpa, data=dataset)
cookd <- cooks.distance(fit2)
top5 <- tail(sort(cookd), 5)


## ---- echo=FALSE, fig.show="hold", fig.height=4, fig.width=5, out.width="50%"----
ggplot(data=dataset, aes(x=TotalSleepTime, y=fit1$residuals)) +
  geom_point() +
  ggtitle("Model 1 Residuals") +
  labs(x="total sleep time (minutes/night)", y="residuals")

ggplot(data=dataset, aes(x=cum_gpa, y=fit2$residuals)) +
  geom_point() +
  ggtitle("Model 2 Residuals") +
  labs(x="cumulative GPA (/4)", y="residuals")


## ---- echo=FALSE, fig.show="hold", fig.height=4, fig.width=5, out.width="50%"----
qqnorm(residuals(fit1), main="Model 1 Q-Q Plot")
qqline(residuals(fit1))

qqnorm(residuals(fit2), main="Model 2 Q-Q Plot")
qqline(residuals(fit2))


## ---- echo=FALSE--------------------------------------------------------------
#confint(fit1, level=0.95)
#summary(fit1)


## ---- echo=FALSE--------------------------------------------------------------
#confint(fit2, level=0.95)
#summary(fit2)
#summary(fit1)

