## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, fig.pos= "H", out.extra = "")


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(ggplot2)
library(dplyr)
library(broom)
library(gridExtra)


## ---- include=FALSE-----------------------------------------------------------
data <- Rateprof


## ---- fig.cap="Histogram of continuous variables"-----------------------------
easiness_hist <- ggplot(data, aes(x=easiness)) + geom_histogram(bins=30) + xlab("Average easiness rating (1 hardest - 5 easiest)") + theme_grey(base_size=10)
quality_hist <- ggplot(data, aes(x=quality)) + geom_histogram(bins=30) + xlab("Average quality rating (1 worst - 5 best)") + theme_grey(base_size=10)
grid.arrange(easiness_hist, quality_hist, ncol=2)


## ---- fig.cap="Scatter plot of easiness vs quality"---------------------------
ggplot(data, aes(x=easiness, y=quality)) + geom_point() + labs(x = "Average easiness rating (1 hardest - 5 easiest)", y = "Average quality rating (1 worst - 5 best)")


## ---- fig.cap="Box plot of categorical variables"-----------------------------
gender_box <- ggplot(data, aes(x=gender, y=quality)) + geom_boxplot() + ylab("Average quality rating (1 worst - 5 best)")
pepper_box <- ggplot(data, aes(x=pepper, y=quality)) + geom_boxplot() + ylab("Average quality rating (1 worst - 5 best)")
discipline_box <- ggplot(data, aes(x=discipline, y=quality)) + geom_boxplot() + ylab("Average quality rating (1 worst - 5 best)")
grid.arrange(gender_box, pepper_box, discipline_box, ncol=3)


## ---- fig.cap="Table summarizing average quality rating for each factor level"----
data |>
	group_by(gender) |>
	summarize(mean_quality = mean(quality), sd_quality = sd(quality), min_quality = min(quality), max_quality = max(quality)) |>
	knitr::kable(digits = 1, booktabs = TRUE,
		col.names = c("Gender",
		"Mean quality rating", "Standard deviation quality rating", "Smallest quality rating", "Largest quality rating"))
data |>
	group_by(pepper) |>
	summarize(mean_quality = mean(quality), sd_quality = sd(quality), min_quality = min(quality), max_quality = max(quality)) |>
	knitr::kable(digits = 1, booktabs = TRUE,
		col.names = c("Consensus Attractive",
		"Mean quality rating", "Standard deviation quality rating", "Smallest quality rating", "Largest quality rating"))
data |>
	group_by(discipline) |>
	summarize(mean_quality = mean(quality), sd_quality = sd(quality), min_quality = min(quality), max_quality = max(quality)) |>
	knitr::kable(digits = 1, booktabs = TRUE,
		col.names = c("Discipline",
		"Mean quality rating", "Standard deviation quality rating", "Smallest quality rating", "Largest quality rating"))


## ---- fig.cap="Scatterplot between easiness and quality for male/female gender"----
ggplot(data, aes(x=easiness, y=quality)) + geom_point() + labs(x = "Average easiness rating (1 hardest - 5 easiest)", y = "Average quality rating (1 worst - 5 best)") + facet_wrap(vars(gender))

## ---- fig.cap="Scatterplot between easiness and quality for whether the instructor was on consensus attractive or not"----
ggplot(data, aes(x=easiness, y=quality)) + geom_point() + labs(x = "Average easiness rating (1 hardest - 5 easiest)", y = "Average quality rating (1 worst - 5 best)") + facet_wrap(vars(pepper))

## ---- fig.cap="Scatterplot between easiness and quality for each discipline"----
ggplot(data, aes(x=easiness, y=quality)) + geom_point() + labs(x = "Average easiness rating (1 hardest - 5 easiest)", y = "Average quality rating (1 worst - 5 best)") + facet_wrap(vars(discipline))


## ---- include=FALSE-----------------------------------------------------------
pepper_reduced_lm <- lm(quality ~ gender * easiness + discipline * easiness, data = data)
pepper_reduced_lm_aug <- augment(pepper_reduced_lm)
pepper_reduced_lm_sum <- summary(pepper_reduced_lm)


## ---- include=FALSE-----------------------------------------------------------
easiness_reduced_lm <- lm(quality ~ gender + pepper + discipline, data = data)
easiness_reduced_lm_aug <- augment(easiness_reduced_lm)
easiness_reduced_lm_sum <- summary(easiness_reduced_lm)


## ---- include=FALSE-----------------------------------------------------------
gender_all_reduced_lm <- lm(quality ~ easiness + pepper + discipline * easiness, data = data)
gender_all_reduced_lm_aug <- augment(gender_all_reduced_lm)
gender_all_reduced_lm_sum <- summary(gender_all_reduced_lm)


## ---- include=FALSE-----------------------------------------------------------
discipline_all_reduced_lm <- lm(quality ~ gender * easiness + pepper + easiness, data = data)
discipline_all_reduced_lm_aug <- augment(discipline_all_reduced_lm)
discipline_all_reduced_lm_sum <- summary(discipline_all_reduced_lm)


## ---- include=FALSE-----------------------------------------------------------
gender_reduced_lm <- lm(quality ~ gender + pepper + discipline * easiness, data = data)
gender_reduced_lm_aug <- augment(gender_reduced_lm)
gender_reduced_lm_sum <- summary(gender_reduced_lm)


## ---- include=FALSE-----------------------------------------------------------
discipline_reduced_lm <- lm(quality ~ gender * easiness + pepper + discipline , data = data)
discipline_reduced_lm_aug <- augment(discipline_reduced_lm)
discipline_reduced_lm_sum <- summary(discipline_reduced_lm)


## ---- include=FALSE-----------------------------------------------------------
full_lm <- lm(quality ~ gender * easiness + pepper + discipline * easiness, data = data)
full_lm_aug <- augment(full_lm)
full_lm_sum <- summary(full_lm)
full_lm_confint <- confint(full_lm)
full_lm_coef <- coef(full_lm_sum)


## -----------------------------------------------------------------------------
resid_scatter <- ggplot(full_lm_aug, aes(x=.fitted, y = .resid)) + geom_point() + labs(x="Fitted value (Average quality rating, between 1, worst, to 5, best)", y = "Residual")


## -----------------------------------------------------------------------------
qq_plot <- ggplot(full_lm_aug, aes(sample=.resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical quantiles", y = "Observed quantiles")


## -----------------------------------------------------------------------------
cook_hist <- ggplot(full_lm_aug, aes(x=.cooksd)) + geom_histogram(bins=30) + xlab("Cook's Distance")


## ---- fig.cap="Diagnostic Plots"----------------------------------------------
grid.arrange(resid_scatter, qq_plot, cook_hist, ncol=2)


## ---- include=FALSE-----------------------------------------------------------
cookd <- cooks.distance(full_lm)
sorted_f_cookd <- pf(cookd, 2, nrow(data) - 2)


## ---- include=FALSE-----------------------------------------------------------
pepper_reduced_result <- anova(pepper_reduced_lm, full_lm)
pepper_reduced_p <- pepper_reduced_result[6][2, ]
pepper_reduced_f <- pepper_reduced_result[5][2, ]
pepper_reduced_df1 <- pepper_reduced_result[3][2, ]
pepper_reduced_df2 <- pepper_reduced_result[1][2, ]

easiness_reduced_result <- anova(easiness_reduced_lm, full_lm)
easiness_reduced_p <- easiness_reduced_result[6][2, ]
easiness_reduced_f <- easiness_reduced_result[5][2, ]
easiness_reduced_df1 <- easiness_reduced_result[3][2, ]
easiness_reduced_df2 <- easiness_reduced_result[1][2, ]

gender_all_reduced_result <- anova(gender_all_reduced_lm, full_lm)
gender_all_reduced_p <- gender_all_reduced_result[6][2, ]
gender_all_reduced_f <- gender_all_reduced_result[5][2, ]
gender_all_reduced_df1 <- gender_all_reduced_result[3][2, ]
gender_all_reduced_df2 <- gender_all_reduced_result[1][2, ]

discipline_all_reduced_result <- anova(discipline_all_reduced_lm, full_lm)
discipline_all_reduced_p <- discipline_all_reduced_result[6][2, ]
discipline_all_reduced_f <- discipline_all_reduced_result[5][2, ]
discipline_all_reduced_df1 <- discipline_all_reduced_result[3][2, ]
discipline_all_reduced_df2 <- discipline_all_reduced_result[1][2, ]

gender_reduced_result <- anova(gender_reduced_lm, full_lm)
gender_reduced_p <- gender_reduced_result[6][2, ]
gender_reduced_f <- gender_reduced_result[5][2, ]
gender_reduced_df1 <- gender_reduced_result[3][2, ]
gender_reduced_df2 <- gender_reduced_result[1][2, ]

discipline_reduced_result <- anova(discipline_reduced_lm, full_lm)
discipline_reduced_p <- discipline_reduced_result[6][2, ]
discipline_reduced_f <- discipline_reduced_result[5][2, ]
discipline_reduced_df1 <- discipline_reduced_result[3][2, ]
discipline_reduced_df2 <- discipline_reduced_result[1][2, ]


## ---- include=FALSE-----------------------------------------------------------
full_lm_sum
full_lm_confint
full_lm_coef


## ---- include=FALSE-----------------------------------------------------------
easiness_coef <- full_lm_coef[3]
easiness_coef_lb <- full_lm_confint[3]
easiness_coef_ub <- full_lm_confint[14]


pepper_coef <- full_lm_coef[4]
pepper_coef_lb <- full_lm_confint[4]
pepper_coef_ub <- full_lm_confint[15]

