## ---- echo = FALSE, results = 'hide'------------------------------------------
library(ggplot2)

df <- read.csv("cmu-sleep.csv")

ggplot(df, aes(x = TotalSleepTime)) + geom_histogram(binwidth = 50) + labs(x = "Sleep Time (minutes)", caption = "Figure 1: Histogram of Sleep Time") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = term_gpa)) + geom_histogram(binwidth = 0.25) +
labs(x = "GPA (out of 4.0)", caption = "Figure 2: Histogram of GPA") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
library(ggplot2)

plot1 <- ggplot(df, aes(x=TotalSleepTime, y=term_gpa)) + 
  geom_point() 

plot1 + labs(y = "GPA (out of 4.0)", x = "Sleep Time (minutes)", caption = "Figure 3: Semester GPA final grade versus average daily sleep duration") + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
library(ggplot2)
library(broom)
lm1 <- lm(term_gpa ~ TotalSleepTime, data = df)

augment(lm1) |> ggplot(aes(x = TotalSleepTime, y = .resid)) +
geom_point() + labs(x = "Sleep Time (minutes)", y = "Residual", caption = "Figure 4: Residual plot of GPA versus Sleep Time") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
ggplot(augment(lm1), aes(sample = .resid)) + geom_qq() +
geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles", caption = "Figure 5: QQ-plot of GPA versus Sleep Time") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
library(ggplot2)

plot1 <- ggplot(df, aes(x=TotalSleepTime, y=term_gpa)) + 
  geom_point() 

plot1 + labs(y = "GPA (out of 4.0)", x = "Sleep Time (minutes)", caption = "Figure 6: GPA versus Sleep Time") + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

summary(lm(term_gpa ~ TotalSleepTime, data = df))


## ---- echo = FALSE, results = 'hide'------------------------------------------
confint(lm(term_gpa ~ TotalSleepTime, data = df))


## ---- echo = FALSE, results = 'hide'------------------------------------------
120* 0.0019846

