## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

# install.packages("GGally")
# options(scipen=0)

# Libraries
library(alr4)
library(ggplot2)
library(scales)
library(knitr)
library(dplyr)
library(kableExtra)
library(gridExtra)
library(grid)
library(GGally)
library(bestglm)
library(broom)


## ---- include=FALSE-----------------------------------------------------------
# Explain what the data is in more detail
print(nrow(Rateprof))


## ---- fig.width=3, fig.height=2.5, fig.align='center', echo=FALSE, warning=FALSE----
# Quality histogram
quality.hist = ggplot(Rateprof, aes(x=quality)) +
  geom_histogram(color="#6c584c", fill="#edafb8", bins=20, linewidth=0.2) +
  labs(x="Average quality rating from 1 to 5", y="Frequency",
       title="Distribution Quality Rating of Professors",
       caption="Figure 1: histogram for the distribution of\ninstructors' quality ratings.") +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))

# Add mean line
quality.hist = quality.hist + geom_vline(aes( xintercept=median(quality)),
                          color="#6c584c", linetype="dashed", size=0.5)

quality.hist


## ---- echo=FALSE, warning=FALSE-----------------------------------------------
calculate.percentages <- function(counts_table) {
  percentages <- prop.table(counts_table) * 100
  return(percentages)
}

gender.counts <- table(Rateprof$gender)
gender.percentages <- round(calculate.percentages(gender.counts), 3)

gender.percentages %>%
  kable(booktabs = TRUE,
        col.names = c("Gender", "Frequency"),
        caption = "ratio of instructors female to male") %>% 
  kable_styling(latex_options = "HOLD_position")


## ---- echo=FALSE, warning=FALSE-----------------------------------------------
pepper.counts <- table(Rateprof$pepper)
pepper.percentages <- round(calculate.percentages(pepper.counts), 3)

pepper.percentages %>%
  kable(booktabs = TRUE,
        col.names = c("y/n", "Frequency"),
        caption = "student ratio on perceptions attractiveness") %>% 
  kable_styling(latex_options = "HOLD_position")


## ---- fig.width=2.5, fig.height=2, fig.align='center', echo=FALSE, warning=FALSE----
discipline_bar <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill = "#b0c4b1", color = "#6c584c") +
  labs(
    x = "Discipline",
    y = "Frequency",
    title = "Frequency of Disciplines Taught by Instructors",
    caption = "Figure 2: bar graph depicting the distribution of disciplines."
  ) +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))


## ---- fig.width=2.5, fig.height=2, fig.align='center', echo=FALSE, warning=FALSE----
# easiness histogram
easiness.hist = ggplot(Rateprof, aes(x=easiness)) +
  geom_histogram(color="#6c584c", fill="#b0c4b1", bins=20, linewidth=0.2) +
  labs(x="Average easiness rating from 1 to 5", y="Frequency",
       title="Distribution Easiness Rating of Professors",
       caption="Figure 3: histogram for the distribution\nof instructors' level of easiness") +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))

# Add mean line
easiness.hist = easiness.hist + geom_vline(aes( xintercept=median(easiness)),
                          color="#6c584c", linetype="dashed", size=0.5)



## ---- echo=FALSE, warning=FALSE-----------------------------------------------
grid.arrange(discipline_bar, easiness.hist,
             heights = c(2.5, 1),
             ncol=2)


## ---- fig.align='center', echo=FALSE, warning=FALSE---------------------------
# Easiness
bivar_easiness = ggplot(Rateprof, aes(x=easiness, y=quality)) +
  geom_point() +
  labs(
    x = "Average Easiness Rating",
    y = "Instructor quality (1 to 5)",
    title = "Quality of instructor teaching\nby average easiness rating",
    caption = "Figure 4: scatterplot of quality by easiness"
  ) +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))


## ---- fig.align='center', echo=FALSE, warning=FALSE---------------------------
# Discipline
custom_colors <- c("#bbd0ff", "#edafb8", "#dde5b6", "#f2cc8f")

bivar_disciplines = ggplot(Rateprof, aes(x=discipline, y=quality, fill=discipline)) +
  geom_boxplot() +
  labs(
    x = "",
    y = "Instructor quality\n(1 to 5)",
    title = "Quality of instructor teaching by discipline",
    caption = "Figure 5: bar plot of quality by discipline"
  ) +
  scale_fill_manual(values = custom_colors) +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))


## ---- fig.align='center', echo=FALSE, warning=FALSE---------------------------
# Gender
custom_colors <- c("#ffcfd2", "#c8b6ff")

bivar_gender = ggplot(Rateprof, aes(x=gender, y=quality, fill=gender)) +
  geom_boxplot() +
  labs(
    x = "",
    y = "Instructor quality\n(1 to 5)",
    title = "Quality of instructor teaching by gender",
    caption = "Figure 6: barplot of quality by gender"
  ) +
  scale_fill_manual(values = custom_colors) +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))


## ---- fig.align='center', echo=FALSE, warning=FALSE---------------------------
# pepper
custom_colors <- c("#457b9d", "#f4a261")

bivar_pepper = ggplot(Rateprof, aes(x=pepper, y=quality, fill=pepper)) +
  geom_boxplot() +
  labs(
    x = "",
    y = "Instructor quality\n(1 to 5)",
    title = "Quality of instructor teaching by perceptions of attractiveness",
    caption = "Figure 7: barplot of quality by attractiveness"
  ) +
  scale_fill_manual(values = custom_colors) +
  theme(axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(size = 10, hjust = 0.5))


## ---- fig.align='center', echo=FALSE, warning=FALSE---------------------------
grid.arrange(bivar_easiness, bivar_disciplines,
             bivar_gender, bivar_pepper,
             heights = c(3.4, 3),
             nrow=2,
             ncol=2)


## ---- include=FALSE, warning=FALSE--------------------------------------------
# All predictors with interactions
all.inter.lm = lm(quality ~ easiness + easiness:gender + easiness:discipline, data=Rateprof)
summary(all.inter.lm)
extractAIC(all.inter.lm)


## ---- include=FALSE, warning=FALSE--------------------------------------------
# Model prediction after reducing model
red.inter.lm = step(all.inter.lm, direction="both", trace=0)
extractAIC(red.inter.lm)
summary(red.inter.lm)


## ---- echo=FALSE, warning=FALSE-----------------------------------------------
# Model 1 residuals
all.inter.res = ggplot(data=Rateprof, aes(x=fitted(all.inter.lm), y=resid(all.inter.lm))) +
  geom_point(alpha=0.6, color="#f77f6d") +
  geom_smooth(method="loess", se=FALSE, linetype="dashed") +
  labs(x="Fitted Values",
       y="Residuals",
       title = "Model 1 residuals",
       caption="Figure 8: residuals for model with\nall variables and interaction terms") +
  theme(text=element_text(family="Times"),
        plot.title=element_text(size=12, hjust=0.5))


## ---- echo=FALSE, warning=FALSE-----------------------------------------------
# Model 2 residuals
red.inter.res = ggplot(data=Rateprof, aes(x=fitted(red.inter.lm), y=resid(red.inter.lm))) +
  geom_point(alpha=0.6, color="#f77f6d") +
  geom_smooth(method="loess", se=FALSE, linetype="dashed") +
  labs(x="Fitted Values",
       y="Residuals",
       title = "Model 2 residuals",
       caption="Figure 9: residuals for model\nwith reduced interaction terms") +
  theme(text=element_text(family="Times"),
        plot.title=element_text(size=12, hjust=0.5))


## ---- fig.align='center', fig.width=5, fig.height=2.5, echo=FALSE, warning=FALSE, message=FALSE----
grid.arrange(all.inter.res, red.inter.res, 
             nrow=1, ncol=2)


## ---- fig.width=5, fig.height=3, fig.align="center", echo=FALSE, warning=FALSE----
par(mfrow = c(1, 2))

# Model 1
residuals.all = residuals(all.inter.lm)
qqnorm(residuals.all)
qqline(residuals.all, col = "red")
title("\n\n\nFigure 10: full model", cex.main = 0.8)

# Model 2
residuals.red = residuals(red.inter.lm)
qqnorm(residuals.red)
qqline(residuals.red, col = "red")
title("\n\n\nFigure 11: final model", cex.main = 0.8)


## ---- fig.align='center', echo=FALSE, warning=FALSE---------------------------
# Just easiness---
easiness.lm = lm(quality ~ easiness, data=Rateprof)
# summary(easiness.lm)
# Just discipline---
discip.lm = lm(quality ~ factor(discipline), data=Rateprof)
# summary(discip.lm)
# Just gender---
gender.lm = lm(quality ~ factor(gender), data=Rateprof)
# summary(gender.lm)
# Just pepper---
pepper.lm = lm(quality ~ factor(pepper), data=Rateprof)
# summary(pepper.lm)

# Create table of significance values on individual simple linear regression
simple.df = data.frame(
  Predictor =  c("Easiness",
                 "Discipline Math", "Discipline Social Science", "Discipline STEM", "Discipline Pre-prof",
                 "Gender Female", "Gender Male",
                 "Attractive (No)", "Attractive (Yes)"),
  P_values = c(format(summary(easiness.lm)$coefficients["easiness", "Pr(>|t|)"], digits=3),

               format(summary(discip.lm)$coefficients["(Intercept)", "Pr(>|t|)"], digits=3),
               format(summary(discip.lm)$coefficients["factor(discipline)SocSci", "Pr(>|t|)"], digits=3),
               format(summary(discip.lm)$coefficients["factor(discipline)STEM", "Pr(>|t|)"], digits=3),
               format(summary(discip.lm)$coefficients["factor(discipline)Pre-prof", "Pr(>|t|)"], digits=3),

               format(summary(gender.lm)$coefficients["(Intercept)", "Pr(>|t|)"], digits=3),
               format(summary(gender.lm)$coefficients["factor(gender)male", "Pr(>|t|)"], digits=3),

               format(summary(pepper.lm)$coefficients["(Intercept)", "Pr(>|t|)"], digits=3),
               "1.24e-13" )
)

simple.df %>%
  kable(booktabs = TRUE,
        caption = "Individual significance values per predictor") %>% 
  kable_styling(latex_options = "HOLD_position")



## ---- include=FALSE-----------------------------------------------------------
# Without interactions
all.lm = lm(quality ~ easiness + gender + discipline, data=Rateprof)
summary(all.lm)
extractAIC(all.lm)

# With interactions
all.inter.lm = lm(quality ~ easiness*gender + easiness*discipline, data=Rateprof)
summary(all.inter.lm)
extractAIC(all.inter.lm)


## ---- echo=FALSE, warning=FALSE-----------------------------------------------
# Perform ANOVA testing
# anova(all.lm, all.inter.lm)

# Create a table
anova.table <- anova(all.lm, all.inter.lm) %>%
  tidy()

anova.table$model <- c("Model without interactions", "Model with interactions")
anova.table <- anova.table %>%
  select(model, df.residual, statistic, p.value)
  
kable(anova.table, booktabs = TRUE, 
      caption = "ANOVA table without interactions / with interactions") %>%
  kable_styling(latex_options = "HOLD_position")



## ---- include=FALSE-----------------------------------------------------------
# Model prediction after reducing model
red.inter.lm = step(all.inter.lm, direction="both", trace=0)

red.inter.lm = lm(quality ~ easiness + gender , data=Rateprof)
lm.summary = summary(red.inter.lm)
lm.summary
extractAIC(red.inter.lm)


## ---- fig.align='center', fig.width=5, fig.height=3.5, echo=FALSE-------------
ggplot(Rateprof, aes(x = easiness, y = quality, color = gender)) +
  geom_point() +
  geom_abline(intercept = coef(red.inter.lm)[1], slope = coef(red.inter.lm)[2], color = "red") +  # Add abline using model coefficients
  labs(
    x = "Easiness (1 to 5)",
    y = "Quality (1 to 5)",
    title = "Instructor Quality by Easiness",
    caption = "Figure 11: linear model fit of quality given easiness"
  )


## ---- echo=FALSE--------------------------------------------------------------
lm.table <- data.frame(
  # Coefficient = c("(Intercept)", "easiness", "gendermale"),
  Estimate = lm.summary$coefficients[, "Estimate"],
  P_Value = c( format(lm.summary$coefficients["(Intercept)", "Pr(>|t|)"], digits=3),
               format(lm.summary$coefficients["easiness", "Pr(>|t|)"], digits=3),
               format(lm.summary$coefficients["gendermale", "Pr(>|t|)"], digits=3)),
  CI_Lower = confint(red.inter.lm)[, 1],
  CI_Upper = confint(red.inter.lm)[, 2]
)


kable(lm.table, booktabs = TRUE, 
      col.names = c("Estimate", "P-Value", "Lower CI", "Upper CI"),
      caption = "Model summary") %>%
  kable_styling(latex_options = "HOLD_position")

