## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, include=FALSE--------------------------------------------
library(ggplot2)


## -----------------------------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")
summary_table <- summary(sleep[, c("TotalSleepTime", "cum_gpa", "term_gpa")])
knitr::kable(summary_table, caption = "Summary of Key Variables")


## -----------------------------------------------------------------------------
hist(sleep$TotalSleepTime, main = "Histogram of Total Sleep Time", xlab = "Minutes of Sleep")
hist(sleep$cum_gpa, main = "Histogram of Cumulative GPA", xlab = "Cumulative GPA")
hist(sleep$term_gpa, main = "Histogram of Term GPA", xlab = "Term GPA")


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot of Total Sleep Time vs. Term GPA"----
plot(term_gpa ~ TotalSleepTime, data = sleep,
     xlab = "Total Sleep Time (minutes)", ylab = "Term GPA")


## ---- fig.width=6, fig.height=4, fig.cap="QQ Plot of Residuals from Simple Linear Regression Model"----
fit <- lm(term_gpa ~ TotalSleepTime, data = sleep)
residuals <- resid(fit)
qqnorm(residuals)
qqline(residuals)


## -----------------------------------------------------------------------------
fit <- lm(exp(term_gpa) ~ TotalSleepTime, data = sleep)
plot(exp(term_gpa) ~ TotalSleepTime, data = sleep,
     xlab = "Total Sleep Time (minutes)", ylab = "Exponential of Term GPA")
abline(fit, col = "red")


## ---- fig.width=6, fig.height=4, fig.cap="QQ Plot of Residuals from Transformed Model"----
residuals <- resid(fit)
qqnorm(residuals)
qqline(residuals)


## -----------------------------------------------------------------------------
summary_table_fit <- summary(fit)
knitr::kable(summary_table_fit$coefficients, caption = "Summary of Regression Coefficients")

