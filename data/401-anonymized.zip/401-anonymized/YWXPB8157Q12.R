## ----setup, include = FALSE, echo=FALSE, warning=FALSE------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----cars---------------------------------------------------------------------
library("ggplot2")
sleep <- read.csv("cmu-sleep.csv")[,c("subject_id", "TotalSleepTime", "cum_gpa", "term_gpa")]
sleep$term_gpa_r <- log(max(sleep$term_gpa)+1-sleep$term_gpa)
sleep$cum_gpa_r <- log(max(sleep$cum_gpa)+1-sleep$cum_gpa)
model.cube <- lm(term_gpa^3 ~ cum_gpa^3 + TotalSleepTime, sleep)
model.log <- lm(term_gpa_r ~ cum_gpa_r  + TotalSleepTime, sleep)
model <- lm(term_gpa ~ cum_gpa + TotalSleepTime, sleep)


## -----------------------------------------------------------------------------
hist(sleep$TotalSleepTime, xlab="Average Sleep Time", main="Average Sleep Time Histogram")


## -----------------------------------------------------------------------------
hist(sleep$term_gpa, xlab="Term GPA", main="Term GPA Histogram")


## -----------------------------------------------------------------------------
hist(sleep$cum_gpa, xlab="Cumulative GPA", main="Cumulative GPA Histogram")


## -----------------------------------------------------------------------------
plot(sleep$TotalSleepTime, sleep$term_gpa, xlab="Average Sleep Time", ylab="Term GPA", main="Average Sleep Time vs Term GPA")

## -----------------------------------------------------------------------------
plot(sleep$cum_gpa, sleep$term_gpa, xlab="Cumulative GPA", ylab="Term GPA", main="Cumulative GPA vs Term GPA")


## ---- fig.dim=c(6,5)----------------------------------------------------------
par(mfrow=c(2,2))
plot(model)


## ---- fig.dim=c(6,5)----------------------------------------------------------
par(mfrow=c(2,2))
hist(sleep$term_gpa^3, xlab="Term GPA Cubed", main="Term GPA Cube Transfom Histogram")
hist(sleep$cum_gpa^3, xlab="Cumulative GPA Cubed", main="Cumulative GPA Cube Transfom Histogram")
hist(sleep$term_gpa_r, xlab="Term GPA Reverse Log", main="Term GPA Reverse Log Transfom Histogram")
hist(sleep$cum_gpa_r, xlab="Cumulative GPA Reverse Log", main="Cumulative GPA Reverse Log Transfom Histogram")


## -----------------------------------------------------------------------------
plot(sleep$TotalSleepTime, sleep$term_gpa^3, xlab="Average Sleep Time", ylab="Term GPA", main="Average Sleep Time vs Cube Transforemd Term GPA")
plot(sleep$TotalSleepTime, sleep$term_gpa_r, xlab="Average Sleep Time", ylab="Term GPA", main="Average Sleep Time vs Reversed Log Transformed Term GPA")


## ---- fig.dim=c(6,5)----------------------------------------------------------
par(mfrow=c(2,2))
plot(model.cube)


## ---- fig.dim=c(6,5)----------------------------------------------------------
par(mfrow=c(2,2))
plot(model.log)


## -----------------------------------------------------------------------------
sleep$predictions <- predict(model.log, sleep)
sleep$predictions.r <- abs(exp(sleep$predictions) - max(sleep$term_gpa)-1)
ggplot(sleep, aes(x=TotalSleepTime, y=predictions)) +
  geom_point() +
  geom_smooth(method="lm", color="red") +
  labs(x="Average Sleep Time", y="Reverse Log Transformed Term GPA", title="Reverse Log Transformed Fitted Model", subtitle = "Includes 95% confidence interval")


## -----------------------------------------------------------------------------
sleep$predictions <- predict(model.log, sleep)
sleep$predictions.r <- abs(exp(sleep$predictions) - max(sleep$term_gpa)-1)
ggplot(sleep, aes(x=TotalSleepTime, y=predictions.r)) +
  geom_point() +
  geom_smooth(method="lm", color="red") +
  labs(x="Average Sleep Time", y="Reverse Log Transformed Term GPA", title="Reverse Log Transformed Fitted Model", subtitle = "Includes 95% confidence interval")

