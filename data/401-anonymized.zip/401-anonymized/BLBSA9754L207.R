## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(dplyr)
cmu <- read.csv("cmu-sleep.csv")


## ---- fig.width=5, fig.height=3, fig.cap="Histogram of Average Sleep Time"----
cmu %>%
ggplot(aes(x= TotalSleepTime)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Average Sleep Time per Night in minutes", y = "Frequency")


## -----------------------------------------------------------------------------
summary(cmu$TotalSleepTime)


## ---- fig.width=5, fig.height=3, fig.cap="Histogram of Students' GPA In The Semester Studied"----
cmu %>%
ggplot(aes(x= term_gpa)) +
geom_histogram(color = "black", fill = "lightblue", bins =50) + 
labs(x = "Student GPA out of 4.0", y = "Frequency",)


## ---- fig.width=5, fig.height=3,fig.cap=" Histogram of Students' GPA In The Previous Semester"----
cmu %>%
ggplot(aes(x= cum_gpa)) +
geom_histogram(color = "black", fill = "lightblue", bins =50) + 
labs(x = "Student GPA out of 4.0", y = "Frequency",)


## ---- fig.width=5, fig.height=3, fig.cap="Scatterplot of Sleep Time vs. Student GPA In The Semester Studied"----
cmu %>%
ggplot(aes(x=TotalSleepTime, y= term_gpa)) +
  geom_point()+
labs(x = "Average Sleep Time per Night in minutes", y = "Student GPA out of 4.0",)


## ---- fig.width=5, fig.height=3, fig.cap="Scatterplot of Sleep Time vs. Student GPA Semester Before"----
cmu %>%
ggplot(aes(x=TotalSleepTime, y= cum_gpa)) +
  geom_point()+
labs(x = "Average Sleep Time per Night in minutes", y = "Student GPA out of 4.0",)


## ---- fig.width=5, fig.height=3,fig.cap="Scatterplot of log(Sleep Time) vs. Student GPA In Semester During"----
cmu %>%
ggplot(aes(x=log(TotalSleepTime), y= term_gpa)) +
  geom_point()+
labs(x = "log(Average Sleep Time per Night in minutes)", y = "Student GPA out of 4.0",)


## ---- fig.width=5, fig.height=3,fig.cap="Scatterplot of log(Sleep Time) vs. Change in GPA"----
cmu$change = cmu$term_gpa - cmu$cum_gpa
cmu %>%
ggplot(aes(x=log(TotalSleepTime), y=change)) +
  geom_point()+
labs(x = "log(Average Sleep Time per Night in minutes)", y = "change in GPA",)


## -----------------------------------------------------------------------------
model_1 = lm(term_gpa ~ log(TotalSleepTime), data = cmu)


## -----------------------------------------------------------------------------
model_2 = lm(change ~ log(TotalSleepTime), data = cmu)


## ---- fig.width=5, fig.height=3, fig.cap="Model 1 Residual Plot"--------------
plot(model_1, which = 1,)


## ---- fig.width=5, fig.height=3,fig.cap="Model 1 Normal Q-Q Plot"-------------
plot(model_1, which = 2,)


## ---- fig.width=5, fig.height=3, fig.cap="Model 2 Residual Plot"--------------
plot(model_2, which = 1,)


## ---- fig.width=5, fig.height=3, fig.cap="Model 2 Q-Q Plot"-------------------
plot(model_2, which = 2,)


## -----------------------------------------------------------------------------
summary(model_1)


## -----------------------------------------------------------------------------
confint(model_1)


## -----------------------------------------------------------------------------
summary(model_2)


## -----------------------------------------------------------------------------
confint(model_2)


## -----------------------------------------------------------------------------
prediction <- predict(model_2, newdata = data.frame(TotalSleepTime = 397.3 - 120), interval = "prediction", level =0.95)
prediction

