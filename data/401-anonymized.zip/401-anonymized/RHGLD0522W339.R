## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
sleep = read.csv("cmu-sleep.csv")
library(ggplot2)


## -----------------------------------------------------------------------------
ggplot(sleep, aes(x = TotalSleepTime)) +
  geom_histogram(bins = 30) + 
  labs(x = "Total Sleep Time (minutes)", y = "Frequency") +
  ggtitle("Histogram 1: Histogram of Total Sleep Time among Students in Spring Semester")

ggplot(sleep, aes(x = log(TotalSleepTime))) +
  geom_histogram(bins = 30) + 
  labs(x = "Total Sleep Time (minutes)", y = "Frequency") +
  ggtitle("Histogram 2: Histogram of Log Transformed Total Sleep Time among Students in Spring Semester")

ggplot(sleep, aes(x = cum_gpa)) +
  geom_histogram(bins = 30) + 
  labs(x = "Cumulative GPA before Spring Semester", y = "Frequency") +
  ggtitle("Histogram 3: Histogram of Frequency of Cumulative GPA")

ggplot(sleep, aes(x = term_gpa)) +
  geom_histogram(bins = 30) + 
  labs(x = "Term GPA during Spring Semester", y = "Frequency") +
  ggtitle("Histogram 4: Histogram of Frequency of Term GPA during Spring Semester")


## -----------------------------------------------------------------------------
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + 
      labs(x = "Total Sleep Time (minutes) in Spring Semester", y = "Term GPA (out of 4.0)") +
      ggtitle("Scatterplot 1: Association between Sleep Time and Term GPA")

ggplot(sleep, aes(x = log(TotalSleepTime), y = term_gpa)) + geom_point() + 
      labs(x = "Log of Total Sleep Time (minutes) in Spring Semester", y = "Term GPA (out of 4.0)") +
      ggtitle("Scatterplot 2: Association between Log Transformed Sleep Time and Term GPA")


ggplot(sleep, aes(x = cum_gpa, y = term_gpa)) + geom_point() + 
      labs(x = "Cumulative GPA (out of 4.0)", y = "Term GPA (out of 4.0)") +
      ggtitle("Scatterplot 3: Association between Cumulative GPA and Term GPA")

ggplot(sleep, aes(x = TotalSleepTime, y = cum_gpa-term_gpa)) + geom_point() + 
      labs(x = "Total Sleep Time (minutes)", y = "Difference between Cumulative GPA and Term GPA") +
      ggtitle("Scatterplot 4: Association between Total Sleep Time and Change in GPA")


## -----------------------------------------------------------------------------
library(modelsummary)
sleep_model = lm(term_gpa ~ TotalSleepTime, data = sleep)
sleep_model_log = lm(term_gpa ~ log(TotalSleepTime), data = sleep)

knitr::kable(summary(sleep_model)$coefficients, format = "markdown", 
             caption = "Coefficients of Linear Model without Log Transform")
knitr::kable(summary(sleep_model_log)$coefficients, format = "markdown", 
             caption = "Coefficients of Linear Model with Log Transform")


knitr::kable(confint(sleep_model), format = "markdown",
             caption = "95% Confidence Interval of Model without Log Transform")
knitr::kable(confint(sleep_model_log), format = "markdown",
             caption = "95% Confidence Interval of Model with Log Transform")



## -----------------------------------------------------------------------------
modelsummary(list("Sleep Model" = sleep_model, "Sleep Model w/ Log" = sleep_model_log),
             gof_map = c("r.squared", "nobs"), statistic = c("std.error", "p.value"), 
             output = "markdown", 
             caption = "Model Summary with and without Log Transformation")


## -----------------------------------------------------------------------------
library(regressinator)
sleep_resid = residuals(sleep_model)

plot(sleep$TotalSleepTime, residuals(sleep_model),
     xlab = "Total Sleep Time (minutes)", ylab = "Residuals",
     main = "Residual Plot 1: Residuals of Total Sleep Time in Linear Sleep Model")

var_hat = sum(sleep_resid)/(length(sleep_resid)-2) 
x = var_hat**(0.5)
x = format(x, 12)
x = matrix(c(x), ncol = 1, byrow = TRUE)
colnames(x) = "Variance"
rownames(x) = "Value"
new = as.table(x)
knitr::kable(new, output = "markdown", caption = "Variance of the Residuals")

qqnorm(residuals(sleep_model), main = "Q-Q Plot 1: Normal QQ Plot for the Model without Log Transform")
qqline(residuals(sleep_model))

qqnorm(residuals(sleep_model_log), main = "Q-Q Plot 2: Normal QQ Plot for the Model with Log Transform")
qqline(residuals(sleep_model_log))


## -----------------------------------------------------------------------------
x1 = 0.8215551 * -120
x2 = 0.001984649 * -120
outputs = matrix(c(x1, x2), ncol = 2, nrow = 1, byrow = TRUE)
colnames(outputs) = c("Model with Log Transform", "Model without Log Transform")
rownames(outputs) = c("Change in GPA")
output_table = as.table(outputs)

knitr::kable(output_table, output = "markdown", caption = "Model Prediction of Change in GPA with 2 Hours Less Sleep")

