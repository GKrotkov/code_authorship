## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(ggplot2)
library(tidyverse)


## ---- message = FALSE---------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = discipline)) + geom_bar() +
  labs(x = "Discipline", y = "Count", 
       title = "Figure 1: Bar Plot of Professors by Discipline")
Rateprof %>%
  ggplot(aes(x = gender)) + geom_bar() +
  labs(x = "Discipline", y = "Count", 
       title = "Figure 2: Bar Plot of Professors by Gender")
Rateprof %>%
  ggplot(aes(x = pepper)) + geom_bar() +
  labs(x = "Discipline", y = "Count", 
       title = "Figure 3: Bar Plot of Professors by Attractiveness")
Rateprof %>%
  ggplot(aes(x = easiness)) + geom_histogram() +
  labs(x = "Easiness", y = "Count", 
       title = "Figure 4: Bar Plot of Professors by Easiness")
Rateprof %>%
  ggplot(aes(x = quality)) + geom_histogram() +
  labs(x = "Quality", y = "Count", 
       title = "Figure 5: Histogram of Professors by Avg Quality Ratings")


## ---- message = FALSE---------------------------------------------------------
library(GGally)

rateprof.small <- Rateprof %>%
  select('quality', 'discipline', 'gender', 'pepper', 'easiness')

ggpairs(rateprof.small) + labs(title = "Figure 6: Pairwise Plot of Variables")


## -----------------------------------------------------------------------------
tent.mod.1 <- lm(quality ~ easiness + pepper + gender + discipline, 
                 data = rateprof.small)


## -----------------------------------------------------------------------------
res <- resid(tent.mod.1)
plot(fitted(tent.mod.1), res, xlab = "Predicted Value", ylab = "Residual",
     main = "Figure 7: Simple Model Residual Plot")
abline(0,0)


## -----------------------------------------------------------------------------
qqnorm(res, main = "Figure 8: Normal Q-Q Plot, Simple Model")
qqline(res, datax = FALSE, distribution = qnorm, probs = c(0.25, 0.75))


## ---- include=FALSE-----------------------------------------------------------
summary(tent.mod.1)


## ---- include = FALSE---------------------------------------------------------
lm2 <- lm(quality ~ easiness + easiness:gender + easiness:discipline,
          data = rateprof.small)
lm3 <- lm(quality ~ easiness, data = rateprof.small)
lm4 <- lm(quality ~ easiness + easiness:discipline, data = rateprof.small)
lm5 <- lm(quality ~ easiness + easiness:gender, data = rateprof.small)

anova(lm3, lm2)


## ---- include=FALSE-----------------------------------------------------------
anova(lm3, lm4)
anova(lm3, lm5)

