## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(tidyverse)
library(ggplot2)
library(alr4)
library(broom)
library(knitr)
library(kableExtra)
library(gridExtra)


## ---- fig.height = 4----------------------------------------------------------
a1 <- ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(binwidth = 1, fill = "slategray3", color = "black") +
  labs(x = "Quality", y = "Frequency") 

a2 <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = 1, fill = "slategray3", color = "black") +
  labs(x = "Easiness", y = "Frequency")

grid.arrange(a1, a2, ncol = 2, top = "Figure 1: Histograms of Quantitative Variables")




## ---- fig.width=8, fig.height = 4---------------------------------------------
par(mfrow = c(1, 3))

b1 <- ggplot(Rateprof, aes(x = gender)) +
  geom_bar(fill = "lightpink3") +
  labs(x = "Gender", y = "Count")

# Create a ggplot bar plot for Attractiveness Distribution
b2 <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(fill = "lightpink3") +
  labs(x = "Attractiveness (Pepper Rating)", y = "Count")

# Create a ggplot bar plot for Discipline Distribution
b3 <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill = "lightpink3") +
  labs(x = "Discipline", y = "Count")

grid.arrange(b1, b2, b3, ncol = 3, top="Figure 2: Frequency Barplots of Categorical Variables")




## ---- fig.width=10------------------------------------------------------------

boxplot_color <- "honeydew3"

p1 <- ggplot(Rateprof, aes(x = gender, y = quality)) + 
      geom_boxplot(fill = boxplot_color) + 
      labs(title = "Gender vs. Quality Rating", x = "Gender", y = "Quality Rating")

p2 <- ggplot(Rateprof, aes(x = pepper, y = quality)) + 
      geom_boxplot(fill = boxplot_color) + 
      labs(title = "Attractiveness vs. Quality Rating", x = "Attractiveness", y = "Quality Rating")

p3 <- ggplot(Rateprof, aes(x = discipline, y = quality)) + 
      geom_boxplot(fill = boxplot_color) + 
      labs(title = "Discipline vs. Quality Rating", x = "Discipline", y = "Quality Rating")

p4 <- ggplot(Rateprof, aes(x = gender, y = easiness)) + 
      geom_boxplot(fill = boxplot_color) + 
      labs(title = "Gender vs. Easiness Rating", x = "Gender", y = "Easiness Rating")

p5 <- ggplot(Rateprof, aes(x = pepper, y = easiness)) + 
      geom_boxplot(fill = boxplot_color) + 
      labs(title = "Attractiveness vs. Easiness Rating", x = "Attractiveness", y = "Easiness Rating")

p6 <- ggplot(Rateprof, aes(x = discipline, y = easiness)) + 
      geom_boxplot(fill = boxplot_color) + 
      labs(title = "Discipline vs. Easiness Rating", x = "Discipline", y = "Easiness Rating")

grid.arrange(p1, p2, p3, p4, p5, p6, ncol = 3, top="Figure 3: Bivariate Boxplots of the Variables")




## ---- fig.height = 5----------------------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality, color = discipline, shape = gender)) +
  geom_point() + labs(title = "Figure 4: Scatterplot of Easiness vs. Quality",
       x = "Easiness Rating",
       y = "Quality Rating")


## ---- fig.height = 5----------------------------------------------------------
model_with_interactions <- lm(quality ~ easiness * gender * discipline, data = Rateprof)

tidy_output <- tidy(model_with_interactions)
interaction_terms <- tidy_output %>%
  filter(term == "easiness:gendermale" | term == "easiness:disciplineSocSci" | term == "easiness:disciplineSTEM"| term == "easiness:disciplinePre-prof"| term == "easiness:gendermale:disciplineSocSci" | term == "easiness:gendermale:disciplineSTEM" | term == "easiness:gendermale:disciplinePre-prof")

interaction_terms$p.value <- sprintf("%.12f", interaction_terms$p.value)

knitr::kable(interaction_terms, digits = 3, 
             col.names = c("Term", "Estimate", "Std. Error", "Statistic", "P-value"), 
             caption = "Table 1: Interaction Terms from the Linear Model with Interactions") %>%
  kable_styling(latex_options = "HOLD_position")




## -----------------------------------------------------------------------------
model <- lm(quality ~ easiness + gender + pepper, data = Rateprof)



## ---- fig.height = 4----------------------------------------------------------
par(mfrow = c(2, 2))
plot(model)
mtext("Figure 6: Diagnostic Plots for Selected Model",side=3,line=-1,outer=TRUE)



## -----------------------------------------------------------------------------

gof_stats <- data.frame(
  Statistic = c("R-squared", "Adjusted R-squared", "Residual Standard Error", "F-statistic p-value"),
  Value = c(
    summary(model)$r.squared, 
    summary(model)$adj.r.squared, 
    sigma(model), 
    pf(summary(model)$fstatistic[1], 
       summary(model)$fstatistic[2], 
       summary(model)$fstatistic[3], lower.tail = FALSE)
  )
)

kable(gof_stats, caption = "Table 2: Goodness of Fit Statistics for Selected Model", digits = 4) %>%
  kable_styling(latex_options = "HOLD_position")


## -----------------------------------------------------------------------------

tidy_output <- tidy(model)
tidy_output$p.value <- sprintf("%.12f", tidy_output$p.value)

knitr::kable(tidy_output, digits = 3, col.names = c("Term", "Estimate", "Std. Error", "Statistic", "P-value"), caption = "Table 3: Statistics from the Linear Model") %>%
  kable_styling(latex_options = "HOLD_position")

