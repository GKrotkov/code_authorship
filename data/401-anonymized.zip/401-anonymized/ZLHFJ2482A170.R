## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
suppressWarnings(library(bestglm))
rateprof <- Rateprof


## ---- fig.width=3, fig.height=3, fig.cap="Genders of professors", cache=FALSE----
plot(rateprof$gender, main="Gender of professor", ylab="Count")


## ---- fig.width=3, fig.height=3, fig.cap="Attractiveness of professors", cache=FALSE----
plot(rateprof$pepper, main="Is your professor attractive?", ylab="Count")


## ---- fig.width=4, fig.height=3, fig.cap="Disciplines of professors' courses"----
plot(rateprof$discipline, main="Discipline of professors' courses", ylab="Count")


## ---- fig.width=4, fig.height=3, fig.cap="Easiness of professors' courses"----
hist(rateprof$easiness, main="Easiness of professors' courses", xlab="Easiness (1=hard & 5=easy)")


## ---- fig.width=4, fig.height=3, fig.cap="Quality of professors' courses"-----
hist(rateprof$quality, main="Quality of professors' courses", xlab="Quality (1=bad & 5=good)")


## -----------------------------------------------------------------------------
subrp <- subset(rateprof, select = -c(numYears,numRaters,numCourses,dept,helpfulness,clarity,raterInterest,sdQuality,sdHelpfulness,sdClarity,sdEasiness,sdRaterInterest))


## ---- fig.width=4, fig.height=3, fig.cap="Quality of professors' courses"-----
pairs(subrp)


## ---- fig.width=4, fig.height=3, fig.cap="Attractiveness & gender correlation"----
plot(subrp$pepper ~ subrp$gender, main="Attractiveness and gender correlation", xlab="Gender", ylab="Attractive?")


## ---- fig.width=4, fig.height=3, fig.cap="Attractiveness & discipline correlation"----
plot(subrp$pepper ~ subrp$discipline, main="Attractiveness and discipline correlation", xlab="Discipline", ylab="Attractive?")


## ---- fig.width=4, fig.height=3, fig.cap="Gender & discipline correlation"----
plot(subrp$gender ~ subrp$discipline, main="Discipline and gender correlation", xlab="Discipline", ylab="Gender")


## ---- include=FALSE-----------------------------------------------------------
lmrp <- lm(quality ~ gender + pepper + discipline + easiness, subrp)
step(lmrp, trace = 0)
bestglm(subrp)
steprp <- lm(quality ~ gender + pepper + easiness, subrp)
bestglmrp <- lm(quality ~ discipline, subrp)


## -----------------------------------------------------------------------------
steprp$coefficients
bestglmrp$coefficients


## -----------------------------------------------------------------------------
AIC(steprp)
AIC(bestglmrp)


## ---- include=FALSE-----------------------------------------------------------
summary(steprp)
confint(steprp)


## -----------------------------------------------------------------------------
vif(steprp)


## ---- fig.width=4, fig.height=3, fig.cap="QQ plot for fitted model"-----------
qqnorm(resid(steprp))

