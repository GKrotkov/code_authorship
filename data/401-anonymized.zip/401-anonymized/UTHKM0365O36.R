## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
suppressPackageStartupMessages(library("alr4"))
rateprof <- alr4::Rateprof


## -----------------------------------------------------------------------------
suppressPackageStartupMessages(library(ggplot2))
hist(rateprof$easiness,
    main = "Professors' Average Easiness Ratings",
          xlab = "Average Easiness Rating",
          ylab = "Frequency of Easiness Rating",
    breaks = 10)

## -----------------------------------------------------------------------------
hist(rateprof$quality,
    main = "Professors' Average Quality Ratings",
          xlab = "Average Quality Rating",
          ylab = "Frequency of Quality Rating",
    breaks = 16)


## -----------------------------------------------------------------------------
ggplot(rateprof, aes(x=easiness, y=quality)) +
         geom_point() +
         labs(title="Average Easiness Rating vs. Average Quality", x="Average Easiness Rating", y="Average Quality")


## -----------------------------------------------------------------------------
suppressPackageStartupMessages(library(bestglm))
rateprof$gender <- factor(rateprof$gender)
rateprof$pepper <- factor(rateprof$pepper)
rateprof$discipline <- factor(rateprof$discipline)



## -----------------------------------------------------------------------------
best_model <- bestglm(rateprof[, c(1, 5, 6, 11, 8)], IC="AIC")
best_model

## -----------------------------------------------------------------------------
analysis <- lm(formula = quality ~ gender + pepper + easiness, data = rateprof)
summary(analysis)

## -----------------------------------------------------------------------------
plot(analysis, which=1)

## -----------------------------------------------------------------------------
plot(analysis, which=2)


## -----------------------------------------------------------------------------
suppressPackageStartupMessages(library(modelsummary))
modelsummary(analysis)

