## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
library(alr4)
library(GGally)
library(dplyr)
library(ggpubr)
library(broom)
library(modelsummary)
df_prof <- Rateprof


## ---- echo = FALSE------------------------------------------------------------
quality_plot <- ggplot(df_prof, aes(x=quality)) + 
  geom_histogram(bins = 30) + ggtitle("Distribution of \nQuality Scale \n(1, worst, to 5, best)") + xlab("Scale") + ylab("Count")
gender_plot <- ggplot(df_prof, aes(x=gender)) + 
  geom_bar() + ggtitle("Distribution of \nGender") + xlab("Gender") + ylab("Count")
pepper_plot <- ggplot(df_prof, aes(x=pepper)) + 
  geom_bar() + ggtitle("Distribution of \nAttractiveness \nRating") + xlab("Attractiveness Status") + ylab("Count")
easiness_plot <- ggplot(df_prof, aes(x=easiness)) + 
  geom_histogram(bins = 30) + ggtitle("Distribution of \nEasiness \n(1, worst, to 5, best)") + xlab("Scale") + ylab("Count")
discipline_plot <- ggplot(df_prof, aes(x=discipline)) + 
  geom_bar() + ggtitle("Distribution of \nDiscipline") + xlab("Discipline") + ylab("Count")

easiness_gender_plot <- ggplot(df_prof, aes(x = gender, y = easiness, fill = gender)) +
  geom_boxplot() + ggtitle("Box Plot of Easiness by Gender") + xlab("Gender") + ylab("Easiness Score")
easiness_pepper_plot <- ggplot(df_prof, aes(x = pepper, y = easiness, fill = pepper)) +
  geom_boxplot() + ggtitle("Box Plot of Easiness by Pepper Score") + xlab("Pepper Score") + ylab("Easiness Score")
easiness_discipline_plot <- ggplot(df_prof, aes(x = discipline, y = easiness, fill = discipline)) +
  geom_boxplot() + ggtitle("Box Plot of Easiness \nby Discipline") + xlab("Discipline") + ylab("Easiness Score")

quality_gender_plot <- ggplot(df_prof, aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() + ggtitle("Box Plot of Quality by Gender") + xlab("Gender") + ylab("Quality Score")
quality_pepper_plot <- ggplot(df_prof, aes(x = pepper, y = quality, fill = pepper)) +
  geom_boxplot() + ggtitle("Box Plot of Quality by Pepper Score") + xlab("Pepper Score") + ylab("Quality Score")
quality_discipline_plot <- ggplot(df_prof, aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() + ggtitle("Box Plot of Quality \nby Discipline") + xlab("Discipline") + ylab("Quality Score")

ggarrange(quality_plot, gender_plot, pepper_plot, easiness_plot, discipline_plot, ncol = 3, nrow = 2)

easiness_quality_plot <- ggplot(df_prof, aes(x = quality, y = easiness)) +
  geom_point() + geom_smooth(method = 'loess', formula = 'y ~ x') + ggtitle("Scatter Plot of Easiness by Quality") + xlab("Quality Score") + ylab("Easiness Score")


## ---- echo = FALSE------------------------------------------------------------
ggarrange(easiness_gender_plot, quality_gender_plot, easiness_pepper_plot, quality_pepper_plot, easiness_discipline_plot, quality_discipline_plot, ncol = 2, nrow = 3)
easiness_quality_plot


## ---- echo = FALSE------------------------------------------------------------
total_lm <- lm(data = df_prof, quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline)

quality_resid <- ggplot(augment(total_lm), aes(x = quality, y = .resid)) +
  geom_point() + labs(x = "Quality Scores", y = "Residual")
pepper_resid <- ggplot(augment(total_lm), aes(x = pepper, y = .resid)) +
  geom_boxplot() + labs(x = "Pepper Scores", y = "Residual")
easy_resid <- ggplot(augment(total_lm), aes(x = easiness, y = .resid)) +
  geom_point() + labs(x = "Easiness Scores", y = "Residual")
discipline_resid <- ggplot(augment(total_lm), aes(x = discipline, y = .resid)) +
  geom_boxplot() + labs(x = "Discipline", y = "Residual")
ggarrange(quality_resid, pepper_resid, easy_resid, discipline_resid, ncol = 2, nrow = 2)

ggplot(augment(total_lm), aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted value", y = "Residual")


## ---- echo = FALSE------------------------------------------------------------
# summary(total_lm)
modelsummary(total_lm)
# pep_interval <- confint(total_lm, "pepperyes", level = 0.95)
# easy_interval <- confint(total_lm, "easiness", level = 0.95)
# confint(total_lm, level = 0.95)


## -----------------------------------------------------------------------------
reduced_lm <- lm(data = df_prof, quality ~ easiness:discipline)
modelsummary(reduced_lm)
# confint(reduced_lm, level = 0.95)
anova(reduced_lm, total_lm)

