## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## -----------------------------------------------------------------------------
#tinytex::install_tinytex()

## -----------------------------------------------------------------------------
#install.packages("flextable")


## ----include = FALSE----------------------------------------------------------
library(alr4)
library(ggplot2)
library(modelsummary)
library(flextable)


## ----include = FALSE----------------------------------------------------------
data("Rateprof")
#head(Rateprof)


## ----figure1, fig.cap="Figure 1: Histogram of Average Quality Ratings",echo = FALSE----
hist(Rateprof$quality, main="Histogram of Average Quality Ratings", xlab="Quality Rating", breaks=20)


## ----figure2, fig.cap="Figure 2: Histogram of Easiness Ratings",echo = FALSE----
hist(Rateprof$easiness, main="Histogram of Easiness Ratings", xlab="Quality Rating", breaks=20)


## ----figure3, fig.cap="Figure 3: Histogram of Average Quality Ratingsvs Easiness Rating",echo = FALSE----
plot(quality ~ easiness,data = Rateprof,main = "Average Quality Rating vs Easiness Rating",xlab = "Easiness Rating",ylab = "Average Quality Rating")
model <- lm(quality ~ easiness, data = Rateprof)
abline(model, col="red")


## ----figure4, fig.cap="Figure 4: Bar Plot of Gender Distribution",echo = FALSE----
table_gender <- table(Rateprof$gender)
barplot(table_gender, main="Gender Distribution", xlab="Gender", ylab="Frequency")


## ----figure5, fig.cap="Figure 5: Box Plot of Average Quality Rating by Gender",echo = FALSE----
boxplot(quality ~ gender, data = Rateprof, main = "Quality Rating by Gender",xlab="Gender", ylab="Average Quality Rating")


## ----figure6, fig.cap="Figure 6: Bar Plot of Acctractive Professors",echo = FALSE----
table_pepper <- table(Rateprof$pepper)
barplot(table_pepper, main="Distribution of Attractive Professors", xlab="Is the Professor Considered Attractive", ylab="Frequency")


## ----figure7, fig.cap="Figure 7: Box Plot of Average Quality Rating by Attractiveness",echo = FALSE----
boxplot(quality ~ pepper, data = Rateprof, main = "Quality Rating by Attractiveness",xlab="Is the Professor Considered Attractive", ylab="Average Quality Rating")


## ----figure8, fig.cap="Figure 8: Bar Plot of the Distribution of Professor Disciplines",echo = FALSE----
table_dept <- table(Rateprof$discipline)
barplot(table_dept, main="Distribution of Professor Disciplines", xlab="Discipline", ylab="Frequency")


## ----figure9, fig.cap="Figure 9: Box Plot of Average Quality Rating by Discipline",echo = FALSE----
boxplot(quality ~ discipline, data = Rateprof, main = "Quality Rating by Discipline",xlab="Discipline", ylab="Average Quality Rating")


## ----include = FALSE----------------------------------------------------------
gender_pepper_table <- table(Rateprof$gender, Rateprof$pepper)

print(gender_pepper_table)
print(23/159)
print(23/207)


## ----include = FALSE----------------------------------------------------------
gender_disc_table <- table(Rateprof$gender, Rateprof$discipline)

print(gender_disc_table)
print(207/364)


## ----figure10, fig.cap="Figure 10: Easiness vs. Quality Rating by Gender Scatter plot",echo = FALSE,message = FALSE,warning= FALSE----
ggplot(Rateprof, aes(x = easiness, y = quality, color = gender)) +
  geom_point() +
  labs(title = "Easiness vs. Quality Rating by Gender", x = "Easiness Rating", y = "Average Quality Rating")


## ----figure11, fig.cap="Figure 11: Easiness Rating vs. Average Quality Rating by Attractiveness Scatterplot",echo = FALSE,message = FALSE,warning= FALSE----
ggplot(Rateprof, aes(x = easiness, y = quality, color = pepper)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(title = "Easiness Rating vs. Average Quality Rating by Attractiveness", x = "Easiness Rating", y = "Average Quality Rating")


## ----include = FALSE----------------------------------------------------------
full_model <- lm(quality ~ gender + discipline + pepper * easiness, data = Rateprof)

reduced_model <- lm(quality ~ gender + discipline + pepper + easiness, data = Rateprof)


## ----figure12, fig.cap="Figure 12: Residuals vs Fitted Values",echo = FALSE----
par(mfrow=c(1,2))
plot(reduced_model, which = 1)
plot(full_model, which = 1)


## ----figure13, fig.cap="Figure 13: Q-Q Plots",echo = FALSE--------------------
par(mfrow=c(1,2))
qqnorm(resid(reduced_model))
qqline(resid(reduced_model), col="red")

qqnorm(resid(full_model))
qqline(resid(full_model), col="red")


## ----include = FALSE----------------------------------------------------------
library(car)
vif(reduced_model)


## ----figure14, fig.cap="Figure 14: Leverage vs Residuals Squared Plots",echo = FALSE----
par(mfrow=c(1,2))
plot(hatvalues(reduced_model), resid(reduced_model)^2, 
     xlab="Leverage", ylab="Residuals Squared", 
     main="Leverage vs Residuals Squared (Reduced Model)")

plot(hatvalues(full_model), resid(full_model)^2, 
     xlab="Leverage", ylab="Residuals Squared", 
     main="Leverage vs Residuals Squared (Full Model)")


## ---- include = FALSE---------------------------------------------------------
anova_test <- anova(reduced_model, full_model)
summary(anova_test)


## ----include = FALSE----------------------------------------------------------
summary(full_model)
conf_intervals <- confint(full_model)
print(conf_intervals)


## ----figure15, fig.cap="Figure 15: Full model Summary",echo = FALSE-----------
modelsummary(full_model)

