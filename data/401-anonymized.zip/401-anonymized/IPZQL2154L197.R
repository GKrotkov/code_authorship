## ---- include = FALSE---------------------------------------------------------
data = read.csv('/Users/gwenli/Downloads/cmu-sleep.csv')


## ---- echo = FALSE------------------------------------------------------------
hist(data$TotalSleepTime, 
     main = "Frequency of Time Spent Sleeping", 
     xlab = "Time Spent Sleeping (in minutes)", 
     ylab = "Number of Students", 
     sub = "Figure 1: Unimodal and relatively symmetric and bell-shaped.")


## ---- echo = FALSE------------------------------------------------------------
hist(data$term_gpa, 
     main = "Frequency of Semester GPA", 
     xlab = "Semester GPA (out of 4.0)", 
     ylab = "Number of Students", 
     sub = "Figure 2: Unimodal and skewed to the left.")


## ---- echo = FALSE------------------------------------------------------------
plot(data$TotalSleepTime, data$term_gpa, 
     main = "Semester GPA vs. Time Spent Sleeping", 
     xlab = "Time Spent Sleeping (in minutes)", 
     ylab = "Semester GPA (out of 4.0)", 
     sub = "Figure 3: Weakly positive and linear.")


## ---- echo = FALSE------------------------------------------------------------
hist(data$cum_gpa, 
     main = "Frequency of Cumulative GPA", 
     xlab = "Cumulative GPA (out of 4.0)", 
     ylab = "Number of Students", 
     sub = "Figure 4: Unimodal and skewed to the left.")


## ---- echo = FALSE------------------------------------------------------------
plot(data$TotalSleepTime, data$cum_gpa, 
     main = "Cumulative GPA vs. Time Spent Sleeping", 
     xlab = "Time Spent Sleeping (in minutes)", 
     ylab = "Cumulative GPA (out of 4.0)", 
     sub = "Figure 5: Possibly nonlinear and parabolic.")


## ---- include = FALSE---------------------------------------------------------
model = lm(data$term_gpa ~ data$TotalSleepTime)
summary(model)
confint(model)


## ---- echo = FALSE------------------------------------------------------------
residuals = resid(model)
plot(data$TotalSleepTime, residuals, 
     main = "Residuals vs. Time Spent Sleeping", 
     xlab = "Time Spent Sleeping (in minutes)", 
     ylab = "Residuals", 
     sub = "Figure 6: Relatively randomly and constantly scattered around zero.")


## ---- echo = FALSE------------------------------------------------------------
qqnorm(residuals, 
       main = "Normal Q-Q Plot", 
       sub = "Figure 7: Points relatively follow the line.")
qqline(residuals)

