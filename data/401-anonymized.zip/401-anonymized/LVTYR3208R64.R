## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(bestglm)
library(ggplot2)
library(modelsummary)
library(patchwork)
library(broom)
library(parameters)


## ----message=FALSE,fig.width=4, fig.height=3, fig.cap="The distribution of quality variable"----
histo1 <- ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(fill = "blue", color = "black") +
  ggtitle("Distribution of average quality rating") +
  xlab("Quality ratings") +
  ylab("Count") +
  theme_minimal()


## ----include=FALSE------------------------------------------------------------
summary(Rateprof$quality)
summary(Rateprof$easiness)


## ----fig.width=8, fig.height=4, fig.cap="The distribution of easiness variable",message=FALSE----
histo2 <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(fill = "blue", color = "black") +
  ggtitle("Distribution of average easiness rating") +
  xlab("Easiness ratings") +
  ylab("Count") +
  theme_minimal()
combinedH <- histo1 + histo2
combinedH


## ----fig.width=4, fig.height=3, fig.cap="The distribution of gender variable"----
barplot1 <- ggplot(Rateprof, aes(x = gender)) + geom_bar(color = "black", fill = "blue") +
labs(title = "Distribution of Gender",x = "Male/Female",y = "Counts")


## ----fig.width=7, fig.height=3, fig.cap="The distribution of pepper variable"----
barplot2 <- ggplot(Rateprof, aes(x = pepper)) + geom_bar(color = "black", fill = "blue") +labs(title = "Distribution of Attractiveness", x = "Rate professors as attractive or not", y = "Counts")
combinedB <- barplot1 + barplot2
combinedB


## ----include=FALSE------------------------------------------------------------
summary(Rateprof$pepper)
summary(Rateprof$gender)


## ----fig.width=5, fig.height=4, fig.cap = "Three barplots"--------------------
barplot(table(Rateprof$discipline), 
        main = "Distribution of levels of Discipline", 
        xlab = "Categories", 
        ylab = "Counts", 
        col = c("red", "green", "blue", "purple"))


## ----include=FALSE------------------------------------------------------------
summary(Rateprof$discipline)


## ----message=FALSE,fig.width=10,fig.height=4,fig.cap="Bivariate EDA"----------
boxplot1 <- ggplot(Rateprof, aes(x = gender, y = quality)) + geom_boxplot(color = "blue") + ggtitle("gender vs.quality") + xlab("gender") + ylab("Average quality rating")
boxplot2 <- ggplot(Rateprof, aes(x = pepper, y = quality)) + geom_boxplot(color = "blue") + ggtitle("pepper vs.quality") + xlab("Rate instructors attractive(Y/N)") + ylab("Average quality rating")
boxplot3 <- ggplot(Rateprof, aes(x = discipline, y = quality)) + geom_boxplot(color = "blue") + ggtitle("discipline vs. quality") + xlab("Levels of discipline") + ylab("Average quality rating")
scatterplot1 <- ggplot(Rateprof, aes(x = easiness, y = quality)) + geom_point() + geom_smooth(method = "lm", color = "blue") + ggtitle("easiness vs.quality") + xlab("Average easiness rating") + ylab("Average quality rating")
combinedP <- boxplot1 + boxplot2 + boxplot3 +scatterplot1
combinedP


## ----fig.width=7,fig.height=3,fig.cap = "Residual plot"-----------------------
lm2 <- lm(quality ~ pepper + gender + easiness, data = Rateprof)
residuals <- residuals(lm2)
Residual1 <- ggplot(Rateprof, aes(x = easiness, y = residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "blue") +
  ggtitle("Residuals vs Easiness") +
  xlab("Easiness") +
  ylab("Residuals")
Residual2 <- ggplot(Rateprof, aes(x = pepper, y = residuals)) +
  geom_boxplot() +
  geom_hline(yintercept = 0, color = "blue") +
  ggtitle("Residuals vs Pepper") +
  xlab("Pepper") +
  ylab("Residuals")
Residual3 <- ggplot(Rateprof, aes(x = gender, y = residuals)) +
  geom_boxplot() +
  geom_hline(yintercept = 0, color = "blue") +
  ggtitle("Residuals vs gender") +
  xlab("Gender") +
  ylab("Residuals")
combinedR <- Residual1 +Residual2 + Residual3
combinedR


## ----fig.width=3,fig.height=3,fig.cap = "Normality check"---------------------
ggplot(Rateprof, aes(sample = easiness)) +
  stat_qq() +
  stat_qq_line() +
  ggtitle("Normal Q-Q Plot for easiness") +
  xlab("Easiness quantiles") +
  ylab("Sample Quantiles")


## ----include=FALSE------------------------------------------------------------
full_model <- lm(quality ~ gender +pepper + easiness + discipline + gender:easiness + discipline:easiness, data = Rateprof)
reduced_model <- lm(quality~ gender + pepper + easiness +discipline, data=Rateprof)
anova(reduced_model,full_model)
summary(full_model)
summary(reduced_model)
optimal_model <- lm(quality ~ pepper +easiness + gender, data = Rateprof)
summary(optimal_model)
vif(optimal_model)
confint(optimal_model)
AIC(full_model)
AIC(reduced_model)
AIC(optimal_model)
step <- step(full_model,IC="AIC")
step2 <- step(step, IC="AIC")


## -----------------------------------------------------------------------------
modelsummary(list("Optimal" = optimal_model, "Stepwise" = step, "Reduced" = reduced_model, "Full_model" = full_model), gof_map = c("adj.r.squared", "nobs", "aic"))

