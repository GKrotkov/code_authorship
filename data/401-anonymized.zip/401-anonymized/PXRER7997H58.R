## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(tidyverse)
library(ggplot2)
library(gridExtra)
library(modelsummary)
sleep_data = read.csv("cmu-sleep.csv")


## ---- fig.width=5, fig.height=4, fig.cap="Histograms of Term and Cumulative GPA of Students out of 4.0."----
hist1 = ggplot(sleep_data, aes(x = term_gpa)) + 
  geom_histogram(bins = 20, color = "black", fill = "white") + 
  labs(y = "Frequency")
hist2 = ggplot(sleep_data, aes(x = cum_gpa)) + 
  geom_histogram(bins = 20, color = "black", fill = "white") + 
  labs(y = "Frequency")
grid.arrange(hist1, hist2, nrow=1)
hist3 = ggplot(sleep_data, aes(x = TotalSleepTime)) + 
  geom_histogram(bins = 20, color = "black", fill = "white") + 
  labs(y = "Frequency")
grid.arrange(hist1, hist2, hist3, nrow=2)


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot Matrix of Relationships Between Cumulative/Term GPA and Total Sleep Time."----
plot(sleep_data[, c(8, 12:13)], pch=20 , cex=1.5)


## -----------------------------------------------------------------------------
cor(sleep_data[, c(8, 12:13)])


## -----------------------------------------------------------------------------
sleep_model1 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep_data)
summary(sleep_model1)
modelsummary(list("Term GPA" = sleep_model1),
             gof_map = c("r.squared", "p.value", "nobs"))
confint(sleep_model1)


## -----------------------------------------------------------------------------
plot(sleep_model1)

