## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
library(ggplot2)


## -----------------------------------------------------------------------------
summary(Rateprof$easiness)
summary(Rateprof$quality)


## -----------------------------------------------------------------------------

hist(Rateprof$easiness, main = "Class Difficulty Histogram", xlab = "Difficulty", ylab = "Frequency",breaks = 30)
hist(Rateprof$quality, main = "Quality Ratings Histogram",xlab = "Quality",ylab = "Frequency",breaks = 30 )


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = gender)) +
  geom_bar() +
  ggtitle("Gender Distribution")

ggplot(Rateprof, aes(x = pepper)) +
  geom_bar() +
  ggtitle("Pepper Distribution")

ggplot(Rateprof, aes(x = discipline)) +
  geom_bar() +
  ggtitle("Discipline Distribution")

## -----------------------------------------------------------------------------
table(Rateprof$gender)
table(Rateprof$pepper)
table(Rateprof$discipline)


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "red") +
  ggtitle("Scatterplot of Easiness vs Quality") +
  xlab("Easiness") +
  ylab("Quality")


## ----Bivariate, echo=FALSE, message=FALSE-------------------------------------
library(GGally)
library(dplyr)
library(ggplot2)
data[["gender"]] <- as.factor(data[["gender"]])
data[["discipline"]] <- as.factor(data[["discipline"]])
data[["pepper"]] <- as.factor(data[["pepper"]])

# Selecting relevant variables and creating a pairs plot
data %>%
  select(quality, gender, pepper, easiness, discipline) %>%
  ggpairs()



## -----------------------------------------------------------------------------
model_1 = lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)
discipline = lm(quality~easiness+gender+pepper,data)
summary(model_1)
anova(model_1,discipline)


## -----------------------------------------------------------------------------
final = lm(quality~easiness*pepper+gender,data)
summary(final)
anova(discipline,final)


## -----------------------------------------------------------------------------
question2 = lm(quality~easiness*gender + easiness*discipline,data)
question2
question2rev = lm(quality~easiness,data)
anova(question2,question2rev)


## -----------------------------------------------------------------------------
ggplot(data = data, aes(x = easiness, y = residuals(final))) +
  geom_point() +
  labs(x = "Average Easiness Rating", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of Instructor Attractiveness. Figure 8"----
ggplot(data = data, aes(x = pepper, y = residuals(final))) +
  geom_boxplot() +
  labs(x = "Attractiveness of Instructor", y = "Residuals")

## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of Gender of Instructor. Figure 9"----
ggplot(data = data, aes(x = gender, y = residuals(final))) +
  geom_boxplot() +
  labs(x = "Gender of Instructor", y = "Residuals")

## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Residuals vs Fitted Values. Figure 10"----
library(broom)
ggplot(augment(final), aes(x = .fitted, y = .resid)) + 
  geom_point() + 
  labs(x = "Fitted value", y = "Residual")

## ---- fig.width=4, fig.height=3, fig.cap="Normal QQ-Plot. Figure 11"----------
ggplot(augment(final), aes(sample = .resid)) + 
  geom_qq() + 
  geom_qq_line() + 
  labs(x = "Theoretical quantiles", y = "Sample quantiles")

