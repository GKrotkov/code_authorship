## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

#install.packages("alr4")
#install.packages("stargazer")
library(alr4)
library(ggplot2)
library(modelsummary)
library(stargazer)
library(knitr)
library(bestglm)

Rateprof



## ---- fig.width=4.5, fig.height=3---------------------------------------------

attach(Rateprof)

par(mfrow = c(1,2))

hist1 <- hist(Rateprof$quality, xlab = "Quality rating", ylab = "Frequency", main = " Figure 1 - Quality rating", cex.main = 0.7, cex.lab = 0.7)

hist2 <- hist(Rateprof$easiness, xlab = "Easiness of the class", ylab = "Frequency", main = " Figure 2 - Easiness of the class", cex.main = 0.7, cex.lab = 0.7)





## ---- fig.width=3.5, fig.height=1.5-------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(x = "Class easiness",
       y = "rating",
       title = "Figure 3 - Relationship between easiness and quality rating", cex.main = 0.5, cex.labs = 0.5)


## ---- fig.width=7, fig.height=2, message=FALSE--------------------------------

attach(Rateprof)

par(mfrow = c(2,1))

boxplot1 <- ggplot(data = Rateprof, mappin = aes(x = gender, y = quality)) + geom_boxplot() + 
  labs(y = "Quality Rating", title = "Figure 4 - Boxplot of Quality Rating and Gender")

boxplot2 <- ggplot(data = Rateprof, mappin = aes(x = pepper, y = quality)) + geom_boxplot() + 
  labs(y = "Quality Rating", title = "Figure 5 - Boxplot of Quality Rating and Attractiveness")

boxplot3 <- ggplot(data = Rateprof, mappin = aes(x = discipline, y = quality)) + geom_boxplot() + 
  labs(y = "Quality Rating", title = "Figure 6 - Boxplot of Quality Rating and Discipline")

boxplot1

boxplot2

boxplot3


## ---- message=FALSE-----------------------------------------------------------
fit1 <- lm(quality ~ gender + pepper + easiness + discipline, Rateprof)
res1 <- resid(fit1)
df1 <- model.matrix(fit1, data = Rateprof)[,-1]
mat.df1 <- as.data.frame(df1)
mat.df1$quality <- Rateprof$quality
best.model1 <- bestglm(mat.df1, IC = "AIC")




library(GGally) 
library(dplyr)


library(patchwork)
library(ggplot2)
library(broom)



Rateprof$gender <- factor(Rateprof$gender)
Rateprof$discipline <- factor(Rateprof$discipline)
library(bestglm)


fit <- lm(quality ~ pepper + gender + easiness + discipline + easiness*gender + easiness*discipline, data = Rateprof)
res <- resid(fit)
df <- model.matrix(fit, data = Rateprof)[,-1]
mat.df <- as.data.frame(df)
mat.df$quality <- Rateprof$quality
best.model <- bestglm(mat.df, IC = "AIC")



par(mfrow = c(2,2))
plot(fitted(fit1), res1, main = "Figure 7 - Residual Plot - Simple model")
qqnorm(residuals(fit1))
qqline(residuals(fit1))
plot(fitted(fit), res, main = "Figure 8 - Residual Plot - Complex model")
qqnorm(residuals(fit))
qqline(residuals(fit))




## -----------------------------------------------------------------------------
fit.3 <- lm(quality ~ gender + easiness + discipline, data = Rateprof)

reduced_fit.3 <- lm(quality ~ easiness, data = Rateprof)

par(mfrow = c(1,2))
res3 <- resid(fit.3)
plot(fitted(fit.3), res3, main = "Figure 9 - Residual Plot: Full model", cex.main = 0.85)
qqnorm(residuals(fit.3))
qqline(residuals(fit.3))




## ---- message=FALSE-----------------------------------------------------------

fit <- lm(quality ~ pepper + gender + easiness + discipline + easiness*gender + easiness*discipline, data = Rateprof)

knitr::kable(summary(fit)$coefficient, caption = "Table 1 - Summary Results for Model with Interaction")

knitr::kable(confint(fit), caption = "Table 2 - 95 % Confidence Interval for Model with Interaction")



## -----------------------------------------------------------------------------

fit.3 <- lm(quality ~ gender + easiness + discipline, data = Rateprof)

reduced_fit.3 <- lm(quality ~ easiness, data = Rateprof)

result = anova(reduced_fit.3, fit.3)

knitr::kable(result, caption = "Table 3 - ANOVA Test")



