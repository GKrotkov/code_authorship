## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------

#install.packages("alr4")
library(patchwork)
library(ggplot2)
library(broom)
library(alr4)

Rateprof


## ---- fig.width=10, fig.height=2----------------------------------------------

library(ggplot2)

g1 <- ggplot(Rateprof, aes(x=gender)) +
  geom_bar(fill= "lightskyblue1", 
           color="black") +
  labs(x="Gender", 
       y="Count", 
       title="Distribution of Instructors by Gender") +
  theme_minimal()

g2 <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(fill="lightskyblue", 
           color="black") +
  labs(x="Attractiveness", 
       y="Count", 
       title="Distribution of Attractiveness") +
  theme_minimal()

g1|g2



## ---- fig.width=10, fig.height=2----------------------------------------------

g3 <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(fill="lightskyblue2", 
                 color="black", bins = 30) +
  labs(x="Easiness Rating", 
       y="Count", 
       title="Distribution of Easiness Scores") +
  theme_minimal()

g4 <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill="lightskyblue3", 
           color="black") +
  labs(x="Discipline", 
       y="Count", 
       title="Distribution by Disciplines") +
  theme_minimal()

g3|g4


## ---- fig.width=10, fig.height=2----------------------------------------------

g5 <- ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(fill="lightskyblue4", 
           color="black", bins = 30) +
  labs(x="Quality Rating", 
       y="Count", 
       title="Distribution by Quality Rating") +
  theme_minimal()

g5


## ---- fig.width=10, fig.height=2----------------------------------------------

a1 <- ggplot(Rateprof, aes(x = gender, 
                     y = quality)) +
  geom_boxplot(fill = "darkolivegreen1", 
               color = "black") +
  labs(x = "Gender", 
       y = "Quality Rating",
       title = "Quality Rating vs. Gender") +
  theme_minimal()

a2 <- ggplot(Rateprof, aes(x = pepper, 
                     y = quality)) +
  geom_boxplot(fill = "darkolivegreen2", 
               color = "black") +
  labs(x = "Attractiveness", 
       y = "Quality Rating",
       title = "Quality Rating vs. Attractiveness") +
  theme_minimal()

a1|a2


## ---- fig.width=6, fig.height=2-----------------------------------------------
a3 <- ggplot(Rateprof, aes(x = easiness, 
                     y = quality)) +
  geom_point(alpha = 1, 
             color = "darkolivegreen3") +
  labs(x = "Easiness", 
       y = "Quality Rating", 
       title = "Quality Rating vs. Easiness") +
  theme_minimal()

a4 <- ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "darkolivegreen4", 
               color = "black") +
  labs(x = "Discipline", 
       y = "Quality Rating", 
       title = "Quality Rating vs. Discipline") +
  theme_minimal()

a3|a4



## ---- include = FALSE---------------------------------------------------------
library(ggplot2)
library(palmerpenguins)
library(modelsummary)

linearmodel <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

confint(linearmodel, level = 0.95)

library(xtable)

xtable(linearmodel)


## ---- include= FALSE----------------------------------------------------------
interaction_model <- lm(quality ~ easiness * gender
                        + easiness * discipline, 
                        data = Rateprof)

library(xtable)
confint(interaction_model)
xtable(interaction_model)



## ---- include = FALSE, fig.width=6, fig.height=2------------------------------
q1 <- ggplot(linearmodel, aes(sample = .resid)) +
  geom_qq(col = "pink") +
  geom_qq_line(col = "red") +
  labs(x = "Theoretical quantile",
     y = "Sample quantile") +
  ggtitle("QQ plot for multiple linear regression")

q2 <- ggplot(interaction_model, aes(sample = .resid)) +
  geom_qq(col = "skyblue") +
  geom_qq_line(col = "blue") +
  labs(x = "Theoretical quantile",
     y = "Sample quantile") +
  ggtitle("QQ plot for multiple linear regression with interaction")


## ---- include = FALSE, fig.width=10, fig.height=3-----------------------------

library(patchwork)
library(ggplot2)
library(broom)

q1|q2


## ---- include = FALSE---------------------------------------------------------

p1 <- ggplot(linearmodel, aes(x = .fitted, y = .resid)) +
  geom_point(col = "red3") +
  labs(x = "Fitted value", y = "Residual") +
  ggtitle("Residual vs Fitted without Interaction")



## ---- include = FALSE---------------------------------------------------------

p2 <- ggplot(interaction_model, aes(x = .fitted, y = .resid)) +
  geom_point(col = "blue3") +
  labs(x = "Fitted value", y = "Residual") +
  ggtitle("Residual vs Fitted with Interaction")


## ---- include = FALSE, fig.width=10, fig.height=3-----------------------------

p1 | p2


## ---- include = FALSE---------------------------------------------------------
fullmodel <- lm(quality ~ gender + pepper + easiness + discipline 
                + gender:easiness + gender:discipline 
                + easiness:discipline, data = Rateprof)

reducedmodel <- lm(quality ~ gender + pepper + easiness +
                     discipline, 
                   data = Rateprof)

anova <- anova(reducedmodel, fullmodel)
library(xtable)
print(xtable(anova))


