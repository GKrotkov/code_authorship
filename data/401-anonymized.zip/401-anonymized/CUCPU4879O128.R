## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
knitr::opts_chunk$set(fig.pos = "H", out.extra = "")
library(ggplot2)
library(alr4)
library(broom)
library(gridExtra)
Rateprof <- alr4::Rateprof




## ---- fig.cap="Distributions of Quality, Easiness, Gender, Attractiveness, and Discipline", fig.align='center', warning=FALSE, message =FALSE----
b1 <- ggplot(Rateprof, aes(x=quality)) +
  geom_histogram(stat = "bin") + xlab("Average Quality Rating (from 1-5(best))")

b2 <-ggplot(Rateprof, aes(x=easiness)) +
  geom_histogram(stat = "bin") + xlab("Average Easiness Rating(from 1-5(best))")

b3 <- ggplot(Rateprof, aes(x=gender)) + 
  geom_bar(stat = "count") +
  xlab("Genders of Professors")

b4 <- ggplot(Rateprof, aes(x=pepper)) + 
  geom_bar(stat = "count") +
  xlab("Attractiveness of Professors")

b5 <- ggplot(Rateprof, aes(x=discipline)) + 
  geom_bar(stat = "count") +
  xlab("Disciplines of Professors")


grid.arrange(b1, b2, b3, b4, b5, ncol = 2, nrow = 3)


## ---- fig.cap="Bivariate Relationships between Predictors and Response Variable", warning=FALSE, message=FALSE, fig.align='center'----
c1 <- ggplot(Rateprof, aes(x=easiness, y =quality)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(x="Avg Easiness Rating (1-5(easiest)", 
       y = "Avg Quality Rating (1-5(best))", 
       title = "Quality Rating vs Easiness Rating") 

c2 <-ggplot(Rateprof, aes(x=pepper, y=quality)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Attractiveness (yes as attractive)", 
       y = "Avg Quality Rating(1-5(best))",
       title = "Quality Rating vs Attractiveness")

c3 <-ggplot(Rateprof, aes(x=gender, y=quality)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Gender of Instructors", 
       y = "Avg Quality Rating(1-5(best))",
       title = "Quality Rating vs Gender")

c4 <-ggplot(Rateprof, aes(x=discipline, y=quality)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Discipline of Instructors", 
       y = "Avg Quality Rating(1-5(best))",
       title = "Quality Rating vs Discipline")


grid.arrange(c1, c2, c3, c4, ncol = 2, nrow = 2)


## ---- include=FALSE-----------------------------------------------------------
lm1 <- lm(quality ~ gender*easiness + pepper + easiness + discipline*easiness, data = Rateprof)
summary(lm1)

lm3 <- lm(quality ~ gender*easiness + pepper* easiness + discipline*easiness, data = Rateprof)
summary(lm3)

lm2 <- lm(quality ~ gender + pepper+ easiness + discipline, data = Rateprof)
summary(lm2)

anova(lm2, lm3)


## ---- fig.cap="Residual Diagnostics for the Multiple Regression Model", warning=FALSE, message=FALSE, fig.align='center'----

u1 <- ggplot(lm2, aes(x = .fitted, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(x = "Fitted value", y = "Residuals")

u2 <- ggplot(lm2, aes(x = easiness, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(x = "Easiness", y = "Residuals")

u3 <- ggplot(lm2, aes(x=gender, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Gender", y = "Residuals")

u4 <- ggplot(lm2, aes(x=pepper, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Attractiveness", y = "Residuals")

u5 <- ggplot(lm2, aes(x=discipline, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Discipline", y = "Residuals")

u6 <- ggplot(augment(lm2), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Actual Quantiles")

grid.arrange(u1, u2, u3, u4, u5, u6, ncol = 2, nrow = 3)



## ---- include = FALSE---------------------------------------------------------

ggplot(lm3, aes(x = .fitted, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(x = "Fitted value", y = "Residuals")

ggplot(lm3, aes(x = easiness, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(x = "Easiness", y = "Residuals")

ggplot(lm3, aes(x=gender, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Gender", y = "Residuals")

ggplot(lm3, aes(x=pepper, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Attractiveness", y = "Residuals")

ggplot(lm3, aes(x=discipline, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Discipline", y = "Residuals")

ggplot(augment(lm3), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Actual Quantiles")



## ---- include = FALSE---------------------------------------------------------
cookd <- cooks.distance(lm2)
which.max(cookd)
cookd[359]


## ---- include = FALSE---------------------------------------------------------
vif(lm2)


## ---- include= FALSE----------------------------------------------------------

lm_red <- lm(quality ~ easiness, data = Rateprof)

lm_full <- lm(quality ~ gender* easiness + gender + easiness + discipline + discipline*easiness, data = Rateprof)

anova(lm_red, lm_full)


## ---- include= FALSE----------------------------------------------------------

ggplot(lm_full, aes(x = .fitted, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(x = "Fitted value", y = "Residuals")

ggplot(lm_full, aes(x = easiness, y = .resid)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(x = "Easiness", y = "Residuals")

ggplot(lm_full, aes(x=gender, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Gender", y = "Residuals")

ggplot(lm_full, aes(x=discipline, y=.resid)) + 
  geom_boxplot() +
  geom_hline(yintercept = 0) +
  labs(x = "Discipline", y = "Residuals")

ggplot(augment(lm_full), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Actual Quantiles")



## ---- include=FALSE-----------------------------------------------------------
confint(lm2)


## ---- include = FALSE---------------------------------------------------------
lm3 <- lm(quality ~ gender*easiness + pepper* easiness + discipline*easiness, data = Rateprof)
summary(lm3)

lm2 <- lm(quality ~ gender + pepper+ easiness + discipline, data = Rateprof)
summary(lm2)

anova(lm2, lm3)

