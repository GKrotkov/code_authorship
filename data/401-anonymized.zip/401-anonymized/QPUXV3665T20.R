## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
library(tidyverse)
library(ggplot2)
library(car)
library(modelsummary)
library(knitr)
knitr::opts_chunk$set(echo = FALSE)



## -----------------------------------------------------------------------------

sldat<-read.csv("cmu-sleep.csv")
sldat2<-sldat%>%
  select(cum_gpa, term_gpa, TotalSleepTime)



ggplot(data=sldat2)+geom_histogram(aes(cum_gpa), bins = 30)+ggtitle("Histogram of  Student's Cumulative GPA's")+xlab("Cumulative GPA's")+ylab("Frequency")


## -----------------------------------------------------------------------------
ggplot(data=sldat2)+geom_histogram(aes(term_gpa),bins = 30)+ggtitle("Histogram of Student's GPA's this Term")+xlab(" GPA's this Term")+ylab("Frequency")


## -----------------------------------------------------------------------------
                                                                                                                                 
ggplot(data=sldat2)+geom_histogram(aes(TotalSleepTime),bins = 30)+ggtitle("Histogram of Students Total Sleep Time")+xlab("Total Sleep Time(Mins)")+ylab("Frequency")



## -----------------------------------------------------------------------------
ggplot(sldat2)+geom_point(aes(x=TotalSleepTime, y=term_gpa))+ggtitle("Plot of Total Sleep Time vs. GPA's this semester")+xlab("Total Sleep Time(Mins)")+ylab("GPA's this term")


## -----------------------------------------------------------------------------
ggplot(sldat2)+geom_point(aes(x=cum_gpa, y=term_gpa))+ggtitle("Plot of Cumulative GPA's vs. GPA's this term")+xlab("Cumulative GPA's")+ylab("GPA's this term")


## -----------------------------------------------------------------------------
means<-lapply(sldat2[,], mean)
sds<-lapply(sldat2[,], sd)

#means<-as.data.frame(means)
#means[2,]<-sds
#knitr::kable(as.data.frame(means), "simple", digits=3, col.names=c("Cumulative", "Term", "Sleep"), row.names=c("Mean", "Std. Dev."))
#knitr::kable(as.data.frame(means), "simple", digits=3, col.names=c("Cumulative", "Term", "Sleep"))




## -----------------------------------------------------------------------------
m1<-lm(term_gpa~TotalSleepTime, data=sldat2)
m2<-lm(term_gpa~TotalSleepTime+cum_gpa, data=sldat2)

qqPlot(m1, id=F, xlab="Model 1 Residuals")
qqPlot(m2, id=F, xlab="Model 2 Residuals")


## -----------------------------------------------------------------------------
sum1<-summary(m1)
sum2<-summary(m2)

modelsummary(list("Model 1"=m1, "Model 2"=m2), gof_map=NA, fmt=fmt_decimal(digits=5))

new_avg<-mean(sldat2$term_gpa)-120*0.00198


