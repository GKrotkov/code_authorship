## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----include=FALSE------------------------------------------------------------
library(GGally) # necessary for the ggpairs() function
library(dplyr)
sleep_df = read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=4, fig.cap="Pairs plot between TotalSleepTime, term_gpa, and cum_gpa. We see left skewed distributions for term_gpa and cum_gpa"----
sleep_df |>
select(TotalSleepTime, term_gpa, cum_gpa) |> ggpairs()


## ---- fig.width=5, fig.height=4, fig.cap="Scatter plot of total sleep time Vs. log(term GPA). We notice a positive correlation."----
plot(x=sleep_df$TotalSleepTime,
     y=log(sleep_df$term_gpa),
     xlab = "Total Sleep time (minutes)",
     ylab = "log(termGPA) for monitored semester",
     main = "Total Sleep Time Vs. log(termGPA)")


## ---- fig.width=5, fig.height=4, fig.cap="Scatter plot of cummulative gpa vs term gpa. We notic a positive correlation betwen the two."----
plot(x=log(sleep_df$cum_gpa),
     y=log(sleep_df$term_gpa),
     xlab = "log(cummulative GPA) for semeseter before",
     ylab = "log(GPA) for monitored semester",
     main = "log(cummulative GPA) Vs. log(term GPA)")


## ---- include = FALSE---------------------------------------------------------
#cookd <- cooks.distance(gpa_fit)
#sort(pf(cookd, 2, 632), decreasing = TRUE)

sleep_df2 = sleep_df[-c(484),]
sleep_df2


## ---- include = FALSE---------------------------------------------------------
sleepTime = sleep_df2$TotalSleepTime
term_gpa_log = log(sleep_df2$term_gpa)
cum_gpa_log = log(sleep_df2$cum_gpa)

gpa_fit <- lm(term_gpa_log ~ sleepTime + cum_gpa_log)
summary(gpa_fit)
confint(gpa_fit)


## ---- include = FALSE---------------------------------------------------------
library(broom)


## ---- fig.width=4, fig.height=4, fig.cap="Residual plot for fitted multiple regression model. Clearly heteroskedastic."----
ggplot(augment(gpa_fit), aes(x = .fitted, y = .resid)) +
geom_point() +
labs(x = "Fitted value", y = "Residual")


## ---- fig.width=4, fig.height=4, fig.cap="QQ plot for residuals of fitted multiple linear regression model. Indicates that distribution of residuals are more heavy tailed than normal"----
ggplot(augment(gpa_fit), aes(sample = .resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical quantiles", y = "Sample quantiles")

