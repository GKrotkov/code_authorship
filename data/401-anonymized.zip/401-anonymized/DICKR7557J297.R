## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(ggplot2)

sleepData <- read.csv("C:\\Users\\rhyth\\Modern Regression\\cmu-sleep.csv")


## ----fig.width=4, fig.height=3------------------------------------------------
totalSleepHist <- ggplot(sleepData, aes(x = TotalSleepTime)) + geom_histogram(binwidth = 13, color = "black", fill = "red") + labs(x = "Total Sleep Time per Night (minutes)", y = "Frequency", title = "Total Sleep Time Histogram")
print(totalSleepHist)

## -----------------------------------------------------------------------------

summary(sleepData$TotalSleepTime)


## ----fig.width=4, fig.height=3------------------------------------------------
termGpaHist <- ggplot(sleepData, aes(x = term_gpa)) + geom_histogram(binwidth = 0.1, color = "black", fill = "blue") + labs(x = "Term GPA while being studied", y = "Frequency", title = "Term GPA histogram")
print(termGpaHist)



## -----------------------------------------------------------------------------
summary(sleepData$term_gpa)


## ---- fig.width=4, fig.height=3-----------------------------------------------
cumGPAHist <- ggplot(sleepData, aes(x = cum_gpa)) + geom_histogram(binwidth = 0.1, color = "black", fill = "green") + labs(x = "Student's GPA before being studied", y = "Frequency", title = "Fall GPA histogram")
print(cumGPAHist)


## -----------------------------------------------------------------------------
summary(sleepData$cum_gpa)


## ---- fig.width=5, fig.height=4-----------------------------------------------
p1 <- ggplot(sleepData, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + labs(x = "Total Sleeping Time(minutes)" , y = "Student's Term GPA during the study (out of 4.0)", title = "Total Sleep vs Term GPA")

p1


## ---- fig.width=5, fig.height=4-----------------------------------------------
p1log <- ggplot(sleepData, aes(x = log(TotalSleepTime), y = term_gpa)) + geom_point() + labs(x = "log(Total Sleeping Time(minutes))" , y = "Student's Term GPA during the study", title = "log(Total Sleep) vs Term GPA")

p1log


## ---- fig.width=5, fig.height=4-----------------------------------------------
p2 <- ggplot(sleepData, aes(x = TotalSleepTime, y = cum_gpa)) + geom_point() + labs(x = "Total Sleeping Time(minutes)" , y = "Student's Cumalitive GPA Before the study(out of 4.0)", title = "Total Sleep vs Cumalitive GPA")

p2


## ---- fig.width=5, fig.height=4-----------------------------------------------
p2log <- ggplot(sleepData, aes(x = log(TotalSleepTime), y = cum_gpa)) + geom_point() + labs(x = "log(Total Sleeping Time(minutes))" , y = "Student's Cumalitive GPA Before the study(Out of 4.0)", title = "log(Total Sleep) vs Log(Cumalitive GPA)")

p2log


## ---- fig.width=5, fig.height=4-----------------------------------------------


p3 <- ggplot(sleepData, aes(x = TotalSleepTime, y = (term_gpa)^1/3)) + geom_point() + labs(x = "Total Sleeping Time(minutes)" , y = "(Student's Term GPA During study(Out of 4.0))^1/3", title = "Total Sleep vs (Term GPA)^1/3")
p3



## ---- fig.width=5, fig.height=4-----------------------------------------------


p4 <- ggplot(sleepData, aes(x = TotalSleepTime, y = (term_gpa-cum_gpa))) + geom_point() + labs(x = "Total Sleeping Time(minutes)" , y = "GPA Change", title = "Total Sleep vs GPA Change")
p4



## -----------------------------------------------------------------------------
m3 <- lm(formula = (term_gpa^1/3) ~ TotalSleepTime, data = sleepData)


## -----------------------------------------------------------------------------
plot(m3,which =1,)


## -----------------------------------------------------------------------------
plot(m3,which =2)


## -----------------------------------------------------------------------------

summary(m3)
confint(m3)

