## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(GGally)
library(dplyr)


## -----------------------------------------------------------------------------
rp = Rateprof


## ---- fig.cap = "Histogram of Quality Rating"---------------------------------
hist(rp$quality, main = "Histogram of Quality Rating among Professors", xlab = "Quality Rating", ylab = "Count of Quality Rating (by bin)", breaks = 15, col = "cadetblue2")


## ---- fig.cap = "Histogram of Gender"-----------------------------------------
plot(rp$gender, main = "Histogram of Gender by Professor", xlab = "Gender", ylab = "Count by Gender", col = "coral")


## ---- fig.cap = "Histogram of Attractiveness"---------------------------------
plot(rp$pepper, main = "Histogram of Attractiveness by Professor", xlab = "Attractive (y/n)", ylab = "Count of Professors by Atractiveness", col = "lightgreen")


## ---- fig.cap = "Histogram of Easiness"---------------------------------------
hist(rp$easiness, main = "Histogram of Easiness by Professor", xlab = "Easiness", ylab = "Count of Easiness (by Bin)", col = "burlywood")


## ---- fig.cap = "Histogram of Discipline"-------------------------------------
plot(rp$discipline, main = "Histogram of Discipline by Professor", xlab = "Dsicipline", ylab = "Frequency (by Disicpline)", col = "darkorchid1")


## ---- fig.width = 10, fig.height = 12, fig.cap = "Pairs plot of selected columns in the Rateprof dataset", message = FALSE----
rp %>%
  select('quality', 'gender', 'pepper', 'easiness', 'discipline') %>%
  ggpairs()


## ---- fig.cap = "Scatterplot showing the relationship between quality and easiness colored by gender"----
colors = c("coral", "steelblue2")

rp$Color = colors[as.factor(rp$gender)]

plot(rp$quality, rp$easiness, main = "Quality vs. Easiness by Gender", xlab = "Easiness", ylab = "Quality", col = rp$Color, pch = 19)

legend("topleft",
       legend = unique(rp$gender),
       fill = colors,
       title = "Gender",
       cex = 0.8
)


## ---- fig.cap = "Scatterplot of Quality vs. Easiness colored by Discipline"----
colors = c("coral", "steelblue2", "darkorchid1", "burlywood")

rp$Color = colors[as.factor(rp$discipline)]

plot(rp$quality, rp$easiness, main = "Quality vs. Easiness by Discipline", xlab = "Easiness", ylab = "Quality", col = rp$Color, pch = 19)

legend("topleft",
       legend = unique(rp$discipline),
       fill = colors,
       title = "Discipline",
       cex = 0.8
)


## -----------------------------------------------------------------------------
full = lm(quality ~ gender + pepper + easiness + discipline, data = rp)


## ---- fig.cap = "Plot of Residuals vs. Fitted Values"-------------------------
plot(full, which=1)


## ---- fig.cap = "QQ-Plot of Residuals"----------------------------------------
set.seed(1)
qqnorm(rp$quality, pch = 1, frame = FALSE)
qqline(rp$quality, col = "steelblue", lwd = 2)


## -----------------------------------------------------------------------------
partial_gender = lm(quality ~ pepper + easiness + discipline, data = rp)


## -----------------------------------------------------------------------------
partial_pepper = lm(quality ~ gender + easiness + discipline, data = rp)


## -----------------------------------------------------------------------------
partial_discipline = lm(quality ~ gender + pepper + easiness, data = rp)


## -----------------------------------------------------------------------------
intercept_model = lm(quality ~ gender + pepper + easiness + discipline + easiness*gender + easiness*discipline, data = rp)

