## ----setup, include = FALSE---------------------------------------------------

knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(alr4)
library(modelsummary)
library(broom)

Rateprof2 <- Rateprof

levels(Rateprof2$discipline)[levels(Rateprof2$discipline) == "Hum"] <- "Humanities"

levels(Rateprof2$discipline)[levels(Rateprof2$discipline) == "SocSci"] <- "Social Sciences"

levels(Rateprof2$discipline)[levels(Rateprof2$discipline) == "Pre-prof"] <- "Pre-Professional"

colnames(Rateprof2)[5] <- "Attractive?"
attach(Rateprof2)



## ---- fig.cap = "Quantitative Variable Distributions", fig.height = 4---------
par(mfrow = c(1,2))
hist(quality, 
     main = "Histogram of Quality Rating", 
     xlab = "Quality Rating (0 to 5)")

hist(easiness, main = "Histogram of Easiness Rating", 
     xlab = "Easiness Rating (0 to 5)")



## ---- fig.cap = "Bivariate Boxplots for Quality Rating and Categorical Variables", fig.height = 8----

par(mfrow = c(3,1))
boxplot(quality~gender, 
        xlab = "Gender", 
        ylab = "Quality Rating")

boxplot(quality~discipline, 
        xlab = "Discipline", 
        ylab = "Quality Rating")

boxplot(quality~`Attractive?`, 
        xlab = "Attractive?", 
        ylab = "Quality Rating")



## ---- fig.cap = "Scatterplot of Quality vs Easiness Rating", fig.height = 4, fig.width = 5----

plot(easiness, quality, 
     xlab = "Easiness Rating (0-5)", 
     ylab = "Quality Rating (0-5)")

# ggplot(data = Rateprof2, mapping = aes(easiness, quality)) + 
#   geom_point(aes(color = gender)) + theme_bw()
#   



## ---- fig.cap = "Residuals vs Fitted Plot", fig.height = 4, fig.width = 5-----
reg2 <- lm(quality~easiness*discipline + easiness*gender+ discipline + `Attractive?`, data = Rateprof2)

reg2aug <- augment(reg2)

plot(reg2aug$.fitted, reg2aug$.resid, xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, lty = 2)



## ---- fig.cap = "Residuals vs Predictors", fig.height = 4, fig.width = 4------
# par(mfrow = c(2,2))
# plot(reg2aug$easiness, reg2aug$.resid, xlab = "Easiness Rating (0-5)", ylab = "Residuals")
# abline(h = 0, lty = 2)
# 
# boxplot(reg2aug$.resid~reg2aug$discipline, ylab = "Residuals", xlab = "Discipline")
# boxplot(reg2aug$.resid~reg2aug$gender, ylab = "Residuals", xlab = "Gender")
boxplot(reg2aug$.resid~reg2aug$`Attractive?`, ylab = "Residuals", xlab = "Attractive?")



## ---- fig.cap = "Quantile-Quantile Plot", fig.height = 4, fig.width = 5-------
qqnorm(resid(reg2))
qqline(resid(reg2))



## ---- fig.cap = "Regression Output"-------------------------------------------
modelsummary(reg2,
             estimate = c("{estimate}{stars}"),
             fmt = fmt_significant(3),
             coef_rename = c("easiness" = "Easiness",
                             "gendermale" = "Gender = Male",
                             "disciplineSocial Sciences" = "Discipline = Soc. Sci.",
                             "disciplineSTEM" = "Discipline = STEM",
                             "disciplinePre-Professional" = "Discipline = Pre. Prof",
                             "Attractive?yes" = "Attractive? = Yes"),
             # statistic = c("t: {statistic}", "p value: {p.value}",
             #               "std.error: {std.error}"),
             gof_map = c("r.squared", "nobs"),
             gof_omit = 'DF|Deviance|R2|AIC|BIC|Log.Lik.|RMSE|F', 
             caption = "Regression Output")


## -----------------------------------------------------------------------------
reducedMod <- lm(quality~easiness + easiness*gender + easiness:discipline + `Attractive?`, data = Rateprof2)
# anova(reducedMod, reg2)



## -----------------------------------------------------------------------------
reducedMod2 <- lm(quality~easiness + discipline + gender + `Attractive?`, data = Rateprof2)
# anova(reducedMod2, reg2)


