## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
# upload data
sleepData <- read.csv("cmu-sleep (1).csv")


## ---- fig.width=10, fig.height=4, fig.cap="Average amount of sleep."----------
# histogram for TotalSleepTime
hist(sleepData$TotalSleepTime, main = "Histogram of Total Sleep Time", 
     xlab = "Average amount of sleep students get each night, in minutes", 
     breaks = 25)

## ---- fig.width=10, fig.height=4, fig.cap="GPA the semester of the study."----
# histogram for term_gpa
hist(sleepData$term_gpa, main = "Histogram of GPA the semester being studied", 
     xlab = "Student's GPA the semester of the study (on a 4.0 scale)",
     breaks = 50)

## ---- fig.width=10, fig.height=4, fig.cap="Cumulative GPA before the semester of the study."----
# histogram for cum_gpa
hist(sleepData$cum_gpa, 
     main = "Histogram of GPA for all semesters before the semester of the study", 
     xlab = "Student's cumulative GPA before the semester of the study (on a 4.0 scale)", 
     breaks = 30)


## ---- fig.width=10, fig.height=5----------------------------------------------
# scatterplot of TotalSleepTime and term_gpa
plot(sleepData$TotalSleepTime, sleepData$term_gpa, 
     main = "Scatterplot of Total Sleep Time and GPA of the semester studied", 
     xlab = "Average amount of sleep students get each night, in minutes", 
     ylab = "GPA the semester of the study (on a 4.0 scale)")

## ---- fig.width=10, fig.height=5----------------------------------------------
# scatterplot of TotalSleepTime and cum_gpa
plot(sleepData$TotalSleepTime, sleepData$cum_gpa, 
     main = "Scatterplot of Total Sleep Time and GPA of all 
     semesters before the semester studied", 
     xlab = "Average amount of sleep students get each night, in minutes", 
     ylab = "Cumulative GPA before semester of the study (on a 4.0 scale)")

## ---- fig.width=10, fig.height=5----------------------------------------------
# scatterplot of term_gpa and cum_gpa
plot(sleepData$term_gpa, sleepData$cum_gpa, 
     main = "Scatterplot of GPA of the semester studied and GPA 
     of all semesters before the semester studied", 
     xlab = "GPA the semester of the study (on a 4.0 scale)", 
     ylab = "Cumulative GPA before semester of the study (on a 4.0 scale)")


## -----------------------------------------------------------------------------
sleepLM <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleepData)
summary(sleepLM)


## ---- fig.width=10, fig.height=5----------------------------------------------
plot(sleepLM, which = 1)


## ---- fig.width=10, fig.height=5----------------------------------------------
plot(sleepLM, which = 2)


## -----------------------------------------------------------------------------
inverseSleepLM <- lm(exp(term_gpa) ~ TotalSleepTime + exp(cum_gpa), data = sleepData)
summary(inverseSleepLM)

## ---- fig.width=10, fig.height=5----------------------------------------------
plot(inverseSleepLM, which = 1)

## ---- fig.width=10, fig.height=5----------------------------------------------
plot(inverseSleepLM, which = 2)


## -----------------------------------------------------------------------------
library(modelsummary)
modelsummary(list("Model 1" = sleepLM, "Model 2" = inverseSleepLM),
             gof_map = c("r.squared", "nobs"))

