## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(alr4)

Rateprof <-Rateprof
names(Rateprof)




## ----include=FALSE------------------------------------------------------------
summary(Rateprof$quality)
summary(Rateprof$easiness)


## ---- echo=FALSE, fig.cap="Distr of Avg Quality Rating"-----------------------
hist(Rateprof$quality, main= "Hist of Quality Rating for Professors", 
     xlab="Quality rating",ylab="Freq",col = "lightsteelblue",            
     border = "black",breaks=30)


## ---- echo=FALSE, fig.cap="Distr of Avg Easiness Rating"----------------------
hist(Rateprof$easiness, main= "Hist of Easiness Rating for Professors", 
     xlab="Easiness rating", ylab="Freq", col = "skyblue",            
     border = "black",  
     breaks=30)



## ----show=FALSE---------------------------------------------------------------

gendercount <- table(Rateprof$gender)
barplot(gendercount,
        main = "Distr of Professors by Gender",
        xlab = "Gender",
        ylab = "Freq",
        col = c("lightblue", "lightsteelblue"),
        legend.text = TRUE)



## ----show=FALSE---------------------------------------------------------------

peppercount <- table(Rateprof$pepper)
barplot(peppercount,
        main = "Distr of Professors by Attractiveness",
        xlab = "Attractivness(Pepper rating)",
        ylab = "Freq",
        col = c("lightblue", "lightsteelblue"),
        legend.text = TRUE)



## ----show=FALSE---------------------------------------------------------------

disciplinecount <- table(Rateprof$discipline)
barplot(disciplinecount,
        main = "Distr of Professors by Discipline",
        xlab = "Discipline",
        ylab = "Freq",
        col = c("lightsteelblue"),
        legend.text = TRUE)



## ---- show=FALSE--------------------------------------------------------------
plot(Rateprof$easiness,
     Rateprof$quality, main = "Quality vs. Easiness", xlab = "Easiness", ylab = "Quality", 
     col="navy", pch=16)
plot(Rateprof$gender,
     Rateprof$quality, main = "Quality vs. Gender", xlab = "Gender", ylab = "Quality", 
     col="lightsteelblue", pch=16)

plot(Rateprof$pepper,
     Rateprof$quality, main = "Quality vs. Attractiveness", xlab =
       "Attractiveness", ylab = "Quality", 
     col="lightsteelblue", pch=16)

plot(Rateprof$discipline,
     Rateprof$quality, main = "Quality vs. Discipline", xlab =
       "Discipline", ylab = "Quality", 
     col="lightsteelblue", pch=16)





## ----include=FALSE------------------------------------------------------------

rate_fit <- lm(quality ~ gender + pepper + easiness + discipline + 
            gender:easiness + discipline:easiness,data = Rateprof)
coefficients <- coef(rate_fit)
conf_int <- confint(rate_fit)
p_values <- summary(rate_fit)$coefficients[, 4]

# Combine into a data frame
result_table <- data.frame(
  Coefficient = coefficients,
  "95% CI Lower" = conf_int[, 1],
  "95% CI Upper" = conf_int[, 2],
  "P-value" = p_values
)

summary(rate_fit)



## -----------------------------------------------------------------------------
library(knitr)
knitr::kable(result_table, format = "markdown")



## ---- include=FALSE-----------------------------------------------------------

#assumptions tested as mentioned in methods, not included in output 
library(ggplot2)
library(broom)
ggplot(augment(rate_fit), aes(x = .fitted, y = .resid)) +
geom_point(col="navy") +
labs(x = "Fitted value", y = "Residual")

ggplot(augment(rate_fit), aes(sample = .resid)) +
geom_qq() +
geom_qq_line(col="navy") +
labs(x = "Theoretical quantiles", y = "Sample quantiles")

