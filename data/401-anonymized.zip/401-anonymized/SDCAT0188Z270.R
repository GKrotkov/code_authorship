## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE, message = FALSE----------------------------------------
library(readr)
library(ggplot2)
library(alr4)
library(broom)
library(car)
library(gridExtra)

data = alr4 :: Rateprof


## ---- echo = FALSE, message = FALSE-------------------------------------------
plot1 = ggplot(data, aes(x = factor(gender))) + 
  geom_bar(color = "seagreen", fill = "limegreen") +
  labs(x = "Gender", y = "Frequency") +
  ggtitle("Barplot: Gender")

plot2 = ggplot(data, aes(x = factor(pepper))) + 
  geom_bar(color = "seagreen", fill = "limegreen") +
  labs(x = "Attractiveness", y = "Frequency") +
  ggtitle("Barplot: Attractiveness")

plot3 = ggplot(data, aes(x = easiness)) + 
  geom_histogram(color = "seagreen", fill = "limegreen") +
  labs(x = "Easiness", y = "Frequency") +
  ggtitle("Histogram: Easiness")

plot4 = ggplot(data, aes(x = factor(discipline))) + 
  geom_bar(color = "seagreen", fill = "limegreen") +
  labs(x = "Discipline", y = "Frequency") +
  ggtitle("Barplot: Disciplines")

plot5 = ggplot(data, aes(x = quality)) + 
  geom_histogram(color = "seagreen", fill = "limegreen") +
  labs(x = "Quality", y = "Frequency") +
  ggtitle("Histogram: Quality")
grid.arrange(plot1, plot2, plot3, plot4, plot5, ncol = 3)


## ---- echo = FALSE, message = FALSE-------------------------------------------
plot10 = ggplot(data, aes(x = factor(gender), y = quality, fill = factor(gender))) + 
  geom_boxplot() +
  labs(x = "Gender", y = "Average Quality Ratings") +
  ggtitle("Quality vs Genders")

plot11 = ggplot(data, aes(x = factor(pepper), y = quality, fill = factor(pepper))) + 
  geom_boxplot() +
  labs(x = "Attractiveness", y = "Average Quality Ratings") +
  ggtitle("Quality vs Attractiveness")

plot12 = ggplot(data, aes(x = easiness, y = quality)) + 
  geom_point() +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(x = "Average Easiness Ratings", y = "Average Quality Ratings") +
  ggtitle("Quality vs Easiness")

plot13 = ggplot(data, aes(x = factor(discipline), y = quality, fill = factor(discipline))) + 
  geom_boxplot() +
  labs(x = "Disciplines", y = "Average Quality Ratings") +
  ggtitle("Quality vs Disciplines")
grid.arrange(plot10, plot11, plot12, plot13, ncol = 2)


## ---- echo = FALSE------------------------------------------------------------
rate_full_model = lm(quality ~ factor(gender) + factor(pepper) + easiness + 
                      factor(discipline) + easiness:factor(gender) + 
                       easiness:factor(discipline), data)
rate_red_model1 = lm(quality ~ factor(gender) + factor(pepper) + easiness + 
                      factor(discipline) + easiness:factor(discipline), data)
rate_red_model2 = lm(quality ~ factor(gender) + factor(pepper) + easiness + 
                      factor(discipline) + easiness:factor(gender), data)
rate_red_model3 = lm(quality ~ factor(gender) + factor(pepper) + easiness + 
                      factor(discipline), data)


## ---- echo = FALSE------------------------------------------------------------
residual = residuals(rate_full_model)
fitted = fitted(rate_full_model)
plot20 = ggplot(data = data, aes(x = fitted, y = residual)) +
       geom_point() +
       geom_abline(slope = 0, col = "red", lty = 2) +
       labs(x = "Fitted Values", y = "Residuals") +
       ggtitle("Residual Plot For Full Model")


## ---- echo = FALSE------------------------------------------------------------
plot21 = ggplot(data = data, aes(sample = residual)) +
  geom_qq() +
  geom_qq_line(color = "red", linetype = "dashed") +
  labs(x = "Theoretical quantiles", y = "Observed quantiles") +
  ggtitle("Normal QQ Plot For Full Model")


## -----------------------------------------------------------------------------
plot22 = ggplot(augment(rate_full_model), aes(x = easiness, y = .cooksd)) +
  geom_point() + 
  labs(title = "Cook's Distance Plot", x = "Observations", y = "Cook's Distance")
grid.arrange(plot20, plot21, plot22, ncol = 2)


## ---- include = FALSE---------------------------------------------------------
rate_better_model = step(rate_full_model, direction = "both")
AIC(rate_full_model)
AIC(rate_better_model)


## ---- include = FALSE---------------------------------------------------------
rate_lm = lm(quality ~ factor(gender) + easiness + factor(pepper) + factor(discipline), data)
summary(rate_lm)
confint(rate_lm)
anova(rate_red_model1, rate_full_model)
anova(rate_red_model2, rate_full_model)
anova(rate_red_model3, rate_full_model)

