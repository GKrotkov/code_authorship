## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----eda, message = FALSE, fig.title = "Histograms of Predictor Variables", fig.cap="Frequency of Predictor Variables in Dataset"----
library(alr4)

?Rateprof

pepper <- Rateprof[,5]
discipline <- Rateprof[,6]
gender <- Rateprof[,1]
easiness <- Rateprof[,11]

#table(pepper)
#table(discipline)
#table(gender)
#summary(easiness)
#sd(easiness)

par(mfrow = c(2, 2))
barplot(table(pepper), names = c("No", "Yes"), xlab = "Pepper Rating?", ylab = "Count")
barplot(table(discipline), names = c("Hum", "SocSci", "STEM", "Pre-Prof"), xlab = "Discipline", ylab = "Count")
barplot(table(gender), names = c("Female", "Male"), xlab = "Gender", ylab = "Count")
hist(easiness, prob = TRUE, xlab = "Average Easiness Rating (1 = worst, 5 = best)", main = "")


## ----response plot, message = FALSE, fig.cap="Frequency of Quality Rating Among Professors"----

quality <- Rateprof[,8]

#summary(quality)
#sd(quality)

hist(quality, main = "Frequency of Quality Rating", xlab = "Average Quality Rating (1 = worst, 5 = best)", breaks = 20)



## ----pairs, message = FALSE, fig.cap="Pair plots of response and predictor variables."----

library(GGally)

pairs(quality ~ pepper + easiness + gender + discipline, data = Rateprof, pch = 16, cex = 0.7)



## ----boxplot, message = FALSE, fig.cap="Box plots of factor variables against quality rating."----

par(mfrow = c(1, 3))

boxplot(quality ~ pepper, ylab = "Quality Rating", data = Rateprof, xlab = "Pepper Rating?", names = c("No", "Yes"), pch = 16)

boxplot(quality ~ discipline, ylab = "Quality Rating", data = Rateprof, xlab = "Discipline", names = c("Hum", "SocSci", "STEM", "Pre-Prof"), pch = 16)

boxplot(quality ~ gender, ylab = "Quality Rating", data = Rateprof, xlab = "Gender", names = c("Female", "Male"), pch = 16)



## ----residuals, message = FALSE, fig.cap="Plot of residuals."-----------------

library(ggplot2)
library(patchwork)
library(broom)

lin_model <- lm(quality ~ easiness + factor(pepper) + factor(gender) + factor(discipline), data = Rateprof)

res <- resid(lin_model)

p1 <- ggplot(augment(lin_model), aes(x = easiness, y = .resid)) + geom_point() + labs(title = "Residual against Easiness Rating", x = "Average Easiness Rating (1 = worst, 5 = best)", y = "Residual")

p2 <- ggplot(augment(lin_model), aes(x = .fitted, y = .resid)) + geom_point() + labs(title = "Residual against Fitted Value",  x = "Fitted Value", y = "Residual")

p1 | p2



## ----cook, message = FALSE, fig.cap="Plot of Cook's Distance of fitted values."----

ggplot(augment(lin_model), aes(x = .fitted, y = .cooksd)) + geom_point() + labs(title = "Plot of Cook's Distance of Fitted Values",x = "Fitted Value", y = "Cook's Distance")



## ---- message = FALSE, fig.cap="Q-Q Plot of the Residuals of the Transformed Data."----
qqnorm(res)
qqline(res, col = "green")
          


## ----model, message = FALSE, include = FALSE----------------------------------

full_model <- lm(quality ~ easiness + factor(pepper) + factor(gender) + factor(discipline), data = Rateprof)

summary(full_model)

confint(full_model, level = 0.95)


## ----easiness, message = FALSE, include = FALSE-------------------------------

easiness_model <- lm(quality ~ factor(pepper) + factor(gender) + factor(discipline), data = Rateprof)

anova(easiness_model, full_model)



## ----pepper, message = FALSE, include = FALSE---------------------------------

pepper_model <- lm(quality ~ easiness + factor(gender) + factor(discipline), data = Rateprof)

anova(pepper_model, full_model)


## ----gender, message = FALSE, include = FALSE---------------------------------

gender_model <- lm(quality ~ easiness + factor(pepper) + factor(discipline), data = Rateprof)

anova(gender_model, full_model)



## ----discipline, message = FALSE, include = FALSE-----------------------------

discipline_model <- lm(quality ~ easiness + factor(pepper) + factor(gender), data = Rateprof)

anova(discipline_model, full_model)



## ----interaction, message = FALSE, include = FALSE----------------------------

#include = FALSE

interaction_model <- lm(quality ~ easiness + factor(pepper) + factor(gender) + factor(discipline) + easiness:discipline + easiness:gender, data = Rateprof)

anova(full_model, interaction_model)


