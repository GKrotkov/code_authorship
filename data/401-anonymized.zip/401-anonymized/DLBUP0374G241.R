## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(dplyr)
library(alr4)
library(ggplot2)
library(GGally)
library(bestglm)
library(modelsummary)
library(gridExtra)
profdata = Rateprof


## -----------------------------------------------------------------------------
ggplot(data = profdata, aes(x = gender)) + geom_bar(fill="darkgreen") + labs(title = "Gender of Professors")


## -----------------------------------------------------------------------------
qual = ggplot(data = profdata, aes(x = quality)) + geom_histogram(binwidth = .1, fill="blue", color = "black")+ labs(title = "Distribution of Quality", x = "Quality")
helpful = ggplot(data = profdata, aes(x = helpfulness)) + geom_histogram(binwidth = .1, fill="red", color = "black")+ labs(title = "Distribution of Helpfulness", x = "Helpfulness")
clar = ggplot(data = profdata, aes(x = clarity)) + geom_histogram(binwidth = .1, fill="darkgreen", color = "black")+ labs(title = "Distribution of Clarity", x = "Clarity")
ease = ggplot(data = profdata, aes(x = easiness)) + geom_histogram(binwidth = .1, fill="purple", color = "black")+ labs(title = "Distribution of Class Difficulty", x = "Difficulty")
inter = ggplot(data = profdata, aes(x = raterInterest)) + geom_histogram(binwidth = .1, fill="yellow", color = "black") + labs(title = "Distribution of Interest Levels", x = "Interest")
grid.arrange(qual, helpful, clar, ease, inter, nrow=3)


## -----------------------------------------------------------------------------
qual1 = qual + facet_grid(cols = vars(gender))
help1 = helpful + facet_grid(cols = vars(gender))
clar1 = clar + facet_grid(cols = vars(gender))
ease1 = ease + facet_grid(cols = vars(gender))
inter1 = inter + facet_grid(cols = vars(pepper))
ggplot(data = profdata, aes(x = pepper)) + geom_bar(fill = "darkgreen") + labs(title= "Professor Attractiveness", x = "Attractive") + facet_grid(cols=vars(gender))


## -----------------------------------------------------------------------------
grid.arrange(qual1, inter1, nrow=2)


## -----------------------------------------------------------------------------
qual + facet_grid(rows = vars(discipline))


## -----------------------------------------------------------------------------
p1 = ggplot(data = profdata, aes(x = quality, y = helpfulness)) + geom_point(aes(color = gender)) + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth", color="green")
p2 = ggplot(data = profdata, aes(x = quality, y = clarity)) + geom_point(aes(color = gender)) + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth", color="green")
p3 = ggplot(data = profdata, aes(x = quality, y = easiness)) + geom_point(aes(color = gender)) + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth", color="green")
p4 = ggplot(data = profdata, aes(x = quality, y = raterInterest)) + geom_point(aes(color = gender)) + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth", color="green")
grid.arrange(p1,p2,p3,p4, nrow = 2)


## -----------------------------------------------------------------------------
par(mfrow = c(2,2))

fm = lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = profdata)

lin = plot(fm$fitted.values, fm$residuals, main = "Residuals vs Fitted", xlab = "Fitted Values", ylab = "Residuals")
qq = qqnorm(fm$residuals); qqline(fm$residuals)
cook = plot(fm, which = c(4))


## ---- results='hide', echo=FALSE----------------------------------------------
rm = lm(quality ~ gender + pepper + easiness + discipline, data = profdata)
summary(rm)
confint(rm, level=.95)
rm$aic = AIC(rm)
fm$aic = AIC(fm)
confint(fm, level=.95)
anova(rm, fm)

