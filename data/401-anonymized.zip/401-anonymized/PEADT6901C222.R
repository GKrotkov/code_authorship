## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep <- read.csv("/Users/ananya/Downloads/cmu-sleep.csv")
library(tidyverse)


## ---- fig.width=5, fig.height=5-----------------------------------------------
ggplot(sleep, aes(x = TotalSleepTime)) + 
  geom_histogram(fill = "hotpink4", color = "black", binwidth = 40) + 
  ggtitle("Histogram of Total Sleep Time") +
  xlab("Total Sleep Time (in minutes)") +
  ylab("Count")


## ---- fig.width=5, fig.height=5-----------------------------------------------
ggplot(sleep, aes(x = term_gpa)) + 
  geom_histogram(fill = "darkgreen", color = "black", binwidth = 0.3) + 
  ggtitle("Histogram of Semester GPA") +
  xlab("GPA (out of 4.0)") +
  ylab("Count")


## ---- fig.width=5, fig.height=5-----------------------------------------------
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point(color = "steelblue") +
  ggtitle("Total Sleep Time vs. Term GPA") +
  xlab("Total Sleep Time (in minutes)") +
  ylab("Term GPA")


## -----------------------------------------------------------------------------
sleep$TotalSleepTime <- sleep$TotalSleepTime/60


## -----------------------------------------------------------------------------
# fitting the lm model
sleepfit <- lm(term_gpa ~ TotalSleepTime, data = sleep)


## ---- fig.width=5, fig.height=5-----------------------------------------------
library(broom)
# finding the cook's distance
# have to figure out how to determine if there are influential cases
cooksleep <- cooks.distance(sleepfit)
ggplot(augment(sleepfit), aes(x = TotalSleepTime, y = .cooksd)) +
  geom_point()


## ---- fig.width=5, fig.height=5-----------------------------------------------
plot(sleepfit, which = 1)


## ---- fig.width=5, fig.height=5-----------------------------------------------
# qq plot for normal probability plot
qqnorm(residuals(sleepfit), pch = 1, frame = FALSE)
qqline(residuals(sleepfit))


## ---- fig.width=5, fig.height=5-----------------------------------------------
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point(color = "steelblue") +
  geom_smooth(method = "lm", level = 0.95, se = TRUE, color = "hotpink4") +
  ggtitle("Total Sleep Time vs. Term GPA") +
  xlab("Total Sleep Time (in minutes)") +
  ylab("Term GPA")


## -----------------------------------------------------------------------------
confint(sleepfit)

