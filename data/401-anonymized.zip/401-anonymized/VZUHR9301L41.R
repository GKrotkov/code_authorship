## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(GGally)
library(dplyr)
library(kableExtra)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)


## ---- out.width="50%", fig.align="center"-------------------------------------
# quality & potentially sdQuality
hist(Rateprof$quality,
     breaks = 20,
     main = "",
     xlab = "Quality Rating",
     ylab = "Frequency",
     col = "lightblue")


## ---- out.width="50%"---------------------------------------------------------
# gender
barplot(table(Rateprof$gender), 
        main = "", 
        xlab = "Gender", 
        ylab = "Frequency", 
        col = c("#1d71ba", "#b25690"))

# pepper
barplot(table(Rateprof$pepper), 
        main = "", 
        xlab = "Pepper (Attractiveness)", 
        ylab = "Frequency", 
        col = c("#edc400", "#71b379"))

# easiness & potentially sdEasiness
hist(Rateprof$easiness,
     breaks = 20,
     main = "",
     xlab = "Easiness",
     ylab = "Frequency")

# discipline
barplot(table(Rateprof$discipline), 
        main = "", 
        xlab = "Discipline", 
        ylab = "Frequency", 
        col = c("#cb625f", "#d0944d", "#67c2d4", "#3988a4"))


## ---- out.width="50%"---------------------------------------------------------
# Response variable x predictor
# quality x gender
boxplot(quality ~ gender, 
        data = Rateprof, 
        main = "Quality by Gender", 
        xlab = "Gender", 
        ylab = "Quality", 
        col = c("#1d71ba", "#b25690"))
# summary((Rateprof[Rateprof$gender == "female", ])$quality)
# summary((Rateprof[Rateprof$gender == "male", ])$quality)

# quality x pepper
boxplot(quality ~ pepper, 
        data = Rateprof, 
        main = "Quality by Pepper", 
        xlab = "Pepper (Attractiveness)", 
        ylab = "Quality",
        col = c("#edc400", "#71b379"))
# summary((Rateprof[Rateprof$pepper == "no", ])$quality)

# quality x easiness
plot(Rateprof$easiness, 
     Rateprof$quality, 
     main = "Quality vs Easiness", 
     xlab = "Easiness", 
     ylab = "Quality", 
     pch = 19)

# quality x discipline
boxplot(quality ~ discipline, 
        data = Rateprof, 
        main = "Quality by Discipline", 
        xlab = "Discipline", 
        ylab = "Quality",
        col = c("#cb625f", "#d0944d", "#67c2d4", "#3988a4"))
# summary((Rateprof[Rateprof$discipline == "Hum", ])$quality)


## ---- out.width="50%"---------------------------------------------------------
plot(easiness ~ gender, 
     data = Rateprof, 
     xlab = "Gender", 
     ylab = "Easiness", 
     main = "Easiness Scores by Gender",
     col = c("#1d71ba", "#b25690"))
# summary((Rateprof[Rateprof$gender == "female", ])$easiness)
# summary((Rateprof[Rateprof$gender == "male", ])$easiness)

# Easiness x Discipline
plot(easiness ~ discipline, 
     data = Rateprof, 
     xlab = "Discipline", 
     ylab = "Easiness", 
     main = "Easiness Scores by Discipline",
     col = c("#cb625f", "#d0944d", "#67c2d4", "#3988a4"))
# summary((Rateprof[Rateprof$discipline == "Hum", ])$quality)


## ---- out.width="50%"---------------------------------------------------------
Rateprof.mod1 <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

plot(Rateprof.mod1, which = c(1,2), main="")

## ---- include = FALSE---------------------------------------------------------
# , include = FALSE
# summary(Rateprof.mod1)

cookd_df <- data.frame(cookd = cooks.distance(Rateprof.mod1)) %>%
  arrange(desc(cookd))

n <- length(cooks.distance(Rateprof.mod1))
f_20th <- qf(0.2, df1 = 2, df2 = n - 2)
f_50th <- qf(0.5, df1 = 2, df2 = n - 2)

concern_points <- cookd_df %>% filter(cookd > f_50th)
between_20_50_points <- cookd_df %>% filter(cookd > f_20th & cookd < f_50th)

# vif(Rateprof.mod1)


## ---- out.width="50%"---------------------------------------------------------
Rateprof.mod2 <- lm(quality ~ gender + pepper + easiness + discipline 
                       + easiness:gender + easiness:discipline, data = Rateprof)

plot(Rateprof.mod2, which = c(1,2), main="")


## ---- include = FALSE---------------------------------------------------------
# , include = FALSE
# summary(Rateprof.mod2)

cookd_df <- data.frame(cookd = cooks.distance(Rateprof.mod2)) %>%
  arrange(desc(cookd))

n <- length(cooks.distance(Rateprof.mod2))
f_20th <- qf(0.2, df1 = 2, df2 = n - 2)
f_50th <- qf(0.5, df1 = 2, df2 = n - 2)

concern_points <- cookd_df %>% filter(cookd > f_50th)
between_20_50_points <- cookd_df %>% filter(cookd > f_20th & cookd < f_50th)

vif(Rateprof.mod2)


## -----------------------------------------------------------------------------
result <- data.frame(
  Variable = c("(Intercept)", "gendermale", "pepperyes", "easiness"),
  Estimate = c("1.57883", "0.14470", "0.65529", "0.56837"),
  `sd.dev` = c("0.16132", "0.07109", "0.10740", "0.04659"),
  `Confidence Interval` = c("[1.261572839, 1.8960917]",
                            "[0.004884619, 0.2845138]",
                            "[0.444077454, 0.8665078]",
                            "[0.476750306, 0.6599858]"),
  `t-value` = c("9.787", "2.035", "6.101", "12.200"),
  `p-value` = c("< 2e-16", "0.0426", "2.72e-09", "< 2e-16")
)

kable(result, align = "c", escape = FALSE)


## ---- include = FALSE---------------------------------------------------------
# , include = FALSE
summary(Rateprof.mod1)
confint(Rateprof.mod1)


## -----------------------------------------------------------------------------
# , include = FALSE
Rateprof.mod1 <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

Rateprof.mod1.reduced <- lm(quality ~ gender + pepper + easiness, data = Rateprof)
anova.discipline <- anova(Rateprof.mod1.reduced, Rateprof.mod1)
kable(anova.discipline)


## -----------------------------------------------------------------------------
anova.interaction <- anova(Rateprof.mod1, Rateprof.mod2)
kable(anova.interaction)

