## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
data <- read.csv("cmu-sleep.csv")


## ---- fig.width=5, fig.height=4, fig.align="center", fig.cap="Histogram of average amount of sleep appears centered and unimodal"----
hist(data$TotalSleepTime,
     main="Average Amount of Sleep",
     xlab="Average Amount of Sleep (Minutes)",
     breaks=25)

## ----include=FALSE------------------------------------------------------------
mean(data$TotalSleepTime)
sd(data$TotalSleepTime)


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="Histogram of term GPA shows signficant left skew"----
hist(data$term_gpa,
     main="Term GPA",
     xlab="Term GPA (out of 4.0)",
     breaks=20)

## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="Histogram of cumulative GPA also shows signficant left skew"----
hist(data$cum_gpa,
     main="Cumulative GPA",
     xlab="Cumulative GPA (out of 4.0)",
     breaks=20)


## ----fig.width=5, fig.height=4, fig.align="center", fig.cap="Histogram of the change in students' GPAs is centered and unimodal"----
change_GPA = data$term_gpa-data$cum_gpa
data$change_GPA <- change_GPA
hist(change_GPA, breaks=15,
     main="Change in GPA across Semesters",
     xlab="Change in GPA (term - cumulative, out of 4.0)")

## ----include=FALSE------------------------------------------------------------
mean(change_GPA)
sd(change_GPA)


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="The relationship between sleep time and cumulative GPA is clustered unevenly"----
plot(data$TotalSleepTime, data$cum_gpa,
     main="Average Sleep Time \nvs Cumulative GPA",
     xlab="Average Minutes of Sleep",
     ylab="Cumulative GPA (out of 4.0)")

## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="The relationship between sleep time and term GPA is clustered unevenly"----
plot(data$TotalSleepTime, data$term_gpa,
     main="Average Sleep Time \nvs Term GPA",
     xlab="Average Minutes of Sleep",
     ylab="Term GPA (out of 4.0)")


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="The relationship between cumulative and term GPA appearly strongly correlated"----
plot(data$cum_gpa, data$term_gpa,
     main="Cumulative GPA vs Term GPA",
     xlab="Cumulative GPA (out of 4.0)",
     ylab="Term GPA (out of 4.0)")


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="The relationship between sleep time and change in GPA do not have an obvious correlation"----
plot(data$TotalSleepTime, change_GPA,
     main="Average Sleep Time vs Change in GPA",
     xlab="Average Minutes of Sleep",
     ylab="Change in GPA Points")


## ---- include=FALSE-----------------------------------------------------------
change_lm <- lm(change_GPA ~ TotalSleepTime, data=data)
summary(change_lm)


## ---- include=FALSE-----------------------------------------------------------
mean(data$TotalSleepTime)
mean(data$TotalSleepTime)-120
predict(change_lm, newdata=data.frame(TotalSleepTime=mean(data$TotalSleepTime)-120),interval="confidence", level=0.95)


## -----------------------------------------------------------------------------
library(stats)
cooksd <- cooks.distance(change_lm)
cook6 <- data.frame(head(sort(cooksd, decreasing=TRUE), 6))
names(cook6)[1] <- "Cook's Distances"
cook6$"Percentile" <- head(sort(pf(cooksd, 2, 632), decreasing = TRUE), 6)
knitr::kable(cook6, digits = 4, row.name=FALSE,caption = "Top 6 Cook's Distance Data Points")

## ----fig.width=5, fig.height=4, fig.align="center", fig.cap="Highlighted points with large Cook's Distance tend to have lower amounts of sleep"----
plot(data$TotalSleepTime, change_GPA,
     main="Average Sleep Time vs Change in GPA",
     xlab="Average Minutes of Sleep",
     ylab="Change in GPA Points")
legend(x="bottomright",
       legend=c("Top 6 Largest Cook's Distance Points"),
       pch=c(1), col="red", cex=0.7)
points(data$TotalSleepTime[471], data$change_GPA[471], col="red")
points(data$TotalSleepTime[259], data$change_GPA[259], col="red")
points(data$TotalSleepTime[87], data$change_GPA[87], col="red")
points(data$TotalSleepTime[407], data$change_GPA[407], col="red")
points(data$TotalSleepTime[32], data$change_GPA[32], col="red")
points(data$TotalSleepTime[297], data$change_GPA[297], col="red")


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="Model residuals are evenly distributed with roughly mean zero and constant standard deviation"----
plot(fitted(change_lm), resid(change_lm),
     main="Model Residuals",
     xlab="Fitted Change in GPA",
     ylab="Model Residual (GPA points)")
abline(0,0, col="blue")


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="Normal Q-Q plot shows that residuals have heavy-tails"----
qqnorm(resid(change_lm),main="Normal Q-Q Plot of Residuals")
qqline(resid(change_lm), col="blue")


## ----fig.width=4, fig.height=3, fig.align="center", fig.cap="Density graph of residuals shows centered and roughly normal distribution of residuals"----
plot(density(resid(change_lm)),
     main="Density Graph of Residuals")


## ---- include=FALSE-----------------------------------------------------------
confint(change_lm, level=0.95)
change_lm$coefficients[2]*60


## ---- include=FALSE-----------------------------------------------------------
predict(change_lm, newdata=data.frame(TotalSleepTime=mean(data$TotalSleepTime)-120),interval="confidence", level=0.95)

