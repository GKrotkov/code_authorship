## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------

library(dplyr)
library(readr)
library(ggplot2)
library(grid)
library(gridExtra)



## -----------------------------------------------------------------------------

sleep_data <- read_csv("cmu-sleep.csv")



## ---- fig.width=7, fig.height=3, fig.cap="Count of Sleep Time + Log Sleep Time"----

combined_plot <- arrangeGrob(
  ggplot(sleep_data, aes(x = sleep_data$TotalSleepTime)) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Average Nightly Sleep Times (min)', y = "Count", title = "Figure 1: Count of Average Nightly Sleep Times (min)") +
    theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = log(sleep_data$TotalSleepTime))) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Log of Average Nightly Sleep Times (min)', y = "Count", title = "Figure 2: Count of Log of Average Nightly Sleep Times (min)") +
    theme(plot.title = element_text(size = 8)),
  
  layout_matrix = rbind(c(1, 2))
)

grid.arrange(combined_plot)



## ---- fig.width=7, fig.height=3, fig.cap="Count of Term / Cum GPA"------------

combined_plot <- arrangeGrob(
  ggplot(sleep_data, aes(x = sleep_data$term_gpa)) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Term GPA (out of 4.0)', y = "Count", title = "Figure 3: Count of Term GPA (out of 4.0)") +
    theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = sleep_data$cum_gpa)) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Cumulative GPA (out of 4.0)', y = "Count", title = "Figure 4: Count of Cumulative GPA (out of 4.0)") +
    theme(plot.title = element_text(size = 8)),
  
  layout_matrix = rbind(c(1, 2))
)

grid.arrange(combined_plot)



## ---- fig.width=7, fig.height=3, fig.cap="Count of Sqrt, Log, Exp of Term GPA"----

combined_plot <- arrangeGrob(
  ggplot(sleep_data, aes(x = sqrt(sleep_data$term_gpa))) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Square Root of Term GPA (out of 4.0)', y = "Count", title = "Figure 5: Count of Square Root of Term GPA (out of 4.0)") +
    theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = log(sleep_data$term_gpa))) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Log of Term GPA (out of 4.0)', y = "Count", title = "Figure 6: Count of Log of Term GPA (out of 4.0)") +
    theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = exp(sleep_data$term_gpa))) +
    geom_histogram(color = 'darkgray', fill = 'white') +
    labs(x = 'Exp of Term GPA (out of 4.0)', y = "Count", title = "Figure 7: Count of Exp of Term GPA (out of 4.0)") +
    theme(plot.title = element_text(size = 8)),
  
  layout_matrix = rbind(c(1, 2), c(3,3))
)

grid.arrange(combined_plot)



## ---- fig.width=4, fig.height=3, fig.cap="Sleep vs. GPA"----------------------

sleep_data %>%
  ggplot(aes(x = sleep_data$TotalSleepTime, y = sleep_data$term_gpa)) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "blue") + labs(x = "Average Nightly Sleep Times (min)", y = "Term GPA", title = "Figure 8: Average Nightly Sleep vs. GPA") + theme_minimal()



## ---- fig.width=8, fig.height=5, fig.cap="Sqrt, Log, Exp Term GPA vs. Sleep + Log Term GPA vs. Log Sleep"----

combined_plot <- arrangeGrob(
  ggplot(sleep_data, aes(x = TotalSleepTime, y = sqrt(term_gpa))) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "blue") + labs(x = "Average Nightly Sleep (min)", y = "Square Root of Term GPA", title = "Figure 9: Average Nightly Sleep vs. Square Root of Term GPA") + theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = TotalSleepTime, y = log(term_gpa))) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "blue") + labs(x = "Average Nightly Sleep (min)", y = "Log of Term GPA", title = "Figure 10: Average Nightly Sleep vs. Log of Term GPA") + theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = TotalSleepTime, y = exp(term_gpa))) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "blue") + labs(x = "Average Nightly Sleep (min)", y = "Exp of Term GPA", title = "Figure 11: Average Nightly Sleep vs. Exp of Term GPA") + theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = log(TotalSleepTime), y = log(term_gpa))) + geom_point() + geom_smooth(method = "lm", se = FALSE, color = "blue") + labs(x = "Log of Average Nightly Sleep (min)", y = "Log of Term GPA", title = "Figure 12: Log of Average Nightly Sleep vs. Log of Term GPA") + theme(plot.title = element_text(size = 8)),
  
  layout_matrix = rbind(c(1, 2), c(3,4))
)

grid.arrange(combined_plot)


## ---- fig.width=8, fig.height=5, fig.cap="Residuals of Regular, Exp Term GPA vs. Sleep + Log Term GPA vs. Log Sleep"----

sleep_model_raise_1 <- lm(term_gpa ~ TotalSleepTime, data = sleep_data)

r_squared_1 <- summary(sleep_model_raise_1)$r.squared

sleep_model_raise_2 <- lm(log(term_gpa) ~ log(TotalSleepTime), data = sleep_data)

r_squared_2 <- summary(sleep_model_raise_2)$r.squared

sleep_model_raise_3 <- lm(exp(term_gpa) ~ TotalSleepTime, data = sleep_data)

r_squared_3 <- summary(sleep_model_raise_3)$r.squared

combined_plot <- arrangeGrob(
  ggplot(sleep_data, aes(x = fitted(sleep_model_raise_1), y = resid(sleep_model_raise_1))) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(x = "Fitted Values", y = "Residuals", title = "Figure 13: Residuals vs. Fit for Sleep vs. Term GPA") + theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = fitted(sleep_model_raise_2), y = resid(sleep_model_raise_2))) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") + 
  labs(x = "Fitted Values", y = "Residuals", title = "Figure 14: Residuals vs. Fit for Log of Sleep vs. Log of Term GPA") + theme(plot.title = element_text(size = 8)),
  
  ggplot(sleep_data, aes(x = fitted(sleep_model_raise_3), y = resid(sleep_model_raise_3))) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") + 
  labs(x = "Fitted Values", y = "Residuals", title = "Figure 15: Residuals vs. Fit for Sleep vs. Exp of Term GPA") + theme(plot.title = element_text(size = 8)),
  
  layout_matrix = rbind(c(1, 2), c(3,3))
)

grid.arrange(combined_plot)



## ---- fig.width=7, fig.height=5, fig.cap="Q-Q Plot of Residuals of Average Nightly Sleep vs. Term GPA"----

sleep_model_raise_1 <- lm(term_gpa ~ TotalSleepTime, data = sleep_data)

qqnorm(residuals(sleep_model_raise_1))
qqline(residuals(sleep_model_raise_1))



## ---- fig.width=7, fig.height=5, fig.cap="Q-Q Plot of Residuals of Average Nightly Sleep vs. Exp of Term GPA"----

sleep_model_raise_3 <- lm(exp(term_gpa) ~ TotalSleepTime, data = sleep_data)

lower_bound <- 0.0458567 * -120 - (0.0099875 * 1.963) #https://library.virginia.edu/data/articles/interpreting-log-transformations-in-a-linear-model
lower_bound_adj <- (exp(lower_bound - 1))*100
upper_bound <- 0.0458567 * -120 + (0.0099875 * 1.963)
upper_bound_adj <- (exp(upper_bound - 1))*100
result_adj <- (exp((0.0458567 * -120) - 1))*100

qqnorm(residuals(sleep_model_raise_3))
qqline(residuals(sleep_model_raise_3))



## -----------------------------------------------------------------------------

sleep_model_raise_3 <- lm(exp(term_gpa) ~ TotalSleepTime, data = sleep_data)
model_summary <- summary(sleep_model_raise_3)
coefficients <- model_summary$coefficients
coefficients_df <- data.frame(
  Coefficient = rownames(coefficients),
  Estimate = coefficients[, 1],
  Std.Error = coefficients[, 2],
  t.value = coefficients[, 3],
  Pr..t.. = coefficients[, 4]
) 
knitr::kable(coefficients_df, digits = 7)

critical_val <- qt(1 - 0.025, 632)


