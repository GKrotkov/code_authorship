## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep <- read.csv("C:\\Users\\thoma\\Downloads\\cmu-sleep.csv")


## -----------------------------------------------------------------------------
library(ggplot2)
sleep <- read.csv("C:\\Users\\thoma\\Downloads\\cmu-sleep.csv")
hist(sleep$TotalSleepTime,
    main = "Students' Average Sleep Times",
          xlab = "Student",
          ylab = "Average Sleep Time (in minutes)",
    breaks = 16)

## -----------------------------------------------------------------------------
hist(sleep$cum_gpa,
    main = "Students' Cumulative GPAs",
          xlab = "Student",
          ylab = "Cumulative GPA (out of 4.0)",
          breaks = 20)

## -----------------------------------------------------------------------------
hist(sleep$term_gpa,
    main = "Students' Semester GPAs",
          xlab = "Student",
          ylab = "Semester GPA (out of 4.0)",
    breaks = 20)

## -----------------------------------------------------------------------------
ggplot(sleep, aes(x=TotalSleepTime, y=term_gpa)) +
         geom_point() +
         labs(title="Average Sleep Time vs. Term GPA", x="Average Sleep Time (in minutes)", y="Term GPA (out of 4.0)")

## -----------------------------------------------------------------------------
ggplot(sleep, aes(x=cum_gpa, y=term_gpa)) +
         geom_point() +
         labs(title="Cumulative GPA (out of 4.0) vs. Term GPA", x="Cumulative GPA (out of 4.0)", y="Term GPA (out of 4.0)")


## -----------------------------------------------------------------------------
analysis <- lm(formula = term_gpa ~ TotalSleepTime, data = sleep)
summary(analysis)

## -----------------------------------------------------------------------------
plot(analysis, which=1)


## -----------------------------------------------------------------------------
new_analysis <- lm(formula = exp(term_gpa) ~ TotalSleepTime + exp(cum_gpa), data = sleep)
summary(new_analysis)

## -----------------------------------------------------------------------------
plot(new_analysis, which=1)

## -----------------------------------------------------------------------------
plot(new_analysis, which=2)

