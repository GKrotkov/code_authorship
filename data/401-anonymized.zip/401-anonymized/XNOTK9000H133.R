## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)


## ---- fig.width=5, fig.height=2.5, fig.cap="Histograms for the Quantitative Variables", message=FALSE----
library(tidyverse)
library(patchwork)

histogram_quality <- Rateprof %>% 
  ggplot(aes(x = quality)) +
  geom_histogram(bins = 30, fill = "lightblue", color = "navy") +
  labs(title = "Distribution of `quality`",
       x = "Average quality rating (1 to 5)",
       y = "Count") +
  theme_bw() +
  theme(plot.title = element_text(size = 10, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        axis.text = element_text(size = 9))

histogram_easiness <- Rateprof %>% 
  ggplot(aes(x = easiness)) +
  geom_histogram(bins = 30, fill = "lightblue", color = "navy") +
  labs(title = "Distribution of `easiness`",
       x = "Average easiness rating (1 to 5)",
       y = "Count") +
  theme_bw() +
  theme(plot.title = element_text(size = 10, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        axis.text = element_text(size = 9))

histogram_quality | histogram_easiness


## ---- fig.width=8, fig.height=2.5, fig.cap="Barplots for the Three Categorical Variables", message=FALSE----
library(gridExtra)

barplot_gender <- Rateprof %>% 
  ggplot(aes(x=gender, fill=gender)) +
  geom_bar(stat = "count") +
  labs(title = "Distribution of `gender`",
       x = "Instructor's gender",
       y = "Count") +
  theme_bw() +
  guides(fill = "none") +
  theme(plot.title = element_text(size = 11, hjust = 0.5),
        axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        axis.text = element_text(size = 9))

barplot_pepper <- Rateprof %>% 
  ggplot(aes(x=pepper, fill=pepper)) +
  geom_bar(stat = "count") +
  labs(title = "Distribution of `pepper`",
       x = "Whether the instructor is attractive",
       y = "Count") +
  theme_bw() +
  guides(fill = "none") +
  theme(plot.title = element_text(size = 11, hjust = 0.5),
        axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        axis.text = element_text(size = 9))

barplot_discipline <- Rateprof %>% 
  ggplot(aes(x=discipline, fill=discipline)) +
  geom_bar(stat = "count") +
  labs(title = "Distribution of `discipline`",
       x = "Instructor's discipline",
       y = "Count") +
  theme_bw() +
  guides(fill = "none") +
  theme(plot.title = element_text(size = 11, hjust = 0.5),
        axis.title.x = element_text(size = 10),
        axis.title.y = element_text(size = 10),
        axis.text = element_text(size = 9))

grid.arrange(barplot_gender, barplot_pepper, barplot_discipline, nrow=1)


## ---- fig.width=5, fig.height=4, fig.cap="Relationship between Quality Ratings and Each Predictor", message=FALSE----
sp <- Rateprof %>% 
  ggplot(aes(x = easiness, y = quality)) +
  geom_point(alpha = 0.6, size = 0.8) +
  geom_smooth(method="lm", se=FALSE) +
  labs(title = "`quality` vs. `easiness`",
       x = "Average easiness rating (1 to 5)",
       y = "Average quality rating (1 to 5)") +
  theme_bw() +
  theme(plot.title = element_text(size = 10, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        axis.text = element_text(size = 8))
bp1 <- Rateprof %>% 
  ggplot(aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() +
  labs(title = "`quality` by `gender`",
       x = "Instructor's gender",
       y = "Average quality rating (1 to 5)") +
  theme_bw() +
  guides(fill = "none") +
  theme(plot.title = element_text(size = 10, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        axis.text = element_text(size = 8))

bp2 <- Rateprof %>% 
  ggplot(aes(x = pepper, y = quality, fill = pepper)) +
  geom_boxplot() +
  labs(title = "`quality` by `pepper`",
       x = "Whether the instructor is attractive",
       y = "Average quality rating (1 to 5)") +
  theme_bw() +
  guides(fill = "none") +
  theme(plot.title = element_text(size = 10, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        axis.text = element_text(size = 8))

bp3 <- Rateprof %>% 
  ggplot(aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() +
  labs(title = "`quality` by `discipline`",
       x = "Instructor's discipline",
       y = "Average quality rating (1 to 5)") +
  theme_bw() +
  guides(fill = "none") +
  theme(plot.title = element_text(size = 10, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        axis.text = element_text(size = 8))

grid.arrange(sp, bp1, bp2, bp3, nrow=2)


## ---- message=FALSE, fig.width=8, fig.height=2.5, fig.cap="Scatterplots of `quality` vs. `easiness` by `gender` and `discipline`"----
scatterplot1 <- Rateprof %>% 
  ggplot(aes(x = easiness, y = quality, color = gender)) +
  geom_point(alpha = 0.5, size = 0.9) +
  geom_smooth(method="lm", se=FALSE) +
  labs(title = "`quality` vs. `easiness` by `gender`",
       x = "Average easiness rating (1 to 5)",
       y = "Average quality rating (1 to 5)") +
  theme_bw() +
  theme(plot.title = element_text(size = 11, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 8),
        axis.text = element_text(size = 9))

scatterplot2 <- Rateprof %>% 
  ggplot(aes(x = easiness, y = quality, color = discipline)) +
  geom_point(alpha = 0.5, size = 0.9) +
  geom_smooth(method="lm", se=FALSE, linewidth=0.8) +
  labs(title = "`quality` vs. `easiness` by `discipline`",
       x = "Average easiness rating (1 to 5)",
       y = "Average quality rating (1 to 5)") +
  theme_bw() +
  theme(plot.title = element_text(size = 11, hjust = 0.5),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 8),
        axis.text = element_text(size = 9))

scatterplot1 | scatterplot2


## -----------------------------------------------------------------------------
lm_full <- lm(quality ~ easiness+ gender + pepper + discipline +
                easiness:gender + easiness:discipline, 
         data = Rateprof)

lm_reduced <- lm(quality ~ easiness + gender + pepper + discipline, 
                 data = Rateprof)


## ---- message=FALSE, fig.width=10, fig.height=2.5, fig.cap="Residual Diagnostics and Influence Diagnostics"----
library(broom)

rp1 <- augment(lm_reduced) %>% 
  ggplot(aes(x = easiness, y = .resid)) + 
  geom_point() +
  labs(title = "Residual vs. `easiness`",
       x = "Easiness rating", 
       y = "Residual")

rp2 <- augment(lm_reduced) %>% 
  ggplot(aes(x = .fitted, y = .resid)) + 
  geom_point() +
  labs(title = "Residual vs. Fitted",
       x = "Fitted value", 
       y = "Residual")

qq <- augment(lm_reduced) %>% 
  ggplot(aes(sample = .resid)) + 
  geom_qq() +
  geom_qq_line() +
  labs(title = "Normal Q-Q Plot",
       x = "Theoretical quantile", 
       y = "Sample quantile")

cd <- augment(lm_reduced) %>% 
  ggplot(aes(x = .fitted, y = .cooksd)) + 
  geom_point() +
  labs(x = "Fitted value", y = "Cook's distance")

grid.arrange(rp1, rp2, qq, cd, nrow=1)


## -----------------------------------------------------------------------------
library(car)
library(knitr)
vif <- vif(lm_reduced)
kable(vif, digits = 4,
      caption = "Variance Inflation Factors")


## -----------------------------------------------------------------------------
options(knitr.kable.NA = '')

partial_F_test <- anova(lm_reduced, lm_full)
kable(partial_F_test, 
      digits = 4,
      caption = "ANOVA Table for the Partial F-test")


## -----------------------------------------------------------------------------
summary <- tidy(lm_reduced)
summary$p.value <- format(summary$p.value, scientific = TRUE)
kable(summary, 
      digits = 4,
      caption = "Summary of the Reduced Model")


## -----------------------------------------------------------------------------
kable(confint(lm_reduced),
      digits = 4,
      caption = "95% Confidence Interval of the Variables")


## -----------------------------------------------------------------------------
# summary(lm_reduced)

