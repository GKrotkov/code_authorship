## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(modelsummary)
Dataset = read.csv('cmu-sleep.csv')


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of TotalSleepTime."-------
hist(Dataset$TotalSleepTime,
     xlab = "Average time students sleep each night (in minutes)", main = "Histogram of TotalSleepTime")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of term_gpa."-------------
hist(Dataset$term_gpa,
     xlab = "GPA in the studied semester (out of 4.0)", 
     main = "Histogram of term_gpa")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of cum_gpa."--------------
hist(Dataset$cum_gpa,
     xlab = "GPA before the studied semester (out of 4.0)", 
     main = "Histogram of cum_gpa")


## ---- fig.width=4, fig.height=3, fig.cap="Scatter plot between TotalSleepTime and term_gpa."----
plot(Dataset$term_gpa ~ Dataset$TotalSleepTime, xlab= "Average time students sleep each night (in minutes)", ylab = "GPA for classes in the studied semester (out of 4.0)", main = "term_gpa VS TotalSleepTime")



## ---- fig.width=4, fig.height=3, fig.cap="Scatter plot between TotalSleepTime and cum_gpa."----
plot(Dataset$cum_gpa ~ Dataset$TotalSleepTime, 
     xlab= "Average time students sleep each night (in minutes)", 
     ylab = "GPA before the studied semester (out of 4.0)", 
     main = "cum_gpa VS TotalSleepTime")



## ---- fig.width=4, fig.height=3, fig.cap="Linear Regression Model between TotalSleepTime and term_gpa."----
plot(Dataset$term_gpa ~ Dataset$TotalSleepTime, xlab= "Average time students sleep each night (in minutes)", ylab = "GPA for classes in the studied semester (out of 4.0)", main = "term_gpa VS TotalSleepTime")

proslm = lm(Dataset$term_gpa ~ Dataset$TotalSleepTime)
abline(proslm,lwd =2,col=2)


## ---- fig.width=4, fig.height=3, fig.cap="Linear Regression Model between TotalSleepTime and cum_gpa."----
plot(Dataset$cum_gpa ~ Dataset$TotalSleepTime, xlab= "Average time students sleep each night (in minutes)", ylab = "GPA for classes in the studied semester (out of 4.0)", main = "term_gpa VS TotalSleepTime")

proslm = lm(Dataset$cum_gpa ~ Dataset$TotalSleepTime)
abline(proslm,lwd =2,col=2)


## ----fig.width=5, fig.height=4, fig.cap="Table of linear regression model between term_gpa and TotalSleepTime."----
model1=lm(term_gpa ~ TotalSleepTime, data = Dataset)
modelsummary(list("Linear regression model between term_gpa and TotalSleepTime" = model1))


## ---- fig.width=5, fig.height=4, fig.cap="Residual plot between TotalSleepTime and term_gpa."----
res1 <- resid(model1)
plot(Dataset$TotalSleepTime, res1,ylab = "Residual", xlab = "Average time students sleep each night (in minutes)" )
abline(0,0,col=2)


## ----fig.width=5, fig.height=4, fig.cap="Table of linear regression model between cum_gpa and TotalSleepTime."----
model2=lm(cum_gpa ~ TotalSleepTime, data = Dataset)
modelsummary(list("Linear regression model between cum_gpa and TotalSleepTime" = model2))


## ---- fig.width=5, fig.height=4, fig.cap="Residual plot between TotalSleepTime and cum_gpa."----

res2 <- resid(model2)
plot(Dataset$TotalSleepTime, res2,ylab = "Residual", xlab = "Average time students sleep each night (in minutes)")
abline(0,0,col=2)


## ----fig.width=5, fig.height=4, fig.cap="Table of linear regression model between term_gpa and other covariants."----

model3 = lm(term_gpa~demo_race+demo_gender+demo_firstgen+bedtime_mssd+
              midpoint_sleep+frac_nights_with_data+daytime_sleep,data=Dataset)
p_values <- summary(model3)$coefficients[, "Pr(>|t|)"]

p_value_table <- data.frame(P_Value = p_values)

knitr::kable(p_value_table)

