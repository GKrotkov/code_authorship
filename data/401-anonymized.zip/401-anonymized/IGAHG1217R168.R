## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
data = Rateprof
head(data)


## -----------------------------------------------------------------------------
mean(data$quality)
median(data$quality)
hist(data$quality, main = "Distribtuion of Quality Ratings", xlab = "Ratings", breaks = 50)


## -----------------------------------------------------------------------------
par(mfrow = c(2, 2))

barplot(table(data$gender), main = "Distribution of Gender", xlab = "Gender of Prof.", col = "lightblue")
barplot(table(data$discipline), main = "Distribution of Discipline", xlab = "Discipline", col = "red")
barplot(table(data$pepper), main = "Distribution of Attractiveness", xlab = "Attractiveness", col = "green")


## -----------------------------------------------------------------------------
hist(data$easiness, main = "Distribution of the Easiness of the Professors", xlab = "Easiness of Professors", breaks = 20)



## -----------------------------------------------------------------------------
par(mfrow = c(2, 2))

plot(data$quality, data$easiness, main = "Quality vs Easiness of Prof.", xlab = "Easiness", ylab = "Quality")
boxplot(data$quality ~ data$gender, main = "Quality vs Gender of Prof.", xlab = "Gender", ylab = "Quality")
boxplot(data$quality ~ data$pepper, main = "Quality vs Attractiveness of Prof.", xlab = "Attractiveness", ylab = "Quality")
boxplot(data$quality ~ data$discipline, main = "Quality vs Discipline of Prof.", xlab = "Discipline", ylab = "Quality")


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))

boxplot(data$easiness ~ data$gender, main = "Easiness vs Gender of Prof.", xlab = "Gender", ylab = "Easiness")
boxplot(data$easiness ~ data$discipline, main = "Easiness vs Discipline of Prof.", xlab = "Discipline", ylab = "Easiness")


## -----------------------------------------------------------------------------
model1 = lm(data$quality ~ factor(data$gender) + data$easiness + factor(data$pepper) + factor(data$discipline))
model2 = lm(data$quality ~ factor(data$gender) + data$easiness + factor(data$pepper) + factor(data$discipline) + data$discipline * data$easiness + data$gender * data$easiness)

model3 = anova(model1, model2)


## -----------------------------------------------------------------------------
par(mfrow = c(2, 2))

plot(model1$residuals, model1$fitted.values,
     xlab = "Fitted Values",
     ylab = "Residuals",
     main = "Residuals vs Fitted Values")

qqnorm(model1$residuals)
qqline(model1$residuals)

cooksd = cooks.distance(model1)
plot(cooksd, pch = 20, main = "Cook's Distance Plot", xlab = "Observation", ylab = "Cook's Distance")



## -----------------------------------------------------------------------------
summary(model1)
model3

