## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(ggplot2)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
ratings <- Rateprof
# names(ratings)


## ---- fig.width=5, fig.height=2, fig.cap="Histogram of Professors' quality rating, displaying a unimodal approximately normal distribution with left skew"----
ggplot(data = ratings, aes(x = quality)) + 
  geom_histogram(fill = "blue", color = "black", binwidth = 0.2) + 
  labs(title = "Histogram of Professors' Quality Rating", x = "Average Quality Rating", y = "Number of Professors") + 
   theme_classic()


## ---- fig.width=5, fig.height=2, fig.cap="Distribution of Professors' Gender, displaying a larger number of male professors"----
ggplot(data = ratings, aes(x = gender)) + 
  geom_bar(fill = "blue", color = "black") + 
  labs(title = "Dstribution of Professors' Gender", x = "Gender", y = "Number of Professors") + 
  theme_classic()


## ---- fig.width=5, fig.height=2, fig.cap="Distribution of Attractiveness of Professors, displaying that most professors are rated as unattractive"----
ggplot(data = ratings, aes(x = pepper)) + 
  geom_bar(fill = "blue", color = "black") + 
  labs(title = "Distribution of Professors' Attractiveness", x = "Attractive (yes/no)", y = "Number of Professors") + 
  theme_classic()


## ---- fig.width=5, fig.height=2, fig.cap="Histogram of Professors' Easiness, displaying a unimodal approximately normal distribution"----
ggplot(data = ratings, aes(x = easiness)) + 
  geom_histogram(fill = "blue", color = "black", binwidth = 0.5) + 
  labs(title = "Histogram of Professors' Quality Rating", x = "Average Quality Rating", y = "Number of Professors") + 
  theme_classic()


## ---- fig.width=5, fig.height=2, fig.cap="Distribution of Discipline of Professors, displaying more professors in the humanities, followed by STEM, then SocSci and Pre-prof"----
ggplot(data = ratings, aes(x = discipline)) + 
  geom_bar(fill = "blue", color = "black") + 
  labs(title = "Distribution of Discipline of Professors", x = "Discipline", y = "Number of Professors") + 
  theme_classic()


## -----------------------------------------------------------------------------
library(GGally)
ratings_sub <- ratings[, c("quality", "gender", "pepper", "easiness", "discipline")]


## ---- warning=FALSE,message=FALSE,error=FALSE, fig.width=7, fig.height=5, fig.cap="Pairs plot of variables of interest, showing the relationships between each pair possible within the 5 selected variables"----
ggpairs(ratings_sub) + 
  labs(title = "Pairs plot of quality, gender, pepper, easiness, and discipline")


## ---- fig.width=6, fig.height=3, fig.cap="Distribution of Quality vs Easiness by discipline and gender, showing that there does not appear to be a significant difference in the relationship between easiness and quality based on either gender or discipline"----
ggplot(data = ratings, aes(x = easiness, y = quality)) + 
  geom_point(aes(color = discipline, shape = gender)) + 
  labs(title = "Quality vs Easiness by Discipline and Gender", x = "Easiness", y = "Quality Rating") + 
  theme_classic()


## -----------------------------------------------------------------------------
lm_final = lm(data = ratings, quality ~ gender + pepper + easiness)
resid <- residuals(lm_final)


## ---- fig.width=5, fig.height=2.2, fig.cap="Residuals plot of final model (quality ~ gender + pepper + easiness) seems to satisfy the linearity and covariance = 0 assumptions but not the homoskedasticity assumption"----
ggplot(data = data.frame(Fitted = fitted(lm_final), Residuals = resid), aes(x = Fitted, y = Residuals)) +
  geom_point() +
  labs(x = "Fitted Values", y = "Residuals", title = "Residuals vs. Fitted Values on Final Model") +
  geom_hline(yintercept = 0, color = "red") +
  theme_classic()


## ---- fig.width=5, fig.height=2.2, fig.cap="qq plot of final model (quality ~ gender + pepper + easiness) seems satisfy the normality assumption, with points mostly consistent with the qq line"----
qq_data <- data.frame(Theoretical = qnorm(ppoints(resid)), Residuals = resid)
ggplot(qq_data, aes(sample = resid)) +
  stat_qq(distribution = qnorm, dparams = list(mean = 0, sd = sd(resid))) +
  geom_abline(intercept = 0, slope = 1, color = "red") +
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles", title = "Normal Q-Q Plot of Final Model") +
  theme_classic()


## -----------------------------------------------------------------------------
library(broom)
lm_base = lm(data = ratings, quality ~ gender + pepper + easiness + discipline)

#code syntax from hw 5 solutions
tidy(lm_base) |>
knitr::kable(digits = 3, booktabs = TRUE,
col.names = c("Term", "Estimate", "SE", "t", "p"))


## -----------------------------------------------------------------------------
lm_gender_interaction <- lm(data = ratings, quality ~ gender + pepper + easiness + easiness:gender)

knitr::kable(anova(lm_final, lm_gender_interaction))


## -----------------------------------------------------------------------------
#Determining if the interaction term between discipline and easiness is statistically significant
lm_discipline_interaction <- lm(data = ratings, quality ~ gender + pepper + easiness + easiness:discipline)

knitr::kable(anova(lm_final, lm_discipline_interaction))


## -----------------------------------------------------------------------------
lm_final = lm(data = ratings, quality ~ gender + pepper + easiness)
tidy(lm_final) |>
knitr::kable(digits = 3, booktabs = TRUE,
col.names = c("Term", "Estimate", "SE", "t", "p"))

