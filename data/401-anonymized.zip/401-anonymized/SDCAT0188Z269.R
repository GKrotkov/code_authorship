## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(ggplot2)
data = read.csv("/Users/eric_p/Desktop/Fall 2023/36-401/data exam1/cmu-sleep.csv")


## ---- echo = FALSE------------------------------------------------------------
ggplot(data, aes(x = TotalSleepTime)) +
       geom_histogram(fill = "green", color = "black") +
       xlab("TotalSleepTime(minutes)") +
       ylab("Frequency") +
       ggtitle("Histogram of TotalSleepTime")


## ---- echo = FALSE------------------------------------------------------------
ggplot(data, aes(x = term_gpa)) +
       geom_histogram(fill = "green", color = "black") +
       xlab("The student's GPA over the past semester (out of 4.0)") +
       ylab("Frequency") +
       ggtitle("Histogram of GPA over the past semester")


## ---- echo = FALSE------------------------------------------------------------
ggplot(data, aes(x = cum_gpa)) +
       geom_histogram(fill = "green", color = "black") +
       xlab("The student's cumulative GPA (out of 4.0)") +
       ylab("Frequency") +
       ggtitle("Histogram of the student's cumulative GPA")


## ---- echo = FALSE------------------------------------------------------------
ggplot(data, aes(x = TotalSleepTime, y = exp(term_gpa))) +
       geom_point(color = "black") +
       geom_smooth(method = lm, color = "red", se = FALSE) +
       xlab("Average sleep time each night (minutes)") +
       ylab("The exponential of the student's GPA over the past semester (out of 4.0)") +
       ggtitle("Relationship between TotalSleepTime vs. exp(term_gpa)")


## ---- echo = FALSE------------------------------------------------------------
transformed_term_gpa = exp(data$term_gpa)
linear_model = lm(transformed_term_gpa ~ TotalSleepTime, data = data)
summary(linear_model)


## ---- echo = FALSE------------------------------------------------------------
residual = residuals(linear_model)
ggplot(data = data, aes(x = TotalSleepTime, y = residual)) +
       geom_point() +
       geom_abline(slope = 0, col = "red", lty = 2) +
       xlab("TotalSleepingTime") +
       ylab("Residuals") +
       ggtitle("Residual Plot for our model")


## ---- echo = FALSE------------------------------------------------------------
ggplot(data = data, aes(sample = residual)) +
  geom_qq() +
  geom_qq_line(color = "red", linetype = "dashed") +
  labs(x = "Theoretical quantiles", y = "Observed quantiles")

