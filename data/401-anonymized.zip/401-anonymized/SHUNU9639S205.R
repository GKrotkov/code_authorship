## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE, fig.pos = "H", fig.align="center", out.extra = "")


## -----------------------------------------------------------------------------
data = read.csv("cmu-sleep.csv")


## ---- include = FALSE---------------------------------------------------------
nrow(data)
ncol(data)
dim(data)


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Average Sleep Time Per Night"----
hist(data$TotalSleepTime,
     main = "",
     xlab='Average Sleep Time (in Minutes)')


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Previous Semester GPA before Being Studied"----
hist(data$cum_gpa,
     main = "",
     xlab="Previous Semester GPA (out of 4.0)")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Current Semester GPA When Being Studied"----
hist(data$term_gpa,
     main = "",
     xlab="Current Semester GPA (out of 4.0)")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Current-semester GPA Associated with Each Average Sleep Time"----
plot(data$TotalSleepTime, data$term_gpa,
     main = "",
     cex.lab = 0.9,
     xlab="Average Sleep Time (in Minutes)",
     ylab="Current Semester GPA (out of 4.0)")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Current-semester GPA Associated with Each Previous-semester GPA"----
plot(data$cum_gpa, data$term_gpa,
     main = "",
     cex.lab = 0.9,
     xlab="Previous Semester GPA (out of 4.0)",
     ylab="Current Semester GPA (out of 4.0)")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Distribuion of Current Semester GPA after Exponential Transformation"----
hist(exp(data$term_gpa),
     main = "",
     cex.lab = 0.9,
     xlab="The Exponential of Current GPA (out of 54.5)")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Distribuion of Previous Semester GPA after Exponential Transformation"----
hist(exp(data$cum_gpa),
     main = "",
     cex.lab = 0.9,
     xlab="The Exponential of Previous GPA (out of 54.5)")


## ---- message=FALSE-----------------------------------------------------------
#let's make a new dataframe 
library(dplyr)
dt = as.data.frame(select(data, term_gpa, TotalSleepTime, cum_gpa))
dt$term_gpa = exp(dt$term_gpa)
dt$cum_gpa = exp(dt$cum_gpa)
colnames(dt)[1] = "term.gpa.exp"
colnames(dt)[3] = "cum.gpa.exp"
#fit regression model:
model = lm(data=dt, term.gpa.exp ~ TotalSleepTime + cum.gpa.exp)


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Cook's Distance for Average Sleep Time (in Minutes)"----
library(broom)
library(ggplot2)
#head(augment(model))
augment(model) |>
  ggplot(aes(x = TotalSleepTime, y = .cooksd), cex.lab = 0.9,) +
  geom_point() +
  labs(x = "Average Sleep Time (in Minutes)", y = "Cook's Distance")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Cook's Distance for Exponential Previous Semester GPA"----
augment(model) |>
  ggplot(aes(x = cum.gpa.exp, y = .cooksd)) +
  geom_point() +
  labs(x = "Exponential of Previous Semester GPA (out of 54.6)", y = "Cook's Distance") + 
  theme(axis.title.x = element_text(size = 9.3))


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Residuals from the Model, Plotted Against the Fitted Values "----
ggplot(augment(model), 
       aes(x = .fitted, y = .resid), cex.lab = 0.9,) +
  geom_point() +
  labs(x = "Fitted Values", y = "Residuals")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Normal Probability Plot for the Residuals in the Model"----
ggplot(augment(model), 
       aes(sample = .resid), cex.lab = 0.9,) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles")


## ---- include=FALSE-----------------------------------------------------------
summary(model)
sum(residuals(model)^2) / model$df.residual


## -----------------------------------------------------------------------------
#show the summary in the table
df <- data.frame("Estimates" = rep(c(-0.747750, 0.026601, 0.718535)),
                 "Standard Error" = rep(c(3.012853, 0.007341, 0.030541)),
                 "t-value" = rep(c(-0.248, 3.624, 23.527)),
                 "p-value" = rep(c(0.804071, 0.000314, "< 2e-16")),
                 row.names = rep(c("Intercept", "Average Sleep Time", "Exponential Current Semester GPA")))
library("knitr")
kable(df, caption = "Model Summary")
df2 <- data.frame("Residual Standard Error" = "9.335 on 631 degrees of freedom")
kable(df2)


## ---- include=FALSE-----------------------------------------------------------
coef(model)[2]
confint(model, 'TotalSleepTime', level=0.95)
#calculate (in context) 
library("SciViews")
exp_GPA = (2*60) * 0.026601 
GPA = ln(exp_GPA)
GPA

