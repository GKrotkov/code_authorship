## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(tidyverse)
library(gridExtra)
library(knitr)
library(alr4)
library(broom)

# Helper functions for plotting nice tables: 
# Display Numerical Variable Info
numericSummaryTable = function(variables, data) {
  summary_stats = data.frame(
    #Variable = variables,
    Mean = sapply(variables, function(var) mean(data[[var]])),
    Median = sapply(variables, function(var) median(data[[var]])),
    Min = sapply(variables, function(var) min(data[[var]])),
    Max = sapply(variables, function(var) max(data[[var]])),
    Q1 = sapply(variables, function(var) quantile(data[[var]], 0.25)),
    Q3 = sapply(variables, function(var) quantile(data[[var]], 0.75))
  )
  return(summary_stats)
}

# Display Factor Variable Info 
factorSummaryTable = function(factors, data) {
  summary_stats = data.frame(
    Factor = factors,
    Levels = sapply(factors, function(factor_var)
      paste(levels(data[[factor_var]]), collapse = ", "))
  )
  
  return(summary_stats)
}


# Display Model Summary Helper
modelSummaryTable = function(model) {
  summary_model = summary(model)
  coefficients = summary_model$coefficients
  colnames(coefficients) = c("Estimate", "Std. Error", "t-value", "P-Value")
  
  table = data.frame(
    coefficients
  )
  
  return(table)
}


## -----------------------------------------------------------------------------
# Convert factors into numerics
factorVariables <- c("gender", "pepper", "discipline")

Rateprof <- Rateprof %>%
  mutate(across(all_of(factorVariables), as.numeric, .names = "{col}Num"))

numericVariables = c("quality", "easiness", "genderNum", "pepperNum", "disciplineNum")
factorVariables = c("gender", "pepper", "discipline")

numericTable = numericSummaryTable(numericVariables, Rateprof)
factorTable = factorSummaryTable(factorVariables, Rateprof)

kable(numericTable, digits = 2, format = "markdown")
kable(factorTable, digits = 2, format = "markdown")




## ---- fig.width=8,fig.height=4------------------------------------------------
# Numerical Variables
# Histogram for quality
hist_quality = Rateprof %>% 
  ggplot(aes(x = quality)) +
  geom_histogram(binwidth = 0.25, fill = "lavender", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Quality", x = "Quality", y = "Frequency")

# Histogram for easiness
hist_easiness <- Rateprof %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(binwidth = 0.25, fill = "slategray2", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Easiness", x = "Easiness", y = "Frequency")

box_quality = Rateprof %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(fill = "lavender", color = "gray2") +
  labs(title = "Quality Boxplot",
       y = "Quality Rating (1-5)")

box_easiness = Rateprof %>% 
  ggplot(aes(y = easiness)) +
  geom_boxplot(fill = "slategray2", color = "gray2") +
  labs(title = "Easiness Boxplot",
       y = "Difficulty Rating (1-5)")
# Arrange the plots in a grid
grid.arrange(hist_quality, hist_easiness, box_quality, box_easiness, ncol = 2)



## ---- fig.width=8,fig.height=3------------------------------------------------
# Boxplot for gender
boxplot_gender <- ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot(fill = "lightgreen", color = "black") +
  labs(title = "Boxplot of Quality \n by Gender", x = "Gender (M/F)", y = "Quality")

# Boxplot for pepper
boxplot_pepper <- ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot(fill = "slategray", color = "black") +
  labs(title = "Boxplot of Quality \n by Attractiveness", x = "Attractive (Y/N)", y = "Quality")

# Boxplot for discipline
boxplot_discipline <- ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "salmon", color = "black") +
  labs(title = "Boxplot of Quality \n by Discipline", x = "Discipline", y = "Quality")

grid.arrange(boxplot_gender, boxplot_pepper, boxplot_discipline, ncol = 3)


## ---- fig.width=6,fig.height=4------------------------------------------------

# Create our base plot looking at quality and easiness
easinessPlot = Rateprof %>% ggplot(aes(x = quality, y = easiness )) +
  geom_point(col = "slategray2", size = 1.5) +
  labs(x = "Quality (1-5)", y = "Easiness (1-5)") +
  ggtitle("Scatterplot of Quality \n vs. Easiness in class")
easinessPlot



## ---- fig.width=8,fig.height=4------------------------------------------------

# Faceted on gender
genderPlot <- Rateprof %>% 
  ggplot(aes(x = quality, y = easiness)) +
  geom_point(col = "lightgreen", size = 1.2) +
  labs(x = "Quality (1-5)", y = "Easiness (1-5)") +
  ggtitle("Scatterplot of Quality \n vs. Easiness Faceted \n on Gender") +
  facet_wrap(~gender, scales = "free")

# Faceted on pepper
pepperPlot <- Rateprof %>% 
  ggplot(aes(x = quality, y = easiness)) +
  geom_point(col = "slategray", size = 1.2) +
  labs(x = "Quality (1-5)", y = "Easiness (1-5)") +
  ggtitle("Scatterplot of Quality \n vs. Easiness Faceted \n on Attractiveness") +
  facet_wrap(~pepper, scales = "free")

# Faceted on discipline
discPlot <- Rateprof %>% 
  ggplot(aes(x = quality, y = easiness)) +
  geom_point(col = "salmon", size = 0.9) +
  labs(x = "Quality (1-5)", y = "Easiness (1-5)") +
  ggtitle("Scatterplot of Quality \n vs. Easiness Faceted \n on Discipline") +
  facet_wrap(~discipline, scales = "free")

grid.arrange(genderPlot, pepperPlot, discPlot, ncol = 3)



## -----------------------------------------------------------------------------
# Models

fullModel = lm(quality ~ easiness + gender + pepper + discipline, data = Rateprof)
easyModel = lm(quality ~ easiness, data = Rateprof)
q2Model = lm(quality ~ easiness + gender + discipline + easiness:gender + easiness:discipline, data = Rateprof)

fullTable = modelSummaryTable(fullModel)
easyTable = modelSummaryTable(easyModel)
q2Table = modelSummaryTable(q2Model)

# Table
cat("Summary Statistics for Simple Model\n")
kable(easyTable, digits = 4, format = "markdown")

cat("Summary Statistics for Full Model without Pepper \n")
kable(q2Table, digits = 4, format = "markdown")

cat("Summary Statistics for Full Model\n")
kable(fullTable, digits = 4, format = "markdown")


## ---- results='hide'----------------------------------------------------------
final_model = step(fullModel, criteria = AIC, direction = "both")
reducedTable = modelSummaryTable(final_model)


## -----------------------------------------------------------------------------
cat("Summary Statistics for Filtered Model, trimmed using AIC values \n")
kable(reducedTable, digits = 4, format = "markdown")


## -----------------------------------------------------------------------------
anovaTestFull <- aov(fullModel, data = Rateprof)
tidy_anova <- tidy(anovaTestFull)

cat("Summary of Anova Test output \n")
kable(tidy_anova, format = "markdown", digits=4)



## -----------------------------------------------------------------------------
anovaQ2 <- aov(q2Model, data = Rateprof)
tidy_anovaQ2 <- tidy(anovaQ2)

cat("Summary of Anova Test output \n")
kable(tidy_anovaQ2, format = "markdown", digits=4)


## -----------------------------------------------------------------------------
# t-test for each coefficient in the full model
t_test_full <- summary(fullModel)$coefficients[, c("Estimate", "Std. Error", "t value", "Pr(>|t|)")]


# t-test for each coefficient in the final model
t_test_final <- summary(final_model)$coefficients[, c("Estimate", "Std. Error", "t value", "Pr(>|t|)")]


# Table
cat("T-Test Results for our Full Model \n")
kable(t_test_full, digits = 4, format = "markdown")

# Table
cat("T-Test Results for our Trimmed Model \n")
kable(t_test_final, digits = 4, format = "markdown")


