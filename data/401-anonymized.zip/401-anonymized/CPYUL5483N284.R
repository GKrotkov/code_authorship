## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(alr4)
library(modelsummary)
library(xtable)
data(Rateprof)


## ---- fig.width=7.5, fig.height=3, fig.cap="Instructors' average quality rating has a slight left skew. Instructors' average easiness rating is distributed close to normally."----
par(mfrow = c(1,2))
hist(Rateprof$quality,
     main = "Average Quality Rating",
     xlab = "On a scale of 1 (worst) to 5 (best)")
hist(Rateprof$easiness,
     main = "Average Easiness Rating",
     xlab = "On a scale of 1 (hardest) to 5 (easiest)")


## ---- results = 'hide'--------------------------------------------------------
mean(Rateprof$quality)
sd(Rateprof$quality)


## ---- fig.width=11.25, fig.height=3, fig.cap="Instructors' genders are close to evenly spread with more male instructors than female instructors. Only 46 of the 366 instructors in the dataset are considered attractive. A majority of the instructors' disciplines are humanities and STEM."----
par(mfrow = c(1,3))
barplot(table(Rateprof$gender),
        main = "Gender")
barplot(table(Rateprof$pepper),
        main = "Attractiveness")
barplot(table(Rateprof$discipline),
        main = "Discipline",
        names = c("Hum", "SocS", "STEM", "Prof"))


## ---- results = 'hide'--------------------------------------------------------
table(Rateprof$gender)


## ---- fig.width=5, fig.height=4, fig.cap="Instructors' average easiness rating appears to be correlated with the average quality rating and uncorrelated with the other predictors."----
pairs(~ quality + easiness + gender + pepper + discipline, data = Rateprof)


## ---- fig.width=8, fig.height=4, fig.cap="Instructors' average quality rating appears to have a relationship with attractiveness but not with the other categorical predictors (gender, discipline)."----
par(mfrow = c(1,3))
boxplot(quality ~ gender, data = Rateprof, 
        xlab = "Gender", ylab = "Average Quality Rating")
boxplot(quality ~ pepper, data = Rateprof, 
        xlab = "Attractiveness", ylab = "Average Quality Rating")
boxplot(quality ~ discipline, data = Rateprof, 
        xlab = "Discipline", ylab = "Average Quality Rating")


## ---- results = 'hide'--------------------------------------------------------
lm_reduced = lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
lm_smallest = lm(quality ~ gender + pepper + easiness, data = Rateprof)
lm_full = lm(quality ~ gender + pepper + easiness + discipline + gender:easiness +
               discipline:easiness,
          data = Rateprof)
summary(lm_reduced)
summary(lm_full)
anova(lm_reduced, lm_full)


## ---- fig.width=11.25, fig.height=3, fig.cap="The linearity assumption is satisfied for all of our models."----
par(mfrow = c(1,3))
plot(resid(lm_smallest) ~ Rateprof$easiness,
     main = "Average Easiness Rating vs. Smallest Model Residuals",
     xlab = "Average Easiness Rating",
     ylab = "Smallest Model Residuals")
plot(resid(lm_reduced) ~ Rateprof$easiness,
     main = "Average Easiness Rating vs. Reduced Model Residuals",
     xlab = "Average Easiness Rating",
     ylab = "Reduced Model Residuals")
plot(resid(lm_full) ~ Rateprof$easiness,
     main = "Average Easiness Rating vs. Full Model Residuals",
     xlab = "Average Easiness Rating",
     ylab = "Full Model Residuals")


## ---- fig.width=12.5, fig.height=4, fig.cap="All necessary assumptions for the reduced model are met except homoskedasticity."----
par(mfrow=c(1,3))
plot(lm_reduced, which=1)
plot(lm_reduced, which=2)
plot(lm_reduced, which=5)


## ---- results = 'hide'--------------------------------------------------------
xtable(vif(lm_reduced))


## ---- fig.width=12.5, fig.height=4, fig.cap="All necessary assumptions for the full model are met except homoskedasticity."----
par(mfrow=c(1,3))
plot(lm_full, which=1)
plot(lm_full, which=2)
plot(lm_full, which=5)


## ---- results="hide"----------------------------------------------------------
summary(lm_reduced)


## ---- results="hide"----------------------------------------------------------
anova(lm_smallest, lm_reduced)


## ---- results="hide"----------------------------------------------------------
anova(lm_reduced, lm_full)

