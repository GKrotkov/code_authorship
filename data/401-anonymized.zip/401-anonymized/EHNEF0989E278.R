## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, warning=FALSE, include=FALSE-----------------------------
library(alr4)
library(ggplot2)


## ----key-vars-summary---------------------------------------------------------
# Selecting the key variables for the summary table
key_vars <- Rateprof[, c("gender", "pepper", "quality", "easiness", "discipline")]
summary_key_vars <- summary(key_vars)
knitr::kable(summary_key_vars, caption = "Summary of Key Variables in Instructor Evaluations")


## ---- fig.height=3, fig.width=8, fig.cap="Bar plot of gender"-----------------
barplot(table(Rateprof$gender), xlab = "Gender", ylab = "Frequency")


## ---- fig.height=3, fig.width=8, fig.cap="Bar plot of discipline"-------------
barplot(table(Rateprof$discipline), xlab = "Discipline", ylab = "Frequency")


## ---- fig.height=3, fig.width=8, fig.cap="Bar plot of Percieved Attractiveness"----
barplot(table(Rateprof$pepper), xlab = "Attractiveness (Pepper)", ylab = "Frequency")


## ---- fig.height=3, fig.width=8, fig.cap="Histogram of quality"---------------
hist(Rateprof$quality, main="Histogram of Quality Ratings" ,xlab = "Quality Rating", breaks = 10)


## ---- fig.height=3, fig.width=8, fig.cap="Histogram of easiness"--------------
hist(Rateprof$easiness, main = "Histogram of Easiness Ratings", xlab = "Easiness Rating", breaks = 10)


## ---- fig.height=3, fig.width=8, fig.cap="Scatterplot of Quality Rating vs. Attractiveness"----
plot(Rateprof$quality ~ Rateprof$pepper,
     xlab = "Attractiveness (Pepper)",
     ylab = "Quality Rating",
     main = "Quality Rating vs. Attractiveness"
     )


## ---- fig.height=3, fig.width=8, fig.cap="Scatterplot of Quality Rating vs. Gender"----
plot(Rateprof$quality ~ Rateprof$gender,
     xlab = "Gender",
     ylab = "Quality Rating",
     main="Quality Rating vs. Gender"
     )


## ---- fig.height=3, fig.width=8, fig.cap="Scatterplot of Quality Rating vs. Easiness"----
plot(Rateprof$quality ~ Rateprof$easiness,
     xlab = "Easiness Rating",
     ylab = "Quality Rating",
     main="Quality Rating vs. Easiness")


## ---- fig.height=3, fig.width=8,fig.cap="Scatterplot of Quality Rating vs. Discipline"----
plot(Rateprof$quality ~ Rateprof$discipline,
     xlab = "Discipline",
     ylab = "Quality Rating",
     main="Quality Rating vs. Discipline")


## ----model-fit----------------------------------------------------------------
fit <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)


## ----model-fit-formula--------------------------------------------------------
fit_formula <- formula(fit)
print(fit_formula)


## -----------------------------------------------------------------------------
model_summary <- summary(fit)
model_table <- model_summary$coefficients
knitr::kable(model_table, caption = "Summary of Linear Regression Model", digits = 4, 
             col.names = c("Estimate", "Std. Error", "t value", "Pr(>|t|)"))


## ----anova--------------------------------------------------------------------
anova_result <- anova(fit)
knitr::kable(anova_result, caption = "ANOVA for the Linear Regression Model")


## ----vif-check----------------------------------------------------------------
library(car)
vif_values <- vif(fit)
knitr::kable(as.data.frame(vif_values), caption = "Variance Inflation Factors for Each Predictor")


## ----interaction-model--------------------------------------------------------
fit_interaction <- lm(quality ~ gender * discipline + pepper + easiness, data = Rateprof)

fit_interaction_formula <- formula(fit_interaction)
print(fit_interaction_formula)


## ----interaction-model-summary------------------------------------------------
fit_interaction_summary <- summary(fit_interaction)
fit_interaction_table <- fit_interaction_summary$coefficients
knitr::kable(fit_interaction_table, caption = "Summary of Linear Regression Model with Interaction Effects", digits = 4, 
             col.names = c("Estimate", "Std. Error", "t value", "Pr(>|t|)"))


## ----effect-size--------------------------------------------------------------
coefficients_summary <- summary(fit_interaction)$coefficients
statistically_significant <- coefficients_summary[coefficients_summary[, "Pr(>|t|)"] < 0.05, ]
knitr::kable(statistically_significant, caption = "Effect Sizes for Statistically Significant Predictors")


## -----------------------------------------------------------------------------
conf_intervals <- confint(fit, level = 0.95)
rows_of_interest <- which(rownames(conf_intervals) %in% c("pepperyes", "easiness"))

specific_conf_intervals <- conf_intervals[rows_of_interest, ]

knitr::kable(specific_conf_intervals, caption = "95% Confidence Intervals for 'Pepper' and 'Easiness' Coefficients", digits = 4,
             col.names = c("2.5 %", "97.5 %"))


## ----model-diagnostics--------------------------------------------------------
par(mfrow = c(2, 2))
plot(fit_interaction)

