## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)


## ---- echo = FALSE------------------------------------------------------------
cmu_sleep.df = read.csv("C:/Users/riyup/OneDrive/Documents/cmu-sleep.csv")
library(ggplot2, warn.conflicts = FALSE)
library(psych, warn.conflicts = FALSE)


## ---- out.width="49%",out.height="49%",fig.show='hold',fig.align='center', fig.cap="Distribution of the average quality ratings of professors and easiness ratings of courses they teach."----


hist(Rateprof$quality,
     xlab = "Quality Rating (1 = worst to 5 = best)", ylab = "Frequency", main = "Distribution of Quality Rating")

hist(Rateprof$easiness,
     xlab = "Easiness Rating (1 = worst to 5 = best)", ylab = "Frequency", main = "Distribution of Easiness Rating")
library(psych, warn.conflicts = FALSE)



## ---- fig.width = 7, fig.height = 4, fig.cap="Count of attractive professors, female and male professors, and discipline of professors (Hum = humanities, SocSci = social science, STEM = science, tech, engineering, or math, and Pre-Prof = professional training)."----

par(mfrow = c(2,2))

barplot(table(Rateprof$pepper), xlab = "Attractive (yes or no)", ylab = "Frequency", main = "Attractiveness of Professors")
barplot(table(Rateprof$gender), xlab = "Gender (male or female)", ylab = "Frequency", main = "Gender of Professors")
barplot(table(Rateprof$discipline), xlab = "Discipline", ylab = "Frequency", names.arg = c("Hum", "SocSci", "STEM", "Pre-Prof"), main = "Discipline Professors Teach In")




## ---- fig.width = 7, fig.height = 5, fig.cap="Scatterplot depicting relationship between average quality ratings of professors and average easiness ratings of courses, along with side-to-side boxplots of average quality ratings based on gender, attractiveness, and discipline of professors."----

par(mfrow = c(2,2))

plot(Rateprof$easiness, Rateprof$quality, main = "Quality Rating vs Easiness Rating", ylab = "Quality Rating (1 to 5)", xlab = "Easiness Rating (1 to 5)")
boxplot(quality ~ gender, data = Rateprof, main = "Quality Rating Based on Gender", ylab = "Quality Rating (1 to 5)", xlab = "Gender")
boxplot(quality ~ pepper, data = Rateprof, main = "Quality Rating Based on Attraction", ylab = "Quality Rating (1 to 5)", xlab = "Attractiveness")
boxplot(quality ~ discipline, data = Rateprof, main = "Quality Rating Based on Discipline", ylab = "Quality Rating (1 to 5)", xlab = "Discipline")



## ---- echo=FALSE,out.width="49%",out.height="49%",fig.show='hold',fig.align='center', fig.cap="Left: Residuals plotted against fitted values, Right: Normal Q-Q Plot to assess normality of residuals"----

library(ggplot2)
library(broom)
library(knitr)

quality.full = lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)


ggplot(augment(quality.full), aes(x = .fitted, y = .resid)) +
geom_point() + geom_hline(yintercept = 0) +
labs(title = "Residuals vs Fitted Values", x = "Fitted value", y = "Residuals")


qqnorm(residuals(quality.full), ylab="Residuals")
qqline(residuals(quality.full))



## ---- echo=FALSE--------------------------------------------------------------

library(ggplot2)
library(broom)
library(knitr)

quality.int = lm(quality ~ discipline + easiness + easiness:discipline, data = Rateprof)
quality.noint = lm(quality ~ discipline + easiness, data = Rateprof)

quality.int1 = lm(quality ~ gender + easiness + easiness:gender, data = Rateprof)
quality.noint1 = lm(quality ~ gender + easiness, data = Rateprof)



## ---- echo = FALSE------------------------------------------------------------

quality.lm = lm(quality ~ gender + easiness + pepper, data = Rateprof)



## ---- echo=FALSE--------------------------------------------------------------

library(broom)
library(knitr)
out <- tidy(quality.full)
kable(out, digit = 4, col.names = c("Term","Estimate", "SE", "t", "p"))



## -----------------------------------------------------------------------------

test3 = anova(quality.lm, quality.full)
output3 <- tidy(test3)
kable(output3, digits = 3, col.names = c("Term", "Res.Df", "RSS", "Df", "Sum of Sq", "F", "p"))



## -----------------------------------------------------------------------------

x1 <- extractAIC(quality.lm)
x2 <- extractAIC(quality.full)

AIC.df <- data.frame(x1, x2)

library(data.table)
AIC.t <- transpose(AIC.df)

colnames(AIC.t) <- c("Total Variables in Model", "AIC")

kable(AIC.t, digit = 4)



## -----------------------------------------------------------------------------


out1 <- tidy(quality.lm)
kable(out1, digit = 4, col.names = c("Term","Estimate", "SE", "t", "p"))



## ---- echo=FALSE--------------------------------------------------------------

test1 = anova(quality.noint, quality.int)
output1 <- tidy(test1)
kable(output1, digits = 3, col.names = c("Term", "Res.Df", "RSS", "Df", "Sum of Sq", "F", "p"))

test2 = anova(quality.noint1, quality.int1)
output2 <- tidy(test2)
kable(output2, digits = 3, col.names = c("Term", "Res.Df", "RSS", "Df", "Sum of Sq", "F", "p"))

