## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(tidyverse)


## ---- include = FALSE---------------------------------------------------------
data <- Rateprof


## ---- include = FALSE---------------------------------------------------------
nrow(data)
ncol(data)


## ---- include = FALSE---------------------------------------------------------
summary(data[, c("quality", "gender", "pepper", "easiness", "discipline")])
apply(data[, c("quality", "easiness")], 2, sd)


## ---- fig.cap = "Univariate EDA of Variables of Interest"---------------------
par(mfrow = c(2,3))
hist(data$quality, prob = TRUE, xlab = "Average Quality Rating", main = "")
barplot(table(data$gender), names = c("Female", "Male"), xlab = "Instructor Gender", ylab = "Count", main = "")
barplot(table(data$pepper), names = c("No", "Yes"), xlab = "Consensus that Instructor is Attractive", ylab = "Count", main = "")
hist(data$easiness, prob = TRUE, xlab = "Average Easiness Rating", main = "")
barplot(table(data$discipline), names = c("Hum", "SocSci", "STEM", "Pre-prof"), 
        xlab = " Instructor Discipline", ylab = "Count", main = "")


## ---- out.width = "60%", fig.cap = "Scatterplot between Easiness and Quality Rating (Squared)"----
ggplot(data, aes(x = easiness, y = quality)) + 
  geom_point() + 
  labs(x = "Average Easiness Rating", y = "Average Quality Rating")


## ---- fig.cap = "Boxplots between Gender,Discipline and Quality"--------------
par(mfrow = c(1, 2))
boxplot(quality ~ gender, data = data, 
        xlab = "Instructor Gender", ylab = "Average Quality Rating", pch = 16)

boxplot(quality ~ discipline, data = data, 
        xlab = "Instructor Discipline", names = c("Hum", "SocSci", "STEM", "Pre-prof"),
        ylab = "Average Quality Rating", pch = 16)



## ---- include = FALSE---------------------------------------------------------
library(modelsummary)
full.lm <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = data)
reduced.lm <- lm(quality ~ gender + pepper + easiness + discipline, data = data)
lm.estimates <- get_estimates(reduced.lm)
lm.estimates <- subset(lm.estimates, select = -c(s.value, group, df.error))


## -----------------------------------------------------------------------------
knitr::kable(lm.estimates, digits = 5)


## ---- include = FALSE---------------------------------------------------------
lm.estimates


## ---- include = FALSE---------------------------------------------------------
anova.result <- anova(reduced.lm, full.lm)
library(xtable)
print(xtable(anova.result))


## ---- include = FALSE---------------------------------------------------------
library(patchwork)
library(ggplot2)
library(broom)


## ---- fig.cap= "Model Diagnosis via Residual Plotting"------------------------
augmented.lm <- augment(reduced.lm)
p1 <- ggplot(augmented.lm, aes(x = easiness, y = .resid)) + 
  geom_point() + 
  labs(x = "Average Easiness Rating", y = "Residual")

p2 <- ggplot(augmented.lm, aes(x = pepper, y = .resid)) + 
  geom_point() + 
  labs(x = "Pepper", y = "Residual")

p3 <- ggplot(augmented.lm, aes(x = gender, y = .resid)) + 
  geom_point() + 
  labs(x = "gender", y = "Residual")

p4 <- ggplot(augmented.lm, aes(x = discipline, y = .resid)) + 
  geom_point() + 
  labs(x = "discipline", y = "Residual")

p5 <- ggplot(augmented.lm, aes(x = .fitted, y = .resid)) + 
  geom_point() + 
  labs(x = "Fitted Value", y = "Residual")



p1 + p2 + p3 + p4 + p5


## -----------------------------------------------------------------------------
test.lm <- lm(quality^2 ~ gender + pepper + easiness + discipline, data = data)


## ---- fig.cap = "Diagnosis using normal Q-Q plot and Cook's Distance"---------
p6 <- ggplot(augmented.lm, aes(x = .fitted, y = .cooksd)) +
  geom_point() +
  labs(main = "Q-Q plot without Transformation", x = "Fitted value", y = "Cook's distance")

p7 <- ggplot(augmented.lm, aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(main = "Q-Q plot without Transformation", x = "Theoretical quantile", y = "Sample quantile")

p8 <- ggplot(augment(test.lm), aes(sample = .resid)) +
  geom_qq() + 
  geom_qq_line() +
  labs(x = "Theoretical quantile", y = "Sample quantile")

p7 + p8 + p6


## ---- include = FALSE---------------------------------------------------------
cookd <- cooks.distance(reduced.lm)
f_percentile.50 <-qf(0.4, df1 = 2, df2 = 632)
influential_points <- which(cookd > f_percentile.50)
influential_points


## ---- include = FALSE---------------------------------------------------------
vif.result = vif(reduced.lm)
print(xtable(vif.result))

