## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(tidyverse)
library(GGally)


## ---- include=FALSE-----------------------------------------------------------
cmu.sleep <- read.csv("~/Documents/2023-2024/1. Fall Semester/36-401/Data Exams/DE 1 - Sleep/cmu-sleep.csv")
reduced = cmu.sleep %>% select(TotalSleepTime, cum_gpa, term_gpa)


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Distribution of Average Nightly Sleep"----
reduced %>%
  ggplot(aes(x=TotalSleepTime)) +
  geom_histogram(bins=20, fill="navyblue") +
  labs(x="Total Nightly Sleep (in minutes)")


## ---- fig.width=3, fig.height=1.75, fig.cap="Distribution of GPA Entering Spring"----
reduced %>%
  ggplot(aes(x=cum_gpa)) +
  geom_histogram(bins=16, fill="green4") +
  labs(x="Cumulative GPA (out of 4.0)")


## ---- fig.width=3, fig.height=1.75, fig.cap="Distribution of Spring Semester GPA"----
reduced %>%
  ggplot(aes(x=term_gpa)) +
  geom_histogram(bins=16, fill="green4") +
  labs(x="Spring Semester GPA (out of 4.0)")


## ---- fig.width=3, fig.height=1.75, fig.cap="Distribution of Spring Semester GPA"----
reduced %>%
  ggplot(aes(x=term_gpa^2)) +
  geom_histogram(bins=16, fill="darkgreen") +
  labs(x="Spring Semester GPA Squared")


## ---- fig.width=6.5, fig.height=3.5, fig.cap="Pairwise scatterplots of `sleep` dataset"----
reduced %>% ggpairs()


## ---- fig.width=3.5, fig.height=2.5, fig.cap="`cum_gpa` vs `term_gpa` Regression with Confidence Band", message=FALSE----
reduced %>%
  ggplot(aes(x=cum_gpa, y=term_gpa)) +
  geom_point() +
  labs(x="Cumulative GPA", y="Term GPA") +
  geom_smooth(method="lm")


## ---- include=FALSE-----------------------------------------------------------
gpa_mod <- lm(term_gpa ~ cum_gpa, data=reduced)
summary(gpa_mod)
confint(gpa_mod)


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Average Nightly Sleep vs Term GPA", message=FALSE----
reduced %>%
  ggplot(aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point(alpha=0.5) +
  labs(x="Average Nightly Sleep", y="Term GPA")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Average Nightly Sleep vs Term GPA", message=FALSE----
reduced %>%
  ggplot(aes(x=TotalSleepTime, y=term_gpa^2)) +
  geom_point(alpha=0.5) +
  labs(x="Average Nightly Sleep", y="Term GPA Squared")


## ---- include=FALSE-----------------------------------------------------------
lin_mod = lm(term_gpa      ~ TotalSleepTime, data=reduced)
sq_mod =  lm(term_gpa^2    ~ TotalSleepTime, data=reduced)


## ---- fig.width=3.5, fig.height=2, fig.cap="Residuals vs Fit (Sleep vs Term GPA)", message=FALSE----
tibble(fits = fitted(lin_mod), 
       residuals = residuals(lin_mod)) %>%
  ggplot(aes(x = fits, y = residuals)) +
  geom_point(alpha = 0.5) +
  geom_hline(yintercept = 0, 
             linetype = "dashed",
             color = "red")


## ---- fig.width=3.5, fig.height=2, fig.cap="Residuals vs Fit (Sleep vs Term GPA Squared)", message=FALSE----
tibble(fits = fitted(sq_mod), 
       residuals = residuals(sq_mod)) %>%
  ggplot(aes(x = fits, y = residuals)) +
  geom_point(alpha = 0.5) +
  geom_hline(yintercept = 0, 
             linetype = "dashed",
             color = "red")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Residuals vs Fit (Sleep vs Term GPA Squared)", message=FALSE----
hist(summary(sq_mod)$residuals, main="Distribution of Residuals", xlab="Residuals")


## ---- fig.width=5, fig.height=3.5, fig.cap="`TotalSleepTime` vs `term_gpa` Squared Regression with Confidence Band", message=FALSE----
reduced %>%
  ggplot(aes(x=TotalSleepTime, y=term_gpa^2)) +
  geom_point() +
  labs(x="Average Nightly Sleep (in minutes)", y="Term GPA Squared") +
  geom_smooth(method="lm")


## ---- include=FALSE-----------------------------------------------------------
summary(sq_mod)
confint(sq_mod)


## ---- include=FALSE-----------------------------------------------------------
sq_mod$coefficients[[2]]*60


## ---- include=FALSE-----------------------------------------------------------
sq_mod$coefficients[[2]]*(-120)


## ---- include=FALSE-----------------------------------------------------------
b0 = sq_mod$coefficients[[1]]
b1 = sq_mod$coefficients[[2]]
f <- function(x, diff=60)
{
  a = b0 + b1*x
  b = b0 + b1*(x + diff)
  return(sqrt(b)-sqrt(a))
}


## ---- include=FALSE-----------------------------------------------------------
f(240)
f(300)
f(360)
f(420)

f(240, -120)
f(300, -120)
f(360, -120)
f(420, -120)

