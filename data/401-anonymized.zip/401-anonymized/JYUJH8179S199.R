## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
knitr::opts_chunk$set(warning = FALSE)
knitr::opts_chunk$set(message = FALSE)


## -----------------------------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(broom)
data_original = read.csv("cmu-sleep.csv")
data = select(data_original, TotalSleepTime, cum_gpa, term_gpa)
data["diff_gpa"] = data$term_gpa-data$cum_gpa


## ---- fig.width=3, fig.height=2.5, fig.cap="Histogram of TotalSleepTime"------
ggplot(data, aes(x = TotalSleepTime))+geom_histogram(fill = "#73e0f4", binwidth = 13)+labs(x = "TotalSleepTime (minutes)", y = "Density")+theme_dark()


## ---- fig.width=3, fig.height=2.5, fig.cap="Histogram of diff_gpa"------------
ggplot(data, aes(x = diff_gpa))+geom_histogram(fill = "#ff8d53", binwidth = 0.1)+labs(x = "diff_gpa", y = "Density")+theme_dark()+xlim(-2,2)



## ---- fig.width=5, fig.height=4, fig.cap="Scatter Plot of diff_gpa v.s. TotalSleepTime"----
ggplot(data, aes(x=TotalSleepTime, y = diff_gpa))+geom_point(color = "#ff8d53")+labs(x = "TotalSleepTime (Minutes)", y = "diff_gpa", title = "diff_gpa v.s. TotalSleepTime")+theme_dark()


## ---- fig.width=5, fig.height=4, fig.cap="Scatter Plot of diff_gpa v.s. TotalSleepTime"----

ggplot(data, aes(x=TotalSleepTime, y = diff_gpa))+geom_point(color = "#ff8d53")+theme_dark()+stat_smooth(method = "lm", color = "#73e0f4")+stat_smooth(method = "lm", formula = y~poly(x, 2), color = "#69FA38")+labs(x = "TotalSleepTime (Minutes)", y = "diff_gpa", title = "diff_gpa v.s. TotalSleepTime")+stat_smooth(method = "lm", formula = y~poly(x, 3), color = "#b079cd")+stat_smooth(method = "lm", formula = y~poly(x, 5), color = "#fdc621")


## ---- fig.width=3, fig.height=2.5, fig.cap="Histogram of TotalSleepTime"------
fit = lm(diff_gpa ~ TotalSleepTime, data)
ggplot(augment(fit), aes(x=TotalSleepTime, y = fit$residual))+geom_point(color = "#ff8d53", size = 0.5)+labs(x = "TotalSleepTime (Minutes)", y = "residuals", title = "residuals v.s. TotalSleepTime")+theme_dark()


## ---- fig.width=3, fig.height=2.5, fig.cap="Q-Q Plot of linear regression model"----

qqnorm(fit$residuals)
qqline(fit$residuals, datax = FALSE, distribution = qnorm)


## ---- fig.width=3, fig.height=2.5, fig.cap="Q-Q Plot of linear regression model"----
summary(fit)

