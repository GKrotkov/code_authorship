## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(tidyverse)
library(ggplot2)
library(gridExtra)
library(modelsummary)
library(GGally)
library(alr4)


## ---- fig.width=5, fig.height=4, fig.cap="Distributions of variables Quality and Easiness."----
hist1 = ggplot(Rateprof, aes(x = quality)) + 
  geom_histogram(bins = 20, color = "black", fill = "white") + 
  labs(x = "Avg Quality Rating (1 to 5)", y = "Frequency")
hist2 = ggplot(Rateprof, aes(x = easiness)) + 
  geom_histogram(bins = 20, color = "black", fill = "white") + 
  labs(x = "Avg Easiness Rating (1 to 5)", y = "Frequency")
grid.arrange(hist1, hist2, nrow=1)

## ---- fig.width=6, fig.height=4, fig.cap="Plots of Discipline, Gender, Attractiveness"----
boxplot(quality~discipline, data=Rateprof, 
   xlab="All Disciplines", ylab="Avg Quality Rating")
boxplot(quality~gender, data=Rateprof, 
   xlab="Gender", ylab="Avg Quality Rating")
boxplot(quality~pepper, data=Rateprof, 
   xlab="Attractiveness (Y/N)", ylab="Avg Quality Rating")


## ---- fig.width=4, fig.height=4, fig.cap="Relationship Between Avg Easiness and Avg Quality Rating."----
plot(Rateprof[, c("quality", "easiness")], pch=20, cex=1)


## -----------------------------------------------------------------------------
cor(Rateprof[, c("quality", "easiness")])


## -----------------------------------------------------------------------------
ratemodel = lm(quality ~ easiness + gender + pepper + discipline, data = Rateprof)
summary(ratemodel)
modelsummary(list("Avg. Quality" = ratemodel),
             gof_map = c("r.squared", "adj.r.squared", "rmse", "F", "DF"))
confint(ratemodel)


## -----------------------------------------------------------------------------
plot(ratemodel)


## -----------------------------------------------------------------------------
ratemodel2 = lm(quality ~ easiness + gender + pepper + discipline + easiness:gender + easiness:discipline, data = Rateprof)
anova(ratemodel, ratemodel2)

