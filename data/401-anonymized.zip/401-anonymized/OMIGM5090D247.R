## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
library(ggplot2)
library(gridExtra)


## -----------------------------------------------------------------------------
plot1 <- ggplot(Rateprof, aes(x = gender, fill = gender)) +
  geom_bar() +
  labs(title = "Instructors' Gender", x = "Gender", y = "Count") +
  scale_fill_manual(values = c("pink", "blue"))  

plot2 <- ggplot(Rateprof, aes(x = pepper, fill = pepper)) +
  geom_bar() +
  labs(title = "Instructors' Attractiveness", x = "Chili Pepper Rating", y = "Count") +
  scale_fill_manual(values = c("red", "green"))  

plot3 <- ggplot(Rateprof, aes(x = discipline, fill = discipline)) +
  geom_bar() +
  labs(title = "Instructors' Discipline", x = "Discipline", y = "Count") +
  scale_fill_manual(values = c("purple", "yellow", "cyan", "orange"))  

plot4 <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = 1, color = "gold") +
  labs(title = "Class Easiness", x = "Easiness", y = "Frequency")  

grid.arrange(plot1, plot2, plot3, plot4, nrow = 2, ncol = 2)


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(binwidth = 1/3, color = "turquoise") +
  labs(title = "Instructor Quality", x = "Quality", y = "Frequency")  


## -----------------------------------------------------------------------------
plot5 <- ggplot(Rateprof, aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() +
  labs(title = "Quality vs Gender", x = "Gender", y = "Quality") +
  scale_fill_manual(values = c("blue", "pink"))  

plot6 <- ggplot(Rateprof, aes(x = pepper, y = quality, fill = pepper)) +
  geom_boxplot() +
  labs(title = "Quality vs Attractiveness", x = "Attractiveness (Chili Pepper Rating)", y = "Quality") +
  scale_fill_manual(values = c("lightgreen", "gold", "red"))  

plot7 <- ggplot(Rateprof, aes(x = easiness, y = quality, color = easiness)) +
  geom_point() +
  labs(title = "Quality vs Easiness", x = "Easiness", y = "Quality") +
  scale_color_gradient(low = "black", high = "black")  

plot8 <- ggplot(Rateprof, aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() +
  labs(title = "Quality vs Discipline", x = "Discipline", y = "Quality") +
  scale_fill_brewer(palette = "Set2")  

grid.arrange(plot5, plot6, plot7, plot8, nrow = 2, ncol = 2)


## ---- fig.width=4, fig.height=3-----------------------------------------------
library(GGally)
library(dplyr)
Rateprof |>
  dplyr::select(quality, gender,
         pepper, easiness,
         discipline) |>
ggpairs()


## -----------------------------------------------------------------------------
Rateprof$pepper <- as.factor(Rateprof$pepper)
Rateprof$gender <- as.factor(Rateprof$gender)
Rateprof$discipline <- as.factor(Rateprof$discipline)
model <- lm(quality ~ pepper + gender + discipline + easiness + 
               gender:easiness + discipline:easiness, data = Rateprof)
model1 <- lm(quality ~ pepper + gender + easiness + 
               gender:easiness + discipline:easiness, data = Rateprof)
model2 <- lm(quality ~ pepper + gender + discipline + easiness + 
               gender:easiness, data = Rateprof)
#summary(model)


## ---- fig.width=4, fig.height=3-----------------------------------------------
residualPlot(model, main = "Model Residuals vs Fitted Values")


## ---- fig.width=4, fig.height=3-----------------------------------------------
qqnorm(residuals(model), main = "Q-Q Plot")
qqline(residuals(model), col = "blue")


## -----------------------------------------------------------------------------
library(broom)
table = (tidy(model))
table
#confint(model)


## -----------------------------------------------------------------------------
#anova(model,model1)


## -----------------------------------------------------------------------------
#anova(model,model2)

