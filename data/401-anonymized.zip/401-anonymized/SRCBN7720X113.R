## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----include = FALSE----------------------------------------------------------
library(alr4)


## ---- fig.width=4.5, fig.height=3.5, fig.cap="Distribution of professor's average teaching quality rating", fig.align = "center"----
hist(Rateprof$quality, xlab = "Average Teaching Quality Rating", 
     main = "Frequency Distribution of Teaching Quality")


## ---- fig.width=4.5, fig.height=3.5, fig.cap="Distribution of professor's average course easiness", fig.align="center"----
hist(Rateprof$easiness, xlab = "Average Course Easiness", 
     main = "Frequency Distribution of Course Easiness")


## -----------------------------------------------------------------------------
library(knitr)
gen_df = as.data.frame(table(Rateprof$gender))
names(gen_df) = c("Genders", "Frequency")
kable(gen_df, caption = "Frequency Table for Professor Genders")

att_df = as.data.frame(table(Rateprof$pepper))
kable(att_df, col.names = c("Attractive?", "Frequency"), 
      caption = "Frequency Table for Professor Attractiveness")

disc_df = as.data.frame(table(Rateprof$discipline))
kable(disc_df, col.names = c("Discipline", "Frequency"), 
      caption = "Frequency Table for Course Discipline")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot inspecting teaching quality rating and taught course easiness rating", fig.align="center"----
plot(quality ~ easiness, data = Rateprof, xlab = "Average Taught Course Easiness", 
     ylab = "Average Professor Quality", main = "Teaching Quality vs Course Easiness")


## ---- fig.width=3, fig.height=3, fig.cap="Boxplot inspecting teaching quality rating by professor gender", fig.align="center"----
boxplot(quality ~ gender, data = Rateprof, xlab = "Professor Gender", 
        ylab = "Average Professor Quality", main = "Quality by Professor Gender")

## ---- fig.width=3.5, fig.height=3, fig.cap="Boxplot inspecting teaching quality rating by professor attractiveness", fig.align="center"----
boxplot(quality ~ pepper, data = Rateprof, xlab = "Professor is Attractive?", 
        ylab = "Average Professor Quality", main = "Quality by Professor Attractiveness")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot inspecting teaching quality rating by course discipline", fig.align="center"----
boxplot(quality ~ discipline, data = Rateprof, xlab = "Discipline", 
        ylab = "Average Professor Quality", main = "Quality by Course Discipline")


## ---- fig.width=4, fig.height=3.5, fig.cap="Residuals plot for full multiple linear regression model", fig.align="center"----
full_mod = lm(quality ~ easiness + gender + pepper + discipline + easiness * discipline + easiness * gender, data = Rateprof)
plot(full_mod, which = 1)


## ---- fig.width=4, fig.height=3.5, fig.cap="q-q plot for full multiple linear regression model", fig.align= "center"----
plot(full_mod, which = 2)


## -----------------------------------------------------------------------------
base_mod = lm(quality ~ easiness + gender + pepper + discipline, data = Rateprof)
format_pvalue <- function(p) {
  ifelse(p < 2e-7, "< 2e-7", format(p, digits = 3))
}

sum_base = as.data.frame(summary(base_mod)$coefficients)
df = summary(base_mod)$df[2]
sum_base$`Pr(>|t|)` <- sapply(sum_base$`Pr(>|t|)`, format_pvalue)
sum_base$DF = rep(df, nrow(sum_base))
kable(sum_base, caption = "Base Model Coefficients Summary")


## -----------------------------------------------------------------------------
no_disc_mod = lm(quality ~ easiness + gender + pepper, data = Rateprof)
f_test_disc = as.data.frame(anova(no_disc_mod, base_mod))
kable(f_test_disc, caption = "Partial F-test for including discipline term in model")


## -----------------------------------------------------------------------------
f_test_interaction = as.data.frame(anova(base_mod, full_mod))
kable(f_test_interaction, caption = "Partial F-test for including interaction in model")

