## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE)


## ---- echo = FALSE------------------------------------------------------------
data <- read.csv("/Users/veramazeeva/Library/CloudStorage/OneDrive-Personal/Carnegie Mellon/ModernRegression/data/cmu-sleep.csv")
data$gpa_change <- data$term_gpa - data$cum_gpa


## ---- echo = FALSE, fig.show="hold", fig.height=3.4, fig.width=5, out.width="50%"----
library(ggplot2)

hist(data$TotalSleepTime,
    main = "Total Sleep Time Distribution", xlab = "Sleep time (minutes",
    prob = FALSE, cex.main = 0.9, cex.axis = 0.8, cex.lab = 0.8)

hist(data$cum_gpa,
    main = "Cumulative GPA Distribution", xlab = "Cumulative gpa",
    prob = FALSE, cex.main = 0.9, cex.axis = 0.8, cex.lab = 0.8)

hist(data$term_gpa,
    main = "Term GPA Distribution", xlab = "Term gpa",
    prob = FALSE, cex.main = 0.9, cex.axis = 0.8, cex.lab = 0.8)

hist(data$gpa_change,
    main = "Change in GPA Distribution", xlab = "Change in gpa",
    prob = FALSE, cex.main = 0.9, cex.axis = 0.8, cex.lab = 0.8)


## ---- echo = FALSE, fig.align="center", fig.height=3.1, fig.width=5-----------
ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
    geom_point() +
    xlab("Total sleep time (minutes)") +
    ylab("Term gpa") +
    ggtitle("Total Sleep vs Term GPA") +
    theme(plot.title = element_text(size = 12)) +
    ggeasy::easy_center_title()


## ---- echo = FALSE, fig.align="center", fig.height=3.1, fig.width=5-----------
ggplot(data, aes(x = TotalSleepTime, y = gpa_change)) +
    geom_point() +
    xlab("Total sleep time (minutes)") +
    ylab("Change in gpa") +
    ggtitle("Total Sleep vs Change in GPA") +
    theme(plot.title = element_text(size = 12)) +
    ggeasy::easy_center_title()


## ---- echo = FALSE, fig.align="center", fig.height=3.1, fig.width=5-----------
ggplot(data, aes(x = cum_gpa, y = term_gpa)) +
    geom_point() +
    xlab("Cumulative gpa") +
    ylab("Term gpa") +
    ggtitle("Cumulative vs Term GPA") +
    theme(plot.title = element_text(size = 12)) +
    ggeasy::easy_center_title()


## ---- include = FALSE---------------------------------------------------------
fit1 <- lm(term_gpa ~ TotalSleepTime, data)
summary(fit1)
plot(data$TotalSleepTime, resid(fit1), ylab = "Residuals", xlab = "Total Sleep Time")

qqnorm(resid(fit1), pch = 1, frame = FALSE)
qqline(resid(fit1), col = "steelblue", lwd = 2)


cooksD <- cooks.distance(fit1)
influential <- cooksD[(cooksD > (3 * mean(cooksD, na.rm = TRUE)))]


## ---- echo = FALSE------------------------------------------------------------
fit2 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data)
summary(fit2)


## ---- echo = FALSE, fig.show="hold", fig.height=3.5, fig.width=5, out.width="50%"----
library(broom)

plot(data$TotalSleepTime, resid(fit2), ylab = "Residuals", xlab = "Total sleep time")
plot(data$cum_gpa, resid(fit2), ylab = "Residuals", xlab = "Cumulative gpa")


## ---- echo = FALSE, fig.align="center", fig.height=3.5, fig.width=5, out.width="50%"----

plot(augment(fit2)$.fitted, augment(fit2)$.resid, ylab="Residual", xlab="Fitted value", title="Residual Plot")


## ---- echo = FALSE, fig.align="center", fig.height=3.5, fig.width=5, out.width="50%"----
qqnorm(residuals(fit2))
qqline(residuals(fit2))


## ---- echo = FALSE, fig.align="center", fig.height=3.5, fig.width=4-----------
plot(data$cum_gpa, data$TotalSleepTime, ylab = "Total sleep time", xlab = "Cumulative gpa")


## ---- echo = FALSE, fig.show="hold", fig.height=3.5, fig.width=4, out.width="50%"----

augment(fit2) |>
ggplot(aes(x = term_gpa, y = .cooksd)) +
geom_point() +
labs(x = "Term gpa", y = "Cook's distance")

augment(fit2) |>
ggplot(aes(x = TotalSleepTime, y = .cooksd)) +
geom_point() +
labs(x = "Total sleep time", y = "Cook's distance")


## ---- echo = FALSE------------------------------------------------------------
summary(fit2)$coefficients

