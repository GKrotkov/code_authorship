## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(broom)
library(alr4)
library(modelsummary)
library(xtable)
library(kableExtra)


## ---- fig.width=4, fig.height=3, fig.cap="Relationship of Easiness vs. Quality seems to be linear"----
Rateprof %>% ggplot(aes(x = easiness, y = quality)) + 
  geom_point(size = 0.2) + 
  labs(title = "Average Professor Easiness vs. Quality") + 
  xlab("Avg. Easiness from 1 (worst) to 5 (best)") + 
  ylab("Avg. Quality from 1 (worst) to 5 (best)")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship of Easiness vs. Quality does not seem to differ by Discipline", message = FALSE----
Rateprof %>% ggplot(aes(x = easiness, y = quality, color = discipline)) + 
  geom_point(size = 0.2, alpha = 0.5) + 
  geom_smooth(method = lm, se = FALSE, linewidth = 0.5) + 
  labs(title = "Avg. Professor Easiness vs. Quality \nby Discipline") + 
  xlab("Avg. Easiness from 1 (worst) to 5 (best)") + 
  ylab("Avg. Quality from 1 (worst) to 5 (best)")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship of Easiness vs. Quality does not seem to differ by Gender", message = FALSE----
Rateprof %>% ggplot(aes(x = easiness, y = quality, color = gender)) + 
  geom_point(size = 0.2, alpha = 0.5) + 
  geom_smooth(method = lm, se = FALSE, linewidth = 0.5) + 
  labs(title = "Avg. Professor Easiness vs. \nQuality by Gender") + 
  xlab("Avg. Easiness from 1 (worst) to 5 (best)") + 
  ylab("Avg. Quality from 1 (worst) to 5 (best)")


## ---- fig.width=4, fig.height=3, fig.cap="Average Quality seems to differ by Attractiveness", message = FALSE----
Rateprof %>% ggplot(aes(x = pepper, y = quality)) +
  geom_boxplot() + 
  labs(title = "Avg. Professor Quality \nby Attractiveness") + 
  xlab("Professor Attractive") + 
  ylab("Avg. Quality from 1 (worst) to 5 (best)")


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of Average Quality show evidence of left skew"----
Rateprof %>% ggplot(aes(x = quality)) + 
  geom_histogram(bins = 15) +
  labs(title = "Distribution of Avg. Professor Quality") + 
  xlab("Avg. Quality from 1 (worst) to 5 (best)") + 
  ylab("Count")


## ---- include = FALSE---------------------------------------------------------
full.model <- lm(quality ~ easiness + gender + discipline + pepper + easiness:gender + easiness:discipline, data = Rateprof)

partial.model <- lm(quality ~ easiness + pepper, data = Rateprof)


## ---- fig.width=4, fig.height=3, fig.cap="Plot of Residuals vs. Fitted Values show evidence of fanning, but no evidence of non-linearity"----
full.model %>% augment %>% ggplot(aes(x = .fitted, y = .resid)) + 
  geom_point(size = 0.1) + 
  labs("Residuals vs. Fitted Values") + 
  xlab("Fitted Values") + ylab("Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="QQ Plot of Residuals demonstrate relatively normally distributed errors"----
full.model %>% augment %>% ggplot(aes(sample = .resid)) + 
  geom_qq(size = 0.1) + 
  geom_qq_line() + 
  xlab("Theoretical Quantiles") + 
  ylab("Sample Quantiles")


## ---- fig.width=4, fig.height=3-----------------------------------------------
result = anova(partial.model, full.model)
rownames(result) <- c("Partial Model", "Full Model")

result %>%
  kbl(caption="ANOVA Output for F-Test",
       format= "latex") %>%
   kable_classic(full_width = F)


## ---- fig.width=4, fig.height=3-----------------------------------------------
modelsummary(list("Partial Model" = partial.model),
             gof_map = c("r.squared", "nobs"), 
             title = "Coefficients and information from Model")


## ---- include = FALSE---------------------------------------------------------
# to calculate p-values for hypothesis tests
t.val <- c(11.770, 5.838)
p.val <- pt(t.val, 363, lower.tail = FALSE)
p.val

