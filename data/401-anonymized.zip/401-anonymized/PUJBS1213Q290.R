## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(tidyr)
library(ggplot2)
library(broom)
library(gridExtra)
library(modelsummary)


## ---- fig.width=4, fig.height=3, fig.cap="Histograms of quality and easiness ratings",message=FALSE----
long <- gather(data=Rateprof, key=measure, value=rating, c(quality,easiness))
ggplot(data=long,aes(x=rating, fill=measure)) + 
  geom_histogram() + 
  xlab("Rating") +
  facet_wrap(~measure) +
  theme_bw() +
  theme(legend.position="none",
        strip.text.x = element_text(size=12))


## ---- fig.width=8, fig.height=3, fig.cap="Bar plots of counts of factor variables",message=FALSE----
p1 <- data.frame(table(Rateprof$gender)) |>
  ggplot(aes(x=Var1, y=Freq)) + geom_bar(stat="identity") +
  theme_bw() + xlab("Gender") + ylab("Count") + theme(axis.text.x=element_text(size=12))

p2 <- data.frame(table(Rateprof$discipline)) |>
  ggplot(aes(x=Var1, y=Freq)) + geom_bar(stat="identity") +
  theme_bw() + xlab("Discipline") + ylab("Count") + theme(axis.text.x=element_text(size=12,
                                                                                   angle=45,
                                                                                   vjust=1,
                                                                                   hjust=1))

p3 <- data.frame(table(Rateprof$pepper)) |>
  ggplot(aes(x=Var1, y=Freq)) + geom_bar(stat="identity") +
  theme_bw()+ xlab("Attractive Rating") + ylab("Count") + theme(axis.text.x=element_text(size=12))
grid.arrange(p1,p2,p3,ncol=3)


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between predictors and response",message=FALSE----
ggplot(Rateprof, aes(x=easiness,y=quality)) +
  geom_point() + xlab("Easiness Rating") + ylab("Quality Rating") +
  theme_bw() 


## ---- fig.width=8, fig.height=5, fig.cap="Relationship between predictors and response",message=FALSE----

p1 <- ggplot(Rateprof, aes(x=gender,y=quality)) + 
  geom_boxplot() + xlab("Gender") + ylab("Quality") +
  theme_bw()

p2 <- ggplot(Rateprof, aes(x=pepper,y=quality)) + 
  geom_boxplot() + xlab("Attractive Rating") + ylab("Quality") +
  theme_bw()

p3 <- ggplot(Rateprof, aes(x=discipline,y=quality)) + 
  geom_boxplot() + xlab("Discipline") + ylab("Quality") +
  theme_bw() + theme(axis.text.x = element_text(angle=45,hjust=1,vjust=1))

hotprofs <- Rateprof
hotprofs$genderXpepper <- paste0(hotprofs$gender,"_",hotprofs$pepper)
p4 <- ggplot(hotprofs, aes(x=genderXpepper,y=quality)) + 
  geom_boxplot() +
  scale_x_discrete(limits=c("female_no", "male_no", "female_yes", "male_yes"),
                   labels=c("Female/No", "Male/No", "Female/Yes", "Male/Yes")) +
  xlab("Gender/Attractive Rating") + ylab("Quality") +
  theme_bw()

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)


## ---- fig.width=8, fig.height=5, fig.cap="Relationships between predictors",message=FALSE----
# easiness/gender
p1 <- ggplot(Rateprof, aes(x=gender,y=easiness)) + 
  geom_boxplot() + xlab("Gender") + ylab("Easiness") +
  theme_bw()
# easiness/discipline
p2 <- ggplot(Rateprof, aes(x=discipline,y=easiness)) + 
  geom_boxplot() + xlab("Discipline") + ylab("Easiness") +
  theme_bw() + theme(axis.text.x = element_text(angle=45,hjust=1,vjust=1))
# easiness/pepper
p3 <- ggplot(Rateprof, aes(x=pepper,y=easiness)) + 
  geom_boxplot() + xlab("Attractive Rating") + ylab("Easiness") +
  theme_bw()

p4 <- ggplot(Rateprof, aes(x=easiness,y=quality,col=pepper)) +
  geom_point() + xlab("Easiness Rating") + ylab("Quality Rating") +
  guides(fill=guide_legend(title="Attractive Rating")) +
  theme_bw() 

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)


## ---- message=FALSE-----------------------------------------------------------
model_simp <- lm(quality ~ easiness + discipline + gender + pepper +
                   easiness:pepper, data=Rateprof)

model_comp <- lm(quality ~ easiness + discipline + gender + pepper +
                   easiness:pepper +
                   gender*discipline*easiness - gender:discipline, 
                 data=Rateprof)


## -----------------------------------------------------------------------------
modelsummary(list("Simpler Model" = model_simp, 
                  "More Complex Model" = model_comp),
             gof_map = c("r.squared", "nobs"))


## ---- fig.width=8, fig.height=10, fig.cap="Diagnostic Plots",message=FALSE----
# resid vs easiness both models
p1 <- augment(model_simp) |>
  ggplot(aes(x=easiness,y=.resid)) +
  geom_point() + theme_bw() + xlab("Easiness") + ylab("Residuals") +
  ggtitle("Simpler Model")

p2 <- augment(model_comp) |>
  ggplot(aes(x=easiness,y=.resid)) +
  geom_point() + theme_bw() + xlab("Easiness") + ylab("Residuals") +
  ggtitle("More Complex Model")

# resid vs gender, attractiveness, discipline for both models
myModel <- model_simp
p3 <- augment(myModel) |>
  ggplot(aes(x=gender,y=.resid)) +
  geom_boxplot() + theme_bw() + xlab("Gender") + ylab("Residuals") +
  ggtitle("Simpler Model")

p4 <- augment(myModel) |>
  ggplot(aes(x=discipline,y=.resid)) +
  geom_boxplot() + theme_bw() + xlab("Discipline") + ylab("Residuals") +
  ggtitle("Simpler Model")

p5 <- augment(myModel) |>
  ggplot(aes(x=pepper,y=.resid)) +
  geom_boxplot() + theme_bw() + xlab("Attractive Rating") +
  ylab("Residuals") + ggtitle("Simpler Model")

myModel <- model_comp
p6 <- augment(myModel) |>
  ggplot(aes(x=gender,y=.resid)) +
  geom_boxplot() + theme_bw() + xlab("Gender") + ylab("Residuals") +
  ggtitle("More Complex Model")

p7 <- augment(myModel) |>
  ggplot(aes(x=discipline,y=.resid)) +
  geom_boxplot() + theme_bw() + xlab("Discipline") + ylab("Residuals") +
  ggtitle("More Complex Model")

p8 <- augment(myModel) |>
  ggplot(aes(x=pepper,y=.resid)) +
  geom_boxplot() + theme_bw() + xlab("Attractive Rating") +
  ylab("Residuals") + ggtitle("More Complex Model")

grid.arrange(p1,p2,p3,p6,p4,p7,p5,p8,nrow=4,ncol=2)


## ---- fig.width=8, fig.height=4, fig.cap="Diagnostic Plots",message=FALSE-----
# resid vs fitted for both models
p1 <- augment(model_simp) |>
  ggplot(aes(x=.fitted,y=.resid)) +
  geom_point() + theme_bw() + xlab("Fitted values") + ylab("Residuals") +
  ggtitle("Simpler Model")

p2 <- augment(model_comp) |>
  ggplot(aes(x=.fitted,y=.resid)) +
  geom_point() + theme_bw() + xlab("Fitted values") + ylab("Residuals") +
  ggtitle("More Complex Model")

grid.arrange(p1,p2,ncol=2)


## ---- fig.width=8, fig.height=4, fig.cap="Diagnostic Plots",message=FALSE-----
# normal qq plots for both models
p1 <- augment(model_simp) |>
  ggplot(aes(sample = .resid)) +
  geom_qq() + geom_qq_line() +
  labs(x="Theoretical quantiles", y="Observed quantiles",
       title="Normal QQ plot of the Residuals") +
  theme_bw() + ggtitle("Simpler Model")

p2 <- augment(model_simp) |>
  ggplot(aes(sample = .resid)) +
  geom_qq() + geom_qq_line() +
  labs(x="Theoretical quantiles", y="Observed quantiles",
       title="Normal QQ plot of the Residuals") +
  theme_bw() + ggtitle("More Complex Model")

grid.arrange(p1,p2,ncol=2)


## ----message=FALSE, results='hide'--------------------------------------------
# Hypothesis tests and confidence intervals
anova(lm(quality ~ easiness + discipline + gender, data=Rateprof), model_simp)
anova(lm(quality ~ pepper + discipline + gender, data=Rateprof), model_simp)
anova(lm(quality ~ easiness + gender + pepper + easiness:pepper, data=Rateprof),
      model_simp)

anova(model_simp, model_comp)

CI <- function(obj, parm, alpha=0.05){
  sum <- summary(obj)$coefficients
  df <- obj$df.residual
  if(length(parm)<2){
    se <- sum[parm,"Std. Error"]
    err <- qt(1-alpha/2,df)*se
    beta <- sum[parm,"Estimate"]
    c(beta - err, beta + err)
  }else{
    a <- rep(0, nrow(sum))
    names(a) <- rownames(sum)
    a[parm] <- 1
    se <- sqrt(t(a)%*%vcov(obj)%*%a)
    err <- qt(1-alpha/2,df)*se
    beta <- sum(sum[parm,"Estimate"])
    print(paste("Beta:",beta))
    c(beta - err, beta + err)
  }
}

CI(model_simp,"gendermale")
CI(model_simp,"pepperyes")
CI(model_simp,"easiness:pepperyes")
CI(model_simp,"easiness")
CI(model_simp, c("easiness","easiness:pepperyes"))

