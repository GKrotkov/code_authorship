## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Average sleep time of students"-----
hist(sleep$TotalSleepTime,
     xlab = "Time slept (minutes)", ylab = "Number of students", main = "Average sleep time of students")


## ---- fig.width=5, fig.height=3, fig.cap="GPA of students for semester during study"----
hist(sleep$term_gpa,
     xlab = "Term GPA (on 4.0 scale)", ylab = "Number of students", main = "GPA of students for semester of study")


## ---- fig.width=5, fig.height=3, fig.cap="GPA of students for semester during study"----
boxplot(sleep$term_gpa,
     xlab = "Term GPA (on 4.0 scale)", ylab = "Number of students", main = "GPA of students for semester of study")


## ---- fig.width=5, fig.height=3, fig.cap="GPA of students for entire college career"----
hist(sleep$cum_gpa,
     xlab = "Cumulative GPA (on 4.0 scale)", ylab = "Number of students", main = "GPA of students for entire college career")


## ---- fig.width=6, fig.height=4, fig.cap="GPA of students for entire college career"----
plot(cum_gpa ~ TotalSleepTime, data=sleep,
     xlab = "Average minutes slept each night", ylab = "Cumulative GPA (on 4.0 scale)", main = "Correlation between minutes slept and cumulative GPA")


## ---- fig.width=7, fig.height=4, fig.cap="GPA of students for entire college career"----
plot(term_gpa ~ TotalSleepTime, data=sleep,
     xlab = "Average minutes slept each night", ylab = "Semester GPA (on 4.0 scale)", main = "Correlation between minutes slept and current semester GPA")


## ---- fig.width=6, fig.height=4, fig.cap="GPA of students for entire college career"----
plot(term_gpa ~ cum_gpa, data=sleep,
     xlab = "Semester GPA (on 4.0 scale)", ylab = "Cumulative GPA (on 4.0 scale)", main = "Correlation between cumulative and semester GPAs")


## -----------------------------------------------------------------------------
t.test(sleep$term_gpa, sleep$cum_gpa, alternative = c("two.sided", "less", "greater"), mu = 0, paired = FALSE, var.equal = FALSE, conf.level = 0.95)


## ---- fig.width=5, fig.height=4, fig.cap="Plot of sleep time vs term gpa"-----
plot(term_gpa ~ TotalSleepTime, data=sleep, xlab="Minutes slept", ylab="Term GPA", main="Sleep vs GPA")


## ---- fig.width=5, fig.height=4, fig.cap="Plot of log of sleep time vs term gpa"----
sleep$hoursleep <- sleep$TotalSleepTime/60
sleep$logsleep <- log(sleep$hoursleep)
plot(term_gpa ~ logsleep, data=sleep, xlab="Log of hours slept", ylab="Term GPA", main="Log sleep vs GPA")


## -----------------------------------------------------------------------------
lmlogsleep <- lm(term_gpa ~ logsleep, data=sleep)
summary(lmlogsleep)


## -----------------------------------------------------------------------------
confint(lmlogsleep)

