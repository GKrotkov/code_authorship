## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----libraries, include = FALSE-----------------------------------------------
library(alr4)
library(xtable)


## ----reshape.data-------------------------------------------------------------
df <- subset(Rateprof,
             select=c("quality", "gender", "pepper", "easiness", "discipline"))


## ----EDA.1var, fig.width=7.5,fig.height=3.5,fig.align='center', fig.cap='Univariate distributions of variables'----
par(mfrow=c(2,3),
    mar=c(4.1, 4.1, 3.1, 1.2),
    cex.lab=1,
    cex.main=1)

hist(df$quality,
     xlab="Avg Quality Rating (from 1 to 5)",
     main="quality",
     col="grey")

hist(df$easiness,
     xlab="Avg Easiness Rating (from 1 to 5)",
     main="easiness",
     col="orange")

plot.new()

barplot(table(df$pepper),
        xlab="Is Instructor Attractive?",
        main="pepper",
        col=c("palevioletred1", "palegreen"))

barplot(table(df$gender),
        xlab="Instructor Gender",
        main="gender",
        col=c("pink", "skyblue"))

barplot(table(df$discipline),
        xlab="Instructor Discipline",
        main="discipline",
        col=c("lightyellow", "turquoise1", "thistle1", "salmon1"))



## ----EDA.2var.B, fig.width=7.5, fig.height=6,fig.align='center', fig.cap='Scatterplots of Quality to Easiness, both separately and w.r.t to the other variables'----
par(mfrow=c(2,3),
    mar=c(10.1, 4, 4.1, 2.1),
    cex.lab=1,
    cex.main=1)

plot(x=df$easiness,
     y=df$quality,
     xlab='Avg Easiness Rating',
     ylab='Avg Quality Rating',
     main='Easiness v.s. Quality',
     cex=0.75,
     col='orange')
abline(lm(quality ~ easiness,
          data=df),
       col='orange2',
       lwd=1.5)

plot.new()

plot.new()

plot(x=df$easiness,
     y=df$quality,
     xlab='Avg Easiness Rating',
     ylab='Avg Quality Rating',
     main='Easiness v.s. Quality w.r.t Gender',
     type='n')
gender.lm <- lm(quality ~ easiness + factor(gender),
                data=df)
gender.coefs <- gender.lm$coefficients

points(subset(df, gender=='female')$easiness,
       subset(df, gender=='female')$quality,
       cex=0.75,
       col="pink")
points(subset(df, gender=='male')$easiness,
       subset(df, gender=='male')$quality,
       cex=0.75,
       col="skyblue")
abline(gender.coefs[1], gender.coefs[2],
       col="deeppink",
       lwd=1.5)
abline(c(gender.coefs[1] + gender.coefs[3], gender.coefs[2]),
       col="blue", 
       lwd=1.5)
legend("bottom",
       title="Gender",
       inset=c(0,-0.9),
       legend = c('female', 'male'),
       fill = c('deeppink', 'blue'),
       cex=0.8,
       xpd=TRUE,
       horiz=TRUE)


plot(x=df$easiness,
     y=df$quality,
     xlab='Avg Easiness Rating',
     ylab='Avg Quality Rating',
     main='Easiness v.s. Quality w.r.t Pepper',
     type='n')
pepper.lm <- lm(quality ~ easiness + factor(pepper),
                data=df)
pepper.coefs <- pepper.lm$coefficients

points(subset(df, pepper=='no')$easiness,
       subset(df, pepper=='no')$quality,
       cex=0.75,
       col="palevioletred1")
points(subset(df, pepper=='yes')$easiness,
       subset(df, pepper=='yes')$quality,
       cex=0.75,
       col="palegreen")
abline(pepper.coefs[1], pepper.coefs[2],
       col="red",
       lwd=1.5)
abline(c(pepper.coefs[1] + pepper.coefs[3], pepper.coefs[2]),
       col="green", 
       lwd=1.5)
legend("bottom",
       title="Pepper",
       inset=c(0,-0.9),
       legend = c('no', 'yes'),
       fill = c('red', 'green'),
       cex=0.8,
       xpd=TRUE,
       horiz=TRUE)


plot(x=df$easiness,
     y=df$quality,
     xlab='Avg Easiness Rating',
     ylab='Avg Quality Rating',
     main='Easiness v.s. Quality w.r.t Discipline',
     type='n')
discipline.lm <- lm(quality ~ easiness + factor(discipline),
                data=df)
discipline.coefs <- discipline.lm$coefficients

points(subset(df, discipline=='Hum')$easiness,
       subset(df, discipline=='Hum')$quality,
       cex=0.75,
       col="lightyellow3")
points(subset(df, discipline=='SocSci')$easiness,
       subset(df, discipline=='SocSci')$quality,
       cex=0.75,
       col="turquoise1")
points(subset(df, discipline=='STEM')$easiness,
       subset(df, discipline=='STEM')$quality,
       cex=0.75,
       col="thistle2")
points(subset(df, discipline=='Pre-prof')$easiness,
       subset(df, discipline=='Pre-prof')$quality,
       cex=0.75,
       col="salmon1")
abline(discipline.coefs[1], discipline.coefs[2],
       col="yellow4",
       lwd=1.5)
abline(c(discipline.coefs[1] + discipline.coefs[3], discipline.coefs[2]),
       col="turquoise3", 
       lwd=1.5)
abline(c(discipline.coefs[1] + discipline.coefs[4], discipline.coefs[2]),
       col="thistle3",
       lwd=1.5)
abline(c(discipline.coefs[1] + discipline.coefs[5], discipline.coefs[2]),
       col="salmon2", 
       lwd=1.5)
legend("bottom",
       title="Discipline",
       inset=c(0,-0.9),
       legend = c('Hum', 'SocSci', 'STEM', 'Pre-Prof'),
       fill = c('yellow4', 'turquoise3', 'thistle3', 'salmon2'),
       cex=0.8,
       xpd=TRUE,
       horiz=TRUE)


## ----methods.plot, fig.width=7.5, fig.height=2.5,fig.align='center', fig.cap='Residual Plots of Full Model'----
par(mfrow=c(1,3),
    cex.lab=1,
    cex.main=1)

lm.full <- lm(quality ~ easiness + factor(pepper) + factor(gender)*factor(discipline) + easiness:factor(gender) + easiness:factor(discipline),
              data=df)

plot(lm.full, which=c(1,2,4))


## ----methods.anova.gender, results='asis'-------------------------------------
lm.reduced <- lm(quality ~ easiness + factor(pepper) + factor(gender)*factor(discipline),
                 data=df)

print(xtable(anova(lm.reduced, lm.full),
             caption='ANOVA table for easiness-gender/easiness-discipline association'), comment=FALSE)


## ----methods.summary, results='asis'------------------------------------------
lm.reduced <- lm(quality ~ easiness + factor(pepper) + factor(gender)*factor(discipline),
                 data=df)
summary.lm <- summary(lm.reduced)
coef <- data.frame(summary.lm$coefficients)
colnames(coef) <- c('Estimate', 'Std. Error', 't.value', 'Pr(>|t|)')
coef[-c(3,4)] <- format(coef[-c(3,4)], digits=2)
coef[c(3,4)] <- format(coef[c(3,4)], digits=3)
conf <- data.frame(confint(lm.reduced))
colnames(conf) <- c('2.5%', '97.5%')
conf['2.5%'] <- format(conf['2.5%'], digits=2)
conf['97.5%'] <- format(conf['97.5%'], digits=3)

print(xtable(cbind(conf[1], coef[1], conf[2], coef[3:4]),
             caption='Summary for Coefficients of Selected model'), comment=FALSE)


## ----methods.anova.gender.discipline, results='asis'--------------------------
lm.reduced.reduced <- lm(quality ~ easiness + factor(pepper),
                         data=df)
print(xtable(anova(lm.reduced.reduced, lm.reduced),
             caption='ANOVA for gender-discipline significance'),
      comment=FALSE)

