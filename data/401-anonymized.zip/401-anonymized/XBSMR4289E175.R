## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(dplyr)
library(patchwork)
library(modelsummary)


## ---- message=FALSE-----------------------------------------------------------
data <- read.csv("cmu-sleep.csv")


## ---- fig.width=3.2, fig.height=2.3, message=FALSE----------------------------

#median(data$TotalSleepTime)
#mean(data$term_gpa)
#mean(data$cum_gpa)

ggplot(data, aes(x = TotalSleepTime)) +
  geom_histogram(fill="skyblue", color="black", binwidth=30) +
  labs(title="Distribution of Sleep Duration", x="Sleep Duration (minutes)", y="Number of Students")


ggplot(data, aes(x = term_gpa)) +
  geom_histogram(fill="lightcoral", color="black", binwidth=0.1) +
  labs(title="Distribution of Term GPA", x="Term GPA", y="Number of Students")



## ---- fig.width=4, fig.height=3, fig.align='center', message=FALSE------------
ggplot(data, aes(x = cum_gpa)) +
  geom_histogram(fill="lightgreen", color="black", binwidth=0.1) +
  labs(title="Distribution of Previous Semester GPA", x="Previous Semester GPA", y="Number of Students")


## ---- message=FALSE, warning=FALSE--------------------------------------------

p1 <- ggplot(data, aes(x = term_gpa, fill = "Term GPA")) +
  geom_density(alpha = 0.6) +
  geom_density(aes(x = cum_gpa, fill = "Previous GPA"), alpha = 0.6) +
  labs(title="GPA Comparison for Current and Previous Semesters", x="GPA", y="Density")

p2 <- ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(title="Sleep time vs Term GPA", x="Sleep Duration(minutes)", y="Term GPA")

data$gpa_difference = data$term_gpa - data$cum_gpa

p3 <- ggplot(data, aes(x = TotalSleepTime, y = gpa_difference)) +
  geom_point(aes(color = gpa_difference)) +
  geom_smooth(method = "lm") +
  labs(title="Sleep time vs Change in GPA", x="Sleep Duration(minutes)", y="Change in GPA", color="GPA Change")

p1/(p2|p3)


## ---- message=FALSE, fig.height=3.5-------------------------------------------
library(ggplot2)

slr_model <- lm(term_gpa ~ TotalSleepTime, data=data)
mlr_model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data=data)
data$log_term_gpa <- log(data$term_gpa)
data$log_cum_gpa <- log(data$cum_gpa)
slr_model_log <- lm(log_term_gpa ~ TotalSleepTime, data=data)


mlr_model_log <- lm(log_term_gpa ~ TotalSleepTime + log_cum_gpa, data=data)

p1_log <- ggplot(data, aes(x=fitted(slr_model_log), y=residuals(slr_model_log))) +
  geom_point() +
  geom_smooth(se=FALSE, method="lm", col="red") +
  labs(title="Single Linear Regression Log",
       x="Fitted values",
       y="Residuals") 

p2_log <- ggplot(data, aes(x=fitted(mlr_model_log), y=residuals(mlr_model_log))) +
  geom_point() +
  geom_smooth(se=FALSE, method="lm", col="red") +
  labs(title="Multiple Linear Regression Log",
       x="Fitted values",
       y="Residuals") 
p1_log|p2_log



## ---- message=FALSE-----------------------------------------------------------

par(mfrow = c(1, 2))
qqnorm(residuals(slr_model))
qqline(residuals(slr_model), col="red")
mtext("Q-Q Plot for Simple Linear Regression", side=1, line=4, cex=0.8)

qqnorm(residuals(mlr_model))
qqline(residuals(mlr_model), col="red")
mtext("Q-Q Plot for Multiple Linear Regression", side=1, line=4, cex=0.8)

par(mfrow = c(1, 2))

#confint(slr_model)
#confint(mlr_model)

#new_data <- data.frame(TotalSleepTime = mean(data$TotalSleepTime) - 120, cum_gpa = mean(data$cum_gpa))
#predict(mlr_model, newdata=new_data, interval="prediction")



## ---- message = FALSE---------------------------------------------------------
library(tidyverse)

slr_model <- lm(term_gpa ~ TotalSleepTime, data = data)
slr_summary <- summary(slr_model)



## -----------------------------------------------------------------------------
expected_change <- coef(slr_model)['TotalSleepTime'] * -120
#print(expected_change)


## ---- message=FALSE-----------------------------------------------------------

mlr_model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)
mlr_summary <- summary(mlr_model)
modelsummary(list("Single Linear Regression" = slr_model, "Multiple Regression" = mlr_model))

