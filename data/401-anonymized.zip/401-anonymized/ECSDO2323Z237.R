## ---- include = FALSE---------------------------------------------------------
library(alr4)
data("Rateprof")


## -----------------------------------------------------------------------------
peppertable <- table(Rateprof$pepper)

barplot(peppertable, 
        main = "Distribution of Attractiveness", 
        xlab = "Attractiveness", 
        ylab = "Frequency", 
        col = c("red", "green"))



## -----------------------------------------------------------------------------
disciplinetable <- table(Rateprof$discipline)

barplot(disciplinetable, 
        main = "Distribution of Discipline", 
        xlab = "Discipline", 
        ylab = "Frequency",
        col = "yellow") 


## -----------------------------------------------------------------------------
gendertable <- table(Rateprof$gender)

barplot(gendertable, 
        main = "Distribution of Gender", 
        xlab = "Gender", 
        ylab = "Frequency", 
        col = c("pink", "lightblue"))


## -----------------------------------------------------------------------------
hist(Rateprof$easiness, 
     col = "purple",
     main = "Distribution of Easiness Ratings",
     xlab = "Easiness")


## -----------------------------------------------------------------------------
hist(Rateprof$quality, 
     col = "orange",
     main = "Distribution of Quality Ratings",
     xlab = "Quality")


## -----------------------------------------------------------------------------
plot(Rateprof$pepper, Rateprof$easiness,
     col = "turquoise",
     main = "Attractiveness vs Easiness",
     xlab = "Attractiveness", 
     ylab = "Easiness")


## -----------------------------------------------------------------------------
boxplot(Rateprof$easiness ~ Rateprof$discipline, 
        col = "maroon",
        main = "Easiness vs Discipline",
        xlab = "Discipline", 
        ylab = "Easiness")


## -----------------------------------------------------------------------------
genderpepper <- table(Rateprof$gender, Rateprof$pepper)

barplot(genderpepper, 
        main = "Attractiveness by Gender",
        xlab = "Gender", 
        ylab = "Count",
        col = c("lightpink", "lightblue"),
        legend = rownames(genderpepper),
        beside = TRUE)


## -----------------------------------------------------------------------------
genderdiscipline <- table(Rateprof$gender, Rateprof$discipline)

barplot(genderdiscipline, 
        main = "Discipline by Gender",
        xlab = "Gender", 
        ylab = "Count",
        col = c("lightpink", "lightblue"),
        legend = rownames(genderdiscipline),
        beside = TRUE)


## -----------------------------------------------------------------------------
par(mfrow = c(2, 2), mar = c(4, 4, 2, 1))

plot(Rateprof$easiness, Rateprof$quality, 
     col = "green",
     main = "Quality Rating vs Easiness",
     xlab = "Easiness", 
     ylab = "Quality Rating")

plot(Rateprof$pepper, Rateprof$quality, 
     col = "green",
     main = "Quality Rating vs Attractiveness",
     xlab = "Attractiveness", 
     ylab = "Quality Rating")

boxplot(Rateprof$quality ~ Rateprof$gender,
        col = "green",
        main = "Quality Rating by Gender",
        xlab = "Gender", 
        ylab = "Quality Rating")


boxplot(Rateprof$quality ~ Rateprof$discipline,
        col = "green",
        main = "Quality Rating by Discipline",
        xlab = "Discipline", 
        ylab = "Quality Rating") 



## -----------------------------------------------------------------------------
lmmodel <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

summary(lmmodel)


## ---- include = FALSE---------------------------------------------------------
lmmodelinteract <- lm(quality ~ gender + pepper * easiness + discipline, data = Rateprof)

summary(lmmodelinteract)


## ---- fig.width = 4-----------------------------------------------------------
library(ggplot2)
residuals <- data.frame(fitted = lmmodelinteract$fitted.values, 
                           residuals = lmmodelinteract$residuals)

ggplot(data = residuals, aes(x = fitted, 
                             y = residuals)) +
  geom_point(col = "pink") +
  geom_hline(yintercept = 0, 
             col = "green") +
  labs(title = "Residuals vs Fitted", 
       x = "Fitted values", 
       y = "Residuals") +
  theme_minimal()


## ---- fig.width=4-------------------------------------------------------------
qqnorm(lmmodelinteract$residuals)

qqline(lmmodelinteract$residuals, col = "grey")


## -----------------------------------------------------------------------------
summary <- summary(lmmodelinteract)

coefficientsummary <- summary$coefficients
print(coefficientsummary)

confintervals <- confint(lmmodelinteract)
print(confintervals)


## -----------------------------------------------------------------------------
anova_table <- anova(lmmodelinteract)
print(anova_table)

