## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----

sleep <- read.csv("cmu-sleep.csv")

library(ggplot2)
library(patchwork)
library(broom)



## -----------------------------------------------------------------------------
sleep$change_in_gpa = sleep$term_gpa - sleep$cum_gpa
sleep$TotalSleepTime.hours = sleep$TotalSleepTime/60


## -----------------------------------------------------------------------------
hist(sleep$TotalSleepTime.hours, main = "Figure 1 - Distribution of Total Sleep Time", xlab = "Total Sleep Time (in hours)")


## -----------------------------------------------------------------------------
hist(sleep$term_gpa, main = "Figure 2 - Distribution of Term GPA", xlab = "Term GPA")


## -----------------------------------------------------------------------------
hist(sleep$cum_gpa, main = "Figure 3 - Distribution of Cumulative GPA", xlab = "Cumulative GPA")


## -----------------------------------------------------------------------------
hist(sleep$change_in_gpa, main = "Figure 4 - Distribution of Change in GPA", xlab = "Change in GPA")


## -----------------------------------------------------------------------------

ggplot(sleep, aes(x=TotalSleepTime.hours, y=term_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(x = "Total Sleep Time (in hours)",
       y = "Term GPA",
       title = "Figure 5 - Relationship between Total Sleep Time and Term GPA")


## -----------------------------------------------------------------------------

ggplot(sleep, aes(x=TotalSleepTime.hours, y=cum_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(x = "Total Sleep Time (in hours)",
       y = "Cumulative GPA",
       title = "Figure 6 - Relationship between Total Sleep Time and Cumulative GPA")



## -----------------------------------------------------------------------------
ggplot(sleep, aes(x=TotalSleepTime.hours, y=change_in_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(x = "Total Sleep Time (in hours)",
       y = "Change in GPA",
       title = "Figure 7 - Relationship between Change in GPA and Total Sleep Time")


## -----------------------------------------------------------------------------

fit.change_in_gpa.hours <- lm(change_in_gpa ~ TotalSleepTime.hours, data = sleep)

#For the code below, I used 'https://www.sharpsightlabs.com/blog/ggplot-titles/' :

p4 <- augment(fit.change_in_gpa.hours) |>
  ggplot(aes(x=TotalSleepTime.hours, y=.resid)) +
  geom_point() +
  labs(x="Total Sleep Time (hours)", y = "Residual",title = "Figure 8 - Residual Plot - Model of Change in GPA against Total Sleep Time")

p4


fit.cum_gpa.hours <- lm(cum_gpa ~ TotalSleepTime.hours, data = sleep)

p2 <- augment(fit.cum_gpa.hours) |>
  ggplot(aes(x=TotalSleepTime.hours, y=.resid)) +
  geom_point() +
  labs(x="Total Sleep Time (hours)", y = "Residual",title = "Figure 9 - Residual Plot - Cum. GPA")

fit.term_gpa.hours <- lm(term_gpa ~ TotalSleepTime.hours, data = sleep)

p3 <- augment(fit.term_gpa.hours) |>
  ggplot(aes(x=TotalSleepTime.hours, y=.resid)) +
  geom_point() +
  labs(x="Total Sleep Time (hours)", y = "Residual",title = "Figure 10 - Residual Plot - Term GPA")

p2 | p3






## -----------------------------------------------------------------------------

fit.change_in_gpa.hours <- lm(change_in_gpa ~ TotalSleepTime.hours, data = sleep)
summary(fit.change_in_gpa.hours)
confint(fit.change_in_gpa.hours)

beta.0.hat = coef(fit.change_in_gpa.hours)["(Intercept)"]
beta.1.hat = coef(fit.change_in_gpa.hours)["TotalSleepTime.hours"]
std.error.beta.1.hat = 0.01876

t.value = beta.1.hat / std.error.beta.1.hat
t.value

qt(0.975,632,lower.tail = TRUE)



## -----------------------------------------------------------------------------
Intercept <- coef(fit.change_in_gpa.hours)["(Intercept)"]
Slope <- coef(fit.change_in_gpa.hours)["TotalSleepTime.hours"]


#For 2 hours less sleep, the change in GPA:
Intercept - 2*Slope


