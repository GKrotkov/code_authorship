## -----------------------------------------------------------------------------
library(dplyr)
library(ggplot2)


## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep.df <- read.csv("/Users/jean/Desktop/cmu-sleep.csv")


## -----------------------------------------------------------------------------
nrow(sleep.df)


## -----------------------------------------------------------------------------
hist(sleep.df$TotalSleepTime, 
     main = "Histogram of TotalSleepTime",
     xlab = "TotalSleepTime (measured in minutes)",
     col = "lightpink",
     breaks = 50)
hist(sleep.df$term_gpa,
     main = "Histogram of term_gpa",
    xlab = "term_gpa (out of 4.0 scale)", 
    col = "lightblue",
    breaks = 50)
hist(sleep.df$cum_gpa, 
     main = "Histogram of cum_gpa", 
     xlab = "cum_gpa (out of 4.0 scale)",
     col = "lightgrey",
     breaks = 50)


## -----------------------------------------------------------------------------
plot(sleep.df$TotalSleepTime, sleep.df$term_gpa, 
     main = "Scatterplot of TotalSleepTime vs term_gpa",
     xlab = "TotalSleepTime (in minutes)",
     ylab = "term_gpa (4.0 scale)",
     col = "black",
     pch = 20)
plot(sleep.df$TotalSleepTime, sleep.df$cum_gpa, 
     main = "Scatterplot of TotalSleepTime vs cum_gpa",
     xlab = "TotalSleepTime (in minutes)",
     ylab = "cum_gpa (4.0 scale)",
     col = "black",
     pch = 20)
plot(sleep.df$term_gpa, sleep.df$cum_gpa, 
     main = "Scatterplot of term_gpa vs cum_gpa",
     xlab = "term_gpa (4.0 scale)",
     ylab = "cum_gpa (4.0 scale)",
     col = "black",
     pch = 20)


## -----------------------------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep.df)
residuals <- residuals(model)

plot(sleep.df$TotalSleepTime, residuals, col = "black", pch = 20,
     xlab = "TotalSleepTime (in minutes)", ylab = "Residuals",
     main = "Residual Plot with TotalSleepTime")
     
abline(h = 0, col = "red", lty = 2)

plot(sleep.df$cum_gpa, residuals, col = "black", pch = 20,
     xlab = "TotalSleepTime (in minutes)", ylab = "Residuals",
     main = "Residual Plot with cum_gpa")

abline(h = 0, col = "red", lty = 2)


## -----------------------------------------------------------------------------
print(summary(model))


## -----------------------------------------------------------------------------
cat("95% CI:", confint(model, "TotalSleepTime", level = 0.95))


## -----------------------------------------------------------------------------
df <- nrow(sleep.df) - 3
print(qt(0.05, df, lower.tail = FALSE))

