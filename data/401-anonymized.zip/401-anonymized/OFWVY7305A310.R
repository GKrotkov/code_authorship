## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, message =FALSE----------------------------------------------
library(alr4)
help("Rateprof")
data("Rateprof")


## ---- echo=FALSE, fig.width=4, fig.height =3, fig.align='center'--------------
hist(Rateprof$quality, breaks = 20, col = "skyblue", main = "Distribution of Quality Ratings", xlab = "Quality Ratings")
hist(Rateprof$easiness, breaks = 20, col = "lightgreen", main = "Distribution of Easiness Ratings", xlab = "Easiness Ratings")
barplot(table(Rateprof$gender), col = rainbow(length(unique(Rateprof$gender))), main = "Gender", xlab = "Gender", ylab = "Frequency")
barplot(table(Rateprof$pepper), col = rainbow(length(unique(Rateprof$pepper))), main = "Attractiveness Ratings", xlab = "Attractiveness", ylab = "Frequency")
barplot(table(Rateprof$discipline), col = rainbow(length(unique(Rateprof$discipline))),
        main = "Distribution of Professors by Discipline", xlab = "Discipline", ylab = "Frequency")



## ----echo=FALSE, fig.width=4, fig.height =3, fig.align='center'---------------
library(ggplot2)
plot(Rateprof$easiness, Rateprof$quality, col = "blue",
     xlab = "Easiness Ratings", ylab = "Quality Ratings", main = "Quality vs. Easiness")
plot(Rateprof$pepper, Rateprof$quality, col = "red",
     xlab = "Attractiveness Ratings", ylab = "Quality Ratings", main = "Quality vs. Attractiveness")
ggplot(Rateprof, aes(x=gender, y=quality)) + geom_boxplot() + xlab ("Gender") + ylab("Quality") + ggtitle("Gender v Quality")
plot(Rateprof$discipline, Rateprof$quality, col = "purple",
     xlab = "Discipline", ylab = "Quality Ratings", main = "Quality vs. Discipline")


## -----------------------------------------------------------------------------
library(modelsummary)
library(knitr)
model1 <- lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)
summary_table <- modelsummary(model1, stars = TRUE, gof_map = c("r.squared","nobs","F"))
summary_table

df <- data.frame(Estimate = c("pepperyes", "easiness","gender"), X2.5 = c(0.444077454	,0.476750306,0.004884619), X97.5 = c(0.8665078	,0.6599858,0.2845138))

knitr::kable(df)



## ----echo=FALSE, fig.width=4, fig.height =3, fig.align='center'---------------
reduced_model <- lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)
full_model <- lm(quality ~ easiness + gender + discipline + pepper + easiness * gender + easiness * discipline, data = Rateprof)
reduced_residuals <- residuals(reduced_model)
full_residuals <- residuals(full_model)
plot(reduced_model$fitted.values, reduced_residuals,
     xlab = "Fitted Values", ylab = "Residuals",
     main = "Residuals vs. Fitted Values (Reduced Model)")

qqnorm(reduced_residuals)
qqline(reduced_residuals)



## -----------------------------------------------------------------------------
library(knitr)
library(modelsummary)
reduced_model <- lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)
full_model <- lm(quality ~ easiness + gender + discipline + pepper + easiness * gender + easiness * discipline, data = Rateprof)
partial_F_test <- anova(reduced_model, full_model)
anova_df <- as.data.frame(partial_F_test)
 

df <- data.frame(Model = c("1","2"),Res.df = c(359, 355), RSS = c(153.59,154.05), Df = c("",4), Sum_of_Sq = c("",0.5435863), "F" = c("",0.3131595), "Pr" = c("",0.8691388))
knitr::kable(df)


## -----------------------------------------------------------------------------
library("modelsummary")
models_list <- list("Reduced Model" = reduced_model, "Full Model" = full_model )
modelsummary(models_list, stars = TRUE, gof_map = c("r.squared","nobs","F"))



## ----echo=FALSE, fig.width=4, fig.height =3, fig.align='center'---------------
plot(full_model$fitted.values, full_residuals,
     xlab = "Fitted Values", ylab = "Residuals",
     main = "Residuals vs. Fitted Values (Full Model)")
qqnorm(full_residuals)
qqline(full_residuals)


## -----------------------------------------------------------------------------
df <- data.frame(Model = c("1","2"),Res.df = c(359, 355), RSS = c(153.59,154.05), Df = c("",4), Sum_of_Sq = c("",0.5435863), "F" = c("",0.3131595), "Pr" = c("",0.8691388))
knitr::kable(df)

