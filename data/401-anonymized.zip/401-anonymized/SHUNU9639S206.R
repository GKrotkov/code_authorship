## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, fig.pos = "H", fig.align="center")
library(alr4)
library(ggplot2)
library(broom)
library(cowplot)
library("knitr")


## ---- include = FALSE---------------------------------------------------------
nrow(Rateprof)
ncol(Rateprof)
dim(Rateprof)


## ----fig.width=10,fig.height=5, fig.cap="Distributions of the response and predictors in the data"----
par(mfrow = c(2, 3))
hist(Rateprof$quality, prob = TRUE, 
     xlab = "Average quality rating (1 to 5, 1 lowest, 5 highest)",
     main = "")
hist(Rateprof$easiness, prob = TRUE, 
     xlab = "Average easiness of the class (1 to 5, 1 hardest, 5 easiest)", 
     main = "")
bp1 = barplot(table(Rateprof$gender), names = c("female", "male"),
              xlab = "Gender of professor", ylab = "Count")
text(bp1, 0, table(Rateprof$gender), cex=1, pos=3) 
bp2 = barplot(table(Rateprof$pepper), names = c("no", "yes"),
              xlab = "Professor is attractive?", ylab = "Count")
text(bp2, 0, table(Rateprof$pepper), cex=1, pos=3) 
bp3 = barplot(table(Rateprof$discipline), 
              names = c("Hum", "SocSci", "STEM", "Pre-prof"),
              xlab = "Discipline of professor", ylab = "Count")
text(bp3, 0, table(Rateprof$discipline), cex=1, pos=3) 


## ----fig.width=5,fig.height=4, fig.cap="Pair plot of the response and predictors in the data"----
pairs(quality ~ easiness + gender + pepper + discipline, data = Rateprof, 
      pch = 16, cex = 0.7)


## ----fig.width=8.5,fig.height=3, fig.cap="Side-by-side boxplots of the response and factor predictors in the data"----
par(mfrow = c(1,3))
boxplot(quality ~ gender, ylab = "Average quality rating", data = Rateprof, 
        xlab = "Gender of professor", names = c("female", "male"), pch = 16)
boxplot(quality ~ pepper, ylab = "Average quality rating", data = Rateprof,
        xlab = "The professor is attractive?", names = c("no","yes"), pch = 16)
boxplot(quality ~ discipline, ylab = "Average quality rating", data = Rateprof,
        xlab = "The discipline of professor", 
        names = c("Hum", "SocSci", "STEM", "Pre-prof"), pch = 16)


## ----fig.width=4,fig.height=3, fig.cap="The distribution of square of average quality rating"----
hist((Rateprof$quality)^2, prob = TRUE, main = "", cex.lab = 0.7, 
     xlab = "Square of average quality rating (1 to 25, 1 lowest, 25 highest)")


## ---- include=FALSE-----------------------------------------------------------
# RQ1: if quality associates with easiness; gender; pepper; discipline
full = lm((quality)^2 ~ easiness + gender + pepper + discipline, 
          data = Rateprof)


## ---- fig.width=5, fig.height=2.5, fig.cap="Residuals from the model, plotted against class easiness and fitted values."----
rp1 = ggplot(augment(full), 
             aes(x = easiness, y = .resid)) + 
  geom_point() +
  labs(x = "Class easiness (1 to 5, 1=hardest, 5=easiest)", 
       y = "Residuals") +
  theme(axis.title = element_text(size = 7))  

rp2 = ggplot(augment(full), 
             aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted Values", y = "Residuals") +
  theme(axis.title = element_text(size = 7))   

plot_grid(rp1, rp2)


## ---- fig.width=4, fig.height=2, fig.cap="Cook's distances plotted against fitted values."----
ggplot(augment(full), aes(x = .fitted, y = .cooksd)) + 
  geom_point() +
  labs(x = "Fitted value", y = "Cook's distance")


## ---- fig.width=4, fig.height=2, fig.cap="Cook's distances plotted against fitted values."----
ggplot(augment(full), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantile", y = "Sample quantile")


## ---- include=FALSE-----------------------------------------------------------
# RQ2: if quality ~ easiness depend on gender + discipline 
full_new = lm((quality)^2 ~ easiness * gender + easiness * discipline, 
              data = Rateprof)


## ---- fig.width=5, fig.height=2.5, fig.cap="Residuals from the model, plotted against class easiness and fitted values."----
rp1 = ggplot(augment(full_new), 
             aes(x = easiness, y = .resid)) + 
  geom_point() +
  labs(x = "Class easiness (1 to 5, 1=hardest, 5=easiest)", 
       y = "Residuals") +
  theme(axis.title = element_text(size = 7))  

rp2 = ggplot(augment(full_new), 
             aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted Values", y = "Residuals") +
  theme(axis.title = element_text(size = 7))   

plot_grid(rp1, rp2)


## ---- fig.width=4, fig.height=2, fig.cap="Cook's distances plotted against fitted values."----
ggplot(augment(full_new), aes(x = .fitted, y = .cooksd)) + 
  geom_point() +
  labs(x = "Fitted value", y = "Cook's distance")


## ---- fig.width=4, fig.height=2, fig.cap="Cook's distances plotted against fitted values."----
ggplot(augment(full_new), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantile", y = "Sample quantile")


## ---- include=FALSE-----------------------------------------------------------
summary(full)
confint(full, "easiness")
confint(full, "gendermale")
confint(full, "pepperyes")


## -----------------------------------------------------------------------------
d3 <- data.frame("Estimate" = rep(c(3.95,0.98,4.89)),
                "t-value" = rep(c(12.46, 2.02, 6.68)),
                "p-value" = rep(c("<2e-16", 0.04, "9.06e-11")),
                "Confidence interval" = rep(c("[3.33, 4.58]",
                                              "[0.02, 1.93]",
                                              "[3.45, 6.33]")),
                "Degree of freedom" = rep(c(359, 359, 359)),
                row.names = rep(c("easiness", "genderMale", "isAttractive")))
kable(d3, caption = "Test outputs and 95% confidence intervals")


## ---- include=FALSE-----------------------------------------------------------
## quality ~ discipline
red3 = lm((quality)^2 ~ easiness + gender + pepper, data = Rateprof)
anova(red3, full)


## -----------------------------------------------------------------------------
d <- data.frame("Res.Df" = rep(c(362,359)),
                "RSS" = rep(c(7270, 7174)),
                "Df" = rep(c("", 3)),
                "Sum of Sq" = rep(c("", 95.45)),
                "F" = rep(c("", 1.59)),
                "p" = rep(c("", 0.19)),
                row.names = rep(c("reduced model", "full model")))
kable(d, caption = "Test result of partial F test")


## ---- include=FALSE-----------------------------------------------------------
# RQ2: if quality ~ easiness depend on gender + discipline 
## partial F-test -> test if quality ~ easiness differ at all across gender & discipline
full_new = lm((quality)^2 ~ easiness * gender + easiness * discipline, data = Rateprof)
red_new1 = lm((quality)^2 ~ easiness, data = Rateprof)
anova(red_new1, full_new)


## -----------------------------------------------------------------------------
d <- data.frame("Res.Df" = rep(c(364,356)),
                "RSS" = rep(c(8231, 8050)),
                "Df" = rep(c("", 8)),
                "Sum of Sq" = rep(c("", 180.57)),
                "F" = rep(c("", 1.00)),
                "p" = rep(c("", 0.44)),
                row.names = rep(c("reduced model", "full model")))
kable(d, caption = "Test result of partial F test")

