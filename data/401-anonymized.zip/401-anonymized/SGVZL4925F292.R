## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE, fig.height=3)
library('ggplot2')
library('MASS')
library('broom')
data <- read.csv("./cmu-sleep.csv")
data$hours = data$TotalSleepTime/60
data$loghrs = log(data$hours)


## -----------------------------------------------------------------------------
ggplot(data=data, aes(x=hours))+ geom_histogram(bins=20) + ggtitle("F1. Marginal Distribution of Sleep Times (in hours)", subtitle="Histogram of marginal distribution of student sleep times during the spring semester.")


## ---- warning=FALSE-----------------------------------------------------------
ggplot(data=data, aes(x=cum_gpa))+ geom_histogram(bins=20) + ggtitle("F2. Marginal Distribution of Fall GPA")



## -----------------------------------------------------------------------------
ggplot(data=data, aes(x=term_gpa))+ geom_histogram(bins=20) + ggtitle("F3. Marginal Distribution of Spring GPA", subtitle="Histogram of marginal distribution of student GPA during the spring semester.")


## -----------------------------------------------------------------------------
ggplot(data=data,aes(x=(hours), y=(term_gpa))) +
  labs(title="F4. Spring Semester GPA v. Sleep Times", subtitle="Conditional distribution of spring GPA given spring sleep time in hours.") +
  ylab("Spring Semester GPA")+ 
  xlab("Sleep Time (hours)")+
  geom_point() 


## -----------------------------------------------------------------------------
ggplot(data=data,aes(y=(cum_gpa), x=(hours)))+
  ggtitle("F5. Fall Semester GPA v. Sleep Times", subtitle="Conditional distribution of fall GPA given spring sleep time in hours.") +
  ylab("Fall Semester GPA")+ 
  xlab("Sleep Time (hours)")+
  geom_point() 


## -----------------------------------------------------------------------------
ggplot(data=data,aes(x=(cum_gpa), y=(term_gpa)))+
  ggtitle("F6. Spring Semester GPA v. Fall Semester GPA", subtitle = "Conditional distribution of spring GPA given fall GPA.") +
  ylab("Spring Semester GPA")+ 
  xlab("Fall Semester GPA")+
  geom_point() 


## -----------------------------------------------------------------------------
gpa_sleep_model <- lm((term_gpa) ~ hours, data=data)
summary(gpa_sleep_model)


## -----------------------------------------------------------------------------
augment(gpa_sleep_model) |>
ggplot(aes(x = hours, y = .cooksd)) +
geom_point() +
labs(x = "Hours Slept", y = "Cook's distance")+
ggtitle("F7. Cook's distance of points", subtitle = "Cook's distance of points (proportional to leverage a given point has on the value of the model coefficients) given predictor variable.")


## -----------------------------------------------------------------------------
augment(gpa_sleep_model) |>
ggplot(aes(x = hours, y = .resid)) +
geom_point() +
labs(x = "Hours Slept", y = "Residual")+
ggtitle("F8. Residual Plot", subtitle="Plot of residuals against predictor variable for our first linear model.")


## -----------------------------------------------------------------------------
model <- lm(term_gpa ~ hours + cum_gpa, data=data)
summary(model)


## -----------------------------------------------------------------------------
augment(model) |>
ggplot(aes(x = hours, y = .cooksd)) +
geom_point() +
labs(x = "Hours Slept", y = "Cook's distance")+
ggtitle("F9. New Cook's Distance Plot", subtitle = "Cook's distance of points (proportional to leverage a given point has on the value of the model coefficients) given predictor variable.")


## -----------------------------------------------------------------------------
augment(model) |>
ggplot(aes(x = hours, y = .resid)) +
geom_point() +
labs(x = "Hours Slept", y = "Residual")+
ggtitle("F10. New Residual Plot", subtitle="Plot of residuals against one predictor variable for the new linear model.")


## ---- fig.height=4------------------------------------------------------------
ggplot(data=model, aes(sample=residuals(model))) + 
  stat_qq_line()+
  stat_qq()+
  ggtitle("F11. QQ Plot", subtitle="Quantile-Quantile plot examining the normal distribution of our residuals.")

