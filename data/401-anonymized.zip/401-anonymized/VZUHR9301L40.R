## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
sleep_data <- read.csv("cmu-sleep.csv")
library(dplyr)
library(gridExtra)
library(ggplot2)
library(modelsummary)
library(kableExtra)


## -----------------------------------------------------------------------------
par(mfrow=c(1,3))

hist(sleep_data$term_gpa,
     breaks = 20,
     main = "",
     xlab = "Term GPA (Out of 4.0)",
     ylab = "Number of Students")

hist(sleep_data$TotalSleepTime,
     breaks = 20,
     main = "",
     xlab = "Total Sleep Time (in Minutes)",
     ylab = "Number of Students")

hist(sleep_data$cum_gpa,
     breaks = 20,
     main = "",
     xlab = "Cumulative GPA (Out of 4.0)",
     ylab = "Number of Students")


## ---- eval = FALSE------------------------------------------------------------
## # For `Total Sleep Time`:
## summary(sleep_data$TotalSleepTime)
## 
## # For `Term GPA`:
## summary(sleep_data$term_gpa)
## 
## # For `Cumulative QPA`:
## summary(sleep_data$cum_gpa)


## ---- out.width="50%"---------------------------------------------------------

plot(term_gpa ~ TotalSleepTime, # y~x
     data = sleep_data,
     xlab = "Total Sleep Time (in Minutes)",
     ylab = "Term GPA")

plot(term_gpa ~ cum_gpa, # y~x
     data = sleep_data,
     xlab = "Cumulative GPA",
     ylab = "Term GPA")


## ---- out.width="50%", fig.align="center"-------------------------------------
sleep_data$trans.TermGPA <- (sleep_data$term_gpa)^3

hist(sleep_data$trans.TermGPA,
        breaks = 20,
        main = "",
        xlab = "Term GPA^3",
        ylab = "Number of Students")


## ---- out.width="50%"---------------------------------------------------------

plot(term_gpa^3 ~ TotalSleepTime, # y~x
     data = sleep_data,
     xlab = "Total Sleep Time (in Minutes)",
     ylab = "Term GPA^3")

plot(term_gpa^3 ~ cum_gpa, # y~x
     data = sleep_data,
     xlab = "Cumulative GPA",
     ylab = "Term GPA^3")


## ---- echo = FALSE------------------------------------------------------------
GPA.sleep.mod2 <- lm(term_gpa^3 ~
                      TotalSleepTime + cum_gpa,
                      data = sleep_data)


## -----------------------------------------------------------------------------
plot(GPA.sleep.mod2, which = 1, main="")


## -----------------------------------------------------------------------------
plot(GPA.sleep.mod2, which = 2, main="")


## -----------------------------------------------------------------------------
result <- data.frame(
  Variable = c("(Intercept)", "Total Sleep Time", "Cumulative GPA"),
  Estimate = c("-45.213081", "0.033152", "21.774544"),
  `sd.dev` = c("4.683715", "0.008738", "1.015543"),
  `Confidence Interval` = c("[−54.411, −36.016]", "[0.016, 0.050]", "[19.780, 23.769]"),
  `p-value` = c("< 2e-16", "0.000162", "< 2e-16")
)

kable(result, align = "c", escape = FALSE)


## ---- eval = FALSE------------------------------------------------------------
## newdata <- data.frame(TotalSleepTime = c(4*60, 6*60, 8*60), cum_gpa = c(3.5, 3.5, 3.5))
## 
## predicted_gpa_cubed <- predict(GPA.sleep.mod2, newdata)
## 
## predicted_gpa_cubed^(1/3)
## 
## # 8->6h: 0.104977
## # 6->4h: 0.111679


## ---- eval = FALSE------------------------------------------------------------
## summary(GPA.sleep.mod2)


## ---- eval = FALSE------------------------------------------------------------
## modelsummary(GPA.sleep.mod2,
##              statistic = c("conf.int",
##                            "s.e. = {std.error}",
##                            "p = {p.value}"),
##              gof_map = c("r.squared", "nobs"))


## ---- echo = FALSE------------------------------------------------------------
GPA.sleep.mod <- lm(term_gpa ~
                      TotalSleepTime + cum_gpa,
                      data = sleep_data)

cookd_df <- data.frame(cookd = cooks.distance(GPA.sleep.mod)) %>%
  arrange(desc(cookd))

n <- length(cooks.distance(GPA.sleep.mod))
f_20th <- qf(0.2, df1 = 2, df2 = n - 2)
f_50th <- qf(0.5, df1 = 2, df2 = n - 2)

concern_points <- cookd_df %>% filter(cookd > f_50th)
between_20_50_points <- cookd_df %>% filter(cookd > f_20th & cookd < f_50th)


## ---- eval = FALSE------------------------------------------------------------
## summary(GPA.sleep.mod)

