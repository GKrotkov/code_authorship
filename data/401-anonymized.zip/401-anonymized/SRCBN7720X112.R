## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(broom)
library(knitr)


## -----------------------------------------------------------------------------
data.df = read.csv("~/Downloads/cmu-sleep.csv")



## ---- fig.align = 'center', fig.width=5, fig.height=3, fig.cap="Frequency Histogram of Total Sleep Time"----
hist(data.df$TotalSleepTime, xlab = "Total Sleep Time (Minutes)", 
     main = "Frequency Distribution of Total Sleep Time")


## ---- fig.align = 'center', fig.width=5, fig.height=3, fig.cap="Frequency Histogram of Term GPA"----
hist(data.df$term_gpa, xlab = "Term GPA, Out of 4.0 (Points)", 
     main = "Frequency Distribution of Term GPA")


## ---- fig.align = 'center', fig.width=5, fig.height=2.5, fig.cap="Frequency Histogram of cum GPA"----
hist(data.df$cum_gpa, xlab = "Cum GPA, Out of 4.0 (Points)", 
     main = "Frequency Distribution of Cum GPA")


## ---- fig.align = 'center', fig.width=5, fig.height=3, fig.cap="Figure of Term GPA vs Total Sleep Time"----
plot(term_gpa ~ TotalSleepTime ,data = data.df, 
     ylab = "Term GPA (Points)", xlab = "Total Sleep Time (Minutes)", 
     main = "Term GPA vs Total Sleep Time")


## ---- fig.align = 'center', fig.width=5, fig.height=3, fig.cap="Figure of Term GPA vs Cum GPA"----
plot(term_gpa ~ cum_gpa ,data = data.df, 
     xlab = "Cum GPA (Points)", ylab = "Term GPA (Points)", 
     main = "Term GPA vs Cum GPA")


## -----------------------------------------------------------------------------
mod = lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data.df)


## -----------------------------------------------------------------------------
multicol.mod = lm(TotalSleepTime ~ cum_gpa, data = data.df)
multicol.out = tidy(multicol.mod)
multicol.R2 = glance(multicol.mod)$r.squared
kable(multicol.out, caption = paste("Summary Output Linear Model: Total Sleep Time vs cum GPA ", 
                                   "R-squared:", round(multicol.R2, 5)))


## ---- fig.align = 'center', fig.width=4, fig.height=3, fig.cap="Residual Plot of Regression Model, Fails Independence Check"----
plot(mod, which = 1, main = "Residual vs Fitted for Regression Model")


## ---- fig.align = 'center', fig.width=4, fig.height=2.5, fig.cap="Q-Q Residuals Plot of Regression Model, Fails Normality Check"----
plot(mod, which = 2)


## -----------------------------------------------------------------------------
# Eliminating "outliers"
cooks.d.mod = cooks.distance(mod)
outliers = which(cooks.d.mod > 4/634)
cleaned.data.df = data.df[-outliers, ]
# New regression model without outliers
cleaned.mod = lm(term_gpa ~ TotalSleepTime + cum_gpa, data = cleaned.data.df)


## ---- fig.align = 'center', fig.width=4, fig.height=3, fig.cap="Residual Plot of Cleaned Regression Model"----
plot(cleaned.mod, which = 1, main = "Residual vs Fitted for Cleaned Model")


## ---- fig.align = 'center', fig.width=4, fig.height=2.5, fig.cap="Q-Q Residuals Plot of Cleaned Regression Model"----
plot(cleaned.mod, which = 2, main = "Q-Q Residuals for Cleaned Model")


## -----------------------------------------------------------------------------
multicol.clean.out = tidy(cleaned.mod)
multi.clean.R2 = glance(cleaned.mod)$r.squared
multi.df = glance(cleaned.mod)$df.residual
kable(multicol.clean.out, caption = paste("Summary Output Multiple Regression Model", 
                                   "R-squared:", round(multi.clean.R2, 5), 
                                   "Degrees of Freedom:", multi.df))


## ---- output = FALSE----------------------------------------------------------
library(dplyr)
# Construct 95% CI 
CI = confint(cleaned.mod, "TotalSleepTime", level = 0.95)
CI = round(CI, 5)
CI.df = as.data.frame(CI) %>%
  rename(Lower_Bound = '2.5 %') %>%
  rename(Upper_Bound = '97.5 %')
  
kable(CI.df, caption = paste("95% Confidence Interval for Total Sleep Time Controlling Cum GPA in Points per Minute", 
                             "Point Estimate: ", 0.00064))


## -----------------------------------------------------------------------------
# Multiply everything by 120
beta1_est = 0.00064 * 120
CI.df = CI.df * 120
kable(CI.df, caption = paste("95% Confidence Interval for Total Sleep Time Controlling Cum GPA in Points per 2 hours", 
      "Point estimate: ", beta1_est))

