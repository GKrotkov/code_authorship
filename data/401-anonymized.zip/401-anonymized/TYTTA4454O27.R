## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
rm(list=ls())
library(tidyverse)
library(ggplot2)
library(alr4)
library(broom)
library(dplyr)
library(gridExtra)
library(kableExtra)
library("ggpubr")
library(bestglm)

rateprof <- Rateprof %>% select(gender, pepper, easiness, discipline, quality)


## ---- fig.cap = "Univariate Distributions", message = F, fig.width = 7, fig.height = 3----
easy  <- rateprof %>% ggplot(aes(x = easiness)) + 
  geom_histogram(fill = "navy") + 
  labs(x = "Easiness", y = "Count")

disc <- rateprof %>% ggplot(aes(x = discipline, fill = discipline)) + 
  geom_bar(show.legend = F) + 
  labs(x = "Discipline", y = "Count")

quality <- rateprof %>% ggplot(aes(x = quality)) + 
  geom_histogram(fill = "forestgreen") + 
  labs(x = "Quality", y = "Count")

ggarrange(easy,disc,quality, nrow = 1, labels = c("A", "B", "C"))


## ---- fig.cap = "Predictor Relationships with Quality", fig.width = 6.5, fig.height =  4----
genderplot <- rateprof %>% ggplot(aes(x = gender, y = quality, fill = gender)) + 
  geom_boxplot(show.legend = F)  +  
  labs(x = "Gender", y  = "Quality") +  
  scale_fill_manual(values = c("pink", "lightblue"))

pepperplot <- rateprof %>% ggplot(aes(x = pepper, y = quality, fill = pepper)) + 
  geom_boxplot(show.legend = F)  +  
  labs(x = "Attractive?", y  = "Quality") +  
  scale_fill_manual(values = c("darkgrey", "maroon"))

disciplineplot <- rateprof %>% ggplot(aes(x = discipline, y = quality, fill = discipline)) + 
  geom_boxplot(show.legend = F)  +  
  labs(x = "Discipline", y  = "Quality") 

ggarrange(genderplot, pepperplot, disciplineplot, nrow = 1, labels = c("A", "B", "C"))


## ---- fig.cap = "Easiness and Quality, by Discipline and Gender", fig.width = 5, fig.height = 3----
rateprof %>% ggplot(aes(x = easiness, y = quality, col = discipline)) + 
  geom_point() + 
  facet_wrap(~gender) + 
  labs(x="Easiness, with 1 = Most Difficult and 5 = Easiest", 
       y="Quality, with 1 = Worst and 5 = Best",
       col = "Discipline")


## -----------------------------------------------------------------------------
qfull.lm <- lm(quality ~ pepper + easiness + gender + discipline + easiness:gender:discipline , data = rateprof)
qred.lm <- lm(quality ~ pepper + easiness + gender + discipline , data = rateprof)


## ---- fig.cap = "Residual and QQ Plots", fig.width = 3, fig.height = 4, results = "hide"----
res <- plot(qfull.lm, which = 1)
qq <- plot(qfull.lm, which = 2)

res + qq


## ---- include = F-------------------------------------------------------------
cooks.d <- cooks.distance(qfull.lm)
cooks.d %>% sort(decreasing = T) %>% head()


## ----include = F--------------------------------------------------------------
car::vif(qred.lm)


## -----------------------------------------------------------------------------
anova.res <- anova(qred.lm, qfull.lm) %>% tidy()
anova.res[1,1] <- "Reduced Model"
anova.res[2,1] <- "Full Model"


## ---- fig.cap = "ANOVA Partial F-Test Output"---------------------------------
anova.res %>%  kable(col.names = 
          c("Term", "Residual df", "RSS", "df", "Sum of Sq", " Statistic", "p-value"),  
          caption = "Partial F-Test Results") %>%  
  row_spec(0, bold = TRUE) %>% kable_styling() 


## ---- fig.cap = "Regression Model Output"-------------------------------------
qred.lm %>%
  tidy() %>%
  kable(col.names = c("Term", "Estimate", "St. Error", "Test Statistic", "p-value"),
        digits = c(0,4,4,4, 10),
        caption = "Regression Output and T-Test Results") %>%  
  row_spec(0, bold = TRUE) %>% kable_styling()

