## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, message=FALSE-----------------------------------------------
library(ggplot2)
library(tidyverse)
library(alr4)
library(modelsummary)
library(car)
library(cowplot)


## ---- echo=FALSE, fig.width=4, fig.height=3, message=FALSE, fig.cap="Figure 1"----
rate<-Rateprof
rate2<-select(rate, c("quality","pepper", "easiness", "discipline", "gender"))
ggplot(data=rate2)+geom_histogram(aes(x=easiness))+ggtitle("Histogram of Class Difficulty(1-5)")


## ---- echo=FALSE, fig.cap="Figure 2"------------------------------------------
ggplot(data=rate2)+geom_histogram(aes(x=easiness), color="Black", binwidth=1/3)+facet_wrap(~discipline)+ggtitle("Histograms of Easiness by Discipline")


## ---- echo=FALSE, fig.cap="Figure 3"------------------------------------------
ggplot(data=rate2)+geom_histogram(aes(x=easiness), color="Black", binwidth=1/3)+facet_wrap(~gender)+ggtitle("Histogram of Easiness by Gender")

## ---- echo=FALSE, fig.cap="Figure 4"------------------------------------------
ggplot(data=rate2)+geom_histogram(aes(x=easiness), color="Black", binwidth=1/3)+facet_wrap(~pepper)+ggtitle("Histograms of Easiness by Attractiveness")

## ---- echo=FALSE--------------------------------------------------------------
mean_d<-rate2%>%group_by(discipline)%>%summarise(means<-mean(easiness))
mean_g<-rate2%>%group_by(gender)%>%summarise(means<-mean(easiness))
mean_p<-rate2%>%group_by(pepper)%>%summarise(means<-mean(easiness))


## ---- echo=FALSE, fig.cap="Figure 5"------------------------------------------
ggplot(data=rate2)+geom_point(aes(x=easiness, y=quality))+ggtitle("Scatterplot of Easiness(1-5) vs. Quality(1-5) Grouped by Discipline")+geom_smooth(aes(x=easiness, y=quality), method=lm, formula=y~x)+facet_wrap(~discipline)

## ---- echo=FALSE, fig.cap="Figure 6"------------------------------------------
ggplot(data=rate2)+geom_point(aes(x=easiness, y=quality))+ggtitle("Scatterplot of Easiness(1-5) vs. Quality(1-5) Grouped by Gender")+geom_smooth(aes(x=easiness, y=quality), method=lm, formula=y~x)+facet_wrap(~gender)


## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
m1<-lm(data=rate2, quality~pepper+easiness+gender+discipline)

m2<-lm(data=rate2, quality~easiness*gender+easiness*discipline+pepper)

m3<-lm(data=rate2, quality~easiness*gender+discipline+pepper)

m4<-lm(data=rate2, quality~easiness*discipline+gender+pepper)


invisible(residualPlot(m1)+title("Model 1 Residual Plot"))

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
invisible(residualPlot(m2)+title("Model 2 Residual Plot"))

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
invisible(residualPlot(m3)+title("Model 3 Residual Plot"))

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
invisible(residualPlot(m4)+title("Model 4 Residual Plot"))

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
qqPlot(m1, id=F, xlab="Model 1 Residuals")

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
qqPlot(m2, id=F, xlab="Model 2 Residuals")

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
qqPlot(m3, id=F, xlab="Model 3 Residuals")

## ----echo=FALSE, fig.width=3, fig.height=3------------------------------------
qqPlot(m4, id=F, xlab="Model 4 Residuals")


## ---- echo=FALSE--------------------------------------------------------------
#F-tests comparing model w/ no interactions to 3 different models 1 with interactions of discipline and gender, 1 with just a gender interaction, and the other with just a discipline interaction, including all other variables of interest with no interactions.
#Summaries for reference
s1<-summary(m1)
s2<-summary(m2)
s3<-summary(m3)
s4<-summary(m4)

#Sum of Squares
SS1<-sum(residuals(m1)^2)
SS2<-sum(residuals(m2)^2)
SS3<-sum(residuals(m3)^2)
SS4<-sum(residuals(m4)^2)

#F-stats
Fstat1<-((SS1-SS2)/(df.residual(m1)-df.residual(m2)))/(SS2/df.residual(m2))
Fstat2<-((SS1-SS3)/(df.residual(m1)-df.residual(m3)))/(SS3/df.residual(m3))
Fstat3<-((SS1-SS4)/(df.residual(m1)-df.residual(m4)))/(SS4/df.residual(m4))

#P-vals
pval1<-1-pf(Fstat1, df.residual(m1)-df.residual(m2), df.residual(m2))
pval2<-1-pf(Fstat2, df.residual(m1)-df.residual(m3), df.residual(m3))
pval3<-1-pf(Fstat3, df.residual(m1)-df.residual(m4), df.residual(m4))


row2 <- data.frame("Coefficients" = "F-Test P-Value",
                  "Model 1" = "", "Model 2" = pval1, "Model 3"= pval2, "Model 4"=pval3 )

attr(row2, "position") <- 1
modelsummary(list("Model 1"=m1, "Model 2"=m2, "Model 3"=m3, "Model 4"=m4), gof_map=NA, fmt=fmt_decimal(digits=4), add_rows=row2)


