## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE, message=FALSE, warning=FALSE-----------------------------
library(ggplot2)
library(readr)
library(alr4)
library(regressinator)
library(tidyverse)
library(dplyr)
library(knitr)
library(broom)
sleep <- read_csv("cmu-sleep.csv")


## ---- fig.height=4, fig.width=12, fig.cap="Histograms of response (left), predictor (middle), and exp transform of predictor (right) variables"----
par(mfrow = c(1,3))
hist(sleep$TotalSleepTime,
     main = "Histogram of Total Sleep Time",
     xlab = "Total sleep time, in minutes",
     ylab = "Number of students"
)
hist(sleep$term_gpa,
     main = "Histogram of GPA (current semester)",
     xlab = "GPA, out of 4.0",
     ylab = "Number of students"
)
hist(exp(sleep$term_gpa),
     main = "Histogram of exp(GPA) (current semester)",
     xlab = "exp of GPA",
     ylab = "Number of students"
)


## ---- fig.height=4, fig.width=12, fig.cap="Scatter plot of term_gpa vs. TotalSleepTime"----
par(mfrow = c(1,2))
plot(sleep$TotalSleepTime, sleep$term_gpa, pch = 20,
     main = "Scatterplot of Term GPA vs. Total Sleep Time",
     xlab = "Total sleep time, in minutes",
     ylab = "GPA, out of 4.0"
)
plot(sleep$TotalSleepTime, exp(sleep$term_gpa), pch = 20,
     main = "Scatterplot of exp of Term GPA vs. Total Sleep Time",
     xlab = "Total sleep time, in minutes",
     ylab = "exp of GPA"
)


## ---- include=FALSE, message=FALSE, warning=FALSE-----------------------------
lm1 <- lm(term_gpa ~ TotalSleepTime, data = sleep)
summary(lm1)

lm2 <- lm(exp(term_gpa) ~ TotalSleepTime, data = sleep)
summary(lm2)


## ---- fig.cap="Residual assumption diagnostic plots"--------------------------
par(mfrow = c(2,2))
plot(lm1)


## -----------------------------------------------------------------------------
res <- summary(lm1)
tidy(res)


## -----------------------------------------------------------------------------
# 0.001984649 * -120
# confint(lm1, "TotalSleepTime", level = 0.95) * -120

