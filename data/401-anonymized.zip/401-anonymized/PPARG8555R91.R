## -----------------------------------------------------------------------------
data = read.csv("/Users/leonadu/Documents/CMU/2023 fall/36401/cmu-sleep.csv")


## -----------------------------------------------------------------------------
hist(data$TotalSleepTime, main = "Distribution of TotalSleepTime", xlab = "TotalSleepTime (minutes)")


## -----------------------------------------------------------------------------
hist(data$term_gpa, main = "Distribution of Term GPA", xlab = "Term GPA")


## -----------------------------------------------------------------------------
hist(data$cum_gpa, main = "Distribution of Cumulative GPA", xlab = "Cumulative GPA")


## -----------------------------------------------------------------------------
data$gpa_change <- data$term_gpa - data$cum_gpa
hist(data$gpa_change, main = "Distribution of GPA Change", xlab = "GPA Change (term_gpa - cum_gpa)")


## -----------------------------------------------------------------------------
plot(data$TotalSleepTime, data$term_gpa, main = "TotalSleepTime vs. Term GPA", xlab = "TotalSleepTime (minutes)", ylab = "Term GPA")


## -----------------------------------------------------------------------------
plot(data$TotalSleepTime, exp(data$term_gpa), main = "TotalSleepTime vs. Term GPA", xlab = "TotalSleepTime (minutes)", ylab = "Term GPA")


## -----------------------------------------------------------------------------
lm_term_gpa <- lm(term_gpa ~ TotalSleepTime, data = data)
summary(lm_term_gpa)
confint(lm_term_gpa, "TotalSleepTime", level = 0.95)


## -----------------------------------------------------------------------------
lm_trans_term_gpa <- lm(exp(term_gpa) ~ TotalSleepTime, data = data)
summary(lm_trans_term_gpa)$r.squared


## -----------------------------------------------------------------------------
multi_reg <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)
summary(multi_reg)
confint(multi_reg, "TotalSleepTime", level = 0.95)
confint(multi_reg, "cum_gpa", level = 0.95)

