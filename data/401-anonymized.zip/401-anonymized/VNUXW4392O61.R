## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE,fig.align = "center",fig.width=4,fig.height=3)


## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
library(data.table)
library(dplyr)    
library(modelsummary)
library(broom)
library(kableExtra)
setwd("C:/Users/chen_/Desktop/36401/data_exam_1")
sleep <- fread("cmu-sleep.csv")


## ----sleep, include=FALSE-----------------------------------------------------
summary(sleep)
head(sleep)


## -----------------------------------------------------------------------------
sleep_segment <- sleep[, c("TotalSleepTime", "term_gpa", "cum_gpa")]
key_stats <- summary(sleep_segment)
knitr::kable(key_stats, digits = 2,caption = "Descriptive Statistics of Sleep Data")%>%
  kable_styling(position = "center",latex_options = "HOLD_position")
# Citation of kable_styling: https://stackoverflow.com/questions/53153537/rmarkdown-setting-the-position-of-kable


## ---- echo=FALSE,fig.width=4,fig.height=2.5-----------------------------------
ggplot(sleep,aes(x=`TotalSleepTime`))+
      ggtitle("Count of TotalSleepTime")+
      geom_histogram(binwidth=8,fill = "navy")+
      labs(x= "TotalSleepTime (min)", y = "count",caption="Fig 1.1 Histogram of the count of TotalSleepTime (min)")


## ---- echo=FALSE,fig.width=5,out.width='.49\\linewidth',fig.height=3----------
ggplot(sleep,aes(x=`term_gpa`))+
      geom_histogram(binwidth=0.03,fill = "navy")+
      ggtitle("Count of TermGPA")+
      labs(x= "term_gpa (out of 4.0)", y = "count",caption="Fig 1.2 Histogram of the count of Term GPA (out of 4.0)")
ggplot(sleep,aes(x=log(`term_gpa`)))+
      geom_histogram(binwidth=0.03,fill = "navy")+
      ggtitle("Count of log(TermGPA)")+
      labs(x= "log(term_gpa)", y = "count",caption="Fig 1.3 Histogram of the count of Log(Term GPA) (out of 4.0)")
ggplot(sleep,aes(x=exp(`term_gpa`)))+
      geom_histogram(binwidth=0.5,fill = "navy")+
      ggtitle("Count of exp(TermGPA)")+
      labs(x= "exp(term_gpa)", y = "count",caption="Fig 1.4 Histogram of the count of Exp(Term GPA) (out of 4.0)")


## ---- message=FALSE,fig.width=5,fig.height=3----------------------------------
ggplot(sleep,aes(x=`cum_gpa`))+
      geom_histogram(binwidth=0.03,fill = "navy")+
      ggtitle("Count of CumGPA")+
      labs(x= "cum_gpa (out of 4.0)", y = "count",caption="Fig 1.5 Histogram of the count of Cum GPA (out of 4.0)")


## ---- echo=FALSE, out.width='.49\\linewidth', fig.width=4, fig.height=3,fig.show='hold',fig.align='center'----
ggplot(sleep,aes(x=`TotalSleepTime`,y=(`term_gpa`)))+
      geom_point(color = 'navy')+ggtitle("Term GPAs v.s. Total Sleep Time (min)")+
      labs(x= "Total Sleep Time (min)", y = "Term GPAs (out of 4.0)",
          caption="Fig 1.6 Scatterplot: Total sleep time v.s. Term GPA")+
      stat_smooth(method = "lm",formula = y ~ x,geom = "smooth")
ggplot(sleep,aes(x=`TotalSleepTime`,y=log(`term_gpa`)))+
      geom_point(color = 'navy')+ggtitle("Log Term GPAs v.s. Total Sleep Time (min)")+
      labs(x= "Total Sleep Time (min)", y = "Log Term GPAs (out of 4.0)",
           caption="Fig 1.7 Scatterplot: Total sleep time v.s. Log Term GPA")+
      stat_smooth(method = "lm",formula = y ~ x,geom = "smooth")
ggplot(sleep,aes(x=`TotalSleepTime`,y=exp(`term_gpa`)))+
      geom_point(color = 'navy')+ggtitle("Exp Term GPAs v.s. Total Sleep Time (min)")+
      labs(x= "Total Sleep Time (min)", y = "Exponential of Term GPAs (out of 4.0)"
           ,caption="Fig 1.8 Scatterplot: Total sleep time v.s. Exp Term GPA")+
      stat_smooth(method = "lm",formula = y ~ x,geom = "smooth")
model1 <- lm(`term_gpa` ~ `TotalSleepTime`,data = sleep)
model2 <- lm(exp(`term_gpa`) ~ `TotalSleepTime`,data = sleep)
model3 <- lm(log(`term_gpa`) ~ `TotalSleepTime`,data = sleep)



## ---- echo=FALSE--------------------------------------------------------------
ggplot(sleep,aes(x=`cum_gpa`,y=(`term_gpa`)))+
      geom_point(color = 'navy')+ggtitle("Term GPAs v.s. Cum GPAs")+
      labs(x= "Cum GPAs (out of 4.0)", y = "Term GPAs (out of 4.0)",
      caption="Fig 1.9 Scatterplot: Term GPAs v.s. Cum GPAs")+
      stat_smooth(method = "lm",formula = y ~ x,geom = "smooth")
model4 <- lm((`term_gpa`) ~ `cum_gpa`,data = sleep)
model5 <- lm((`term_gpa`) ~ `TotalSleepTime`+`cum_gpa`,data = sleep)


## ----echo=FALSE---------------------------------------------------------------
modelsummary(list("1.no_transform" = model1, "2.exp_termGPA" = model2,"3.log_termGPA" = model3,"4.GPAs" = model4,"5.multiregression" = model5),
             statistic= c("t(632) = {statistic}","se = {std.error}",
                          "conf.int",'p={p.value}'), 
             conf_level = 0.95, title = 'Summary of Models',
             gof_map = c("r.squared", "nobs"))%>%
  kable_styling(latex_options = "HOLD_position")
# Citation for code in modelsummary: https://cran.r-project.org/web/packages/modelsummary/modelsummary.pdf



## ----echo=FALSE,fig.width=6,fig.height=3--------------------------------------
cookd <- cooks.distance(model2)
plot(cookd, type = "h", main = "Cook's Distance", ylab = "Cook's D")
abline(h = 0.01, col = "red") 
mtext("Fig 2.1 Cook's Distance for model on TotalSleepTime and Exp Term GPA", side = 1, line = 4)


## ----echo=FALSE---------------------------------------------------------------
ggplot(model2,aes(x=`TotalSleepTime`,y=.resid))+
geom_point(color = 'navy')+ggtitle("Residual of Model v.s. Total Sleep Time (min)")+
labs(x= "Total Sleep Time (min)", y = "Residuals",
     caption="Fig 2.2 Scatterplot: Residual of model v.s. Total Sleep Time (min)")
# summary(model2$residuals)


## ----echo=FALSE,fig.width=6,fig.height=4--------------------------------------
qqnorm(residuals(model2), main = "QQ Plot of Model Residuals")
qqline(residuals(model2))
mtext("Fig 2.3 QQ Plot for assessing normality of residuals from the model", side = 1, line = 4)



## ----echo=FALSE---------------------------------------------------------------
modelsummary(list("2.exp_termGPA" = model2),
             statistic= c("t(632) = {statistic}","se = {std.error}",
                          "conf.int",'p={p.value}'), 
             conf_level = 0.95, title = 'Summary of Models (only model2)',
             gof_map = c("r.squared", "nobs"))%>%
  kable_styling(latex_options = "HOLD_position")
# Citation for code in modelsummary: https://cran.r-project.org/web/packages/modelsummary/modelsummary.pdf



## ----calculation of one-sided confidence interval-----------------------------
ci <- confint(model2, level = 0.95)
alpha <- 0.05

critical_t_value <- qt(1 - alpha, df = df.residual(model2))

one_sided_ci_upper <- coef(model2)["TotalSleepTime"] + 
                      critical_t_value * (summary(model2)$coefficients["TotalSleepTime", "Std. Error"])

t_obs <- summary(model2)$coefficients["TotalSleepTime", "t value"]
p_value <- pt(-t_obs, df = df.residual(model2))

