## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- include=FALSE, message=FALSE--------------------------------------------
# install.packages("alr4")
library(alr4)
library(GGally)
library(ggplot2)
library(dplyr)


## ---- message=FALSE, echo=FALSE, fig.cap="Distributions for response (instructor quality) and each predictor variable", echo=FALSE----
par(mfrow=c(2,3))
hist(Rateprof[,8], xlab="Instructor Quality (1-5 scale)", main="")
barplot(table(Rateprof[,1]), names=c("female", "male"), xlab = "Gender", ylab="Count")
barplot(table(Rateprof[,5]), names=c("no", "yes"), xlab = "Attractive?", ylab="Count")
hist(Rateprof[,11], xlab="Instructor Easiness (1-5 scale)", main="")
barplot(table(Rateprof[,6]), names=c("Hum", "SocSci", "STEM", "Pre-prof"), xlab="Discipline", ylab="Count")


## ---- message = FALSE, echo=FALSE, fig.cap="Depicts the relationship between each variable - there appears to be a positive correlation between the quality and easiness of the Instructor"----
pairs(quality ~ gender + pepper + easiness + discipline, data=Rateprof, pch=16, cex=0.7)


## ---- message=FALSE, echo=FALSE, fig.height = 3.5, fig.cap="Box plot graphs to compare the different categories against each other and the response"----
par(mfrow=c(1,3))
boxplot(quality ~ gender, ylab="Instructor Quality (1-5 scale)", data=Rateprof, xlab="Gender", names=c("female","male"), pch=16)
boxplot(quality ~ pepper, ylab="Instructor Quality (1-5 scale)", data=Rateprof, xlab="Attractive?", names=c("no","yes"), pch=16)
boxplot(quality ~ discipline, ylab="Instructor Quality (1-5 scale)", data=Rateprof, xlab="Discipline", names=c("Hum", "SS", "STEM", "Prof"), pch=16)


## ---- message=FALSE, echo=FALSE, include=FALSE--------------------------------
summary(factor(Rateprof[,6]))
summary(factor(Rateprof[,1]))
summary(factor(Rateprof[,5]))


## ---- message=FALSE, echo=FALSE, include=FALSE--------------------------------
mean_qual = mean(Rateprof$quality)
median_qual = median(Rateprof$quality)
sd_qual = sd(Rateprof$quality)
mean_easy = mean(Rateprof$easiness)
median_easy = median(Rateprof$easiness)
sd_easy = sd(Rateprof$easiness)


## ---- include=FALSE, message=FALSE, echo=FALSE--------------------------------
# install.packages("modelsummary")
library(modelsummary)
model_1 = lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + easiness:factor(gender) + easiness:factor(discipline), data=Rateprof)
model_2 = lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data=Rateprof)
anova(model_1, model_2)
summary(model_1)


## ---- message=FALSE, echo=FALSE, warning=FALSE, fig.height=3, fig.cap = "Residuals plot for the quantitative and fitted values show homoskedascity and linearity"----
library(dplyr)
library(patchwork)
library(broom)

p1 = ggplot(augment(model_1), aes(x=easiness, y=.resid)) + geom_point() + labs(x="Easiness (1-5 Scale)", y="Residual")

p2 = ggplot(augment(model_1), aes(x=.fitted, y=.resid)) + geom_point() + labs(x="Fitted Value", y="Residual")

p1 | p2


## ---- message=FALSE, echo=FALSE, fig.height=4, fig.cap = "Cook's distance and fitted value plot show that no observations are influential / outliers"----
ggplot(augment(model_1), aes(x = .fitted, y = .cooksd)) + geom_point() + labs(x = "Fitted value", y = "Cook's distance")


## ---- message=FALSE, echo=FALSE, fig.height = 4, fig.cap = "The residuals roughly follow a normal distribution with some heavy-tailed residuals"----
ggplot(augment(model_1), aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical quantile", y = "Sample quantile")


## ---- echo=FALSE--------------------------------------------------------------
confidence = confint(model_1, level=0.95)

