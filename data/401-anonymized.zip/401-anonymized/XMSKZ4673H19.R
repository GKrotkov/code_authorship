## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
# knitr::opts_chunk$set(echo = FALSE)
library("alr4")
library(ggplot2)
library(GGally)
library(tidyverse)
library(modelsummary)
data <- Rateprof


## -----------------------------------------------------------------------------
#summary(data$gender)
plot(data$gender,
     main = "Fig 1: Plot of Instructor Gender",
     xlab = "Gender",
     ylab = "Frequency",
     )


## -----------------------------------------------------------------------------
#summary(data$pepper)
plot(data$pepper,
     main = "Fig 2: Plot of Instructor's Attractiveness (via Pepper)",
     xlab = "Attractive",
     ylab = "Frequency",
     )


## -----------------------------------------------------------------------------
#summary(data$easiness)
hist(data$easiness,
     main = "Fig 3: Histogram of Instructor's Easiness",
     xlab = "Easiness (Higher Score Means Easier)",
     ylab = "Frequency",
     breaks = 40)


## -----------------------------------------------------------------------------
#summary(data$discipline)
plot(data$discipline,
     main = "Fig 4: Histogram of Instructor's Discipline",
     xlab = "Discipline",
     ylab = "Frequency",
     )


## -----------------------------------------------------------------------------
#summary(data$quality)
hist(data$quality,
     main = "Fig 5: Histogram of Instructor's Quality",
     xlab = "Quality (Higher Score Means Better)",
     ylab = "Frequency",
     breaks = 40)




## -----------------------------------------------------------------------------

x = data$easiness
y = data$quality
plot(x = x,
     y = y,
     main = "Fig 6: Plot of Instructor's Easiness vs. Quality Rating",
     xlab = "Easiness (Higher Score Means Easier)",
     ylab = "Quality (Higher Score Means Better",)



## -----------------------------------------------------------------------------
full_model <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + gender:discipline, data = data)
par(mfrow = c(1, 2))  # 1 row, 2 columns
plot(full_model, which = 1,)
plot(full_model, which = 2)


## -----------------------------------------------------------------------------
full_model <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + gender:discipline, data = data)

model1 <- lm(quality ~ gender + pepper + easiness + discipline, data = data)

model2 <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness, data = data)

model3 <- lm(quality ~ gender + pepper + easiness + discipline + gender:discipline, data = data)


## -----------------------------------------------------------------------------

modelsummary(list("Full" = full_model, "No Interaction" = model1, "Gender:Easiness" = model2,"Gender:Discipline" = model3),
             gof_map = c("r.squared", "nobs"))



## -----------------------------------------------------------------------------
anova1 <- anova(model1, full_model)
anova1$`Pr(>F)`


## -----------------------------------------------------------------------------
anova2 <- anova(model2, full_model)
anova2$`Pr(>F)`


## -----------------------------------------------------------------------------
anova3 <- anova(model3, full_model)
anova3$`Pr(>F)`


## -----------------------------------------------------------------------------
AIC(full_model)
AIC(model1)
AIC(model2)
AIC(model3)

