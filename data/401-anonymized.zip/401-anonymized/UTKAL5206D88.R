## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=2.5, fig.cap="Distribution of average professor quality ratings (1 worst, 5 best).", message=FALSE----
library(ggplot2)
library(alr4) # For Rateprof dataframe

ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(fill="limegreen", color="black") +
  labs(x = "Average quality rating", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Proportion of male vs. female professors.", message=FALSE----
ggplot(Rateprof, aes(x = gender)) +
  geom_bar(fill="pink", color="black") +
  labs(x = "Gender", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Proportion of consensuses on professor attractiveness.", message=FALSE----
ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(fill="red", color="black") +
  labs(x = "Consensus on attractiveness", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Distribution of average course easiness ratings (1 hardest, 5 easiest).", message=FALSE----
ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(fill="lightblue", color="black") +
  labs(x = "Average easiness rating (1 hardest, 5 easiest)", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Proportion of course disciplines.", message=FALSE----
ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill="purple", color="black") +
  labs(x = "Discipline", 
       y = "Frequency")


## ---- fig.width=8, fig.height=2.5, fig.cap="Professor Gender vs. Average quality rating (1 worst, 5 best).", message=FALSE----
ggplot(Rateprof, aes(x = quality, fill = gender)) +
  geom_histogram(position = "identity", color="black") +
  labs(x = "Average Quality Rating", 
       y = "Frequency") +
  scale_fill_manual(values = c("male" = "blue", "female" = "pink")) +
  facet_wrap(~gender, scales = "free")


## ---- fig.width=8, fig.height=2.5, fig.cap="Professor Attractiveness Consensus vs. Average quality rating (1 worst, 5 best).", message=FALSE----
ggplot(Rateprof, aes(x = quality, fill = pepper)) +
  geom_histogram(position = "identity", color="black") +
  labs(x = "Average Quality Rating", 
       y = "Frequency") +
  scale_fill_manual(values = c("no" = "blue", "yes" = "red")) +
  facet_wrap(~pepper, scales = "free")


## ---- fig.width=4, fig.height=2.5, fig.cap="Average easiness rating (1 hardest, 5 easiest) vs. Average quality rating (1 worst, 5 best).", message=FALSE----
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point(color="orange") +
  labs(x = "Average easiness rating", 
       y = "Average quality rating")


## ---- fig.width=8, fig.height=6, fig.cap="Course Discipline vs. Average quality rating (1 worst, 5 best).", message=FALSE, warning=FALSE----
library(gridExtra)
hum = ggplot(Rateprof[Rateprof$discipline == "Hum", ], aes(x = quality)) +
        geom_histogram(fill="yellow", color="black") +
        labs(x = "Average quality rating", 
             y = "Frequency",
             title = "Humanities")

socsci = ggplot(Rateprof[Rateprof$discipline == "SocSci", ], aes(x = quality)) +
        geom_histogram(fill="red", color="black") +
        labs(x = "Average quality rating", 
             y = "Frequency",
             title = "Social Sciences")

stem = ggplot(Rateprof[Rateprof$discipline == "STEM", ], aes(x = quality)) +
        geom_histogram(fill="blue", color="black") +
        labs(x = "Average quality rating", 
             y = "Frequency",
             title = "STEM")

preprof = ggplot(Rateprof[Rateprof$discipline == "Pre-prof", ], aes(x = quality)) +
        geom_histogram(fill="green", color="black") +
        labs(x = "Average quality rating", 
             y = "Frequency",
             title = "Professional Training")

grid.arrange(hum, socsci, stem, preprof, ncol = 2)


## ---- echo=FALSE--------------------------------------------------------------
model_1 = lm(quality ~ gender + pepper + easiness + discipline + gender:pepper, data=Rateprof)
model_2A = lm(quality ~ easiness + gender + discipline, data=Rateprof)
model_2B = lm(quality ~ easiness*gender + easiness*discipline, data=Rateprof)


## ---- fig.width=8, fig.height=2.5, fig.cap="Residual plots for all models by easiness.", message=FALSE----
res_1 = ggplot(Rateprof, aes(x = easiness, y = residuals(model_1))) + 
          geom_point(color = "orange") +
          labs(x = "easiness (1 hardest, 5 easiest)", 
               y = "Residual",
               title = "Model 1")
res_2A = ggplot(Rateprof, aes(x = easiness, y = residuals(model_2A))) + 
          geom_point(color = "blue") +
          labs(x = "easiness (1 hardest, 5 easiest)", 
               y = "Residual",
               title = "Model 2A")
res_2B = ggplot(Rateprof, aes(x = easiness, y = residuals(model_2B))) + 
          geom_point(color = "red") +
          labs(x = "easiness (1 hardest, 5 easiest)", 
               y = "Residual",
               title = "Model 2B")
grid.arrange(res_1, res_2A, res_2B, ncol = 3)


## ---- echo=FALSE, message=FALSE-----------------------------------------------
#summary(model_1)
#anova(model_1)

# Variable     test statistic      p-value
# gender        F(1,358)=1.2316     0.2678
# pepper        F(1,358)=84.7209   <2e-16
# easiness      t(358)=12.244      <2e-16
# discipline    F(3,1,358)=1.5576   0.1994
# gender:pepper F(1,358)=1.3692,    0.2427

#confint(model_1)
#pepperyes 0.482900338 1.0728014
#easiness 0.478953957 0.6622509


## ---- echo=FALSE, message=FALSE-----------------------------------------------
#anova(model_2A, model_2B)
#F(4,360)=0.2524, p=0.9082

