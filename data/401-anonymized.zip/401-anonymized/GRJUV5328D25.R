## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(ggplot2)

## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the quality variable."----
Rateprof <- Rateprof

ggplot(Rateprof, aes(x=quality)) + geom_histogram(binwidth=.2, fill="black", color="white") + labs(title = "Histogram of Quality Ratings", x="Quality Rating", y="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the easiness variable."----
ggplot(Rateprof, aes(x=easiness)) + geom_histogram(binwidth=.2, fill="black", color="white") + labs(title = "Histogram of Easiness Ratings", x="Easiness Rating", y="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Barplot of the pepper variable."----
barplot(table(Rateprof$pepper), main = "Distribution of Pepper")


## ---- fig.width=4, fig.height=3, fig.cap="Barplot of the gender variable."----
barplot(table(Rateprof$gender), main = "Distribution of Gender")


## ---- fig.width=4.5, fig.height=3, fig.cap="Barplot of the discipline variable."----
barplot(table(Rateprof$discipline), main = "Distribution of Discipline")


## -----------------------------------------------------------------------------
#summary(Rateprof$quality)
#summary(Rateprof$easiness)
#summary(Rateprof$pepper)
#summary(Rateprof$gender)
#summary(Rateprof$discipline)


## ---- include=FALSE-----------------------------------------------------------
library(GGally)
library(dplyr)

## ---- message=FALSE-----------------------------------------------------------
Rateprof %>%
  select(quality, gender, pepper, easiness, discipline) %>%
  ggpairs()


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of the quality variable by attractiveness."----
plot(Rateprof$pepper, Rateprof$quality, main = "Quality vs Attractiveness", 
     xlab = "Attractiveness Rating", ylab = "Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of the quality variable by gender."----
boxplot(quality ~ gender, data = Rateprof, main = "Quality by Gender", 
        xlab = "Gender", ylab = "Quality Rating")


## ---- fig.width=4.5, fig.height=3, fig.cap="Boxplot of the quality variable by discipline."----
boxplot(quality ~ discipline, data = Rateprof, main = "Quality by Discipline", 
        xlab = "Discipline", ylab = "Quality Rating")


## -----------------------------------------------------------------------------
model1 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data = Rateprof)
model2 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(gender):easiness + factor(discipline):easiness, data = Rateprof)
anova(model1, model2)


## ---- include=FALSE-----------------------------------------------------------
model1 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data = Rateprof)
summary(model1)


## ---- include=FALSE-----------------------------------------------------------
model2 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(gender):easiness + factor(discipline):easiness, data = Rateprof)
summary(model2)

anova(model1, model2)


## ---- include=FALSE-----------------------------------------------------------
model3rough <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(gender):easiness + factor(discipline):easiness, data = Rateprof)

m3_fit <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(gender):easiness + factor(discipline):easiness, data = Rateprof)
step_m3_fit <- step(m3_fit, direction = "both", trace = 0)
step_m3_fit

model3final <- lm(quality ~ factor(gender) + factor(pepper) + easiness, data = Rateprof)
summary(model3final)

#AIC(step_m3_fit)
#AIC(model3rough)


## -----------------------------------------------------------------------------
#library(modelsummary)
#modelsummary(list("Model 1" = model1, "Model 2" = model2, "Model 3" =model3final),
#             gof_map = c("r.squared", "nobs"))



## -----------------------------------------------------------------------------
par(mfrow = c(2, 3))
plot(model1, which=1)
plot(model1, which=2)
plot(model2, which=1)
plot(model2, which=2)
plot(model3final, which=1)
plot(model3final, which=2)


## ---- width=3, height=3-------------------------------------------------------
cooksd <- cooks.distance(model3final)
plot(cooksd, pch = 19, main = "Cook's distance plot")
abline(h = 4 / length(cooksd), col = "red")

