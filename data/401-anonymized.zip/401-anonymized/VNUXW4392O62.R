## body {

##   font-family: "Times New Roman", Times, serif;

## }


## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE,fig.align = "center",warning = FALSE)


## ---- include=FALSE-----------------------------------------------------------
library(ggplot2)
library(data.table)
library(dplyr)    
library(ggplot2)
library("alr4")
library(GGally)
library(broom)
library(modelsummary)
library(kableExtra)
library(gridExtra)
library(gt)
library(gtExtras)


## -----------------------------------------------------------------------------
data<-Rateprof
# head(data)
#?Rateprof


## -----------------------------------------------------------------------------
data_segment <- data[, c("gender", "pepper", "discipline","easiness","quality")]
key_stats <- summary(data_segment)
knitr::kable(key_stats, digits = 2,caption = "Table 1. Descriptive Statistics of Professor Data")%>%
  kable_styling(position = "center",latex_options = "HOLD_position")
# Citation of kable_styling: https://stackoverflow.com/questions/53153537/rmarkdown-setting-the-position-of-kable


## ---- echo=FALSE--------------------------------------------------------------
hist1<-ggplot(data,aes(x=`gender`))+
      ggtitle("Count of gender")+
      geom_histogram(stat="count",fill = "navy")+
      labs(x= "Gender", y = "count",caption="Fig 2.1 Histogram of the count of gender distribution")
hist2<-ggplot(data,aes(x=`pepper`))+
      ggtitle("Count of pepper")+
      geom_histogram(stat="count",fill = "navy")+
      labs(x= "Professor Attracted or not", y = "count",caption="Fig 2.2 Histogram of the count of whether professor is attracted")
hist3<-ggplot(data,aes(x=`discipline`))+
      ggtitle("Count of discipline")+
      geom_histogram(stat="count",fill = "navy")+
      labs(x= "Discipline", y = "count",caption="Fig 2.3 Distribution of the discipline of professor")
hist4<-ggplot(data,aes(x=`easiness`))+
      ggtitle("Count of easiness")+
      geom_histogram(binwidth = 0.05,fill = "navy")+
      labs(x= "How Easy is the professor", y = "count",caption="Fig 2.4 Distribution of the easiness of the professor")
hist5<-ggplot(data,aes(x=`quality`))+
      ggtitle("Count of quality")+
      geom_histogram(binwidth = 0.05,fill = "navy")+
      labs(x= "Quality of the professor", y = "count",caption="Fig 2.5 Distribution of the quality of the professor")
grid.arrange(hist1, hist2, hist3,hist4,hist5,nrow=3, ncol=2)


## ----warning=FALSE,message=FALSE----------------------------------------------
plot_1 <- data_segment |>
  ggpairs()

plot_1 <- plot_1 +labs(caption = "Fig 2.6 Overview of the Bivariate EDA for Professor data")

print(plot_1,progress = F)



## ----warning=FALSE,message=FALSE----------------------------------------------

scat1<-ggplot(data, aes(x = easiness, y = quality, color = gender)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  scale_color_manual(values = c("female" = "pink", "male" = "purple")) +
  labs(title = "Easiness vs. Quality by Gender",
       x = "Easiness Rating (1-5)", 
       y = "Quality Rating (1-5)",caption = "Fig 2.7 Easiness vs. Quality by Gender") +
  theme_minimal()

scat2<-ggplot(data, aes(x = easiness, y = quality, color = pepper)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  scale_color_manual(values = c("no" = "pink", "yes" = "purple")) +
  labs(title = "Easiness vs. Quality by Attractiveness",
       x = "Easiness Rating (1-5)",
       y = "",caption = "Fig 2.8 Easiness vs. Quality by Attractiveness" ) +
  theme_minimal() +
  theme(axis.title.y = element_blank())

scat3<-ggplot(data, aes(x = easiness, y = quality, color = discipline)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  scale_color_manual(values = c("Hum" = "pink", "SocSci" = "purple", "STEM" = "grey", "Pre-prof" = "yellow")) +
  labs(title = "Easiness vs. Quality by Discipline",
       x = "Easiness Rating (1-5)", 
       y = "Quality Rating (1-5)",
       caption = "Fig 2.9 Easiness vs. Quality by Discipline") +
  theme_minimal()

grid.arrange(scat1, scat2, scat3,nrow=2, ncol=2)




## -----------------------------------------------------------------------------
model1 <- lm(quality ~ factor(`gender`)+factor(`pepper`)+factor(`discipline`)+
                      easiness+easiness*factor(`gender`)+easiness*factor(`pepper`)+
                      easiness*factor(`discipline`),
                      data = data)
model2 <- lm(quality ~ factor(`gender`)+factor(`pepper`)+factor(`discipline`)+
                      easiness,
                      data = data)


## -----------------------------------------------------------------------------

par(mfrow=c(1, 3))


plot(cooks.distance(model1), type="h", main="Cook's Distance")

plot(model1, which=1)

plot(model1, which=2)

mtext("Fig 3.1 Diagnostis", outer = TRUE, side = 1, line = -1, adj = 1, cex = 0.8)

#summary(model1$residuals)


## ---- results='asis'----------------------------------------------------------

model_tidy <- tidy(model1, conf.int = TRUE, conf.level = 0.95)


model_glance <- glance(model1)


gt_table_coefficients <- model_tidy %>%
  select(term, estimate, std.error, statistic, p.value, conf.low, conf.high) %>%
  gt() %>%
  tab_header(
    title = "Table 3. Coefficient Statistics Summary"
  )%>%
  tab_options(
    table.font.size = 12, table.font.names = "Times New Roman")


gt_table_stats <- model_glance %>%
  gt() %>%
  tab_header(
    title = "Table 4. Model Statistics"
  )%>%
  tab_options(
    table.font.size = 11,table.font.names = "Times New Roman" )


print(gt_table_coefficients)
print(gt_table_stats)


## ----anova-summary, echo=FALSE------------------------------------------------
anova_result <- anova(model2, model1)

tidy_anova <- tidy(anova_result)

tidy_anova %>%
  gt() %>%
  tab_header(
    title = "Table 5 Partial F-test on interaction terms"
  )%>%
  tab_options(
    table.font.size = 14,table.font.names = "Times New Roman" )

