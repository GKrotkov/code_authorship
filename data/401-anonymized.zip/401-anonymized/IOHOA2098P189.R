## ----echo=FALSE, message=TRUE, warning=TRUE-----------------------------------
# Load CMU Sleep Data & R Libraries

suppressMessages(library(tidyverse))
suppressMessages(library(gridExtra))
sleep <- read.csv("cmu-sleep.csv")


## ----echo=FALSE, message=TRUE, warning=TRUE-----------------------------------
# Sleep-time Analysis
sleep %>%
  ggplot(aes(x = TotalSleepTime)) + 
  geom_histogram(aes(y = ..density..), fill="lightblue", color="black", alpha=0.7, bins = 30) + 
  geom_density(color="red", size=0.5) + 
  xlab("Total Sleep Time/ Night (in mins)") + 
  ylab("Density") + 
  ggtitle("Total Sleep Time Distribution") + 
  theme_minimal() 

cat("Summary of TotalSleepTime:")
print(summary(sleep$TotalSleepTime))
cat("Summary of Last Term GPA:")
summary(sleep$cum_gpa)
cat("Summary of Current Term GPA:")
summary(sleep$term_gpa)


## ----echo=FALSE, message=TRUE, warning=TRUE-----------------------------------
# cum_gpa Histogram (last term GPA)
p1 <- sleep %>%
  ggplot(aes(x = cum_gpa)) + 
  geom_histogram(aes(y = ..density..), fill="lightblue", color="black", alpha=0.7, bins = 30) + 
  geom_density(color="red", size=0.5) + 
  xlab("Last Term GPA (out of 4.0)") + 
  ylab("Density") + 
  ggtitle("Last Term GPA Distribution") + 
  theme_minimal()

# term_gpa Histogram (current term GPA)
p2 <- sleep %>%
  ggplot(aes(x = term_gpa)) + 
  geom_histogram(aes(y = ..density..), fill="lightblue", color="black", alpha=0.7, bins = 30) + 
  geom_density(color="red", size=0.5) + 
  xlab("Current Term GPA (out of 4.0)") + 
  ylab("Density") + 
  ggtitle("Current Term GPA Distribution") + 
  theme_minimal()

grid.arrange(p1, p2, ncol=2)


## ----echo=FALSE, message=TRUE, warning=TRUE, fig.width=8, fig.height=3--------
# Current Term GPA vs. Last Term GPA
sleep %>%
  ggplot(aes(x = term_gpa, y = cum_gpa)) +
  geom_point() + 
  theme_minimal() + 
  labs(x = "Current-Term GPA (out of 4.0)", 
       y = "Last-Term GPA (out of 4.0)",
       title = "Current Term GPA vs. Last Term GPA")


## ----echo=FALSE, message=TRUE, warning=TRUE-----------------------------------
# Sleep Time vs. Last Term GPA
p3 <- sleep %>%
  ggplot(aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() + 
  theme_minimal() + 
  labs(x = "Total Sleep Time/ Night (in mins)", 
       y = "Last-Term GPA (out of 4.0)",
       title = "Sleep Time vs. Last Term GPA")

# Sleep Time vs. Current Term GPA
p4 <- sleep %>%
  ggplot(aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() + 
  theme_minimal() + 
  labs(x = "Total Sleep Time/ Night (in mins)", 
       y = "Current-Term GPA (out of 4.0)",
       title = "Sleep Time vs. Current Term GPA")

grid.arrange(p3, p4, ncol=2)


## ----include=FALSE------------------------------------------------------------

summary(lm(term_gpa ~ TotalSleepTime, data = sleep))
summary(lm(term_gpa ~ log(TotalSleepTime), data = sleep))
summary(lm(term_gpa ~ TotalSleepTime + term_units, data = sleep))
summary(lm(term_gpa ~ log(TotalSleepTime) + term_units, data = sleep))
model1 <- lm(log(term_gpa) ~ log(TotalSleepTime) + term_units, data = sleep)


## ----echo=FALSE, message=TRUE, warning=TRUE-----------------------------------

# Setting up the 2x2 plotting grid
par(mfrow = c(2, 2))

# Generating the diagnostic plots
plot(model1)


## ----message=TRUE, warning=TRUE, include=FALSE--------------------------------

sleep_log <- mean(sleep$TotalSleepTime)
new_sleep_log <- mean(sleep$TotalSleepTime) - 120

new_data <- data.frame(TotalSleepTime = c(sleep_log, new_sleep_log), term_units = mean(sleep$term_units, na.rm = TRUE))
prediction <- predict(model1, newdata = new_data, interval = "prediction")

prediction

exp(prediction)

