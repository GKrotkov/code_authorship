## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----include=FALSE------------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(dplyr)


## ----include=FALSE------------------------------------------------------------
sleep.data <- read.csv("cmu-sleep.csv", header = TRUE)
sleepTime.summary <- summary(sleep.data$TotalSleepTime)
termGPA.summary <- summary(sleep.data$term_gpa)
cumGPA.summary <- summary(sleep.data$cum_gpa)
sleepTime.summary
termGPA.summary
cumGPA.summary


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's Sleep Time (minutes)."----
hist(sleep.data$TotalSleepTime, xlab = "Student's Sleep Time (minutes)", 
     main = "Distribution of Student's Sleep Time")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Student's Sleep Time (minutes)."----
boxplot(sleep.data$TotalSleepTime, ylab = "Student's Sleep Time (minutes)", 
     main = "Distribution of Student's Sleep Time")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's Term GPA (out of 4.0)."----
hist(sleep.data$term_gpa, xlab = "Student's Term GPA (out of 4.0)", 
     main = "Distribution of Student's Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Student's Term GPA (out of 4.0)."----
boxplot(sleep.data$term_gpa, ylab = "Student's Term GPA (out of 4.0)", 
     main = "Distribution of Student's Term GPA")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Histogram of Student's Cumulative GPA (out of 4.0)."----
hist(sleep.data$cum_gpa, xlab = "Student's Cumulative GPA (out of 4.0)", 
     main = "Distribution of Student's Cumulative GPA")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Boxplot of Student's Cumulative GPA (out of 4.0)."----
boxplot(sleep.data$term_gpa, ylab = "Student's Cumulative GPA (out of 4.0)", 
     main = "Distribution of Student's Cumulative GPA")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Scatterplot of Student's Sleep Time and Its Term GPA."----
ggplot(data = sleep.data, aes(x = TotalSleepTime,
                              y = term_gpa)) +
  labs(x = "Student's Sleep Time (minutes)", 
       y = "Student's Term GPA (out of 4.0)") +
  geom_point(color = "navy") +
  ggtitle("Relationship between Student's Sleep Time and Its GPA")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Scatterplot of Student's Sleep Time and Its Term GPA."----
ggplot(data = sleep.data, aes(x = TotalSleepTime,
                              y = term_gpa)) +
  labs(x = "Student's Sleep Time (minutes)", 
       y = "Student's Term GPA (out of 4.0)") +
  geom_point(color = "navy") +
  geom_smooth(method = lm, formula = y ~ x) +
  ggtitle("Relationship between Student's Sleep Time and Its GPA")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Squared Transformed Scatterplot of Student's Sleep Time and Its Term GPA."----
ggplot(data = sleep.data, aes(x = TotalSleepTime,
                              y = (term_gpa)^2)) +
  labs(x = "Student's Sleep Time (minutes)", 
       y = "Student's Term GPA (out of 4.0; squared)") +
  geom_point(color = "navy") +
  geom_smooth(method = lm, formula = y ~ x) +
  ggtitle("Relationship between Student's Sleep Time and Its GPA (squared)")

## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Log Transformed Scatterplot of Student's Sleep Time and Its Term GPA."----
ggplot(data = sleep.data, aes(x = log(TotalSleepTime),
                              y = term_gpa)) +
  labs(x = "Log of Student's Sleep Time (minutes)", 
       y = "Student's Term GPA (out of 4.0)") +
  geom_point(color = "navy") +
  geom_smooth(method = lm, formula = y ~ x) +
  ggtitle("Relationship between Log of Student's Sleep Time and Its GPA")


## -----------------------------------------------------------------------------
sleep.model <- lm(term_gpa ~ TotalSleepTime, data = sleep.data)
sleep.model.summary <- summary(sleep.model)
sleep.model.coef <- as.data.frame(sleep.model.summary$coefficients)
knitr::kable(sleep.model.coef, digits = 10)


## -----------------------------------------------------------------------------
sleep.adj.model <- lm(term_gpa ~ log(TotalSleepTime), data = sleep.data)
sleep.adj.model.summary <- summary(sleep.adj.model)
sleep.adj.model.coef <- as.data.frame(sleep.adj.model.summary$coefficients)
knitr::kable(sleep.adj.model.coef, digits = 10)


## -----------------------------------------------------------------------------
cookd <- cooks.distance(sleep.model)


## ----include=FALSE------------------------------------------------------------
which.max(cookd)


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Cook's Distance."----
plot(cookd, pch=21, bg='lightblue', ylab="Cook's distance")


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Log Transformation of Student's Total Sleep Time."----
log.model <- lm(term_gpa ~ log(TotalSleepTime), data = sleep.data)
res.log.y <- residuals(log.model)
res.log.x <- log(sleep.data$TotalSleepTime)
plot(x=res.log.x, y=res.log.y, pch = '.', 
     main = "Residuals vs Log of Student's Total Sleep Time", 
     xlab = "Log of Student's Total Sleep Time",
     ylab = "Residuals")
abline(lm(res.log.y~res.log.x), col='blue', lty=2)


## ---- fig.width=4, fig.height=3, fig.align='center', fig.cap="Normal Q-Q Plot."----
qqnorm(residuals(log.model))
qqline(residuals(log.model))


## -----------------------------------------------------------------------------
est.coef <- coef(log.model)["log(TotalSleepTime)"]
se_coef <- summary(log.model)$coefficients["log(TotalSleepTime)", "Std. Error"]
t.value <- est.coef / se_coef
dof <- nrow(sleep.data) - 2 
p.value <- pt(q=t.value, df=dof, lower.tail=FALSE)


## -----------------------------------------------------------------------------
tab.vals <- c(t.value, dof, p.value)
data <- matrix(tab.vals, ncol=3, byrow=TRUE)
colnames(data) <- c("t-value", "Degrees of Freedom", "p-value")
new_df <- as.data.frame(data)
knitr::kable(new_df, digits = 10)


## -----------------------------------------------------------------------------
org.ci.table <- confint(sleep.model, level=0.95)
knitr::kable(org.ci.table, digits = 6)


## -----------------------------------------------------------------------------
log.ci.table <- confint(log.model, level=0.95)
knitr::kable(log.ci.table, digits = 6)

