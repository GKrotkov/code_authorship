## ----fig.height=2.9, fig.width=2.9, echo=FALSE--------------------------------
library(alr4)

data("Rateprof")
invisible(hist(Rateprof$easiness, 
     main="Histogram of Easiness",
     xlab="Easiness", breaks =10,
     col="lightblue"))


## ----fig.height=2.9, fig.width=2.9,echo=FALSE---------------------------------
invisible(hist(Rateprof$quality, 
     main="Histogram of Easiness",
     xlab="Quality Rating", breaks=10,
     col="coral"))


## ---- echo=FALSE--------------------------------------------------------------
par(mfrow = c(1, 2))

boxplot(quality ~ gender, 
        data = Rateprof, 
        xlab = "Gender", ylab = "Quality Rating",
        main = "Instructor Quality by Gender",
        col = c("lightblue", "coral"))

boxplot(easiness ~ gender, 
        data = Rateprof, 
        xlab = "Gender", ylab = "Easiness Rating",
        main = " Easiness by Gender",
        col = c("lightblue", "coral"))




## ---- echo=FALSE--------------------------------------------------------------
boxplot(quality ~ discipline, 
        data = Rateprof, 
        xlab = "Discipline", ylab = "Quality Rating",
        main = "Instructor Quality by Discipline",
        col = c("lightblue", "coral", "pink", "lightgreen"))


## ----fig.height=3, fig.width=3,echo=FALSE-------------------------------------

boxplot(quality ~ pepper, 
        data = Rateprof, 
        xlab = "Pepper", ylab = "Quality Rating",
        main = "Instructor Quality by Pepper",
        col = c("lightblue", "purple"))




## ---- echo=FALSE--------------------------------------------------------------


boxplot(easiness ~ pepper, 
        data = Rateprof, 
        xlab = "Pepper", ylab = "Easiness Rating",
        main = "Instructor Easiness Rating by Pepper",
        col = c("lightblue", "purple"))

# Adding a legend
legend("topright",              # Position of the legend
       legend = c("no", "yes"),  # Labels
       fill = c("lightblue", "purple"))  # Colors corresponding to the labels




## ---- echo=FALSE,message=FALSE, warning=FALSE,fig.height=4, fig.width=4-------
# Load libraries
library(alr4)
library(tidyverse)
ggplot(Rateprof, aes(x = easiness, y = quality)) +  
  geom_point(alpha = 0.5, position = position_jitter(width = 0.2, height = 0.2), color = "blue", size = 3) +
  labs(
    title = "Easiness vs Quality Rating",
    x = "Easiness Score",
    y = "Quality Rating"
  ) +
  theme_classic() +
  theme(
    plot.title = element_text(size=16, face="bold"),
    axis.title = element_text(size=12, face="bold"),
    axis.text = element_text(size=10),
    legend.position = "bottom",
    plot.margin = margin(1, 1, 1, 1, "cm")
  ) +
  scale_x_continuous(limits = c(1.5, 4.5), breaks = seq(1.5, 4.5, by = 0.5)) +
  scale_y_continuous(limits = c(1.5, 4.5), breaks = seq(1.5, 4.5, by = 0.5))







## ----echo=FALSE---------------------------------------------------------------
 
library(stats)


model1 <- lm(quality ~ easiness + gender + discipline + pepper + easiness:gender + easiness:discipline, data = Rateprof)


model2 <- lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)

anova_result <- anova(model1, model2)


print(anova_result)



## ----echo=FALSE,warning=FALSE-------------------------------------------------

if (!require(bestglm)) {
    install.packages("bestglm")
    library(bestglm)
}



library(alr4)

sub_df <- Rateprof[c('gender', 'pepper', 'discipline', 'easiness', 'quality')]

sub_df$gender <- factor(sub_df$gender)
sub_df$discipline <- factor(sub_df$discipline)
sub_df$pepper <- factor(sub_df$pepper)
sub_df$logquality <- log(sub_df$quality)
 
bestglm(sub_df[, -5], IC = "AIC")


## ---- echo=FALSE,message=FALSE, warning=FALSE---------------------------------



model <- lm(quality ~ gender + pepper + easiness, data = Rateprof)


model_table <- summary(model)$coefficients


knitr::kable(model_table, digits = 3)
rsq <- summary(model)$r.squared  


print(paste0("R-squared: ", round(rsq, 3)))



## ----echo=FALSE---------------------------------------------------------------
par(mfrow = c(1, 2))
model <- lm(quality ~ gender+easiness+pepper, data = Rateprof)
plot(model, which = 1)
plot(model, which = 2)




## ----echo=FALSE---------------------------------------------------------------


model <- lm(quality ~ gender + pepper + easiness, data = Rateprof)


library(car)
 
model=lm(quality ~ gender + pepper + easiness, data = Rateprof)

 
vif_values <- vif(model)

 
print(vif_values)



## ----echo=FALSE---------------------------------------------------------------
 
library(stats)

 
model <- lm(quality ~ gender + pepper + easiness, data = Rateprof)
 
summary(model)

 
anova(model)


