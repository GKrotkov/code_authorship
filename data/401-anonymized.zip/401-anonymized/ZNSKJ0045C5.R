## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, out.width = "50%", fig.align = "center")


## ---- include=FALSE, echo = FALSE---------------------------------------------
library(alr4)
library(tidyverse)
library(ggplot2)
library(GGally)
library(moments)
library(sjPlot)
library(broom)


## -----------------------------------------------------------------------------
df = Rateprof


## ---- fig.cap = "Univariate EDA on Our Variables of Interest", out.width = "100%"----
par(mfrow=c(4,2),mar = c(1,1,1,1))
hist(df$quality, xlab = "Average Quality Rating", main = "", breaks = 25)
barplot(table(df$gender), xlab = "Gender")
barplot(table(df$pepper), xlab = "Attractiveness (yes if attractive)")
hist(df$easiness, xlab = "Average Easiness Rating", main = "")
barplot(table(df$discipline))
hist(df$helpfulness, breaks = 50, xlab = "Average Professor Helpfulness", main ="")
hist(df$clarity, breaks = 50,xlab = "Average Professor Clarity", main = "")
hist(df$raterInterest, xlab = "Average Rater Interest", main ="", breaks = 25)

## ---- echo=FALSE, include = FALSE---------------------------------------------
# skewness of quality
skewness(df$quality)

# skewness of helpfulness
skewness(df$helpfulness)

#skewness of clarity
skewness(df$clarity)


## ---- fig.cap = "Pairs Plot of Variables of Interest",echo = FALSE, warning = FALSE, message=FALSE, out.width="60%"----
df %>%
  select(gender, pepper, easiness, discipline, helpfulness, clarity, raterInterest, quality)%>%
  ggpairs()


## ---- fig.cap="Cook\'s Distance for our Model with Clarity and its Interactions Included"----
bad1 = lm(quality ~ easiness*(gender + discipline + helpfulness + clarity) + pepper*(helpfulness+clarity), data = df)
plot(bad1, which = 4)


## ---- echo = FALSE, include = FALSE-------------------------------------------
# 50th percentile of Cook's Distance of our model with clarity
pf(0.5, 16, 349)

# AIC of our model
model = lm(quality ~ easiness*(gender + discipline + helpfulness) + pepper*helpfulness, data = df)
extractAIC(model)

# AIC of our model with the easiness-pepper interaction added
bad2 = lm(quality ~ easiness*(gender + discipline + pepper+ helpfulness) + pepper*helpfulness, data = df)
extractAIC(bad2)

# AIC of our model with raterInterest and its interactions added
bad3 = lm(quality~easiness*(gender+discipline+helpfulness+raterInterest) + helpfulness*(pepper+raterInterest), data = df)
extractAIC(bad3)


## ---- fig.cap = "Residual Plots",out.width = "100%"---------------------------
par(mfrow = c(1,2))
plot(model, which = c(1,2))


## ---- fig.cap = "Cook\'s Distances for our Observations in our Model"---------
plot(model, which = 4)


## ---- include = FALSE, echo = FALSE-------------------------------------------
#50th percentile of Cook's Distance for our Model
pf(0.5, 13, 352)


## ---- fig.cap = "Summary Table for our Model"---------------------------------
knitr::kable(tidy(model), digits=3, caption = "Summary Table for our Model")


## ---- fig.cap = "ANOVA Table Between our Full Model and Model with Discipline Predictors Removed"----
reduced1 = lm(quality ~ easiness*(gender + helpfulness) + easiness:discipline + pepper*helpfulness, data = df)
knitr::kable(tidy(anova(reduced1, model)), digits = 3, caption = "ANOVA Table Between our Full Model and Model with Discipline Predictors Removed")


## ---- fig.cap = "ANOVA Table Between our Full Model and Model with Discipline Interactions with Easiness Removed"----
reduced2 = lm(quality ~ easiness*(gender + helpfulness) + discipline + pepper*helpfulness, data = df)
knitr::kable(tidy(anova(reduced2, model)), digits = 3, caption = "ANOVA Table Between our Full Model and Model with Discipline Interactions with Easiness Removed")


## ---- include = FALSE, echo = FALSE-------------------------------------------
# confidence interval for our easiness predictor
confint(model, "easiness")

# confidence interval for our gender predictor
confint(model, "gendermale")

# confidence interval for our attractiveness (pepper) predictor
confint(model, "pepperyes")

#confidence interval for our easiness-gender interaction predictor
confint(model, "easiness:gendermale")

