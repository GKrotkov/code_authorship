## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- echo=FALSE, message=FALSE-----------------------------------------------
cmu_sleep = read.csv("cmu-sleep.csv")


## ---- echo=FALSE, message=FALSE, warning=FALSE--------------------------------
library(ggplot2)
library(dplyr)
library(broom)


## ---- echo=FALSE, message=FALSE, out.width="50%", out.height="50%"------------
cmu_sleep %>%
  ggplot(aes(x=TotalSleepTime)) + 
  geom_histogram(bins=40, fill="lightblue") + 
  labs(title = "Histogram of Total Sleep Time for Students", 
       x = "Sleep Time (min)")

cmu_sleep %>%
  ggplot(aes(x=log(TotalSleepTime))) + 
  geom_histogram(bins=40, fill="lightblue") + 
  labs(title = "Histogram of Log Total Sleep Time for Students", 
       x = "Log Sleep Time (min)")


## ---- echo=FALSE, message=FALSE, out.width="50%", out.height="50%"------------
cmu_sleep %>%
  ggplot(aes(x=cum_gpa)) + 
  geom_histogram(bins=40, fill="lightblue") + 
  labs(title = "Histogram of Cummulative GPA", 
       x = "GPA Score (4.0 scale)", 
       y = "Number of Students")

cmu_sleep %>%
  ggplot(aes(x=log(cum_gpa))) + 
  geom_histogram(bins=40, fill="lightblue") + 
  labs(title = "Histogram of Log Cummulative GPA", 
       x = "Log Cummulative GPA Score (4.0 scale)", 
       y = "Number of Students")


## ---- echo=FALSE, message=FALSE, out.width="50%", out.height="50%"------------
cmu_sleep %>%
  ggplot(aes(x=term_gpa)) + 
  geom_histogram(bins=40, fill="lightgreen") + 
  labs(title = "Histogram of Current Term GPA", 
       x = "Term GPA Score (4.0 scale)", 
       y = "Number of Students")

cmu_sleep %>%
  ggplot(aes(x=log(term_gpa))) + 
  geom_histogram(bins=40, fill="lightgreen") + 
  labs(title = "Histogram of Log Current Term GPA", 
       x = "Log Term GPA Score (4.0 scale)", 
       y = "Number of Students")


## ---- echo=FALSE, message=FALSE, out.width="50%", out.height="50%"------------
cmu_sleep %>%
  ggplot(aes(x=log(TotalSleepTime), y=term_gpa)) + 
  geom_point(alpha=0.5, color="pink") + 
  labs(title = "Scatterplot of Term GPA vs. Log TotalSleepTime for Students", 
       x = "Log Total Sleep Time (min)", 
       y = "Term GPA Score (4.0 scale)")

cmu_sleep %>%
  ggplot(aes(x=cum_gpa, y=term_gpa)) + 
  geom_point(alpha=0.5, color="orange") + 
  labs(title = "Scatterplot of Term GPA vs. Cummulative GPA for Students", 
       x = "Cummulative GPA Score (4.0 scale)", 
       y = "Term GPA Score (4.0 scale)")


## ---- echo=FALSE, message=FALSE-----------------------------------------------
#models with 
lm_fit_sleep = lm(term_gpa ~ TotalSleepTime, data=cmu_sleep)
adjusted_R2_1 = summary(lm_fit_sleep)["adj.r.squared"]

lm_fit_cumgpa = lm(term_gpa ~ cum_gpa, data=cmu_sleep)
adjusted_R2_2 = summary(lm_fit_cumgpa)["adj.r.squared"]

lm_fit_both = lm(term_gpa ~ TotalSleepTime + cum_gpa, data=cmu_sleep)
adjusted_R2_3 = summary(lm_fit_both)["adj.r.squared"]

lm_fit_log_sleep = lm(term_gpa ~ log(TotalSleepTime), data=cmu_sleep)
adjusted_R2_4 = summary(lm_fit_log_sleep)["adj.r.squared"]

lm_fit_log_cumgpa = lm(term_gpa ~ log(cum_gpa), data=cmu_sleep)
adjusted_R2_5 =summary(lm_fit_log_cumgpa)["adj.r.squared"]

lm_fit_log_both = lm(term_gpa ~ log(TotalSleepTime) + log(cum_gpa), data=cmu_sleep)
adjusted_R2_6 =summary(lm_fit_log_both)["adj.r.squared"]

lm_fit_chosen = lm(term_gpa ~ log(TotalSleepTime) + cum_gpa, data=cmu_sleep)
sum_fit_chosen = summary(lm_fit_chosen)
adjusted_R2_7 = sum_fit_chosen["adj.r.squared"]

##models with log(term_gpa) as response
lm_fit_sleep2 = lm(log(term_gpa) ~ TotalSleepTime, data=cmu_sleep)
adjusted_R2_8 = summary(lm_fit_sleep2)["adj.r.squared"]

lm_fit_cumgpa2 = lm(log(term_gpa) ~ cum_gpa, data=cmu_sleep)
adjusted_R2_9 = summary(lm_fit_cumgpa2)["adj.r.squared"]

lm_fit_both2 = lm(log(term_gpa) ~ TotalSleepTime + cum_gpa, data=cmu_sleep)
adjusted_R2_10 = summary(lm_fit_both2)["adj.r.squared"]

lm_fit_log_sleep2 = lm(log(term_gpa) ~ log(TotalSleepTime), data=cmu_sleep)
adjusted_R2_11 = summary(lm_fit_log_sleep2)["adj.r.squared"]

lm_fit_log_cumgpa2 = lm(log(term_gpa) ~ log(cum_gpa), data=cmu_sleep)
adjusted_R2_12 =summary(lm_fit_log_cumgpa2)["adj.r.squared"]

lm_fit_log_both2 = lm(log(term_gpa) ~ log(TotalSleepTime) + log(cum_gpa), data=cmu_sleep)
adjusted_R2_13 =summary(lm_fit_log_both2)["adj.r.squared"]

lm_fit_gross2 = lm(log(term_gpa) ~ log(TotalSleepTime) + cum_gpa, data=cmu_sleep)
adjusted_R2_14 = summary(lm_fit_gross2)["adj.r.squared"]


lm_fit_gross3 = lm(term_gpa ~ TotalSleepTime + log(cum_gpa), data=cmu_sleep)
adjusted_R2_15 = summary(lm_fit_gross3)["adj.r.squared"]

lm_fit_gross4 = lm(log(term_gpa) ~ TotalSleepTime + log(cum_gpa), data=cmu_sleep)
adjusted_R2_16 = summary(lm_fit_gross4)["adj.r.squared"]


## ---- echo=FALSE, message=FALSE-----------------------------------------------
pred_var = c("TotalSleepTime", "cum_gpa", "TotalSleepTime + cum_gpa", 
         "log(TotalSleepTime)", "log(cum_gpa)", "log(TotalSleepTime) + log(cum_gpa)", 
         "log(TotalSleepTime) + cum_gpa", "TotalSleepTime + log(cum_gpa)")

adjusted_R2 = c(adjusted_R2_1, adjusted_R2_2, adjusted_R2_3, adjusted_R2_4, 
                adjusted_R2_5, adjusted_R2_6, adjusted_R2_7, 
                adjusted_R2_8, adjusted_R2_9, adjusted_R2_10, adjusted_R2_11,
                adjusted_R2_12, adjusted_R2_13, adjusted_R2_14, 
                adjusted_R2_15, adjusted_R2_16) %>%
  unlist(.)

resp_var = c(rep("term_gpa", length(pred_var)), rep("log(term_gpa)", length(pred_var)))

model_options_df = data.frame(pred_var = rep(pred_var,2), resp_var, adjusted_R2)

ordered_model_options_df = model_options_df %>%
  arrange(desc(adjusted_R2))


## ---- echo=FALSE, message=FALSE-----------------------------------------------
knitr::kable(ordered_model_options_df, digits = 3, caption = "linear model options: predictor variables, response variables, and adjusted R^2 scores", "simple")


## ---- echo=FALSE, message=FALSE-----------------------------------------------
sum_fit_chosen


## ---- echo=FALSE, message=FALSE, warning=FALSE, out.width="50%", out.height="50%"----
plot(log(cmu_sleep$TotalSleepTime), lm_fit_chosen$residuals, 
     xlab = "Log of Total Sleep Time (min)", 
     ylab = "Residuals", 
     main = "Residuals vs. Log of Total Sleep Time")
abline(h = 0, col="black")
plot(cmu_sleep$cum_gpa, lm_fit_chosen$residuals,
     xlab = "Cummulative GPA Score (4.0 scale)", 
     ylab = "Residuals", 
     main = "Residuals vs. Cummulative GPA")
#drew arbitrary lines to illustrate heteroskedasticity
abline(h = 0, col="black")
lines(x = c(3, 3.5, 4), y = c(1, 0.55, 0.45), col="purple")
lines(x = c(3.2, 4), y = c(-1.9, -0.55), col="purple")


## ---- echo=FALSE, message=FALSE, warning=FALSE, out.width="50%", out.height="50%"----
ggplot(augment(lm_fit_chosen), aes(x = .fitted, y = .resid)) +
  geom_point(alpha=0.5) +
  labs(x = "Fitted value", y = "Residual value", 
       title = "Residual values vs. Fitted values") +
  #drew arbitrary lines to illustrate heteroskedasticity
  geom_abline(intercept = 3.95, slope = -0.98, col="purple") + 
  geom_abline(intercept = -8.3, slope = 2, col="purple")


## ---- echo=FALSE, message=FALSE, warning=FALSE, out.width="50%", out.height="50%"----
aug = augment(lm_fit_chosen)
colnames(aug)[2] = "log_TotalSleepTime"

aug |> 
  ggplot(aes(x = cum_gpa, y = .cooksd)) +
  geom_point(alpha = 0.5) +
  labs(x = "Cummulative GPA (4.0 scale)", y = "Cook's distance")

aug |> 
  ggplot(aes(x = log_TotalSleepTime, y = .cooksd)) +
  geom_point(alpha = 0.5) +
  labs(x = "Log of Total Sleep Time (min)", y = "Cook's distance")


## ---- echo=FALSE--------------------------------------------------------------
influ_obs = which(aug$.cooksd > 0.1) * -1

sleep_new = cmu_sleep[influ_obs, ]

lm_fit_chosen2 = lm(term_gpa ~ log(TotalSleepTime) + cum_gpa, data=sleep_new)
sum_fit_chosen2 = summary(lm_fit_chosen2)

sum_fit_chosen2


## ---- echo=FALSE, message=FALSE, warning=FALSE, out.width="50%", out.height="50%"----
plot(log(sleep_new$TotalSleepTime), lm_fit_chosen2$residuals, 
     xlab = "Log of Total Sleep Time (min)", 
     ylab = "Residuals", 
     main = "Residuals vs. Log of Total Sleep Time")
abline(h = 0, col="black")
plot(sleep_new$cum_gpa, lm_fit_chosen2$residuals,
     xlab = "Cummulative GPA Score (4.0 scale)", 
     ylab = "Residuals", 
     main = "Residuals vs. Cummulative GPA")
abline(h = 0, col="black")
#drew arbitrary lines to illustrate heteroskedasticity
lines(x = c(3, 3.5, 4), y = c(1, 0.55, 0.45), col="purple")
lines(x = c(3.2, 3.6, 4), y = c(-1.9, -1.38, -0.55), col="purple")

ggplot(augment(lm_fit_chosen2), aes(x = .fitted, y = .resid)) +
  geom_point(alpha=0.5) +
  labs(x = "Fitted value", y = "Residual value", 
       title = "Residual values vs. Fitted values") +
  #drew arbitrary lines to illustrate heteroskedasticity
  geom_abline(intercept = 3.95, slope = -0.98, col="purple") + 
  geom_abline(intercept = -8.25, slope = 2, col="purple")


## ---- echo=FALSE, message=FALSE, warning=FALSE, out.width="50%", out.height="50%"----
ggplot(augment(lm_fit_chosen), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles", 
       title = "Normal Q–Q Plot of Residuals of Original Model")

ggplot(augment(lm_fit_chosen2), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles", 
       title = "Normal Q–Q Plot of Residuals of New Model")


## ---- echo=FALSE--------------------------------------------------------------
interval <- predict(lm_fit_chosen, newdata = data.frame(TotalSleepTime = 2, cum_gpa = 0), 
                                                        interval = "confidence", level = 0.95)
interval

