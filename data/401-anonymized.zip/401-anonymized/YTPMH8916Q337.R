## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
plot(dist ~ speed, data = cars,
     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## -----------------------------------------------------------------------------
cmu_sleep <- read.csv("C:/Users/jacke/Downloads/cmu-sleep.csv")
library(ggplot2)


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of Average Nightly Sleep Duration in Minutes, excluding naps. Figure 1"----
ggplot(data = cmu_sleep, aes(x=TotalSleepTime)) +
  geom_histogram() +
  labs(x = "Average Nightly Sleep Duration (Mins)")
summary(cmu_sleep$TotalSleepTime)


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of students' GPA during the semester the study took place. Figure 2"----
ggplot(data = cmu_sleep, aes(x=term_gpa)) +
  geom_histogram() +
  labs(x = "Students' Term GPA")
summary(cmu_sleep$term_gpa)


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of students's GPA of all semester outside of the study. Figure 3"----
ggplot(data = cmu_sleep, aes(x=cum_gpa)) +
  geom_histogram() +
  labs(x = "Students' Cumulative GPA")
summary(cmu_sleep$cum_gpa)



## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot showing the relationship between TotalSleepTime and term_gpa. Figure 4"----
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  labs(x = "Average Nightly Sleep Time (mins)", y = "Students' GPA during the study")



## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot showing the relationship between cum_gpa and term_gpa. Figure 5"----
ggplot(data = cmu_sleep, aes(x = cum_gpa, y = term_gpa)) +
  geom_point() +
  labs(x = "Students' cumulative GPA outside of the study", y = "Students' GPA during the study")



## ---- fig.width=4, fig.height=3, fig.cap="Log transformed Scatterplot showing relationship between TotalSleepTime and term_gpa. Figure 6"----
ggplot(data = cmu_sleep, aes(x = log(TotalSleepTime), y = log(term_gpa))) +
  geom_point() +
  labs(x = "Log of Total Sleep Time", y = "Log of Students' GPA during the study")


## -----------------------------------------------------------------------------
#normal regression model 
gpa_fit = lm(term_gpa ~ TotalSleepTime, data = cmu_sleep)
summary(gpa_fit)

#transformed model
gpa_trans_model = lm(log(term_gpa)~log(TotalSleepTime),data = cmu_sleep)
summary(gpa_trans_model)


## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of TotalSleepTime using our simple model. Figure 7"----
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = residuals(gpa_fit))) +
  geom_point() +
  labs(x = "Total Sleep Time", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of TotalSleepTime using our log transformed model. Figure 8"----
ggplot(data = cmu_sleep, aes(x = log(TotalSleepTime), y = residuals(gpa_trans_model))) +
  geom_point() +
  labs(x = "Log Transformation of Total Sleep Time", y = "Residuals")


## -----------------------------------------------------------------------------
library(broom)


## ---- fig.width=4, fig.height=3, fig.cap="Normal QQ-Plot. Figure 9"-----------
ggplot(augment(gpa_fit), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles")


## ---- fig.width=4, fig.height=3, fig.cap="Normal QQ-Plot of Log Transformed Model. Figure 10"----
ggplot(augment(gpa_trans_model), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles of Transformed Model", y = "Sample quantiles of Transformed Model")


## -----------------------------------------------------------------------------
interval1 = predict(gpa_trans_model, newdata = data.frame(TotalSleepTime = 397.3),
                   interval = "confidence", level = 0.95)

interval2 = predict(gpa_trans_model, newdata = data.frame(TotalSleepTime = 277.32),
                   interval = "confidence", level = 0.95)

exp(interval1)
exp(interval2)

