## ----setup, include = FALSE---------------------------------------------------

knitr::opts_chunk$set(echo = FALSE,
                      warning = FALSE,
                      fig.pos = "H",
                      fig.height = 3,
                      fig.pos = 'center'
                      )

library(alr4)
library(ggplot2)
library(modelsummary)


## ---- results='hide'----------------------------------------------------------
head(Rateprof)
prof_df = Rateprof


## ---- fig.cap="Histogram of Quality Ratings"----------------------------------

hist(Rateprof$quality,
     main = "Histogram of quality ratings" , 
     xlab = "Quality Ratings (from 1 (worst) to 5 (best))")



## ---- results='hide'----------------------------------------------------------
mean(Rateprof$quality)
sd(Rateprof$quality)
median(Rateprof$quality)
min(Rateprof$quality)
max(Rateprof$quality)


## ---- fig.cap="Count of Gender"-----------------------------------------------

barplot(table(Rateprof$gender), main = "Distribution of Gender", xlab = "Gender", col = c("red", "blue"))




## ---- results='hide'----------------------------------------------------------
table(Rateprof$gender)


## ---- fig.cap="Count of Attractiveness (Pepper)"------------------------------

barplot(table(Rateprof$pepper), main = "Distribution of Attractiveness", xlab = "Attractiveness (Pepper)", col = c("red", "blue"))



## ---- results='hide'----------------------------------------------------------
table(Rateprof$pepper)


## ---- fig.cap="Histogram of the Easiness of the Classes"----------------------

hist(Rateprof$easiness,
     main = "Histogram of the Easiness of Classes" , 
     xlab = "Easiness (from 1 (worst) to 5 (best))")



## ---- results='hide'----------------------------------------------------------
mean(Rateprof$easiness)
sd(Rateprof$easiness)
median(Rateprof$easiness)
min(Rateprof$easiness)
max(Rateprof$easiness)


## ---- fig.width=4, fig.height=3, fig.cap="Count of the Discipline of the Classes"----

barplot(table(Rateprof$discipline), main = "Distribution of Discipline", xlab = "Discipline", col = c("red", "blue", "green", "yellow"))




## ---- results='hide'----------------------------------------------------------
table(Rateprof$discipline)


## ---- fig.cap="Boxplot of the Quality Rating by Gender"-----------------------

boxplot(Rateprof$quality ~ factor(Rateprof$gender),
     main = "Quality Rating by Gender",
     xlab = "Gender",
     ylab = "Quality Ratings (from 1 (worst) to 5 (best))")



## ---- fig.cap="Boxplot of the Quality Rating by Attractiveness (Pepper)"------

boxplot(Rateprof$quality ~ factor(Rateprof$pepper),
     main = "Quality Rating by Attractiveness",
     xlab = "Attractiveness (pepper)",
     ylab = "Quality Ratings (from 1 (worst) to 5 (best))")



## ---- fig.cap="Scatter Plot of Quality Rating compared with Easiness of the Class"----

plot(Rateprof$easiness, Rateprof$quality,
     main = "Quality Rating Compared to Easiness of the Class",
     xlab = "Easiness of the Class (1 (worst) to 5 (best))",
     ylab = "Quality Ratings (from 1 (worst) to 5 (best))")

abline(lm(Rateprof$quality ~ Rateprof$easiness, data = prof_df), col = "blue")



## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of the Quality Rating by Discipline"----

boxplot(Rateprof$quality ~ factor(Rateprof$discipline),
     main = "Quality Rating by Discipline",
     xlab = "Discipline",
     ylab = "Quality Ratings (from 1 (worst) to 5 (best))")



## ---- fig.cap="Boxplot of the Easiness by Gender"-----------------------------

boxplot(Rateprof$easiness ~ factor(Rateprof$gender),
     main = "Easiness by Gender",
     xlab = "Gender",
     ylab = "Easiness (from 1 (worst) to 5 (best))")



## ---- fig.cap="Boxplot of the Easiness by Discipline"-------------------------

boxplot(Rateprof$easiness ~ factor(Rateprof$discipline),
     main = "Easiness by Discipline",
     xlab = "Discipline",
     ylab = "Easiness (from 1 (worst) to 5 (best))")



## ---- results='hide'----------------------------------------------------------
full_lm = lm(quality ~ easiness + gender + pepper + discipline + easiness*gender + easiness*discipline, data = prof_df)
red_lm = lm(quality ~ easiness + gender + pepper + discipline, data = prof_df)


## ---- fig.cap="QQ Plot of Residuals"------------------------------------------

plot(red_lm,
     which=2)



## ---- fig.cap="Scatterplot of Residuals Compared with Fitted Values"----------

plot(red_lm, which = 1)



## ---- results='hide'----------------------------------------------------------
anova(red_lm, full_lm)


## ---- fig.cap="Summary of Reduced Model"--------------------------------------
modelsummary(list("Model 1" = red_lm),
             gof_map = c("r.squared", "nobs"))


## ---- results='hide'----------------------------------------------------------
summary(red_lm)
confint(red_lm)

