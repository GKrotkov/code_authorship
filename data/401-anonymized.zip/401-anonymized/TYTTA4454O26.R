## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
knitr::opts_chunk$set(message = FALSE) # include this if you don't want markdown to knit messages
knitr::opts_chunk$set(warning = FALSE) # include this if you don't want markdown to knit warnings

rm(list=ls())
#load in appropriate libraries
library(tidyverse)
library(ggplot2)
library(dplyr)
library(broom)
library(gridExtra)
library(kableExtra)

sleep <- read.csv("/Users/ameliaboose/Desktop/CMU/4th Year/401/data exam /cmu-sleep.csv")
sleep <- sleep %>% mutate (hours = TotalSleepTime/60)

sleep$perf <- with(sleep, ifelse(cum_gpa<3.16, "Low",
                          ifelse(cum_gpa>=3.16 & cum_gpa<3.5, "Middle Low",
                                 ifelse(cum_gpa>=3.5 & cum_gpa<3.77, "Middle High",
                                        "High"))))
#reorder levels

sleep$perf <- factor(sleep$perf, 
                     levels = c("Low", "Middle Low", "Middle High", "High"))


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Total Sleep Time, in Average Hours per Night"----
sleep %>% 
  ggplot(aes(x=hours)) + 
  geom_histogram(color = "black", fill = "grey", bins = 30) + 
  labs(x = "Average Hours of Sleep per Night",
       y="Count")


## ---- fig.width=4, fig.height=3, fig.cap = "Histogram of Term GPA, out of 4.0"----
sleep %>% 
  ggplot(aes(x=term_gpa)) + 
  geom_histogram(color = "black", fill = "grey", bins = 30) + 
  labs(x = "Term GPA (Out of 4.0)",
       y="Count") 


## ----fig.width=4, fig.height=3, fig.cap = "Barplot of Performance Groups"-----
sleep %>% 
  ggplot(aes(x=perf)) + 
  geom_bar(fill = "grey", color = "black") + 
  labs(x = "Performance Group",
       y="Count") 


## ---- fig.width=4, fig.height=3, fig.cap="Plot of Total Sleep Time (Hours per Night) and Term GPA (out of 4.0)"----
sleep %>% 
  ggplot(aes(x=hours, y=term_gpa)) + 
  geom_point() + 
  labs(x = "Average Hours of Sleep per Night", 
       y = "Term GPA") + geom_smooth(se=F)


## ---- fig.width=4, fig.height=3, fig.cap="Plot of Term GPA (out of 4.0) by Performance Group"----
sleep %>% 
  ggplot(aes(x = term_gpa, y = perf)) + 
  geom_boxplot() + 
   labs(x = "Term GPA (Out of 4.0)", 
       y = "Performance Group")


## ---- fig.width = 4, fig.height = 4, fig.cap = "Multiple Regression QQ Plot"----
#lm
new.lm <- lm(term_gpa ~ hours + cum_gpa, data = sleep)

#QQ plot
qqnorm(residuals(new.lm))
qqline(residuals(new.lm))


## ---- fig.width = 5, fig.height = 4, fig.cap = "Multiple Regression Residual Plot"----
sleep.new <- augment(new.lm)

sleep.new %>%
  ggplot(aes(x = hours, y = .resid)) + 
  geom_point() + geom_hline(yintercept = 0, color = "red") +
  labs(x = "Average Hours of Sleep per Night")


## ---- fig.width=4, fig.height=3, fig.cap="Plot of Total Sleep Time (Hours per Night) by Performance Group"----
sleep %>% 
  ggplot(aes(x=hours, y=perf)) + 
  geom_boxplot() + 
  labs(x = "Average Hours of Sleep per Night", 
       y = "Performance Group") 


## ---- fig.cap= "Regression Output and T-Test Results"-------------------------
new.lm %>%
  tidy() %>%
  kable(col.names = c("Term", "Estimate", "St. Error", "Test Statistic", "p-value"),
        digits = c(0,4,4,4, 10),
        caption = "Regression Output and T-Test Results") %>%  
  row_spec(0, bold = TRUE) %>% kable_styling()

