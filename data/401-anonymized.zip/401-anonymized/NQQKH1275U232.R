## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(readr)
cmu_sleep <- read_csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
summary (cmu_sleep$TotalSleepTime)


## -----------------------------------------------------------------------------
hist(cmu_sleep$TotalSleepTime,
main = "Figure1 : Distribution of TotalSleepTime", 
xlab ="TotalSleepTime (min)",
ylab= "Frequency",
col = "deepskyblue1",
breaks = 40)


## -----------------------------------------------------------------------------
summary (cmu_sleep$term_gpa)


## -----------------------------------------------------------------------------
hist(cmu_sleep$term_gpa,
main = "Figure2 : Distribution of Term_GPA", 
xlab ="Term GPA (out of 4.0)",
ylab= "Frequency",
col = "deepskyblue2",
breaks = 40)


## -----------------------------------------------------------------------------
summary (cmu_sleep$cum_gpa)


## -----------------------------------------------------------------------------
hist(cmu_sleep$cum_gpa,
main = "Figure3 : Distribution of Cum_GPA", 
xlab ="Cumulative GPA (out of 4.0)",
ylab= "Frequency",
col = "deepskyblue3",
breaks = 40)


## -----------------------------------------------------------------------------
x = cmu_sleep$TotalSleepTime 
y = cmu_sleep$term_gpa

plot(x <- x, 
     у <- y,
main = "Figure4 : Students' Term_GPA by TotalSleepTime", 
xlab = "TotalSleepTime (Min)",
ylab = "Term_GPA (out of 4.0)",
col = "blue3")


## -----------------------------------------------------------------------------
cor(cmu_sleep$TotalSleepTime,cmu_sleep$term_gpa)


## -----------------------------------------------------------------------------
model <- lm(y ~ x, data = cmu_sleep)
#Figure 5 Residual Plot
plot (model, which = 1,
    col = "skyblue3")


## -----------------------------------------------------------------------------
#QQ Plot
plot (model, which = 2)


## -----------------------------------------------------------------------------
x = cmu_sleep$TotalSleepTime 
y = cmu_sleep$term_gpa

plot(x <- log(x), 
     у <- y,
main = "Figure7 : Students' Term_GPA by Log(TotalSleepTime)", 
xlab = "Log(TotalSleepTime) (Min)",
ylab = "Term_GPA (out of 4.0)",
col = "blue3")

## -----------------------------------------------------------------------------
cor(log(x),y)


## -----------------------------------------------------------------------------
set.seed(122)
sleep.c = scale(cmu_sleep$TotalSleepTime, center=TRUE, scale=FALSE)
mod1 = lm(formula = y ~ x, data = cmu_sleep)
summary(mod1)


## -----------------------------------------------------------------------------
CI <- confint(mod1)


## -----------------------------------------------------------------------------
print(CI)

