## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- include=FALSE-----------------------------------------------------------

library(ggplot2)
library(alr4)
install.packages('GGally', repos="http://cran.us.r-project.org")
library(GGally)
library(gridExtra)
library(dplyr)
library(broom)
install.packages('modelsummary', repos="http://cran.us.r-project.org")
library(modelsummary)
install.packages("car", repos="http://cran.us.r-project.org")
install.packages("knitr", repos="http://cran.us.r-project.org")
library(knitr)



## ---- echo=FALSE--------------------------------------------------------------

data <- Rateprof



## ---- echo=FALSE, fig.height=8, message=FALSE---------------------------------

quality <- data$quality
response_dist <- ggplot(data, aes(x=quality))+
  geom_histogram()+
  labs(
    title="Distribution of quality ratings",
    x="Quality Ratings"
  )

gender <- factor(data$gender)
gender_dist <- ggplot(data, aes(x=(gender)))+
  geom_bar()+
  labs(
    title="Distribution of gender",
    x="Instructor Gender"
  )

attractive <- factor(data$pepper)
pepper_dist <- ggplot(data, aes(x=attractive))+
  geom_bar()+
  labs(
    title="Distribution of attractiveness rating",
    x="Whether Instructors are Rated Attractive"
  )

easy <- data$easiness
easy_dist <- ggplot(data, aes(x=easy))+
  geom_histogram()+
  labs(
    title="Distribution of easiness ratings",
    x="Easiness Ratings for Instructors"
  )

discipline <- factor(data$discipline)
discipline_dist <- ggplot(data, aes(x=discipline))+
  geom_bar()+
  labs(
    title="Distribution of disciplines",
    x="Discipline of Instructor"
  )

grid.arrange(response_dist, gender_dist, pepper_dist, easy_dist, discipline_dist)



## ---- echo=FALSE, fig.height=8, message=FALSE---------------------------------

quality_gender <- ggplot(data, aes(x=gender, y=quality))+
  geom_boxplot()+
  labs(
    title="Quality Ratings vs. Gender",
    x="Gender",
    y="Quality Rating"
  )

quality_pepper <- ggplot(data, aes(x=attractive, y=quality))+
  geom_boxplot()+
  labs(
    title="Quality Ratings vs. Attractiveness",
    x="Whether Instructors are Rated Attractive",
    y="Quality Rating"
  )

quality_easy <- ggplot(data, aes(x=easy, y=quality))+
  geom_point()+
  labs(
    title="Quality Ratings vs. Easiness",
    x="Easiness Rating of Course",
    y="Quality Rating"
  )

quality_discipline <- ggplot(data, aes(x=discipline, y=quality))+
  geom_boxplot()+
  labs(
    title="Quality Ratings vs. Discipline",
    x="Discipline of Course",
    y="Quality Rating"
  )

easy_gender <- ggplot(data, aes(x=gender, y=easy))+
  geom_boxplot()+
  labs(
    title="Easiness vs. Gender",
    x="Gender of Instructor",
    y="Easiness Rating"
  )

easy_discipline <- ggplot(data, aes(x=discipline, y=easy))+
  geom_boxplot()+
  labs(
    title="Easiness vs. Discipline",
    x="Discipline of Course",
    y="Easiness Ratingn"
  )

grid.arrange(quality_gender, quality_pepper, quality_easy, quality_discipline,
             easy_gender, easy_discipline)



## ---- echo=FALSE, fig.height=8, message=FALSE---------------------------------

full_fit <- lm(quality ~ easy + easy:discipline + easy:gender + discipline + gender +
                 attractive)

resid_fit <- ggplot(augment(full_fit), aes(x= .fitted, y= .resid))+
  geom_point()+
  labs(
    x="Fitted values",
    y="Residuals"
  )+
  geom_smooth(method=lm)

qq_plot <- ggplot(augment(full_fit), aes(sample= .resid))+
  geom_qq()+
  geom_qq_line()+
  labs(
    x="Theoretical quantiles",
    y="Sample quantiles"
  )

cooks_distance <- ggplot(augment(full_fit), aes(seq_along(.cooksd), .cooksd))+
  geom_bar(stat="identity", position="identity")+
  labs(
    x="Obs. number",
    y="Cook's distance"
  )

grid.arrange(resid_fit, qq_plot, cooks_distance)



## ---- include=FALSE-----------------------------------------------------------

summary(full_fit)
reduced_fit1 <- lm(quality ~ easy + easy:discipline + easy:gender + discipline + gender)
reduced_fit2 <- lm(quality ~ easy + easy:gender + gender + attractive)
reduced_fit3 <- lm(quality ~ easy + easy:discipline + discipline + attractive)
reduced_fit4 <- lm(quality ~ discipline + gender + attractive)
reduced_fit5 <- lm(quality ~ easy + discipline + gender + attractive)
f_1 <- anova(reduced_fit1, full_fit)
f_2 <- anova(reduced_fit2, full_fit)
f_3 <- anova(reduced_fit3, full_fit)
f_4 <- anova(reduced_fit4, full_fit)
f_5 <- anova(reduced_fit5, full_fit)



## ---- echo=FALSE--------------------------------------------------------------

anova_1 <- as.data.frame(f_1)
anova_1$model <- c("Reduced Model 1", "Full Model")
anova_1$`Pr(>F)` <- format(f_1$`Pr(>F)`, scientific = TRUE)
anova_1 <- anova_1[, c("model", names(anova_1)[-ncol(anova_1)])]
kable(anova_1, caption="Reduced Model 1 vs. Full Model")



## ---- echo=FALSE--------------------------------------------------------------

anova_2 <- as.data.frame(f_2)
anova_2$model <- c("Reduced Model 2", "Full Model")
anova_2$`Pr(>F)` <- format(f_2$`Pr(>F)`, scientific = TRUE)
anova_2 <- anova_2[, c("model", names(anova_2)[-ncol(anova_2)])]
kable(anova_2, caption="Reduced Model 2 vs. Full Model")



## ---- echo=FALSE--------------------------------------------------------------

anova_3 <- as.data.frame(f_3)
anova_3$model <- c("Reduced Model 3", "Full Model")
anova_3$`Pr(>F)` <- format(f_3$`Pr(>F)`, scientific = TRUE)
anova_3 <- anova_3[, c("model", names(anova_3)[-ncol(anova_3)])]
kable(anova_3, caption="Reduced Model 3 vs. Full Model")



## ---- echo=FALSE--------------------------------------------------------------

anova_4 <- as.data.frame(f_4)
anova_4$model <- c("Reduced Model 4", "Full Model")
anova_4$`Pr(>F)` <- format(f_4$`Pr(>F)`, scientific = TRUE)
anova_4 <- anova_4[, c("model", names(anova_4)[-ncol(anova_4)])]
kable(anova_4, caption="Reduced Model 4 vs. Full Model")



## ---- echo=FALSE--------------------------------------------------------------

anova_5 <- as.data.frame(f_5)
anova_5$model <- c("Reduced Model 5", "Full Model")
anova_5$`Pr(>F)` <- format(f_5$`Pr(>F)`, scientific = TRUE)
anova_5 <- anova_5[, c("model", names(anova_5)[-ncol(anova_5)])]
kable(anova_5, caption="Reduced Model 5 vs. Full Model")



## ---- echo=FALSE--------------------------------------------------------------

final_fit <- lm(quality ~ easy + attractive)
modelsummary(full_fit, statistic = c("T={statistic}", "conf.int"),
             conf_level = 0.95, caption="Summary Table of Coefficient Estimates")


