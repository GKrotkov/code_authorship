## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
install.packages('alr4', repos = "http://cran.us.r-project.org")
library(alr4)
library(ggplot2)
data = Rateprof


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Average quality rating, between 1, worst, to 5, best. Figure 1"----
ggplot(data, aes(x=quality)) +
  geom_histogram(bins = 15) +
  labs(x = "Average Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Average Easiness rating, between 1, worst, to 5, best. Figure 2"----
ggplot(data, aes(x=easiness)) +
  geom_histogram(bins = 15) +
  labs(x = "Average Easiness Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between Average Quality and Average Easiness based on the attractivenss of the instructor. Figure 3"----
ggplot(data, aes(x = easiness, y = quality, color = pepper)) +
  geom_point() +
  labs(x = "Average Easiness Rating", y = "Average Quality Rating", color = "Attractiveness")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between the Instructors Gender and their Average Easiness Rating. Figure 4"----
ggplot(data, aes(x = gender, y = easiness)) + 
  geom_boxplot() + 
  labs(x = "Gender", y = "Average Easiness Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between whether or not the instructor is considered attractive and their Average Easiness Rating. Figure 5"----
ggplot(data, aes(x = pepper, y = easiness)) + 
  geom_boxplot() + 
  labs(x = "Attractiveness", y = "Average Easiness Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between the Instructors Discipline and their Average Easiness Rating. Figure 6"----
ggplot(data, aes(x = discipline, y = easiness)) + 
  geom_boxplot() + 
  labs(x = "Discipline", y = "Average Easiness Rating")


## -----------------------------------------------------------------------------
## Global F-test to determine which predictors are significant
lm_1full = lm(quality ~ easiness + gender + pepper + discipline, data)
summary(lm_1full)


## -----------------------------------------------------------------------------
## Partial F-test to determine if the interaction between easiness and gender was significant
lm_2full = lm(quality ~ easiness + discipline + gender + pepper + easiness:gender,data)
lm_2red = lm(quality ~ easiness + gender + discipline + pepper,data)
anova(lm_2red,lm_2full)


## -----------------------------------------------------------------------------
## Partial F-test to determine if interaction between easiness and attractiveness was signifcant
lm_3full = lm(quality ~ easiness + discipline + pepper + easiness:pepper,data)
lm_3red = lm(quality ~ easiness + discipline + pepper,data)
anova(lm_3red,lm_3full)


## -----------------------------------------------------------------------------
## Summary of the final model
quality_fit = lm(quality ~ easiness + pepper + gender + discipline + easiness*pepper,data)


## -----------------------------------------------------------------------------
## Model Selection using Stepwise progression
fulllm <- lm(quality ~ easiness * (gender + pepper + discipline),data)
finalmod <- step(fulllm, direction = "both", trace = 0)


## -----------------------------------------------------------------------------
install.packages('modelsummary', repos = "http://cran.us.r-project.org")
library(modelsummary)

modelsummary(list("Model 1" = quality_fit, "Chosen Model" = finalmod),
             gof_map = c("r.squared", "nobs"))


## -----------------------------------------------------------------------------
extractAIC(quality_fit)
extractAIC(finalmod)


## -----------------------------------------------------------------------------
confint(finalmod)


## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of Average Easiness Rating. Figure 7"----
ggplot(data = data, aes(x = easiness, y = residuals(quality_fit))) +
  geom_point() +
  labs(x = "Average Easiness Rating", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of Instructor Attractiveness. Figure 8"----
ggplot(data = data, aes(x = pepper, y = residuals(quality_fit))) +
  geom_boxplot() +
  labs(x = "Attractiveness of Instructor", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Residual scatterplot of Gender of Instructor. Figure 9"----
ggplot(data = data, aes(x = gender, y = residuals(quality_fit))) +
  geom_boxplot() +
  labs(x = "Gender of Instructor", y = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Residuals vs Fitted Values. Figure 10"----
library(broom)
ggplot(augment(quality_fit), aes(x = .fitted, y = .resid)) + 
  geom_point() + 
  labs(x = "Fitted value", y = "Residual")


## ---- fig.width=4, fig.height=3, fig.cap="Normal QQ-Plot. Figure 11"----------
ggplot(augment(quality_fit), aes(sample = .resid)) + 
  geom_qq() + 
  geom_qq_line() + 
  labs(x = "Theoretical quantiles", y = "Sample quantiles")


## -----------------------------------------------------------------------------
vif(quality_fit,type='predictor')

