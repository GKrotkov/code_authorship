## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)


## ---- echo = FALSE------------------------------------------------------------
sleep_data <- read.csv("cmu-sleep.csv")


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of TotalSleepTime, showing a univariate, approximately normal distribution centered around 420 minutes (7 hours) of sleep per night, on average"----
ggplot(sleep_data, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 20) + 
  labs(title = "Distribution of TotalSleepTime", x = "Average minutes slept per night", y = "Number of Students")


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of term_gpa, showing a univariate, approximately normal distribution with left skew, centered around 3.6"----
ggplot(sleep_data, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.1) + 
  labs(title = "Distribution of Spring Term GPA", x = "GPA, out of 4.0", y = "Number of Students")


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of the log of term_gpa, a univariate, approximately normal distribution with left skew, centered around 1.25"----
ggplot(sleep_data, aes(x = log(term_gpa))) +
  geom_histogram(binwidth = 0.1) + 
  labs(title = "Distribution of the Log of Spring Term GPA", x = "Log of GPA, out of 4.0", y = "Number of Students")


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of cum_gpa, showing a univariate, approximately normal distribution with left skew, centered around 3.7"----
ggplot(sleep_data, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.1) + 
  labs(title = "Distribution of Cumulative Fall GPA", x = "GPA, out of 4.0", y = "Number of Students")


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot of term_gpa by TotalSleepTime"----
ggplot(sleep_data, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(title = "Distribution of Spring Term GPA by Average Sleep", x = "Average minutes slept per night", y = "GPA, out of 4.0")


## -----------------------------------------------------------------------------
#converting TotalSleepTime to hours
sleep_data$sleep_hours <- sleep_data$TotalSleepTime/60
#model fitting
sleep_model <- lm(term_gpa ~ sleep_hours, data = sleep_data)


## ---- fig.width=6, fig.height=4, fig.cap="Residual Plot of term_gpa by TotalSleepTime with mean(residuals) = 6.174373*10^-18, or approximately 0, even with a ceiling on residuals due to the 4.0 gpa ceiling"----
#Linear Model assumption testing
residuals <- residuals(sleep_model)
plot(fitted(sleep_model), residuals, xlab="Total Sleep Time", 
     ylab="Residuals",
     main = "Residuals v Predictor (term_gpa)")
abline(h = 0, col = "red")
# mean(residuals)


## ---- fig.width=6, fig.height=4, fig.cap="QQ Plot of term_gpa by TotalSleepTime, showing a deviation from the qq line at the tails"----
qqnorm(residuals)
qqline(residuals, col = "red")

# sleep_model_log <- lm(log(term_gpa) ~ sleep_hours, data = sleep_data)
# residuals_log <- residuals(sleep_model_log)
# plot(fitted(sleep_model_log), residuals_log, xlab="Total Sleep Time",
#      ylab="Residuals",
#      main = "Residuals v Predictor (term_gpa)")
# abline(h = 0, col = "red")


## ---- eval = FALSE------------------------------------------------------------
## summary(sleep_model)
## 
## #correlation coefficient
## sqrt(0.04067)
## 
## #confidence interals
## confint(sleep_model)
## 
## #determining the effect of two hours of sleep on term_gpa
## 0.1191*2
## confint(sleep_model)*2

