## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(dplyr)
library(ggplot2)
library(GGally)
library(tidyverse)

data(Rateprof)
head(Rateprof)


## -----------------------------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = quality)) + 
  geom_histogram(color = "black", fill = "lightpink", bins = 40) + 
  labs(x = "Quality Rating (1 = worst, 5 = best)", y = "Frequency", title = "Distribution of Professor Quality Ratings")
  
summary(Rateprof$quality)


## -----------------------------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = easiness)) + 
  geom_histogram(color = "black", fill = "lightpink", bins = 40) + 
  labs(x = "Easiness Rating (1 = hardest, 5 = easiest)", y = "Frequency", title = "Distribution of Class Easiness Ratings")
  
summary(Rateprof$easiness)


## -----------------------------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = pepper)) + 
  geom_bar(color = "black", fill = "lightpink") + 
  labs(x = "Professor Attractiveness (yes or no)", y = "Frequency", title = "Distribution of Professor Attractiveness")
  
summary(Rateprof$pepper)


## -----------------------------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = gender)) + 
  geom_bar(color = "black", fill = "lightpink") + 
  labs(x = "Gender (male or female)", y = "Frequency", title = "Distribution of Professor Gender")
summary(Rateprof$gender)


## -----------------------------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = discipline)) + 
  geom_bar(color = "black", fill = "lightpink") + 
  labs(x = "Class Discipline", y = "Frequency", title = "Distribution of Class Disciplines")
  
summary(Rateprof$discipline)


## -----------------------------------------------------------------------------
boxplot(Rateprof$quality ~ Rateprof$discipline, xlab = "Class Discipline", ylab = "Professor Quality Rating", main = "Professor Quality Rating vs. Class Discipline")


## -----------------------------------------------------------------------------
boxplot(Rateprof$quality ~ Rateprof$gender, xlab = "Professor Gender (male or female)", ylab = "Professor Quality Rating", main = "Professor Quality Rating vs. Gender")


## -----------------------------------------------------------------------------
boxplot(Rateprof$quality ~ Rateprof$pepper, xlab = "Attractiveness (yes or no)", ylab = "Professor Quality Rating", main = "Professor Quality Rating vs. Attractiveness")


## -----------------------------------------------------------------------------
Rateprof %>%
  ggplot(aes(x = easiness, y = quality, color = gender, shape = discipline)) + geom_point() + 
  labs(x = "Class Easiness", y = "Professor Quality Rating", main = "Professor Quality Rating vs. Class Easiness")


## -----------------------------------------------------------------------------
model1 = lm(quality ~ easiness + gender + pepper + discipline + gender:discipline + easiness:gender + easiness:discipline, data = Rateprof)
model2 = lm(quality ~ easiness + gender + pepper + discipline + easiness:gender, data = Rateprof)
model3 = lm(quality ~ easiness + gender + pepper + discipline + gender:discipline, data = Rateprof)
model4 = lm(quality ~ easiness + gender + pepper + discipline + easiness:discipline, data = Rateprof)
step_model = step(model1, direction = "both", trace = 0)
step_model


## -----------------------------------------------------------------------------
plot(model1)


## -----------------------------------------------------------------------------
test1 = anova(model1, step_model)
test1


## -----------------------------------------------------------------------------
anova(model1, model4)


## -----------------------------------------------------------------------------
anova(model1, model2)


## -----------------------------------------------------------------------------
anova(model1, model3)

