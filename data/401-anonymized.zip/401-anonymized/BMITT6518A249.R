## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
library(alr4)
library(GGally)
library(dplyr)
library(gridExtra)
library(grid)
library(modelsummary)
knitr::opts_chunk$set(echo = FALSE)


## ----quality_easiness,   out.width="50%", fig.align='center', fig.cap="Univariate EDA for Quality and Easiness",  echo=FALSE----
quality = Rateprof$quality
gender = Rateprof$gender
attractiveness = Rateprof$pepper 
discipline = Rateprof$discipline
easiness = Rateprof$easiness 

par(mfrow = c(1, 2))  


hist(quality, main = "Quality", xlab = "Quality (between 1 and 5)", ylab = "Frequency", col = "grey", breaks = 20)
hist(easiness, main = "Easiness", xlab = "Easiness (between 1 and 5)", ylab = "Frequency", col = "grey", breaks = 20)



## ----gender_attract_disc,   out.width="50%", fig.align='center', fig.cap="Univariate EDA for Gender, Attractiveness, and Discipline",  echo=FALSE----
par(mfrow = c(1, 3))  

barplot(table(gender), main = "Bar Plot of Gender", xlab = "Gender", ylab = "Frequency")
barplot(table(attractiveness), main = "Bar Plot of Attractiveness", xlab = "Attractiveness", ylab = "Frequency")
barplot(table(discipline), main = "Bar Plot of Discipline", xlab = "Discipline", ylab = "Frequency")




## ----box_plots,   out.width="50%", fig.align='center', fig.cap="Box Plots for Gender, Attractiveness, and Discipline",  echo=FALSE----
p1 <- ggplot(Rateprof, aes(x = factor(gender), y = quality)) +
  geom_boxplot(position = "dodge") +
  labs(x = "Gender", y = "Professor Quality Ratings (on a scale from 1-5)") +
  ggtitle("Box Plot of Quality Rating by Gender")

p2 <- ggplot(Rateprof, aes(x = factor(attractiveness), y = quality)) +
  geom_boxplot(position = "dodge") +
  labs(x = "Attractiveness", y = "Professor Quality Ratings (on a scale from 1-5)") +
  ggtitle("Box Plot of Quality Rating by Attractiveness")

p3 <- ggplot(Rateprof, aes(x = factor(discipline), y = quality)) +
  geom_boxplot(position = "dodge") +
  labs(x = "Discipline", y = "Professor Quality Ratings (on a scale from 1-5)") +
  ggtitle("Box Plot of Quality Rating by Discipline")

grid.arrange(p1, p2, p3, ncol = 3)


## ----quality_vs_easiness_gender,  out.width="40%", fig.align='center', fig.cap="Scatterplot of Easiness Rating Against Quality Rating by Gender", echo=FALSE----

ggplot(Rateprof, aes(x = easiness, y = quality, color = gender)) +
  geom_point(shape = 20, size = 2) +  
  labs(x = "Easiness Rating (on a scale from 1 to 5)", y = "Quality Rating (on a scale from 1 to 5)",
       title = "Easiness Rating vs. Quality Rating by Gender") +
  scale_color_manual(values = c("blue", "red")) +
  theme_minimal()


## ----quality_vs_easiness_discipline,  out.width="40%", fig.align='center', fig.cap="Scatterplot of Easiness Rating Against Quality Rating by Discipline", echo=FALSE----

ggplot(Rateprof, aes(x = easiness, y = quality, color = discipline)) +
  geom_point(shape = 16, size = 2) +  
  labs(x = "Easiness Rating (1-5)", y = "Quality Rating (1-5)",
       title = "Easiness Rating vs. Quality Rating by Discipline") +
  scale_color_manual(values = c("orange", "lightgreen", "turquoise", "pink")) +
  theme_minimal()


## ----quality_vs_easiness_attractiveness,  out.width="40%", fig.align='center', fig.cap="Scatterplot of Easiness Rating Against Quality Rating by Attractiveness", echo=FALSE----

ggplot(Rateprof, aes(x = easiness, y = quality, color = attractiveness)) +
  geom_point(shape = 16, size = 2) +  
  labs(x = "Easiness Rating (1-5)", y = "Quality Rating (1-5)",
       title = "Easiness Rating vs. Quality Rating by Attractiveness") +
  scale_color_manual(values = c("blue", "red")) +
  theme_minimal()


## ----residual_plot_fitted,  out.width="40%", fig.align='center', fig.cap="Scatterplot of Fitted Values against Residuals", echo=FALSE----

model <- lm(quality ~ factor(gender) + factor(attractiveness) + easiness + factor(discipline) + factor(gender)*easiness + easiness*factor(discipline), data = Rateprof)
res <- resid(model)

plot(fitted(model), res,
     xlab = "Quality Rating (1-5)", 
     ylab = "Residuals",
     main = "Scatterplot of Quality Ratings vs. Residuals"
     )


## ----residual_plots,  out.width="40%", fig.align='center', fig.cap="Scatterplots of Easiness Rating against Residuals", echo=FALSE----


plot(easiness, res,
     xlab = "Easiness Rating (1-5)", 
     ylab = "Residuals",
     main = "Scatterplot of Easiness Ratings vs. Residuals",
     )


## ----qq_plot,  out.width="40%", fig.align='center', fig.cap="Q-Q Plot of the Residuals", echo=FALSE----
qqnorm(res)
qqline(res, col = "red")


## ----model_summary,  out.width="40%", fig.align='center', fig.cap="Model Summary", echo=FALSE----
modelsummary(list("Model" = model),
             gof_map = c("r.squared", "nobs"))


## ---- message = FALSE, include = FALSE----------------------------------------
summary(model)

conf_interval <- confint(model, level = 0.95)
conf_interval


## ---- message = FALSE, include=FALSE------------------------------------------

reduced_model <- lm(quality ~ factor(gender) + factor(attractiveness) + easiness + factor(discipline), data = Rateprof)

partial_F_test <- anova(reduced_model,model)
partial_F_test

