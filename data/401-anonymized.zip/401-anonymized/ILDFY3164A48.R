## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE, fig.pos= "H", out.extra = "")


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(patchwork)
library(GGally)
library(dplyr)
library(broom)
library(modelsummary)
library(kableExtra)


## ---- include=FALSE-----------------------------------------------------------
data <- read.csv('cmu-sleep.csv')


## ---- fig.width=7, fig.height=6, fig.cap="Pairs plot for all variables"-------
data |>
	select(TotalSleepTime, term_gpa, cum_gpa) |>
	ggpairs(columnLabels = c("Total sleep time (minutes)", "Term GPA (out of 4.0)", "Cumulative GPA (out of 4.0)"))


## ---- include=FALSE-----------------------------------------------------------
slm <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data=data)
slm_coefs <- coef(summary(slm))
slm_resid <- residuals(slm)
slm_aug <- augment(slm)
slm_confint <- confint(slm)


## ---- fig.cap="Residual plot against total sleep time"------------------------
plot(data$TotalSleepTime, slm_resid, ylab="residuals", xlab="Total sleep time (minutes)")


## ---- fig.cap="Residual plot against cumulative GPA"--------------------------
plot(data$cum_gpa, slm_resid, ylab="residuals", xlab="Cumulative GPA (out of 4.0)")


## ---- fig.cap="Residual plot against fitted values (GPA out of 4.0)"----------
ggplot(slm_aug, aes(x=.fitted, y = .resid)) + geom_point() + labs(x="Fitted value (GPA out of 4.0)", y = "Residual")


## ---- fig.cap="Normal Q-Q plot of sesiduals"----------------------------------
ggplot(slm_aug, aes(sample=.resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical quantiles", y = "Observed quantiles")


## ---- fig.cap="Histogram of cook's distance"----------------------------------
ggplot(slm_aug, aes(x=.cooksd)) + geom_histogram(bins=30) + xlab("Cook's Distance")


## ---- include=FALSE-----------------------------------------------------------
cookd <- cooks.distance(slm)
sorted_f_cookd <- pf(cookd, 2, nrow(data) - 2)


## ---- include=FALSE-----------------------------------------------------------
b_0 <- signif(slm_coefs[1], 3)
b_0_ub <- signif(slm_confint[4], 3)
b_0_lb <- signif(slm_confint[1], 3)
b_1 <- signif(slm_coefs[2], 3)
b_1_lb <- signif(slm_confint[2], 3)
b_1_ub <- signif(slm_confint[5], 3)
b_1_t_value <- signif(slm_coefs[9], 3)
b_1_p_value <- signif(slm_coefs[11], 3)
b_2 <- signif(slm_coefs[3], 3)
b_2_lb <- signif(slm_confint[3], 3)
b_2_ub <- signif(slm_confint[6], 3)


## ---- include=FALSE-----------------------------------------------------------
fmt_fun <- function(v) {lapply(v, function (e) signif(e, 3))}


## -----------------------------------------------------------------------------
msummary(list("Model" = slm), shape = term ~ statistic, estimate = "{estimate} (95\\% CI [ {conf.low}, {conf.high}])", statistic = c("statistic", "p.value"), conf_level=0.95, title= 'Model summary', gof_map = c("nobs"), fmt = fmt_fun, output="kableExtra") %>% kable_styling(latex_options = c("HOLD_position"))


## ---- include=FALSE-----------------------------------------------------------
x1 <- c(1, 120, 4)
x2 <- c(1, 0, 4)
diff <- (t(x1) %*% coef(slm) - t(x2) %*% coef(slm))[1]
diff_var <- (t(x1 - x2) %*% vcov(slm) %*% (x1 - x2))[1]
diff_se <- sqrt(diff_var)
diff_lb <- diff + qt(0.025, nrow(data) - 3) * diff_se
diff_ub <- diff + qt(0.975, nrow(data) - 3) * diff_se

