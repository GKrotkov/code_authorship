## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=2.5, fig.cap="Histogram of Professors, which is approximately normally distributed quality rating", fig.align='center'----
profData = alr4::Rateprof
rating<-profData$quality
p1 <- hist(rating, main="Distribution of Quality Scores",
     breaks = 15,
     xlab="Average Quality Score", 
     ylab="Number of Professors", col = "Gray")



## ---- fig.width=4, fig.height=2.5, fig.cap="Histogram of Professors' Gender, where slight majority are male", fig.align='center'----
gend<-profData$gender
library(ggplot2)
ggplot(profData, mapping=aes(x=gend)) +
  geom_bar() + xlab("Professor Gender") + 
  ylab("Number of Professors") + 
  ggtitle("Distribution of Professors' Gender")


## ---- fig.width=4, fig.height=2.5, fig.cap="Histogram of Professors' Pepper Rating, where a significant number of professors are rate as non-attractive", fig.align='center'----
pepper<-profData$pepper
ggplot(profData, mapping=aes(x=pepper)) +
  geom_bar() + xlab("Professor's Attractivness") + 
  ylab("Number of Professors") + 
  ggtitle("Distribution of Professors' Attractiveness")


## ---- fig.width=4, fig.height=2.5, fig.cap="Histogram of Course Easiness with an approximately normal distribution", fig.align='center'----
easiness<-profData$easiness
hist(easiness, main="Distribution of Class Easiness",
     breaks = 15,
     xlab="Average Class Difficulty (1 = hard, 5 = easy)", 
     ylab="Number of Professors", col = "Gray")


## ---- fig.width=4, fig.height=2.5, fig.cap="Histogram of Professor Discipline, where humanities, stem, social sciences, and preprofessional training are ranked most to least popular discipline", fig.align='center'----
discipline<-profData$discipline
ggplot(profData, mapping=aes(x=discipline)) +
  geom_bar() + xlab("Professor Discipline") + 
  ylab("Number of Professors") + 
  ggtitle("Distribution of Professor Discipline")


## ---- fig.width=4, fig.height=2.5, fig.cap="Boxplot of Professor Gender, appears to be fairly ubiquitous across male and females", fig.align='center'----
boxplot(rating ~ gend, data = profData,
names = c("Female", "Male"),
xlab = "Gender",
ylab = "Average Quality Rating",
main = "Quality Rating vs. Professor Gender")


## ---- fig.width=4, fig.height=2.5, fig.cap="Boxplot of Professor Attractiveness, implies that professors rated more attractive may have higher teaching quality ratings", fig.align='center'----
boxplot(rating ~ pepper, data = profData,
names = c("No", "Yes"),
xlab = "Attractiveness",
ylab = "Average Quality Rating",
main = "Quality Rating vs. Pepper Rating")


## ---- fig.width=4, fig.height=2.5, fig.cap="Scatterplot of Quality Rating vs Course Difficulty, shows a positively correlated relationship between the two variables", fig.align='center'----
ggplot(profData, mapping=aes(x=easiness, y=rating)) +
  geom_point() + xlab("Course Easiness Rating") + 
  ylab("Average Quality Rating") + 
  ggtitle("Quality Rating vs Course Difficulty")


## ---- fig.width=6, fig.height=2.5, fig.cap="Boxplot of Quality Rating vs. Discipline: does not appear to be a significant realtionship between the two variables", fig.align='center'----
boxplot(rating ~ discipline, data = profData,
xlab = "Discipline",
ylab = "Average Quality Rating",
main = "Quality Rating vs. Professor Discipline")


## ---- fig.width=8, fig.height=2.5, fig.cap="Boxplot of Professor Gender and Easiness, appear to have similar distributions", fig.align='center'----
par(mfrow = c(1, 2))  
boxplot(easiness ~ discipline, data = profData,
xlab = "Discipline",
ylab = "Average Quality Rating",
main = "Quality Rating vs. Professor Discipline")
boxplot(easiness ~ gend, data = profData,
names = c("Female", "Male"),
xlab = "Gender",
ylab = "Course Easiness Rating",
main = "Easiness Rating vs. Professor Gender")


## ---- fig.width=3, fig.height=2.5, fig.cap="Plot of fitted values to residuals, showing relatively random scatter", fig.align='center', fig.pos='H'----
ratingModel <- lm(rating  ~ gend + pepper + easiness + discipline + easiness:gend + easiness:discipline, data = profData)
ggplot((ratingModel), aes(x = .fitted, y = .resid)) +
geom_point() + labs(x = "Fitted value", y = "Residual")


## ---- fig.width=2.5, fig.height=2.5, fig.cap="QQ plot of residuals, showing they follow the normal line", fig.align='center', fig.pos='H'----
qqnorm(ratingModel$residuals)
qqline(ratingModel$residuals)


## ---- fig.align='center'------------------------------------------------------
#install.packages("modelsummary")
library(modelsummary)
full <- lm(rating  ~ gend + pepper + easiness + discipline + easiness:gend + easiness:discipline, data = profData)
reduced <- lm(rating  ~ gend + pepper + easiness + discipline , data = profData)
modelsummary(list("Full Model" = full, "Reduced" = reduced),
             gof_map = c("r.squared", "nobs"),
             caption = "Model Fits for Full and Reduced Model")


## ---- fig.align='center'------------------------------------------------------
anova(full, reduced)

