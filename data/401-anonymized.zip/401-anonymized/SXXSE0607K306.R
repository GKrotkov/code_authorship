## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

library(alr4)
data("Rateprof")
library(GGally)

library(ggplot2)
library(readr)
library(dplyr)
library(tidyr)
library(broom)


## -----------------------------------------------------------------------------
par(mfrow=c(3, 2), mar=c(4, 4, 2, 1))

hist(Rateprof$quality, main = "Distribution of Quality Ratings",
     xlab = "Quality Rating", col = "lightblue", border = "black")

hist(Rateprof$easiness, main = "Distribution of Easiness Ratings",
     xlab = "Easiness Rating", col = "lightblue", border = "black")

table_pepper <- table(Rateprof$pepper)
barplot(table_pepper, main = "Distribution of Attractiveness", 
        xlab = "Attractiveness Rating", ylab = "Frequency", 
        col = c("lightgreen", "lightcoral"))

table_gender <- table(Rateprof$gender)
barplot(table_gender, main = "Distribution of Gender", 
        xlab = "Gender", ylab = "Frequency", 
        col = c("lightpink", "lightblue"))

table_discipline <- table(Rateprof$discipline)
barplot(table_discipline, main = "Distribution of Discipline", 
        xlab = "Discipline", ylab = "Frequency", 
        las = 2)  
par(mfrow=c(1, 1))




## -----------------------------------------------------------------------------
par(mfrow=c(2, 2), mar=c(4, 4, 2, 1))

gender_pepper_counts <- table(Rateprof$gender, Rateprof$pepper)
barplot(gender_pepper_counts, beside = TRUE, 
        main = "Attractiveness Ratings by Gender",
        xlab = "Gender", ylab = "Count",
        col = c("lightpink", "lightblue"),
        legend = rownames(gender_pepper_counts))

plot(Rateprof$pepper, Rateprof$easiness, main="Attractiveness vs Easiness",
     xlab="Attractiveness", ylab="Easiness")

gender_disc_counts <- table(Rateprof$gender, Rateprof$discipline)
barplot(gender_disc_counts, beside = TRUE, 
        main = "Discipline Distribution by Gender",
        xlab = "Gender", ylab = "Count",
        col = c("lightpink", "lightblue"),
        legend = rownames(gender_disc_counts))

boxplot(Rateprof$easiness ~ Rateprof$discipline, main="Easiness by Discipline",
        xlab="Discipline", ylab="Easiness", las=2)

par(mfrow=c(1, 1))



## -----------------------------------------------------------------------------

par(mfrow=c(2, 2), mar=c(4, 4, 2, 1))

boxplot(Rateprof$quality ~ Rateprof$gender, main="Quality Rating by Gender",
        xlab="Gender", ylab="Quality Rating")

plot(Rateprof$pepper, Rateprof$quality, main="Quality Rating vs Attractiveness",
     xlab="Attractiveness (Pepper Rating)", ylab="Quality Rating")

plot(Rateprof$easiness, Rateprof$quality, main="Quality Rating vs Easiness",
     xlab="Easiness", ylab="Quality Rating")

boxplot(Rateprof$quality ~ Rateprof$discipline, main="Quality Rating by Discipline",
        xlab="Discipline", ylab="Quality Rating", las=2) 

par(mfrow=c(1, 1))



## ----include = FALSE----------------------------------------------------------
lm_model <- lm(quality ~ gender + pepper + easiness + discipline, data=Rateprof)
summary(lm_model)


## ----include = FALSE----------------------------------------------------------
lm_interact_model <- lm(quality ~ gender + pepper * easiness + discipline, data=Rateprof)
summary(lm_interact_model)


## ---- fig.width=4, fig.height=3-----------------------------------------------
residuals_df <- data.frame(fitted = lm_interact_model$fitted.values, residuals = lm_interact_model$residuals)
ggplot(data = residuals_df, aes(x = fitted, y = residuals)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(title = "Residuals vs Fitted", x = "Fitted values", y = "Residuals") +
  theme_minimal()


## ---- fig.width=4, fig.height=3-----------------------------------------------
qqnorm(lm_interact_model$residuals)
qqline(lm_interact_model$residuals, col = "red")



## ---- include = FALSE---------------------------------------------------------
summary_info <- summary(lm_interact_model)

coefficients_summary <- summary_info$coefficients

conf_intervals <- confint(lm_interact_model)

print(coefficients_summary)
print(conf_intervals)

