## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(alr4)
library(gridExtra)
library(modelsummary)
library(bestglm)
library(GGally)
data = Rateprof


## ---- fig.width=3, fig.height=3-----------------------------------------------
ggplot(aes(x = factor(gender)), data = data) + geom_bar(aes(fill = factor(gender))) + 
  labs(title = "Distribution of Gender", x = "Gender", y = "Count", fill = "Gender")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = easiness), data = data) + 
  geom_histogram() + labs(title = "Histogram of Easiness of Class", x = "Easiness", y = "Frequency")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = factor(pepper)), data = data) + 
  geom_bar(aes(fill = factor(pepper))) + labs(title = "Distribution of Attractiveness ", 
       x = "Attractiveness", y = "Count", fill = "Attractiveness")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = factor(discipline)), data = data) + 
  geom_bar(aes(fill = factor(discipline))) + labs(title = "Distribution of Discipline ", 
       x = "Discipline", y = "Count", fill = "Discipline")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = quality), data = data) + 
  geom_histogram() + labs(title = "Histogram of Quality of Class", 
                          x = "Quality", y = "Frequency")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = factor(pepper), y = quality), data = data) + 
  geom_boxplot(fill = "lightblue") +labs(title = "Professor Attractiveness vs Quality", 
                       x =  "Attractiveness", y = "Quality")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = factor(discipline), y = quality), data = data) + 
  geom_boxplot(aes(fill = factor(discipline))) + 
  labs(title = "Professor Discipline vs Quality", 
       x = "Discipline", y = "Quality", fill = "Discipline")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = factor(gender), y = quality), data = data) + 
  geom_boxplot(aes(fill = factor(gender))) + 
  labs(title = "Professor Gender vs Quality", 
       x = "Gender", y = "Quality", fill = "Gender")


## ---- fig.width=3.6, fig.height=3---------------------------------------------
ggplot(aes(x = easiness, y = quality), data = data) + 
  geom_point() + labs(title = "Scatterplot of Easiness of Class vs Quality", 
       x = "Easiness", y = "Quality")


## ---- include = FALSE---------------------------------------------------------
tempmodel = lm(quality ~ discipline * easiness * gender * pepper, data = data)
summary(tempmodel)
extractAIC(tempmodel)
model = step(tempmodel, direction = "both", trace = 0)
summary(model)
extractAIC(model)


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))

plot(model, which = 1)

plot(model, which = 2)

par(mfrow = c(1, 1))


## ---- message = FALSE---------------------------------------------------------
library(modelsummary)
modelsummary(model, statistic = c("conf.int", "standard error = {std.error}", "t = {statistic}",
                      "p = {p.value}"), gof_map = c("r.squared", "nobs"))


## -----------------------------------------------------------------------------
mod1 <- lm(quality ~ gender * discipline * easiness, data = data)
mod2 <- lm(quality ~ easiness, data = data)
results <- anova(mod1, mod2)
results

