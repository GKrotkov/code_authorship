## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
data(Rateprof)
library(ggplot2)
library(GGally)

par(mfrow=c(2, 3))
barplot(table(Rateprof$gender), main="Gender Distribution", xlab="Gender")
hist(Rateprof$quality, main="Quality Rating", xlab="Quality Rating")
barplot(table(Rateprof$pepper), main="Attractiveness Distribution", xlab="Attractiveness")
hist(Rateprof$easiness, main="Easiness Rating", xlab="Easiness Rating")
barplot(table(Rateprof$discipline), main="Discipline Distribution", xlab="Discipline")


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() +
  labs(title = "Quality Ratings by Gender", x = "Gender", y = "Quality Rating")


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = pepper, y = quality, fill = pepper)) +
  geom_boxplot() +
  labs(title = "Quality Ratings by Attractiveness", x = "Attractiveness", y = "Quality Rating")


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() +
  labs(title = "Quality Ratings by Discipline", x = "Discipline", y = "Quality Rating")


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(title = "Scatter Plot: Quality vs. Easiness", x = "Easiness Rating", y = "Quality Rating") +
  geom_smooth(method = "lm", se = FALSE, color = "red", formula = y ~ x)


## -----------------------------------------------------------------------------
cor(Rateprof[, c("quality", "easiness")])
cor(as.numeric(as.factor(Rateprof$gender)), Rateprof$easiness)
cor(as.numeric(as.factor(Rateprof$pepper)), Rateprof$easiness)
cor(as.numeric(as.factor(Rateprof$discipline)), Rateprof$easiness)
cor(as.numeric(as.factor(Rateprof$pepper)), as.numeric(as.factor(Rateprof$gender)))
cor(as.numeric(as.factor(Rateprof$pepper)), as.numeric(as.factor(Rateprof$discipline)))
cor(as.numeric(as.factor(Rateprof$gender)), as.numeric(as.factor(Rateprof$discipline)))


## -----------------------------------------------------------------------------
full_model <- lm(quality ~ easiness + gender + pepper + discipline + gender:discipline + pepper:easiness, data = Rateprof)
summary(full_model)


## -----------------------------------------------------------------------------
anova(full_model, update(full_model, . ~ . - gender:discipline))


## -----------------------------------------------------------------------------
reduced_model <- update(full_model, . ~ . - gender:discipline)
anova(reduced_model, update(reduced_model, . ~ . - pepper:easiness))


## -----------------------------------------------------------------------------
summary(reduced_model)

