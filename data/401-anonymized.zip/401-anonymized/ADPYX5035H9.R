## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
suppressPackageStartupMessages(library(car))
suppressPackageStartupMessages(library(modelsummary))
suppressPackageStartupMessages(library(alr4))

## -----------------------------------------------------------------------------
library(alr4)
library(ggplot2)
library(modelsummary)

data<-Rateprof


## -----------------------------------------------------------------------------
hist(data$quality,
main="Average Quality Rating for Instructors",
xlab="Points",
freq=TRUE
)


## -----------------------------------------------------------------------------
barplot(table(data$gender),
        ylab="Frequency",
        xlab="Gender")


## -----------------------------------------------------------------------------
barplot(table(data$pepper),
        ylab="Frequency",
        xlab="Pepper")


## -----------------------------------------------------------------------------
hist(data$easiness,
main="Average Easiness Rating for Instructors Course",
xlab="Points",
freq=TRUE
)


## -----------------------------------------------------------------------------
barplot(table(data$discipline),
        ylab="Frequency",
        xlab="Discipline")


## -----------------------------------------------------------------------------
boxplot(quality~gender,data=data,xlab="Gender",ylab="Quality")


## -----------------------------------------------------------------------------
boxplot(quality~pepper,data=data,xlab="Pepper"
        ,ylab="Quality")


## -----------------------------------------------------------------------------
ggplot(data=data,aes(y=quality,x=easiness)) +geom_point() + labs(y="Average Quality (Out of 5)",x="Easiness(out of 5)")


## -----------------------------------------------------------------------------
boxplot(quality~discipline,data=data,xlab="Discipline"
        ,ylab="Quality")


## ----text=FALSE---------------------------------------------------------------
m1<-lm(quality~gender+pepper+easiness+discipline+easiness*gender
       +discipline*easiness,data=data)
qqPlot(m1,probs=FALSE)
plot(residuals(m1) ~data$easiness)
plot(residuals(m1) ~data$pepper)
plot(residuals(m1) ~data$gender)
plot(residuals(m1) ~data$discipline)


## -----------------------------------------------------------------------------
modelsummary(m1,fmt = 4,statistic = "{p.value} [{conf.low}, {conf.high}]")

