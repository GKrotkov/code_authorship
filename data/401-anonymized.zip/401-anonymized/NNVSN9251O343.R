## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(DBI)
library(RSQLite)
library(dplyr)
library(tidyverse)
library(alr4)
library(patchwork)
library(GGally)
library(magrittr)

## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
sleep.df = read.csv("/Users/elizabethszeto/Downloads/cmu-sleep.csv")


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
hist(sleep.df$TotalSleepTime,
     xlab ="Average student sleep time per night, not including naps (in minutes)",
     ylab = "Frequency",
     main = "Fig 1. Histogram of average student \nsleep time per night")
summary(sleep.df$TotalSleepTime)


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
term_gpa_hist <- hist(sleep.df$term_gpa,
     xlab ="Students' GPA (out of 4.0) for this semester",
     ylab = "Frequency",
     main = "Fig 2. Histogram of students' GPA for this semester")
summary(sleep.df$term_gpa)


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
hist(sleep.df$cum_gpa,
     xlab ="Students' cumulative GPA (out of 4.0), not including current semester",
     ylab = "Frequency",
     main = "Fig 3. Histogram of students' cumulative GPA \nprior to this semester")
mtext("note: As students were all first years, this is only their fall semester GPA", side = 1, cex = 0.75, line = 4)
summary(sleep.df$cum_gpa)


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
gpa_comp <- ggplot(sleep.df, aes(x = term_gpa, y = cum_gpa)) +
  geom_point() +
  labs(x = "Fall semester GPA",
       y = "Spring semester GPA",
       title = "Fig 4. Fall vs. spring semester GPA (on a 4.0 scale)")
gpa_comp


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
curr_sem <- ggplot(sleep.df, aes(x = TotalSleepTime,
y = term_gpa)) +
  geom_point() +
  labs(x = "Average student sleep time per night (in minutes)",
       y = "Spring semester GPA",
       title = "Fig 5. Average sleep time vs. spring semester GPA")
curr_sem


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
past_sem <- ggplot(sleep.df, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
  labs(x = "Average student sleep time per night (in minutes)",
       y = "Past semesters GPA",
       title = "Fig 6. Average sleep time vs. fall semester GPA")

past_sem


## ---- fig.width=5.5, fig.height=4, echo = FALSE-------------------------------
sq_term_gpa_hist = hist(sleep.df$term_gpa^2,
     xlab ="(Students' GPA)^2 (out of 4.0) for this semester",
     ylab = "Frequency",
     main = "Fig 7. Histogram of students' GPA for this sem \n(square transformation")


## ---- echo = FALSE------------------------------------------------------------
term_sq_plot <- ggplot(sleep.df, aes(x = TotalSleepTime, y = term_gpa^2)) +
  geom_point() +
  labs(x = "Average student sleep time per night (in minutes)",
       y = "This semester GPA",
       title = "Fig 8. Average sleep time vs. spring semester GPA \n(Sq transformation)")

term_sq_plot


## ---- echo = FALSE------------------------------------------------------------
term_fit_sq <- lm((term_gpa)^2 ~ TotalSleepTime, data = sleep.df)
summary(term_fit_sq)


## ---- echo = FALSE------------------------------------------------------------
confint_unadj = confint(term_fit_sq, level = 0.95)
confint_unadj


## ---- echo = FALSE------------------------------------------------------------
confint_adj = confint_unadj * 120
confint_adj


## ---- echo = FALSE------------------------------------------------------------
r_sq <- summary(term_fit_sq)$r.squared
r_sq

