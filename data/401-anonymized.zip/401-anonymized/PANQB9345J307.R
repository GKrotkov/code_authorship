## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(modelsummary)
dat <- read_csv("cmu-sleep.csv")


## ---- fig.cap = "Histograms of Sleep Time and GPA"----------------------------
par(mfrow = c(1, 2))

sleepHist <- hist(dat$TotalSleepTime, 
     main = "", 
     xlab = "Sleep Time")

gpaHist <- hist(dat$term_gpa, 
     main = "", 
     xlab = "GPA")



## ---- fig.cap = "Scatterplot of GPA vs Sleep Time"----------------------------
par(mfrow = c(1, 2))

plot(dat$TotalSleepTime, dat$term_gpa, 
     xlab = "Average Sleep Time (minutes)", 
     ylab = "GPA")



## ---- fig.cap = "Residuals vs Sleep Time"-------------------------------------

reg1 <- lm(term_gpa~TotalSleepTime, data = dat)

plot(dat$TotalSleepTime, resid(reg1),
     xlab = "Sleep Time (minutes)",
     ylab = "Residuals")
abline(h = 0, lty = 2)


## ---- fig.cap = "Observing Cook's Distance To Identify Outliers"--------------
plot(reg1, which = 5)


## ---- fig.cap = "Quantile-Quantile Plot"--------------------------------------

qqnorm(resid(reg1))
qqline(resid(reg1))



## ---- fig.cap = "Regression Output"-------------------------------------------

modelsummary(reg1, 
             estimate = c("{estimate}{stars}"), 
             fmt = fmt_significant(3), 
             coef_rename = c("TotalSleepTime" = "Sleep Time"), 
             gof_omit = 'DF|Deviance|R2|AIC|BIC|Log.Lik.|RMSE|F')


