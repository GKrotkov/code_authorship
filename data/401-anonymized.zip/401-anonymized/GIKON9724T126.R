## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=3.4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
hist(sleep$term_gpa, main = "Histogram of Term GPA", xlab = "Term GPA (out of 4.0)", col = "lightblue", border = "black")
hist(sleep$TotalSleepTime, main = "Histogram of Total Sleep Time", xlab = "Total Sleep Time (minutes)", col = "lightgreen", border = "black")
hist(sqrt(sleep$cum_gpa), main = "Histogram of Term GPA", xlab = "Term GPA", col = "red", border = "black")
hist(log(sleep$term_gpa), main = "Histogram of Log(Term GPA)", xlab = "log(Term GPA)", col = "lightblue", border = "black")


## ---- fig.width=3.4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
fit <- lm(term_gpa ~ TotalSleepTime, data = sleep)
plot(sleep$TotalSleepTime, sleep$term_gpa, 
     xlab = "Total Sleep Time (minutes)", 
     ylab = "Term GPA", 
     main = "Term GPA vs. Total Sleep Time",
     abline(fit, col = "red")
       )

fit2 <- lm(term_gpa ~ cum_gpa, data = sleep)
plot(sleep$cum_gpa, sleep$term_gpa, 
     xlab = "Cumulative GPA", 
     ylab = "Term GPA", 
     main = "Term GPA vs. Cumulative GPA",
    abline(fit2, col = "red"))


## ---- fig.width=4.5, fig.height=4, fig.cap="Residual plot."-------------------
plot(sleep$TotalSleepTime, residuals(fit),
     xlab = "Total Sleep Time",
     ylab = "Residuals",
     main = "Residual of Total Sleep Time vs. Term GPA")


## ---- fig.width=4, fig.height=4, fig.cap="Q-Q Plot."--------------------------
qqnorm(residuals(fit))
qqline(residuals(fit))


## ---- fig.width=4, fig.height=3, fig.cap="result"-----------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)
model_summary <- summary(model)
coefficients <- model_summary$coefficients
coefficients_df <- as.data.frame(coefficients)
knitr::kable(coefficients_df, digits = 5)

