## ----setup, include = FALSE, message=FALSE------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Total Sleep Time", fig.align='center'----
data = read.csv("cmu-sleep.csv")
totalSleep = data$TotalSleepTime
hist(totalSleep, main="Distribution of Students' Total Sleep",
     breaks = 15,
     xlab="Average Hours Slept in a Night (in minutes)", 
     ylab="Frequency (in students)", col = "Gray")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Term GPA", fig.align='center'----
term = data$term_gpa
correct_breaks <- seq(0, 4, by = 0.2)
hist(term, main="Distribution of Students' Term GPA",
     breaks = correct_breaks,
     xlab="Average Term GPA (out of 4.0)", 
     ylab="Frequency (in students)", col="Gray")


## ---- fig.width=4.5, fig.height=3, fig.cap="Histogram of Cumulative GPA", fig.align='center'----
cumu = data$cum_gpa
cumu_avg = mean(cumu)
hist(cumu, main="Distribution of Students' Cumulative GPA",
     breaks = correct_breaks,
     xlab="Average Cumulative GPA (out of 4.0)", 
     ylab="Frequency (in students)", col="Gray")


## ---- fig.width=4, fig.height=3, fig.cap="Scatter Plot of Term GPA vs Total Sleep", fig.align='center'----
term = data$term_gpa
ggplot(data, mapping=aes(x=log(totalSleep), y=term)) +
  geom_point() + xlab("Average Hours Slept in a Night (in minutes)") + 
  ylab("Students' Term GPA") + 
  ggtitle("Term GPA vs Average Nightly Sleep")


## ---- include = FALSE---------------------------------------------------------
model <- lm(formula = (2^(term)) ~ totalSleep)
summary(model)


## ---- fig.width=4, fig.height=3, fig.cap="Scatter Plot of Term GPA vs Total Sleep", fig.align='center'----
qqnorm(model$residuals)
qqline(model$residuals)


## ---- fig.width=4, fig.height=3, fig.cap="Scatter Plot of Residuals vs Total Sleep", fig.align='center'----
res <- model$residuals
ggplot(data, mapping=aes(x=totalSleep, y=res)) +
  geom_point() + xlab("Average Hours Slept in a Night (in minutes)") + 
  ylab("Residuals") + 
  ggtitle("Residuals vs Average Nightly Sleep")


## ---- include = FALSE---------------------------------------------------------
confint(model)

