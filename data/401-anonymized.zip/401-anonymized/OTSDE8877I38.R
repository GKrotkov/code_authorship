## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleeps<-read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(sleeps$TotalSleepTime,main="Figure 1: Distribution of Total Sleep Time",xlab="Average Sleep (minutes)")


## ----fig.width=4, fig.height=3------------------------------------------------
hist(sleeps$term_gpa,main="Figure 2: Distribution of Spring GPA",xlab="GPA (out of 4.0)")

## ----fig.width=3.5, fig.height=3----------------------------------------------
hist(sleeps$cum_gpa,main="Figure 3: Distribution of Fall GPA",xlab="GPA (out of 4.0)")


## ----fig.width=4, fig.height=3------------------------------------------------
plot(sleeps$TotalSleepTime,sleeps$term_gpa,main="Figure 4: Sleep Time vs Spring GPA",xlab="Avg Sleep (minutes)",ylab="Spring GPA (out of 4.0)")


## ----fig.width=4, fig.height=3------------------------------------------------
plot(sleeps$TotalSleepTime,sleeps$cum_gpa,main="Figure 5: Sleep Time vs Fall GPA",xlab="Avg Sleep (minutes)",ylab="Spring GPA (out of 4.0)")


## ----fig.width=4, fig.height=3------------------------------------------------
plot(sqrt(sleeps$TotalSleepTime),sleeps$term_gpa,main="Figure 6: Sqrt(Sleep Time) vs Spring GPA",xlab="sqrt(Average Sleep Time(mins))",ylab="Spring GPA (out of 4.0)")


## ----fig.width=4, fig.height=3------------------------------------------------
plot(log(sleeps$TotalSleepTime),sleeps$term_gpa,main="Figure 7: Log(Sleep Time) vs Spring GPA",xlab="Log(Average Sleep Time(mins))",ylab="Spring GPA (out of 4.0)")


## ----fig.width=4, fig.height=3------------------------------------------------
sleep_model<-lm(term_gpa~TotalSleepTime,data=sleeps)
plot(sleep_model,main="Figure 8",which=1,)


## ----fig.width=4, fig.height=3------------------------------------------------
plot(sleep_model,main="Figure 9",which=2)


## -----------------------------------------------------------------------------
summary(sleep_model)


## -----------------------------------------------------------------------------
confint(sleep_model)

