## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
rm(list = ls())
setwd('/Users/nikhilpatel/70208_Datafiles/')
cmu_sleep = read.csv('cmu-sleep.csv')


## ---- fig.width=8, fig.height=3, fig.cap="Histogram of Cumulative GPA. There is a large left skew. The exponent transform results in a more symmetric, normal-like distribution."----
library(ggplot2)
library(patchwork)
p1 <- ggplot(cmu_sleep, aes(x = cum_gpa)) +
geom_histogram(binwidth = 0.1) +
labs(x = "Cumulative-GPA (Out of 4.0)", y = "Count of Students")

library(ggplot2)
p2 <- ggplot(cmu_sleep, aes(x = exp(cum_gpa))) +
geom_histogram(binwidth = 4) +
labs(x = "Exponentiated Cumulative-GPA (Out of 4.0)", y = "Count of Students")

p1 | p2


## ---- fig.width=8, fig.height=3, fig.cap="Histogram of Term GPA.  There is a large left skew. The exponent transform results in a more symmetric, normal-like distribution."----
library(ggplot2)
library(patchwork)
p1 <- ggplot(cmu_sleep, aes(x = term_gpa)) +
geom_histogram(binwidth = 0.1) +
labs(x = "Term-GPA (Out of 4.0)", y = "Count of Students")

library(ggplot2)
p2 <- ggplot(cmu_sleep, aes(x = exp(term_gpa))) +
geom_histogram(binwidth = 4) +
labs(x = "Exponentiated Term-GPA (Out of 4.0)", y = "Count of Students")

p1 | p2


## ---- fig.width=4, fig.height=3, fig.cap="Historgram of Total Sleep Time. The historgram is symmetric and relatively bell-shaped."----
library(ggplot2)
ggplot(cmu_sleep, aes(x = TotalSleepTime)) +
geom_histogram(binwidth = 10) +
labs(x = "Total Hours Slept (Minutes)", y = "Count of Students")


## ---- fig.width=4, fig.height=3, fig.cap="Plot of Cumulative GPA against Term GPA. We see a relatively strong positive correlation"----
library(ggplot2)
plt <- ggplot(cmu_sleep, aes(x = term_gpa, y = cum_gpa)) +
ggtitle("Term GPA vs. Cumulative GPA") +
geom_point() +
labs(x = "Term GPA (Out of 4.0)", y = "Cumulative GPA (Out of 4.0)")
suppressWarnings(print(plt))


## ---- fig.width=8, fig.height=3, fig.cap="Plots of Term GPA against Total Sleep Time. We don't see a very strong association when Term GPA isn't transformed, and we don't see constant variance or apprxoximately 0 mean residuals. We also don't see a very strong association with the exponentiated Term GPA, but we see relatively constant variance and 0 mean residuals."----
library(ggplot2)
library(patchwork)
p1 <- ggplot(cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) +
ggtitle("Total Sleep Time vs. Term GPA") +
geom_smooth(formula = y ~ x, method = "lm") +
geom_point() +
labs(x = "Total Sleep Time (Minutes)", y = "Term GPA (Out of 4.0)")

p2 <- ggplot(cmu_sleep, aes(x = TotalSleepTime, y = exp(term_gpa))) +
ggtitle("Total Sleep Time vs. Exponential Term GPA") +
geom_smooth(formula = y ~ x, method = "lm") +
geom_point() +
labs(x = "Total Sleep Time (Minutes)", y = "Exponentiated Term GPA (Out of 4.0)") 

p1 | p2


## ---- fig.width=4, fig.height=3, fig.cap="Residuals on the (Exp(Term GPA) ~ Total Sleep Time, Exp(Cumulative GPA)) multiple linear regression model. We see relatively constant variance of the residuals, uncorrelated residuals, and 0 mean residuals, indicating the model satifies the linear regression assumptions."----
library(broom)
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime+exp(cum_gpa), data = cmu_sleep)
augmented_table = augment(model)
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime, data = cmu_sleep)
plt <- ggplot(augmented_table, aes(x = TotalSleepTime, y = .resid)) +
ggtitle("Total Sleep Time vs. Residuals") +
geom_point() +
labs(x = "Total Sleep Time (Minutes)", y = "Exp of GPA Residual (Out of 4.0)")
suppressWarnings(print(plt))


## ---- include = FALSE---------------------------------------------------------
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime+exp(cum_gpa), data = cmu_sleep)
augmented_table = augment(model)
ggplot(augmented_table, aes(x = TotalSleepTime, y = .cooksd)) +
ggtitle("Total Sleep Time vs. Cook's Distance for Multiple Linear Regression Model") +
geom_point() +
labs(x = "Total Sleep Time", y = "Cook's Distance")
max(augmented_table$.cooksd)


## ---- fig.width=4, fig.height=3, fig.cap="Fig 9.1 Coefficients on Term GPA ~ Cumulative GPA simple linear regression model."----
model <- lm(formula = exp(term_gpa) ~ exp(cum_gpa), data = cmu_sleep)
summary <- summary(model)
knitr::kable(summary$coefficients, caption = "Coefficients on the (Exp(Term GPA) ~ Exp(Cumulative GPA)) simple linear regression model.", digits=3)


## ---- fig.width=4, fig.height=3, fig.cap="R^2 on Term GPA ~ Cumulative GPA simple linear regression model."----
model <- lm(formula = exp(term_gpa) ~ exp(cum_gpa), data = cmu_sleep)
summary <- summary(model)
knitr::kable(summary$adj.r.squared, caption ="R^2 on the (Exp(Term GPA) ~ Exp(Cumulative GPA)) simple linear regression model.", digits=4)


## ---- fig.width=4, fig.height=3, fig.cap="Coefficients on Term GPA ~ Total Sleep Time simple linear regression model."----
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime, data = cmu_sleep)
summary <- summary(model)
knitr::kable(summary$coefficients, caption="Coefficients on the (Exp(Term GPA) ~ Total Sleep Time) simple linear regression model.", digits=3)

## ---- fig.width=4, fig.height=3, fig.cap="R^2 on Term GPA ~ Total Sleep Time simple linear regression model."----
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime, data = cmu_sleep)
summary <- summary(model)
knitr::kable(summary$adj.r.squared, caption="R^2 on the (Exp(Term GPA) ~ Total Sleep Time) simple linear regression model.", digits=4)


## ---- fig.width=4, fig.height=3, fig.cap="Coefficients on Term GPA ~ Total Sleep Time, Cumulative GPA multiple linear regression model."----
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime+exp(cum_gpa), data = cmu_sleep)
summary <- summary(model)
knitr::kable(summary$coefficients, caption = "Coefficients on the (Exp(Term GPA) ~ Total Sleep Time, Exp(Cumulative GPA)) multiple linear regression model.", digits=5)


## ---- fig.width=4, fig.height=3, fig.cap="R^2 on Term GPA ~ Total Sleep Time, Cumulative GPA multiple linear regression model."----
model <- lm(formula = exp(term_gpa) ~ TotalSleepTime+exp(cum_gpa), data = cmu_sleep)
summary <- summary(model)
knitr::kable(summary$adj.r.squared, caption = "R^2 on the (Exp(Term GPA) ~ Total Sleep Time, Exp(Cumulative GPA)) multiple linear regression model.", digits=4)


## ---- include = FALSE---------------------------------------------------------
qt(p=.025, df=nrow(cmu_sleep)-2, lower.tail=TRUE)
qt(p=.975, df=nrow(cmu_sleep)-2, lower.tail=TRUE)


## ---- include = FALSE---------------------------------------------------------
mean_sleep = mean(cmu_sleep$TotalSleepTime)
mean_cum = mean(exp(cmu_sleep$cum_gpa))
mean_term = mean(exp(cmu_sleep$term_gpa))

model <- lm(formula = exp(term_gpa) ~ TotalSleepTime+exp(cum_gpa), data = cmu_sleep)
augmented_table = augment(model)

confint(model, "TotalSleepTime", TotalSleepTime = 0.95) * 60
confint(model, "TotalSleepTime", TotalSleepTime = 0.95) * 120

interval <- predict(model, newdata = data.frame(TotalSleepTime = mean_sleep, cum_gpa = log(mean_cum)),
interval = "confidence", level = 0.95)
log(interval)

inΩterval <- predict(model, newdata = data.frame(TotalSleepTime = mean_sleep-120, cum_gpa = log(mean_cum)),
interval = "confidence", level = 0.95)
log(interval)

