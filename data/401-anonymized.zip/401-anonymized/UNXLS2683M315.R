## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE, message=FALSE, warning=FALSE-----------------------------
library(ggplot2)
library(readr)
library(alr4)
library(regressinator)
library(tidyverse)
library(dplyr)
library(knitr)
library(broom)
library(GGally)
library(bestglm)


## ---- message=FALSE, warning=FALSE, fig.height=4, fig.width=8, fig.cap="Histograms of response (top left) and predictor (others) variables"----
par(mfrow = c(2,3))
hist(Rateprof$quality,
     main = "Average quality rating",
     xlab = "Average quality rating (from 1 to 5)",
     ylab = "Number of instructors"
)
barplot(table(Rateprof$gender),
     main = "Instructor's gender",
     xlab = "gender",
     ylab = "Number of instructors"
)
barplot(table(Rateprof$pepper),
     main = "Instructor's attractiveness",
     xlab = "attractiveness",
     ylab = "Number of instructors"
)
hist(Rateprof$easiness,
     main = "Average easiness rating",
     xlab = "Average easiness rating (from 1 to 5)",
     ylab = "Number of instructors"
)
barplot(table(Rateprof$discipline),
     main = "Discipline",
     xlab = "discipline",
     ylab = "Number of instructors"
)


## ---- message=FALSE, warning=FALSE, fig.cap="Bivariate EDA on variabels of interest"----
Rateprof_subset <- Rateprof[,c("quality", "gender", "pepper", "easiness", "discipline")]
ggpairs(Rateprof_subset)


## ---- include=FALSE, message=FALSE, warning=FALSE-----------------------------
lm1 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data = Rateprof)
summary(lm1)

lm2 <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) +
            easiness:factor(gender) + easiness:factor(discipline), data = Rateprof)
summary(lm2)


## ---- fig.cap="Residual assumption diagnostic plots"--------------------------
par(mfrow = c(2,2))
plot(lm1)


## -----------------------------------------------------------------------------
res <- summary(lm1)
tidy(res)


## -----------------------------------------------------------------------------
# confint(lm1, "factor(gender)male", level = 0.95)
# confint(lm1, "factor(pepper)yes", level = 0.95)
# confint(lm1, "easiness", level = 0.95)


## ---- include=FALSE, message=FALSE, warning=FALSE-----------------------------
anova(lm1, lm2)

