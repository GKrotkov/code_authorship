## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(dplyr)


## -----------------------------------------------------------------------------
cmu_sleep = read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
cmu_sleep %>%
  ggplot(aes(x = TotalSleepTime)) + 
  geom_histogram(color = "black", fill = "pink", bins = 40) + 
  labs(x = "Average Amount of Sleep Per Night for Students (mins)", y = "Frequency", 
       title = "Distribution of Average Sleep Time")


## -----------------------------------------------------------------------------
summary(cmu_sleep$TotalSleepTime)


## -----------------------------------------------------------------------------
cmu_sleep %>%
  ggplot(aes(x = term_gpa)) + 
geom_histogram(color = "black", fill = "pink", bins = 40) + 
  labs(x = "Student GPA for Current Semester (out of 4.0)", y = "Frequency", 
       title = "Distribution of Student's GPA in Current Semester ")


## -----------------------------------------------------------------------------
summary(cmu_sleep$term_gpa)


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x= cum_gpa)) +
geom_histogram(color = "black", fill = "pink", bins = 40) + 
labs(x = "Students' Cumulative GPA (out of 4.0)", y = "Frequency", title = "Distribution of Students' Cumulative GPA Before Study")


## -----------------------------------------------------------------------------
summary(cmu_sleep$cum_gpa)


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x=TotalSleepTime, y= term_gpa)) +
  geom_point()+
labs(x = "Average Amount of Sleep per Night(min)", y = "Students' Current Semester GPA (out of 4.0)", title = "Average Sleep Time vs. Student GPA for Current Semester")


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x=TotalSleepTime, y= cum_gpa)) +
  geom_point()+
labs(x = "Average Amount of Sleep per Night (min)", y = "Students' Cumulative GPA (out of 4.0)", title = "Average Sleep Time vs. Student Cumulative GPA")


## -----------------------------------------------------------------------------
cmu_sleep %>%
ggplot(aes(x= sqrt(TotalSleepTime), y= term_gpa)) +
  geom_point()+
labs(x = "Square Root of Average Amount of Sleep per Night (min)", y = "Students' Term GPA (out of 4.0)", title = "Square Root of Average Sleep Time vs. Students' Term GPA")


## -----------------------------------------------------------------------------
model = lm(term_gpa ~ sqrt(TotalSleepTime), data = cmu_sleep)
plot(model)


## -----------------------------------------------------------------------------
summary(model)

## -----------------------------------------------------------------------------
confint(model)

