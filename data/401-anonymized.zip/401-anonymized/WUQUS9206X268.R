## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
# load library
suppressPackageStartupMessages(library(alr4))
# upload data
ratingData <- alr4::Rateprof


## ---- fig.width = 10, fig.height = 3.3, fig.cap = "Average quality rating for professors"----
# histogram for quality
hist(ratingData$quality, col = "lightblue",
     main = "Histogram of the Average Quality Rating for Professors", 
     xlab = "Average quality rating for professors, between 1 (worst) and 5 (best)")

## ---- fig.width = 10, fig.height = 3.3, fig.cap = "Instructor gender"---------
# barplot for gender
barplot(table(ratingData$gender), col = "lightblue",
        main = "Barplot of Instructor Gender", 
        xlab = "Instructor gender, female or male",
        ylab = "Frequency")

## ---- fig.width = 10, fig.height = 3.3, fig.cap = "Instructors rated as attractive or not"----
# barplot for pepper
barplot(table(ratingData$pepper), col = "lightblue", 
        main = "Barplot of Instructor Attractiveness", 
        xlab = "Instructors rated as attractive or not:
        yes = consensus is they are attractive, no = consensus is they are not attractive",
        ylab = "Frequency")

## ---- fig.width = 10, fig.height = 3.3, fig.cap = "Average easiness rating for professors"----
# histogram for easiness
hist(ratingData$easiness, col = "lightblue",
     main = "Histogram of the Average Easiness Rating for Professors", 
     xlab = "Average easiness rating for professors, between 1 (worst) to 5 (best)")

## ---- fig.width = 10, fig.height = 3.3, fig.cap= "Disciplines for each professor"----
# barplot for discipline
barplot(table(ratingData$discipline), col = "lightblue", 
        main = "Barplot of the Discipline the Instructors teach", 
        xlab = "Disciplines for each professor (Humanities, Social Science, STEM, or Pre-professional)",
        ylab = "Frequency")


## ---- fig.width = 10, fig.height = 3.5, fig.cap = "Scatterplot of avg quality and easiness"----
# scatterplot of quality and easiness
plot(ratingData$quality, ratingData$easiness, 
     main = "Scatterplot of the average teaching ratings of quality and easiness per professors", 
     xlab = "Average quality ratings, from 1 (worst) & 5 (best)", 
     ylab = "Average easiness ratings, from 1 (worst) & 5 (best)")

## ---- fig.width = 10, fig.height = 4, fig.cap = "Boxplot of avg quality rating per discipline"----
# box plot of quality and discipline
boxplot(quality ~ discipline, data = ratingData, 
        col = c("lightgreen", "lightpink", "lightblue", "lightyellow"),
        main = "Boxplot of Average Quality Rating for Professors per Discipline",
        xlab = "Disciplines for each professor (Humanities, Social Science, STEM, or Pre-professional)",
        ylab = "Average quality ratings, from 1 (worst) & 5 (best)")

## ---- fig.width = 10, fig.height = 4, fig.cap = "Boxplot of avg easiness rating per discipline"----
# boxplot of easiness and discipline
boxplot(easiness ~ discipline, data = ratingData,
        col = c("lightgreen", "lightpink", "lightblue", "lightyellow"),
        main = "Boxplot of Average Easiness Rating for Professors per Discipline",
        xlab = "Disciplines for each professor (Humanities, Social Science, STEM, or Pre-professional)",
        ylab = "Average easiness ratings, from 1 (worst) & 5 (best)")

## ---- fig.width = 10, fig.height = 4, fig.cap = "Boxplot of avg quality rating per gender"----
# boxplot of quality and gender
boxplot(quality ~ gender, data = ratingData,
        col = c("lightpink", "lightblue"),
        main = "Boxplot of Average Quality Rating for Professors per Gender",
        xlab = "Instructor gender, female or male",
        ylab = "Average quality ratings, from 1 (worst) & 5 (best)")


## ---- fig.width = 10, fig.height = 3.5, fig.cap = ""--------------------------
# boxplot of easiness and gender
boxplot(easiness ~ gender, data = ratingData,
        col = c("lightpink", "lightblue"),
        main = "Boxplot of Average Easiness Rating for Professors per Gender",
        xlab = "Instructor gender, female or male",
        ylab = "Average easiness ratings, from 1 (worst) & 5 (best)")


## ---- fig.width = 10, fig.height = 3.5, fig.cap = ""--------------------------
# boxplot of quality and pepper
boxplot(quality ~ pepper, data = ratingData,
        col = c("lightpink", "lightgreen"),
        main = "Boxplot of Average Quality Rating per Professor Attractiveness",
        xlab = "Instructors rated as attractive or not:
        yes = consensus is they are attractive, no = consensus is they are not attractive",
        ylab = "Average quality ratings, from 1 (worst) & 5 (best)")


## ---- fig.width = 10, fig.height = 3.5, fig.cap = ""--------------------------
# boxplot of easiness and pepper
boxplot(easiness ~ pepper, data = ratingData,
        col = c("lightpink", "lightgreen"),
        main = "Boxplot of Average Easiness Rating per Professor Attractiveness",
        xlab = "Instructors rated as attractive or not:
        yes = consensus is they are attractive, no = consensus is they are not attractive",
        ylab = "Average easiness ratings, from 1 (worst) & 5 (best)")


## -----------------------------------------------------------------------------
# import libraries
suppressPackageStartupMessages(library(bestglm))
suppressPackageStartupMessages(library(modelsummary))
# base model to compare + summary
baseRatingModel <- lm(quality ~ (pepper + easiness + discipline) * gender, data = ratingData)
# modelsummary
modelsummary(baseRatingModel, gof_map = c("r.squared", "nobs"), stars = TRUE)


## ---- fig.width=10, fig.height=5----------------------------------------------
# residuals v fitted
plot(baseRatingModel, which = 1)

## ---- fig.width=10, fig.height=5----------------------------------------------
# qqplot
plot(baseRatingModel, which = 2)


## -----------------------------------------------------------------------------
# referencing code from lecture 11

# log transform response (quality)
ratingData$logQuality <- log(ratingData$quality)
# factor cat variables (gender, discipline, and pepper)
ratingData$gender <- factor(ratingData$gender)
ratingData$discipline <- factor(ratingData$discipline)
ratingData$pepper <- factor(ratingData$pepper)
# subset df
subsetOfRatingData <- ratingData[, c("easiness", "gender", "discipline", "pepper", "logQuality")]
# bestglm
bestRatingModelSummary <- bestglm(subsetOfRatingData, IC = "AIC")
bestRatingModelSummary


## -----------------------------------------------------------------------------
# new model w/ suggested predictors + summary (make into table)
bestRatingModel <- lm(logQuality ~ easiness + gender + pepper, data = ratingData)

## ---- fig.width=10, fig.height=5----------------------------------------------
# residuals v fitted
plot(bestRatingModel, which = 1)

## ---- fig.width=10, fig.height=5----------------------------------------------
# residuals v fitted
plot(bestRatingModel, which = 2)


## -----------------------------------------------------------------------------
# table
suppressPackageStartupMessages(library(modelsummary))
modelsummary(bestRatingModel, gof_map = c("r.squared", "nobs"),
             stars = TRUE)

