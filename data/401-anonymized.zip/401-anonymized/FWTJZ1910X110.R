## ----setup, include = FALSE, message=FALSE, warning=FALSE, results='hide'-----
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
#library(tidyverse)
library(patchwork)
library(gridExtra)


sleep <- read.csv("cmu-sleep.csv") #sleep data


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of avearge total sleep time", message=FALSE----
ggplot(sleep, aes(x=TotalSleepTime))+
  geom_histogram(binwidth = 15, color="black")+
  ggtitle("Histogram of average total sleep time")+
  xlab("Sleep time in minute")+ 
  theme_minimal()


## ---- fig.width=6, fig.height=3, fig.cap="Distributions of cumulative GPA and exponential cumulative GPA", results='hide'----
p2 <- ggplot(sleep, aes(x=cum_gpa))+
  geom_histogram(binwidth = 0.1, color="black")+
  ggtitle("Histogram of cumulative GPA")+
  xlab("Cumulative GPA")+ 
  theme_minimal()
  theme(plot.title = element_text(size=6))

p3 <- ggplot(sleep, aes(x=exp(cum_gpa)))+
  geom_histogram(binwidth = 3, color="black")+
  ggtitle("Histogram of exp cum GPA")+
  xlab("Exp(Cumulative GPA)")+ 
  theme_minimal()
  theme(plot.title = element_text(size=6))

p2 | p3


## ---- fig.width=6, fig.height=3, fig.cap="Distributions of term GPA and exponential term GPA"----
p4 <- ggplot(sleep, aes(x=term_gpa)) +
  geom_histogram(binwidth = 0.1, color="black") +
  ggtitle("Histogram of Term GPA") +
  xlab("Term GPA") +
  theme_minimal()

p5 <- ggplot(sleep, aes(x=exp(term_gpa)))+
  geom_histogram(binwidth = 3, color="black")+
  ggtitle("Histogram of exp term GPA")+
  xlab("Exp(Term GPA)")+ 
  theme_minimal()

p4|p5


## ---- warning=FALSE, results='hide', message=FALSE, fig.width=6, fig.height=6, fig.cap="Bivariate Analysis"----
library(GGally)
cor_data <- sleep[, c('TotalSleepTime', 'cum_gpa', 'term_gpa')]
ggpairs(cor_data) +
  theme_bw()


## ---- fig.width=8, fig.height=3, fig.cap="Scatter plot of the relationship between total sleep time and term GPAs."----

p7 <- ggplot(sleep, aes(x=TotalSleepTime, y=term_gpa))+
  geom_point(alpha=0.5)+
  geom_smooth(formula = y ~ x, method="lm", se=FALSE,) +
  ggtitle("Scatter plot of sleep time vs term GPA")+
  xlab("Total sleep time (in mimutes)") + 
  ylab("Term GPA")+ 
  theme_minimal()

p8 <- ggplot(sleep, aes(x=cum_gpa, y=term_gpa))+
  geom_point(alpha=0.5) +
  geom_smooth(formula = y ~ x, method="lm", se=FALSE) +
  ggtitle("Scatter plot of cum GPA vs term GPA") +
  xlab("Cumulative GPA") + 
  ylab("Term GPA") + 
  theme_minimal()

p7|p8


## ---- results="hide"----------------------------------------------------------
lm <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)
summary(lm)


## ---- warning=FALSE, fig.width=8, fig.height=5, fig.cap="Residual Plot and Normal Q-Q Plot"----
par(mfrow=c(1,2))

fitted_values <- fitted(lm)
model_residuals <- resid(lm)

plot(fitted_values, model_residuals, 
     xlab = "Fitted Values", 
     ylab = "Residuals", 
     main = "Residuals Plot")
abline(h = 0)

qqnorm(resid(lm), main = "Normal Q-Q Plot")
qqline(resid(lm))


## ---- results='hide'----------------------------------------------------------
cookd<-cooks.distance(lm)
which.max(cookd)
cookd[484]


## ---- results="hide"----------------------------------------------------------
summary(lm)


## ---- results='hide'----------------------------------------------------------
0.001308 * 2*60

