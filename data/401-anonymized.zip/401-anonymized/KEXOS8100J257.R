## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
cmu.sleep <- read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(dplyr)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Total Sleep Time"------
p1<- ggplot(cmu.sleep, aes(x = TotalSleepTime)) +
  geom_histogram(bins = 30) +
  labs(x = "Average Sleep Time (in minutes)")
p1


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Semester GPA"----------
p2 <- ggplot(cmu.sleep, aes(x = term_gpa)) +
  geom_histogram(bins = 30) +
  #scale_x_log10() +
  labs(x = "Term GPA (out of 4.0)")
p2


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Cumulative GPA"--------
p3 <- ggplot(cmu.sleep, aes(x = cum_gpa)) +
  geom_histogram(bins = 30) +
  #scale_x_log10() +
  labs(x = "Cum GPA (out of 4.0)")
p3


## ---- fig.width=4, fig.height=3, fig.cap="Sleep vs Term GPA"------------------
cmu.sleep$logtime <- log(cmu.sleep$TotalSleepTime)
figure = lm(term_gpa~logtime, cmu.sleep)
plot(term_gpa~logtime, cmu.sleep, xlab = "log of sleep (in mins)", ylab = "Term GPA (out of 4.0)")
abline(figure, col="blue")


## ---- fig.width=4, fig.height=3, fig.cap="Sleep vs Cumulative GPA"------------
cmu.sleep$logtime <- log(cmu.sleep$TotalSleepTime)
figure = lm(cum_gpa~logtime, cmu.sleep)
plot(cum_gpa~logtime, cmu.sleep, xlab = "log of sleep (in mins)", ylab = "Cum GPA (out of 4.0)")
abline(figure, col="blue")


## -----------------------------------------------------------------------------
sleep_fit <- lm(term_gpa ~ log(TotalSleepTime), data = cmu.sleep)
coef_sleep <- coef(sleep_fit)
confint_sleep <- confint(sleep_fit)


## -----------------------------------------------------------------------------
cookd <- (cooks.distance(sleep_fit))


## -----------------------------------------------------------------------------
cookd_dec<- sort(pf(cookd, 2, 9), decreasing = TRUE)


## ---- fig.width=4, fig.height=3, fig.cap="Residual Plot of Fitted Sleep Data"----
residuals <- residuals(sleep_fit)
plot(fitted(sleep_fit), residuals, xlab = "fitted sleep data")
abline(0,0, col = "red", lty = 2)


## -----------------------------------------------------------------------------
new_sleep <- cmu.sleep %>%
  select(TotalSleepTime, term_gpa,cum_gpa ) %>%
  filter(TotalSleepTime <= 60*6) %>%
    summarise(
    avg_TotalSleepTime = mean(TotalSleepTime, na.rm = TRUE),
    avg_term_gpa = mean(term_gpa, na.rm = TRUE),
    avg_cum_gpa = mean(cum_gpa, na.rm = TRUE)
  )


## -----------------------------------------------------------------------------
less_sleep <- data.frame(TotalSleepTime = mean(new_sleep$avg_TotalSleepTime))


## -----------------------------------------------------------------------------
pred_gpa <- predict(sleep_fit, newdata = less_sleep )


## -----------------------------------------------------------------------------
predict(sleep_fit, newdata = (less_sleep), interval = "prediction")

