## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message = FALSE---------------------------------------------------------
library(tidyverse)
library(alr4)
library(GGally)
library(modelsummary)
library(broom)
library(data.table)
rating <- Rateprof


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Marginal Distribution of Gender."----
ggplot(rating, aes(x = gender)) +
  geom_bar(color = "black", fill = "thistle") +
  labs(x = "Gender")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Marginal Distribution of Attractiveness."----
ggplot(rating, aes(x = pepper)) +
  geom_bar(color = "black", fill = "lightblue") +
  labs(x = "Attractiveness")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Marginal Distribution of Discipline."----
ggplot(rating, aes(x = discipline)) +
  geom_bar(color = "black", fill = "maroon") +
  labs(x = "Discipline")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Marginal Distribution of Easiness."----
ggplot(rating, aes(x = easiness)) +
  geom_histogram(color = "black", fill = "darkseagreen", bins = 15) +
  labs(x = "Easiness")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Marginal Distribution of Quality Rating."----
ggplot(rating, aes(x = quality)) +
  geom_histogram(color = "black", fill = "lightblue", binwidth = 0.2) +
  labs(x = "Quality")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Easiness Faceted by Gender."----
ggplot(rating, aes(x = easiness, fill = gender)) +
  geom_histogram(color = "black") +
  facet_wrap(~gender)
  labs(x = "Easiness")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Easiness by Discipline."----
ggplot(rating, aes(x = easiness, fill = discipline)) +
  geom_histogram(color = "black") +
  facet_wrap(~discipline) +
  labs(x = "Easiness")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Quality by Gender."----
ggplot(rating, aes(x = quality, fill = gender)) +
  geom_histogram(color = "black") +
  facet_wrap(~gender)
  labs(x = "Quality")


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Histogram of Quality by Gender."----
ggplot(rating, aes(x = quality, fill = discipline)) +
  geom_histogram(color = "black") +
  facet_wrap(~discipline)
  labs(x = "Quality")


## ---- messsage = FALSE, fig.width=4, fig.height=3, fig.cap="Easiness and Quality Faceted by Discipline and Colored by Gender."----
ggplot(rating, aes(x = easiness, y = quality)) + 
  geom_point(aes(color = gender)) + 
  facet_wrap(~discipline)


## ---- message = FALSE, fig.width=4, fig.height=3, fig.cap="Pairs Plot of Gender, Attractiveness, Easiness, Discipline, and Quality."----
rating |>
  select(gender, pepper, easiness, discipline, quality) |>
  ggpairs()


## ---- message = FALSE, fig.width=4, fig.height=3------------------------------
rating.model <- lm(quality ~ gender + pepper + easiness + discipline, data = rating)
rating.intmodel1 <- lm(quality ~ gender + pepper + (easiness*gender*discipline), data = rating)
rating.intmodel2 <- lm(quality ~ gender + pepper + + easiness + discipline + gender:easiness + discipline:easiness, data = rating)
data.table(Model = c("Model 1", "Model 2", "Model 3"), anova(rating.model, rating.intmodel1, rating.intmodel2))


## ---- message = FALSE, fig.width=4, fig.height=3------------------------------
data.table(
  Model = c("Model 1", "Model 2", "Model 3"),
  AIC = c(AIC(rating.model), AIC(rating.intmodel1), AIC(rating.intmodel2)))


## ---- message = FALSE, fig.width=4, fig.height=3------------------------------
ggplot(augment(rating.intmodel2), aes(x =.fitted, y = .resid)) + 
  geom_point(color="darkgreen") +
  geom_hline(yintercept = 0, linetype = "solid", color = "red") + 
  labs(x = "Fitted Values", y = "Residual Values") 


## ---- message = FALSE, fig.width=4, fig.height=3------------------------------
ggplot(augment(rating.intmodel2), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles")


## -----------------------------------------------------------------------------
summary(rating.intmodel2)
modelsummary(rating.intmodel2)


## -----------------------------------------------------------------------------
ci.rating <- confint(rating.intmodel2, level = 0.95)
ci.table <- data.frame(
  Coefficient = rownames(ci.rating),
  Lower_Bound = ci.rating[, 1],
  Upper_Bound = ci.rating[, 2]
)
print(ci.table)

