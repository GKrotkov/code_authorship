## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE, message=FALSE, warning=FALSE)


## -----------------------------------------------------------------------------
library(tidyverse)
library(ggplot2)
sleep <- read.csv("C://Users//Sathwika//Downloads//cmu-sleep.csv")


## ---- fig.pos='H'-------------------------------------------------------------
library(knitr)
library(kableExtra)

TotalSleepTime_stats <- c(Min = min(sleep$TotalSleepTime, na.rm = TRUE),
                          Median = median(sleep$TotalSleepTime, na.rm = TRUE),
                          Mean = mean(sleep$TotalSleepTime, na.rm = TRUE),
                          Max = max(sleep$TotalSleepTime, na.rm = TRUE),
                          SD = sd(sleep$TotalSleepTime, na.rm = TRUE))

term_gpa_stats <- c(Min = min(sleep$term_gpa, na.rm = TRUE),
                    Median = median(sleep$term_gpa, na.rm = TRUE),
                    Mean = mean(sleep$term_gpa, na.rm = TRUE),
                    Max = max(sleep$term_gpa, na.rm = TRUE),
                    SD = sd(sleep$term_gpa, na.rm = TRUE))

cum_gpa_stats <- c(Min = min(sleep$cum_gpa, na.rm = TRUE),
                   Median = median(sleep$cum_gpa, na.rm = TRUE),
                   Mean = mean(sleep$cum_gpa, na.rm = TRUE),
                   Max = max(sleep$cum_gpa, na.rm = TRUE),
                   SD = sd(sleep$cum_gpa, na.rm = TRUE))

# Combine summary statistics into a data frame
df <- rbind(TotalSleepTime = TotalSleepTime_stats,
            term_gpa = term_gpa_stats,
            cum_gpa = cum_gpa_stats)

knitr::kable(df, caption = "Table of Summary Statistics") %>%
  kable_styling(latex_options = "HOLD_position")





## ---- fig.height=3, fig.width=6, fig.pos='H'----------------------------------
library(ggplot2)
library(gridExtra)

#Histograms for each variable
p1 <- ggplot(sleep, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 10, fill = "skyblue", color = "black") + 
  labs(x = "Total Sleep Time (minutes)", 
       y = "Frequency") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

p2 <- ggplot(sleep, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.1, fill = "skyblue", color = "black") + 
  labs(x = "Term GPA", 
       y = "Frequency") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

p3 <- ggplot(sleep, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.1, fill = "skyblue", color = "black") + 
  labs(x = "Cumulative GPA", 
       y = "Frequency") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

grid.arrange(p1, p2, p3, ncol = 3, top="Figure 1: Histograms of the variables")



## ---- fig.height=3, fig.width=6, fig.pos='H'----------------------------------


# Boxplots for each variable
bp1 <- ggplot(sleep, aes(y = TotalSleepTime)) +
  geom_boxplot(fill = "lightpink") +
  labs(x = "",
       y = "Total Sleep Time (minutes)") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

bp2 <- ggplot(sleep, aes(y = term_gpa)) +
  geom_boxplot(fill = "lightpink") +
  labs(x = "",
       y = "Term GPA") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

bp3 <- ggplot(sleep, aes(y = cum_gpa)) +
  geom_boxplot(fill = "lightpink") +
  labs(x = "",
       y = "Cumulative GPA") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

grid.arrange(bp1, bp2, bp3, ncol = 3, top="Figure 2: Boxplots of the variables")



## ---- fig.height=3, fig.width=6, fig.pos='H'----------------------------------
# TotalSleepTime vs. Term GPA
p1 <- ggplot(sleep, aes(x=TotalSleepTime, y=term_gpa)) + 
  geom_point() +
  labs(x = "Total Sleep Time (minutes)", y = "Term GPA") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

# TotalSleepTime vs. Cumulative GPA
p2 <- ggplot(sleep, aes(x=TotalSleepTime, y=cum_gpa)) + 
  geom_point() +
  labs(x = "Total Sleep Time (minutes)", y = "Cumulative GPA") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

# Term GPA vs. Cumulative GPA
p3 <- ggplot(sleep, aes(x=cum_gpa, y=term_gpa)) + 
  geom_point() +
  labs(x = "Cumulative GPA", y = "Term GPA") + theme(axis.title.x = element_text(size = 9), axis.title.y = element_text(size = 9))

gridExtra::grid.arrange(p1, p2, p3, ncol=3, top="Figure 3: Scatterplots of variables")



## ---- fig.height=3, fig.width=6-----------------------------------------------
log_term_gpa <- log(sleep$term_gpa)

model <- lm(log_term_gpa ~ TotalSleepTime, data = sleep)
#summary(model)

ggplot(sleep, aes(x = TotalSleepTime, y = log_term_gpa)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") + 
  labs(title="Figure 4: Fitted Regression line on Scatterplot of Sleep Time vs. Transformed Term GPA",
       x="Total Sleep Time (minutes)",
       y="Logarithm of Term GPA") + theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size = 10), plot.title = element_text(size = 10))


## -----------------------------------------------------------------------------
model <- lm(log_term_gpa ~ TotalSleepTime, data = sleep)

par(mfrow = c(2, 2))
plot(model)
mtext("Figure 5: Diagnostic Plots",side=3,line=-1,outer=TRUE)


## -----------------------------------------------------------------------------
model <- lm(log_term_gpa ~ TotalSleepTime, data = sleep)

gof_stats <- data.frame(
  Statistic = c("R-squared", "Adjusted R-squared", "Residual Standard Error", "F-statistic p-value"),
  Value = c(summary(model)$r.squared, 
            summary(model)$adj.r.squared, 
            sigma(model), 
            pf(summary(model)$fstatistic[1], 
               summary(model)$fstatistic[2], 
               summary(model)$fstatistic[3], lower.tail = FALSE))
)

knitr::kable(gof_stats, caption = "Goodness of Fit Statistics", digits = 4) %>%
  kable_styling(latex_options = "HOLD_position")



## -----------------------------------------------------------------------------
#install.packages("broom")
library(broom)
library(knitr)
library(kableExtra)


model <- lm(log_term_gpa ~ TotalSleepTime, data = sleep)
#summary(model)

tidy_output <- tidy(model)
tidy_output$p.value <- sprintf("%.12f", tidy_output$p.value)
#print(tidy_output)

knitr::kable(tidy_output, digits = 3, col.names = c("Term", "Estimate", "Std. Error", "Statistic", "P-value"), caption = "Statistics from the Linear Model") %>%
  kable_styling(latex_options = "HOLD_position")


