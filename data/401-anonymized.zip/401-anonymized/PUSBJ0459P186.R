## ---- echo = FALSE, results = 'hide', include = FALSE-------------------------
library(ggplot2)
library(alr4)

df <- Rateprof

ggplot(df, aes(x = quality)) + geom_histogram(binwidth = 1) + labs(x = "Quality Rating (1 to 5)", caption = "Figure 1: Average teaching quality rating") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = factor(gender))) + geom_bar() + labs(x = "Gender", caption = "Figure 2: Gender") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = factor(pepper))) + geom_bar() + labs(x = "Attractiveness", caption = "Figure 3: Attractiveness") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = easiness)) + geom_histogram(binwidth = 1) + labs(x = " Easiness Rating (1 to 5)", caption = "Figure 4: Average course easiness rating") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = factor(discipline))) + geom_bar() + labs(x = "Discipline", caption = "Figure 5: Discipline") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
library(ggplot2)

plot1 <- ggplot(df, aes(x=easiness, y=quality)) + 
  geom_point() 

plot1 + labs(y = "Quality Rating (1 to 5)", x = "Easiness Rating (1 to 5)", caption = "Figure 1: Quality rating versus easiness rating") + stat_smooth(method = "lm", formula = y ~ x, geom = "smooth") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
ggplot(df, aes(x = gender, y = quality)) + geom_boxplot() +
labs(x = "Gender", y = "Quality rating (1 to 5)") + labs(caption = "Figure 2: Average teaching quality rating by gender") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = pepper, y = quality)) + geom_boxplot() +
labs(x = "Attractiveness", y = "Quality rating (1 to 5)") + labs(caption = "Figure 3: Average teaching quality rating by attractiveness") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))

ggplot(df, aes(x = discipline, y = quality)) + geom_boxplot() +
labs(x = "Discipline", y = "Quality rating (1 to 5)") + labs(caption = "Figure 4: Average teaching quality rating by discipline") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
library(ggplot2)
library(broom)
lm1 <- lm(quality ~ gender + pepper + easiness + discipline, data = df)

augment(lm1) |> ggplot(aes(x = easiness, y = .resid)) +
geom_point() + labs(x = "Easiness rating (1 to 5)", y = "Residual", caption = "Figure 5: Residual plot of Quality rating versus Course easiness") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
ggplot(augment(lm1), aes(sample = .resid)) + geom_qq() +
geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles", caption = "Figure 6: QQ-plot of Quality rating versus easiness rating") + theme(plot.caption = element_text(hjust = 0, face = "italic", size = 11))


## ---- echo = FALSE, results = 'hide'------------------------------------------
vif(lm1)


## ---- echo = FALSE, results = 'hide'------------------------------------------
summary(lm1)


## ---- echo = FALSE, results = 'hide'------------------------------------------
step_mod <- step(lm1, direction = "both", trace = 0)
step_mod

lm2 <- lm(quality ~ gender + pepper + easiness, data = df)
summary(lm2)

confint(lm2)


## ---- echo = FALSE, results = 'hide'------------------------------------------
lm_full <- lm(quality ~ easiness + gender + discipline, data = df)

lm_red <- lm(quality ~ easiness, data = df)

anova(lm_red, lm_full)


lm_full2 <- lm(quality ~ easiness + gender, data = df)

anova(lm_red, lm_full2)


lm_full3 <- lm(quality ~ easiness + discipline, data = df)

anova(lm_red, lm_full3)


## ---- echo = FALSE, results = 'hide'------------------------------------------
finalmod <- step(lm_full, direction = "both", trace = 0)
finalmod

summary(lm_full2)

confint(lm_full2)

