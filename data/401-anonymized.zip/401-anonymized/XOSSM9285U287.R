## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
#plot(dist ~ speed, data = cars,
#     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## -----------------------------------------------------------------------------
#packages
library(tidyverse)
library(ggplot2)
library(patchwork)
library(broom)
library(VGAM)
library(GGally)
library(modelsummary)


## -----------------------------------------------------------------------------
#load data
cmu_sleep = read_csv("/Users/marco/Desktop/CMU Fall 2023/36401 Modern Regression/Data Exam 1/cmu-sleep.csv")
sleep = cmu_sleep[,c("TotalSleepTime", "term_gpa", "cum_gpa")]

## -----------------------------------------------------------------------------
#eda
sleep %>%
ggplot(aes(x = TotalSleepTime)) +
geom_histogram(fill = "midnightblue", color = "black") +
labs(title = "Total Nightly Sleep Time Distribution",
     x = "Sleep (minutes)", y = "Count")

sleep %>%
ggplot(aes(x = term_gpa)) +
geom_histogram(fill = "peachpuff", color = "black") +
labs(title = "Term GPA Distribution",
     x = "GPA (4.0 scale)", y = "Count")

sleep %>%
ggplot(aes(x = cum_gpa)) +
geom_histogram(fill = "khaki", color = "black") +
labs(title = "Cumulative GPA Distribution",
     x = "GPA (4.0 scale)", y = "Count")

## -----------------------------------------------------------------------------
#more eda
sleep %>%
  ggplot(aes(x=TotalSleepTime,y=term_gpa)) +
  geom_point(alpha=0.7)

#no transformation needed I think
sleep %>%
  ggplot(aes(x=log(TotalSleepTime),y=term_gpa)) +
  geom_point(alpha=0.7)

sleep %>%
  ggplot(aes(x=TotalSleepTime,y=cum_gpa)) +
  geom_point(color="lavenderblush3", alpha=0.7)

sleep %>%
  ggplot(aes(x=cum_gpa,y=term_gpa)) +
  geom_point(color="indianred3", alpha=0.7)

## -----------------------------------------------------------------------------
sleep_lm = lm(term_gpa ~ (TotalSleepTime), data = sleep)
summary(sleep_lm)

#one_df = sleep[34,]
#predict(sleep_lm, newdata = one_df, interval = "confidence", level = 0.95)
#two_df = sleep[32,]
#predict(sleep_lm, newdata = two_df, interval = "confidence", level = 0.95)

## -----------------------------------------------------------------------------
sleep_residuals = residuals(sleep_lm)
combo_data = data.frame(x=sleep$TotalSleepTime, residuals = sleep_residuals)
ggplot(combo_data, aes(x=x, y=residuals)) + 
  geom_point(color="black") +
  labs(title="Residuals versus Sleep", x="Total Sleep Time (minutes)", y="Residuals")
#there is slight heteroskedacity here...

cookd = cooks.distance(sleep_lm)
cookd[which(cookd==max(cookd))]

ggplot(augment(sleep_lm),
aes(sample =.resid))+
geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles")

ggplot(augment(sleep_lm), aes(x = .fitted,y =.resid))+
geom_point() +
labs(x = "Fitted value", y = "Residual")



## -----------------------------------------------------------------------------
#tobit_model <- vglm(term_gpa ~ TotalSleepTime, tobit(Upper = 4), data = cmu_sleep)
#summary(tobit_model)
#same assumptions, not really a good alternative yet

sleep_transformed = sleep

#sleep_transformed
constant <- max(sleep_transformed$term_gpa) + 1
sleep_transformed$transformed_term_gpa <- log(constant - sleep_transformed$term_gpa)
sleep_transformed$transformed_term_gpa = exp(sleep_transformed$term_gpa)


## -----------------------------------------------------------------------------
sleep_transformed %>%
ggplot(aes(x = term_gpa)) +
geom_histogram(fill = "blue", color = "black") +
labs(title = "Cumulative GPA Distribution",
     x = "GPA (4.0 scale)", y = "Count")
sleep_transformed %>%
ggplot(aes(x = transformed_term_gpa)) +
geom_histogram(fill = "red", color = "black") +
labs(title = "Cumulative GPA Distribution",
     x = "GPA (4.0 scale)", y = "Count")
sleep_transformed %>%
  ggplot(aes(x=TotalSleepTime,y=transformed_term_gpa)) +
  geom_point(alpha=0.7)
t_sleep_lm = lm(transformed_term_gpa ~ (TotalSleepTime), data = sleep_transformed)
summary(t_sleep_lm)

ggplot(augment(t_sleep_lm),
aes(sample =.resid))+
geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles")




## -----------------------------------------------------------------------------
#Q2 work:
differ_sleep = data.frame(TotalSleepTime = c(480,360))
differ_preds = predict(sleep_lm, newdata = differ_sleep)
#differ_preds[1]-differ_preds[2]

x1=c(1,480)
x2=c(1,360)
numerator = t(x1) %*% coef(sleep_lm) - t(x2) %*% coef(sleep_lm)
se = sqrt(t(x1-x2) %*% vcov(sleep_lm) %*% (x1-x2))

numerator+se*qt(0.975, 632)
numerator-se*qt(0.975, 632)

############
#why are these different?, a*X, interested in SE Of 120*coefficient: CURRENT CONFINTS ARE GOOD (95%)
############
sleep_coefficient = coef(sleep_lm)["TotalSleepTime"]
expected_change_in_gpa = sleep_coefficient*(-120)
std_error <- 120*summary(sleep_lm)$coefficients["TotalSleepTime", "Std. Error"]
t_value = qt(0.975, 632)
expected_change_in_gpa-std_error*t_value
expected_change_in_gpa+std_error*t_value

## -----------------------------------------------------------------------------
cmu_sleep %>%
  ggplot(aes(x=midpoint_sleep,y=TotalSleepTime)) +
  geom_point(color="lavenderblush3", alpha=0.7)
cmu_sleep %>%
  ggplot(aes(x=midpoint_sleep,y=term_gpa)) +
  geom_point(color="lavenderblush3", alpha=0.7)

second_sleep = cmu_sleep
second_sleep$bedtime_mssd = second_sleep$bedtime_mssd * 60
second_lm = lm(term_gpa ~ TotalSleepTime + (bedtime_mssd), data=second_sleep)
summary(second_lm)

cmu_sleep %>%
  select(TotalSleepTime, midpoint_sleep, bedtime_mssd) %>%
  ggpairs()

## -----------------------------------------------------------------------------
modelsummary(list("Model 1" = sleep_lm),
             gof_map = c("r.squared", "nobs", "rmse"), statistic = c("s.e. = {std.error}", "t = {statistic}", "p = {p.value}"))


## -----------------------------------------------------------------------------
#eda
sleep %>%
ggplot(aes(x = TotalSleepTime)) +
geom_histogram(fill = "midnightblue", color = "black", binwidth = 12) +
labs(title = "Total Nightly Sleep Time Distribution",
     x = "Sleep (minutes)", y = "Students", 
     caption = "Normal-looking and symmetric distribution of data.")

sleep %>%
ggplot(aes(x = term_gpa)) +
geom_histogram(fill = "peachpuff", color = "black", binwidth = 0.1) +
labs(title = "Term GPA Distribution",
     x = "GPA (4.0 scale)", y = "Students", 
     caption = "Extremely-left skewed data, as you'd expect few students clustered around C, D and lower.")

sleep %>%
ggplot(aes(x = cum_gpa)) +
geom_histogram(fill = "khaki", color = "black", binwidth = 0.1) +
labs(title = "Cumulative GPA Distribution",
     x = "GPA (4.0 scale)", y = "Students", 
     caption = "Very left skewed data, for the same reason.")


## -----------------------------------------------------------------------------
#more eda
sleep %>%
  ggplot(aes(x=TotalSleepTime,y=term_gpa)) +
  geom_point(alpha=0.7) + 
  labs(title = "Term GPA versus Sleep Time",
     x = "Sleep (minutes)", y = "GPA (4.0) scale", 
     caption = "It's hard to make out a trend and some of the data is rather clumped, but it looks like a line could be fitted to this.")

sleep %>%
  ggplot(aes(x=TotalSleepTime,y=cum_gpa)) +
  geom_point(color="lavenderblush3", alpha=0.7) +
  labs(title = "Cumulative GPA versus Sleep Time",
     x = "Sleep (minutes)", y = "GPA (4.0) scale", 
     caption = "This variable behaves like term_gpa when plotted against sleep time, but the GPA seems to be even more varied.")

sleep %>%
  ggplot(aes(x=cum_gpa,y=term_gpa)) +
  geom_point(color="indianred3", alpha=0.7) +
  labs(title = "Term GPA versus Cumulative GPA",
     x = "GPA (4.0) scale", y = "GPA (4.0) scale", 
     caption = "The GPAs from the studied semester and previous semester look highly correlated.")


## -----------------------------------------------------------------------------
ggplot(augment(sleep_lm),
aes(sample =.resid))+
geom_qq() + geom_qq_line() + 
  labs(title = "Normal Q-Q Plot", x = "Theoretical quantiles", y = "Sample quantiles",
       caption = "At both extremes, the sample quantiles are under the line. This is suggestive of left-skewed data which we have.")

ggplot(augment(sleep_lm), aes(x = .fitted,y =.resid))+
geom_point() +
labs(title = "Residual versus Fitted Values Plot", x = "Fitted value", y = "Residual",
     caption = "Note the strange slant, evidence of heteroskedasticity.")


## -----------------------------------------------------------------------------
modelsummary(list("Model 1" = sleep_lm), fmt = fmt_significant(2),
             gof_map = c("r.squared", "nobs", "rmse"), statistic = c("s.e. = {std.error}", "t = {statistic}", "p = {p.value}"))

