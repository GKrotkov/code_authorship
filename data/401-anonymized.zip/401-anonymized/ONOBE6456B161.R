## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(ggplot2)
library(modelsummary)
sleep.dt <- read.csv("cmu-sleep.csv")
config_modelsummary(factory_default = "markdown")


## ----fig.width = 5, fig.height = 3, fig.cap = "Student average sleep time per night over the past semester"----
ggplot(sleep.dt, aes(x = TotalSleepTime)) + geom_histogram(col = "black", fill = "pink", bins = 30) + labs(title = "Histogram of Student Sleep Time Averages", x = "Sleep Time (minutes)")

## ----eval = FALSE-------------------------------------------------------------
## summary(sleep.dt$TotalSleepTime)


## ----fig.width = 5, fig.height = 3, fig.cap = "Student GPAs over the past semester"----
ggplot(sleep.dt, aes(x = term_gpa)) + geom_histogram(col = "black", fill = "green", bins = 30) + labs(title = "Histogram of GPAs from the Past Semester", x = "GPAs (4.0 scale)")

## ----eval = FALSE-------------------------------------------------------------
## summary(sleep.dt$term_gpa)


## ----fig.width = 5, fig.height = 3, fig.cap = "Student Cumulative GPAs over the past year"----
ggplot(sleep.dt, aes(x = cum_gpa)) + geom_histogram(col = "black", fill = "#00aa00", bins = 30) + labs(title = "Histogram of GPAs from the Past Year", x = "GPAs (4.0 scale)")


## ----eval = FALSE-------------------------------------------------------------
## summary(sleep.dt$cum_gpa)


## ----eval = FALSE-------------------------------------------------------------
## hist(sleep.dt$TotalSleepTime)
## hist(sleep.dt$term_gpa)
## hist(exp(sleep.dt$term_gpa))
## hist(3^(sleep.dt$term_gpa))
## hist(4^(sleep.dt$term_gpa))
## hist(5^(sleep.dt$term_gpa))
## hist(exp(sleep.dt$cum_gpa))


## ----fig.width = 6, fig.height = 3, fig.cap = "Student GPAs over the last semester per total average time slept each night last semester"----
ggplot(sleep.dt, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + labs(title = "Student Last Term GPA vs Total Sleep Time", y = "Last term GPA (4.0 scale)", x = "Total Sleep Time (minutes)")


## ----fig.width = 6, fig.height = 3, fig.cap = "Student GPAs over the past year per total average time slept each night last semester"----
ggplot(sleep.dt, aes(x = TotalSleepTime, y = cum_gpa)) + geom_point() + labs(title = "Student Past Year Cumulative GPA vs Total Sleep Time", y = "Past Year GPA (4.0 scale)", x = "Total Sleep Time (minutes)")


## ----eval = FALSE-------------------------------------------------------------
## plot(lm(term_gpa ~ TotalSleepTime, data = sleep.dt)$residuals)
## plot(lm(cum_gpa ~ TotalSleepTime, data = sleep.dt)$residuals)
## sum(lm(cum_gpa ~ TotalSleepTime, data = sleep.dt)$residuals)


## ----fig.width = 6, fig.height = 3, fig.cap = "Student Past Semester GPA vs Past Year Cumulative GPA"----
ggplot(sleep.dt, aes(x = cum_gpa, y = term_gpa)) + geom_point() + labs(title = "Student Past Semester GPA vs Student Past Cumulative GPA", y = "Past Semester GPA (4.0 scale)", x = "Cumulative GPA (4.0 scale)")


## ----eval=FALSE---------------------------------------------------------------
## plot(sleep.dt$term_gpa^5 ~ sleep.dt$TotalSleepTime)
## plot(sleep.dt$cum_gpa ~ sleep.dt$TotalSleepTime)
## plot(exp(sleep.dt$cum_gpa) ~ sleep.dt$TotalSleepTime)
## pow3.termgpa = 4^sleep.dt$term_gpa
## pow3.cumgpa = 4^sleep.dt$cum_gpa
## plot(pow3.termgpa ~ pow3.cumgpa)
## plot(exp(sleep.dt$term_gpa) ~ exp(sleep.dt$cum_gpa))
## plot(log(sleep.dt$term_gpa) ~ log(sleep.dt$TotalSleepTime))


## ----fig.width = 6, fig.height = 3, fig.cap = "Student Past Semester GPAs transformed by doing log(4.1 - GPA) transformation"----
ggplot(sleep.dt, aes(x = log(4.1 - term_gpa))) + geom_histogram(col = "black", fill = "green", bins = 30) + labs(title = "Transformed Histogram of GPAs from the Past Semester", x = "log(4.1 - GPA (4.0 scale))")


## ----fig.width = 6, fig.height = 3, fig.cap = "Student Past year cumulative GPAs transformed by doing log(4.1 - GPA) transformation"----
ggplot(sleep.dt, aes(x = log(4.1 - cum_gpa))) + geom_histogram(col = "black", fill = "#00aa00", bins = 30) + labs(title = "Transformed Histogram of cumulative GPAs from the Past Year", x = "log(4.1 - GPA (4.0 scale))")


## ----fig.width = 6, fig.height = 3, fig.cap = "Transformed Student Last Term GPA per total average time slept each night last semester"----
ggplot(sleep.dt, aes(x = TotalSleepTime, y = log(4.1 - term_gpa) )) + geom_point() + labs(title = "Transformed Student Past Term GPA vs Total Sleep Time", y = "log(4.1 - Last term GPA (4.0 scale))", x = "Average Total Sleep Time (minutes)") #+ geom_smooth(method='lm')


## -----------------------------------------------------------------------------
sleep.lm.basic <- lm(log(4.1 - term_gpa) ~ TotalSleepTime, data = sleep.dt)
sleep.lm.controlled <- lm(log(4.1 - term_gpa) ~ TotalSleepTime + log(4.1 - cum_gpa), data = sleep.dt)
#summary(sleep.lm.controlled)
#summary(sleep.lm.basic)
modelsummary(list("Basic Term GPA vs Sleep Model" = sleep.lm.basic, "Term GPA vs Sleep and Cumulative GPA Model" = sleep.lm.controlled), statistic = c("95% CI [{conf.low}, {conf.high}]", "SE = {std.error}"), fmt = 5, gof_map = c("r.squared", "nobs"))


## ----eval = FALSE-------------------------------------------------------------
## mean(sleep.lm.basic$residuals)


## ----eval = FALSE-------------------------------------------------------------
## head(sort(pf(cooks.distance(sleep.lm.basic), 1, 632), decreasing = TRUE))


## ----fig.cap = "Residual Plotted against Fitted GPA Values"-------------------
ggplot(sleep.lm.basic, aes(x = .fitted, y = .resid)) + geom_point() + geom_hline(yintercept = 0) + labs(title = 'Residuals vs Fitted Value Plot', y = 'Residuals', x = 'Fitted Values')


## ----fig.cap = "Residuals Normal QQ-plot to check for normality"--------------
ggplot(sleep.lm.basic, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles")


## ----eval = FALSE-------------------------------------------------------------
## mean(sleep.lm.controlled$residuals)


## ----eval = FALSE-------------------------------------------------------------
## head(sort(pf(cooks.distance(sleep.lm.controlled), 2, 631), decreasing = TRUE))


## ----fig.cap = "Residuals Plotted Against Past Year log(4.1 - Cumulative GPA)"----
ggplot(sleep.lm.controlled, aes(x = sleep.lm.controlled$model$`log(4.1 - cum_gpa)`, y = .resid)) + geom_point() + geom_hline(yintercept = 0) + labs(title = 'Residuals vs log(4.1 - Cumulative GPA)', y = 'Residuals', x = 'log(4.1 - Cumulative GPA)')


## ----fig.cap = "Residuals Plotted Against Fitted Values"----------------------
ggplot(sleep.lm.controlled, aes(x = .fitted, y = .resid)) + geom_point() + geom_hline(yintercept = 0) + labs(title = 'Residuals vs Fitted Values', y = 'Residuals', x = 'Fitted Values')


## ----fig.cap = "Residuals Normal QQ-plot to check for normality"--------------
ggplot(sleep.lm.controlled, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles")


## ----eval = FALSE-------------------------------------------------------------
## confint(sleep.lm.controlled, 'TotalSleepTime', level = 0.95)

