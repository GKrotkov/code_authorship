## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE,
                      warning = FALSE,
                      fig.align = 'center',
                      fig.height = 2.5,
                      fig.pos = 'H')
library(dplyr)
library(alr4)
library(ggplot2)
library(modelsummary)


## ---- echo = FALSE------------------------------------------------------------
# Data is in the alr4 package
prof_data = Rateprof


## ---- echo = FALSE------------------------------------------------------------
# Quality Rating Histogram
prof_data %>%
  ggplot(aes(x = quality)) +
  geom_histogram(color = "black", fill = "red", bins = 20) +
  labs(title = "Professor Quality Rating Distribution",
       x = "Quality Rating", y = "Frequency",
       caption = "Figure 1: Histogram of professor quality ratings")


## ---- echo = FALSE------------------------------------------------------------
# Attractiveness Distribution
prof_data %>%
  ggplot(aes(x = pepper)) +
  geom_bar(color = "black", fill = "cyan") +
  labs(title = "Professor Attractiveness Distribution",
       x = "Attractive", y = "Frequency",
       caption = "Figure 2: Bar plot of professor attractiveness")


## ---- echo = FALSE------------------------------------------------------------
# Easiness distribution
prof_data %>%
  ggplot(aes(x = easiness)) +
  geom_histogram(color = "black", fill = "orange", bins = 15) +
  labs(title = "Easiness of Professor Distribution",
       x = "Easiness Rating", y = "Frequency",
       caption = "Figure 3: Histogram of professor easiness ratings")


## ---- echo = FALSE------------------------------------------------------------
# Gender distribution
prof_data %>%
  ggplot(aes(x = gender)) +
  geom_bar(color = "black", aes(fill = gender)) +
  labs(title = "Professor Gender Distribution",
       x = "Gender", y = "Frequency",
       caption = "Figure 4: Bar plot of professor genders",
       fill = "Gender")


## ---- echo = FALSE------------------------------------------------------------
# Discipline distribution
prof_data %>%
  ggplot(aes(x = discipline)) +
  geom_bar(color = "black", aes(fill = discipline)) +
  labs(title = "Professor Discipline Distribution",
       x = "Discipline", y = "Frequency",
       caption = "Figure 5: Bar plot of professor disciplines",
       fill = "Discipline")


## ---- echo = FALSE------------------------------------------------------------
# Attractiveness vs Quality Rating
prof_data %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(aes(x = pepper, fill = pepper)) +
  labs(title = "Attractiveness vs Quality Rating Boxplot",
       x = "Attractive?", y = "Quality Rating",
       caption = "Figure 6: Box plot of attractiveness vs quality rating",
       fill = "Attractive")


## ---- echo = FALSE------------------------------------------------------------
# Easiness vs Quality
prof_data %>%
  ggplot(aes(x = easiness, y = quality)) +
  geom_point(alpha = 0.5) +
  geom_smooth(color = "red", method = "lm", se = FALSE) +
  labs(title = "Easiness vs Quality Rating Scatterplot",
       x = "Easiness", y = "Quality Rating",
       caption = "Figure 7: Scatterplot of easiness rating vs quality rating")


## ---- echo = FALSE------------------------------------------------------------
# Gender vs Quality Rating
prof_data %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(aes(x = gender, fill = gender)) +
  labs(title = "Gender vs Quality Rating Boxplot",
       x = "Gender", y = "Quality Rating",
       caption = "Figure 8: Box plot of gender vs quality rating",
       fill = "Gender")


## ---- echo = FALSE------------------------------------------------------------
# Discipline vs Quality Rating
prof_data %>%
  ggplot(aes(y = quality)) +
  geom_boxplot(aes(x = discipline, fill = discipline)) +
  labs(title = "Discipline vs Quality Rating Boxplot",
       x = "Discipline", y = "Quality Rating",
       caption = "Figure 9: Box plot of discipline vs quality rating",
       fill = "Discipline")


## ---- echo = FALSE------------------------------------------------------------
# Gender vs Easiness Plot
prof_data %>%
  ggplot(aes(y = easiness)) +
  geom_boxplot(aes(x = gender, fill = gender)) +
  labs(title = "Gender vs Easiness Boxplot",
       x = "Gender", y = "Easiness Rating",
       caption = "Figure 10: Box plot of gender vs easiness",
       fill = "Gender")


## ---- echo = FALSE------------------------------------------------------------
# Discipline vs Easiness Plot
prof_data %>%
  ggplot(aes(y = easiness)) +
  geom_boxplot(aes(x = discipline, fill = discipline)) +
  labs(title = "Discipline vs Easiness Boxplot",
       x = "Discipline", y = "Easiness Rating",
       caption = "Figure 11: Box plot of discipline vs easiness",
       fill = "Discipline")


## ---- echo = FALSE------------------------------------------------------------
# Build Models

prof.lm.full = lm(quality ~ pepper + easiness + gender + discipline + 
               easiness:discipline + easiness:gender, data = prof_data)

prof.lm.partial = lm(quality ~ pepper + easiness + gender + discipline, 
                     data = prof_data)

# Run ANOVA Test
#anova(prof.lm.full, prof.lm.partial)


## ---- echo = FALSE------------------------------------------------------------
# QQ Plot
qqnorm(residuals(prof.lm.partial),
       main = "QQ Residual Plot",
       ylab = "Residual Amount")
qqline(residuals(prof.lm.partial), col = 'red')


## ---- echo = FALSE------------------------------------------------------------
plot(residuals(prof.lm.partial),
     main = "Evaluation Data Linear Model Residual Plot",
     xlab = "Fitted Values",
     ylab = "Residual Values")


## ---- echo = FALSE------------------------------------------------------------
# Linear model for test
modelsummary(list("Linear Model" = prof.lm.partial),
             gof_map = c("r.squared", "nobs"))

