## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## -----------------------------------------------------------------------------
library(alr4)


## ----fig.width=4, fig.height=3, fig.cap="Figure 1: Unimodal and Left Skewed Histogram of Average Quality"----
hist(Rateprof$quality, main="Histogram of Average Quality", xlab="Average Rating")


## ----fig.width=4, fig.height=3, fig.cap="Figure 2: Unimodal and Normal Histogram of Average Easiness Rating"----
hist(Rateprof$easiness, main="Histogram of Average Easiness", xlab="Average Rating")


## ----fig.width=4, fig.height=3, fig.cap="Figure 3: Table for Binary Pepper Variable"----
table(Rateprof$pepper)


## ----fig.width=4, fig.height=3, fig.cap="Figure 4: Table for Discipline"------
table(Rateprof$discipline)


## ----fig.width=4, fig.height=3, fig.cap="Figure 5: Table for Gender"----------
table(Rateprof$gender)


## -----------------------------------------------------------------------------
median(Rateprof$quality[which(Rateprof$pepper=="yes")])
median(Rateprof$quality[which(Rateprof$pepper=="no")])


## ---- fig.width=4, fig.height=3, fig.cap="Figure 6: Boxplot of Average Quality vs Perceived Hotness"----
boxplot(quality~pepper, data=Rateprof, main="Average Quality vs Perceived Hotness", ylab="Average Quality", xlab="Are They Attractive?", names=c("No", "Yes"))


## -----------------------------------------------------------------------------
median(Rateprof$quality[which(Rateprof$discipline=="Hum")])
median(Rateprof$quality[which(Rateprof$discipline=="SocSci")])
median(Rateprof$quality[which(Rateprof$discipline=="STEM")])
median(Rateprof$quality[which(Rateprof$discipline=="Pre-prof")])

## ---- fig.width=4, fig.height=3, fig.cap="Figure 7: Boxplot of Average Quality vs Discipline"----
boxplot(quality~discipline, data=Rateprof, main="Average Quality vs Discipline", ylab="Average Quality", xlab="Discipline", names=c("Hum", "SocSci", "STEM", "Pre-prof"))

## -----------------------------------------------------------------------------
median(Rateprof$quality[which(Rateprof$gender=="female")])
median(Rateprof$quality[which(Rateprof$gender=="male")])


## ---- fig.width=4, fig.height=3, fig.cap="Figure 8: Boxplot of Average Quality vs Gender"----
boxplot(quality~gender, data=Rateprof, main="Average Quality vs Gender", ylab="Average Quality", xlab="Gender", names=c("Female", "Male"))


## ---- fig.width=4, fig.height=3, fig.cap="Figure 9: Moderate Positive Association shown in Scatterplot of Average Quality vs Average Easiness Color Coded by Pepper"----
pepper.color=ifelse(Rateprof$pepper=="yes","red","blue")
plot(Rateprof$easiness, Rateprof$quality, main="Quality vs Easiness Color Coded by Attractiveness", xlab="Easiness (1 to 5 scale)", ylab="Quality (1 to 5 scale)", col=pepper.color)
legend("bottomright", legend = c("Attractive", "Unattractive"), col = c("red", "blue"), box.col="green", lty=1, cex=0.8,
       box.lty=2, box.lwd=2)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 10: Moderate Positive Association shown in Scatterplot of Average Quality vs Average Easiness Color Coded by Discipline"----
discipline.color=ifelse(Rateprof$discipline=="Hum","red", ifelse(Rateprof$discipline=="SocSci", "blue", ifelse(Rateprof$discipline=="STEM", "orange","turquoise3")))
plot(Rateprof$easiness, Rateprof$quality, main="Quality vs Easiness Color Coded by Discipline", xlab="Easiness (1 to 5 scale)", ylab="Quality (1 to 5 scale)", col=discipline.color)
legend("bottomright", legend = c("Humanities", "STEM", "Professional Training", "Social Sciences"), col = c("red", "orange", "turquoise3", "blue"), box.col="green", lty=1, cex=0.8,
       box.lty=2, box.lwd=2)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 11: Moderate Positive Association shown in Scatterplot of Average Quality vs Average Easiness Color Coded by Gender"----
gender.color= ifelse(Rateprof$gender=="female","red","blue")
plot(Rateprof$easiness, Rateprof$quality, main="Quality vs Easiness by Gender", xlab="Easiness (1 to 5 scale)", ylab="Quality (1 to 5 scale)", col=gender.color)
legend("bottomright", legend = c("Female", "Male"), col = c("red", "blue"), box.col="green", lty=1, cex=0.8,
       box.lty=2, box.lwd=2)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 12: Interaction Plot of Gender and Pepper "----
ave.quality = Rateprof$quality
attractive = Rateprof$pepper
interaction.plot(x.factor = Rateprof$gender, 
                 trace.factor = attractive,
                 response = ave.quality, xlab="Gender", ylab="Mean of average quality")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 13: Interaction Plot of Discipline and Pepper "----
ave.quality = Rateprof$quality
attractive = Rateprof$pepper
interaction.plot(x.factor = Rateprof$discipline, 
                 trace.factor = attractive,
                 response = ave.quality, xlab="Discipline", ylab="Mean of average quality" )


## ---- fig.width=4, fig.height=3, fig.cap="Figure 14: Interaction Plot of Discipline and Gender "----
ave.quality = Rateprof$quality
instruct.gender= Rateprof$gender
interaction.plot(x.factor = Rateprof$discipline, 
                 trace.factor = instruct.gender,
                 response = ave.quality, xlab="Discipline", ylab="Mean of average quality")


## -----------------------------------------------------------------------------
ave.quality.fit.1 <- lm(quality ~ factor(pepper) + factor(discipline) + easiness + factor(gender) + easiness:factor(pepper) + factor(discipline):factor(gender), data=Rateprof)
ave.quality.fits.1 = fitted(ave.quality.fit.1)
ave.quality.res.1 = residuals(ave.quality.fit.1)
#Three way interaction
ave.quality.fit.3 <- lm(quality ~ factor(pepper) + factor(discipline) + easiness + factor(gender) + easiness:factor(pepper) + factor(discipline):factor(gender) + easiness:factor(gender):factor(discipline), data=Rateprof)
ave.quality.fits.3 = fitted(ave.quality.fit.3)
ave.quality.res.3 = residuals(ave.quality.fit.3)

ave.quality.fit.1.full <- lm(quality ~ factor(pepper) + factor(discipline) + easiness + factor(gender) + easiness:factor(pepper), data=Rateprof)
ave.quality.fit.1.red <- lm(quality ~ factor(pepper) + easiness + factor(gender) + easiness:factor(pepper), data=Rateprof)

## -----------------------------------------------------------------------------
library(modelsummary)


## ----fig.width=4, fig.height=3, fig.cap="Figure 15: Residuals versus fitted plot for mulivariate linear regression "----
plot(ave.quality.fits.1 ,ave.quality.res.1, main="residuals versus fitted", xlab="fitted", ylab="residuals")
abline(h=0)



## ----fig.width=4, fig.height=3, fig.cap="Figure 16: Normal probability plot of the residuals"----
qqnorm(ave.quality.res.1)



## ----fig.width=4, fig.height=3, fig.cap="Figure 17: Residuals versus fitted plot for mulivariate linear regression for three way interaction model, model 3 "----

plot(ave.quality.fits.3 ,ave.quality.res.3, main="residuals versus fitted", xlab="fitted", ylab="residuals")
abline(h=0)


## ----fig.width=4, fig.height=3, fig.cap="Figure 18: Normal probability plot of the residuals for three way interaction model, model 3"----

qqnorm(ave.quality.res.3)



## ----fig.width=4, fig.height=3, fig.cap="Figure: Predicted Fitted plot with easiness"----

plot(Rateprof$easiness, ave.quality.res.1, xlab="Easiness", ylab="Model residuals")
abline(h=0)


## ----fig.width=4, fig.height=3, fig.cap="Figure: Predicted Fitted plot with Pepper"----

plot(Rateprof$pepper, ave.quality.res.1, xlab="Pepper", ylab="Model residuals")
abline(h=0)


## ----fig.width=4, fig.height=3, fig.cap="Figure: Predicted Fitted plot with Gender"----

plot(Rateprof$gender, ave.quality.res.1, xlab="Gender", ylab="Model residuals")
abline(h=0)


## ----fig.width=4, fig.height=3, fig.cap="Figure: Predicted Fitted plot with Discipline"----

plot(Rateprof$discipline, ave.quality.res.1, xlab="Discipline", ylab="Model residuals")
abline(h=0)



## ----fig.width=4, fig.height=3, fig.cap="Figure 19: Model 1 Summary Table"----
library(broom)
tidy(ave.quality.fit.1) |>
knitr::kable(digits = 3, booktabs = TRUE,
col.names = c("Term", "Estimate", "SE", "t", "p"))

## ----fig.width=4, fig.height=3, fig.cap="Figure 20: Reduced Model 1 Summary Table"----
tidy(ave.quality.fit.1.red) |>
knitr::kable(digits = 3, booktabs = TRUE,
col.names = c("Term", "Estimate", "SE", "t", "p"))

## ----fig.width=4, fig.height=3, fig.cap="Figure 21: Model 3 Summary Table"----
tidy(ave.quality.fit.3) |>
knitr::kable(digits = 3, booktabs = TRUE,
col.names = c("Term", "Estimate", "SE", "t", "p"))


## -----------------------------------------------------------------------------
confint(ave.quality.fit.1,"factor(pepper)yes",level=0.95)


## -----------------------------------------------------------------------------
confint(ave.quality.fit.1,"easiness",level=0.95)


## -----------------------------------------------------------------------------
model1.full = ave.quality.fit.1.full
model1.red = ave.quality.fit.1.red
anova(model1.red, model1.full)


## -----------------------------------------------------------------------------
model3.full = ave.quality.fit.3
model3.red = ave.quality.fit.1
anova(model3.red, model3.full)

