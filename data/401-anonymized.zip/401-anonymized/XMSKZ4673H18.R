## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(readr)
library(modelsummary)
cmu_sleep <- read_csv("~/Desktop/cmu-sleep.csv")


## -----------------------------------------------------------------------------
summary(cmu_sleep$TotalSleepTime)

summary(cmu_sleep$term_gpa)

summary(cmu_sleep$cum_gpa)





## -----------------------------------------------------------------------------
hist(cmu_sleep$TotalSleepTime,
     main = "Fig 1: Histogram of Total Sleep Time",
     xlab = "Sleep Time (minutes)",
     ylab = "Frequency",
     breaks = 40)
sd(cmu_sleep$TotalSleepTime)



## -----------------------------------------------------------------------------
hist(cmu_sleep$cum_gpa,
     main = "Fig 2: Histogram of the Cumulative GPA Pre Study",
     xlab = "Cumulative GPA (4.0 Scale)",
     ylab = "Frequency",
     breaks = 40)
sd(cmu_sleep$term_gpa)



## -----------------------------------------------------------------------------
hist(cmu_sleep$term_gpa,
     main = "Fig 3: Histogram of GPA During in the Semester Studied",
     xlab = "Term GPA (4.0 Scale)",
     ylab = "Frequency",
     breaks = 40)
sd(cmu_sleep$cum_gpa)


## -----------------------------------------------------------------------------

x = cmu_sleep$TotalSleepTime
y = cmu_sleep$term_gpa

plot(x = x,
     y = y,
     main = "Fig 4: CMU Student's Term GPA by Total Sleep Time",
     xlab = "Total Sleep Time (Minutes)",
     ylab = "Term GPA (4.0 Scale)",)


# Calculate the  correlation
cor1 <- cor(x, y)

print(cor1)


## -----------------------------------------------------------------------------
plot(x = log(x),
     y = y,
     main = "Fig 5: CMU Student's Term GPA by Log Total Sleep Time",
     xlab = "Log of Total Sleep Time (Minutes)",
     ylab = "Term GPA (4.0 Scale)",)
cor2 <- cor(log(x), y)

print(cor2)



## -----------------------------------------------------------------------------
plot(x = x,
     y = log(y),
     main = "Fig 6: CMU Student's Term GPA by Log Total Sleep Time",
     xlab = "Total Sleep Time (Minutes)",
     ylab = "Log Term GPA (4.0 Scale)",)



## -----------------------------------------------------------------------------
plot(x = log(x),
     y = log(y),
     main = "Fig 7: CMU Student's Log Term GPA by Log Total Sleep Time",
     xlab = "Log of Total Sleep Time (Minutes)",
     ylab = "Log Term GPA (4.0 Scale)",)



## -----------------------------------------------------------------------------

model <- lm(y ~ log(x), data = cmu_sleep)

#Residual Plot
plot(model, which = 1,)


## -----------------------------------------------------------------------------
#QQ Plot
plot(model, which = 2)


## -----------------------------------------------------------------------------
model <- lm(y ~ log(x), data = cmu_sleep)

modelsummary(list("First Model" = model),
             gof_map = c("r.squared", "nobs"))


## -----------------------------------------------------------------------------
# Calculate a 95% confidence interval for the model parameters
ci <- confint(model)

# View the confidence intervals
print(ci)


## -----------------------------------------------------------------------------
# Perform an independent samples t-test
z <- cmu_sleep$cum_gpa

t_test_result <- t.test(y, z)



# View the results
print(t_test_result)

