## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
Sleep <- read.csv("cmu-sleep.csv")
knitr::kable(Sleep, digits = 2)
library(ggplot2)
library(broom)


## ----fig.width =5, fig.height=3, fig.cap="Number of minutes students sleep per night on average" ,echo=FALSE----
summary(Sleep$TotalSleepTime)
hist(Sleep$TotalSleepTime, xlab = "Minutes", main = "The average time of student sleep each night, in minutes")


## ----fig.width =5, fig.height=3, fig.cap="The students' current semester GPA, on a 4.0 scale",echo=FALSE----
summary(Sleep$term_gpa)
hist(Sleep$term_gpa, xlab = "Current semester GPA, on a 4.0 scale", main = "The students' current semester GPA")


## ----fig.width =6, fig.height=3, fig.cap="The students' cumulative/fall semester GPA, on a 4.0 scale", echo=FALSE----
summary(Sleep$cum_gpa)
hist(Sleep$cum_gpa, xlab = "Cumulative GPA, on a 4.0 scale", main = "The students' cumulative GPA")


## ----fig.width =8, fig.height=3, fig.cap="Possible relationships between current semester GPA and the total sleeping time of students"----
lm1 <- lm(Sleep$term_gpa ~ Sleep$TotalSleepTime)
plot(Sleep$TotalSleepTime, Sleep$term_gpa, xlab = "Students' sleeping time at night in minutes", ylab = "students' current semester gpa", main = "Relationships between current semester GPA and students' sleeping time")
abline(lm1, col = "Blue")


## ----fig.width =8, fig.height=3, fig.cap="Possible relationships between current semester GPA and the cumulative GPA"----
lm2 <- lm(Sleep$term_gpa ~ Sleep$cum_gpa)
plot(Sleep$cum_gpa, Sleep$term_gpa, xlab = "Students' cumulative GPA", ylab = "students' current semester gpa", main = "Relationships between current semester GPA and students' cumulative GPA")
abline(lm2, col = "Blue")


## ----echo=FALSE,fig.width =8, fig.height=3.5, fig.cap="Relationships between exp of term gpa and the total sleeping time"----
lm3 <- lm(exp(Sleep$term_gpa) ~ Sleep$TotalSleepTime)
plot(Sleep$TotalSleepTime, exp(Sleep$term_gpa))
abline(lm3, col = "Red")
tidy(lm3)


## ----echo=FALSE,fig.width=3,fig.height=2, fig.cap = "QQ plot for the untransformed model"----
ggplot(data.frame(data = Sleep$term_gpa), aes(sample = Sleep$term_gpa)) + stat_qq() + stat_qq_line(col = "Red") + ggtitle("Normal QQ Plot") + xlab("Theoretical Quantiles") + ylab("Sample Quantiles")


## ----echo=FALSE,fig.width=3,fig.height=2, fig.cap = "QQ plot of the transformed model that we used"----
ggplot(data.frame(data = exp(Sleep$term_gpa)), aes(sample = exp(Sleep$term_gpa))) + stat_qq() + stat_qq_line(col = "Red") + ggtitle("Exp QQ Plot") + xlab("Theoretical Quantiles") + ylab("Sample Quantiles")


## ----echo=FALSE, fig.width=5, fig.height=3, fig.cap = "Residual plot vs. x given the transformation"----
plot(Sleep$TotalSleepTime, resid(lm3), main = "Transformed Residual vs. Predictor Plot", xlab = "Exponential of total sleep time", ylab = "Residuals")
abline(h = 0, col = "red")


## ----echo=FALSE, fig.width=5, fig.height=3, fig.cap = "Residual plot vs. x given the transformation"----
lm4 <- lm(Sleep$term_gpa ~ Sleep$TotalSleepTime)
plot(Sleep$TotalSleepTime, resid(lm4), main = "Residual vs. Predictor Plot, original form", xlab = "TotalSleepingTime", ylab = "Residuals")
abline(h = 0, col = "red")


## ----echo=FALSE---------------------------------------------------------------
Eightamsleep <-(Sleep$TotalSleepTime-120)
Predictgpa <- (coef(lm3)[1] + coef(lm3)[2]*Eightamsleep)
tidy(t.test(log(Predictgpa), Sleep$term_gpa))


## ----echo=FALSE, fig.width=8, fig.height=3, fig.cap = "Multiregression models between exp of cum_gpa, total sleeping time, and exp of term_gpa"----
lm10 <- lm(exp(Sleep$term_gpa) ~ Sleep$TotalSleepTime +exp(Sleep$cum_gpa))
tidy(lm10)


## ----echo=FALSE, fig.width=5, fig.height=3, fig.cap = "Multi-regression model's Residual plot vs. x given the transformation"----
plot(Sleep$TotalSleepTime + exp(Sleep$cum_gpa), resid(lm10), main = "Transformed Residual vs. Predictor Plot", xlab = "Exponential of total sleep time", ylab = "Residuals")
abline(h = 0, col = "red")


## ----echo=FALSE,fig.width=3,fig.height=1.5, fig.cap = "QQ plot of the transformed cum_gpa model that we used"----
ggplot(data.frame(data = exp(Sleep$cum_gpa)), aes(sample = exp(Sleep$cum_gpa))) + stat_qq() + stat_qq_line(col = "Red") + ggtitle("Exp Cum-gpa QQ Plot") + xlab("Theoretical Quantiles") + ylab("Sample Quantiles")

