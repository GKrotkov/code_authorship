## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----message=FALSE, warning=FALSE, include=FALSE------------------------------
library(alr4)
library(dplyr)
library(ggplot2)

## ----include=FALSE------------------------------------------------------------
dim(Rateprof)
(Rateprof)
min(Rateprof$easiness)
max(Rateprof$easiness)


## -----------------------------------------------------------------------------
prof <- Rateprof %>%
  select(gender, pepper, easiness, discipline, quality)
prof$gender = factor(prof$gender)
prof$pepper = factor(prof$pepper)
prof$discipline = factor(prof$discipline)

## ----message=FALSE, warning=FALSE---------------------------------------------
ggplot(prof, aes(x = gender)) +
  geom_bar() +
  labs(x = "Gender", y = "Frequency", title = "Distribution of Gender")
ggplot(prof, aes(x = pepper)) +
  geom_bar() +
  labs(x = "Attractiveness", y = "Frequency", title = "Distribution of Attractiveness")
ggplot(prof, aes(x = discipline)) +
  geom_bar() +
  labs(x = "Discipline", y = "Frequency", title = "Distribution of Disciplines")
ggplot(prof, aes(x = easiness)) +
  geom_histogram() +
  labs(x = "Easiness", title = "Distribution of Easiness")
ggplot(prof, aes(x = quality)) +
  geom_histogram() +
  labs(x = "Quality", title = "Distribution of Quality")
ggplot(prof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(x = "Easiness", y = "Quality", title =  "Easiness vs Quality")


## -----------------------------------------------------------------------------
multi <- lm(quality ~ gender + pepper + easiness + discipline, data = prof)
interg <- lm(quality ~ easiness * gender, data = prof)
interd <- lm(quality ~ easiness * discipline, data = prof)
qq_multi <- data.frame(Residuals = residuals(multi))
plot(multi, which = 1)
plot(interg, which = 1)
plot(interd, which = 1)
ggplot(data = qq_multi, aes(sample = Residuals)) +
  geom_qq() +
  labs(title = "Q-Q Plot of Multi-Regression Residuals", y = "Residuals")
qq_interg <- data.frame(Residuals = residuals(interg))
ggplot(data = qq_interg, aes(sample = Residuals)) +
  geom_qq() +
  labs(title = "Q-Q Plot of Interaction-Regression (Gender) Residuals", y = "Residuals")
qq_interd <- data.frame(Residuals = residuals(interd))
ggplot(data = qq_interd, aes(sample = Residuals)) +
  geom_qq() +
  labs(title = "Q-Q Plot of Interaction-Regression (Discipline) Residuals", y = "Residuals")


## ----include=FALSE------------------------------------------------------------
summary(multi)
summary(interg)
summary(interd)

