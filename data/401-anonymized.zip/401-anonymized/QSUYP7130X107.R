## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, message = FALSE---------------------------------------------
library(gridExtra)
library(grid)
library(ggplot2)
library(tidyverse)
library(modelsummary)
library(broom)
library(kableExtra)
library(alr4)


## ----echo = FALSE-------------------------------------------------------------
profData <- Rateprof
# all.equal(profData, Rateprof)
names(profData)[5] <- 'attractiveness'
# head(profData)


## ----fig.width=6, fig.height=5, fig.cap="Histogram Exploratory Data Analysis of Quantitative Variables of Interest"----
#HISTOGRAMS for quant vars
par(mfrow = c(2, 2))
hist(profData$quality, main="Distribution of Average \n Quality Rating", xlab = "Average Quality Rating \n (1: Low 5: High)", col="antiquewhite3", breaks=23)
hist(profData$easiness, main="Distribution of Average \n Easiness Rating ", xlab = "Average Easiness Rating \n (1: Low 5: High)", col="lavenderblush4", breaks=23)
plot(profData$easiness, profData$quality, main="Quality vs Easiness", col="lightslategray", xlab = "Average Easiness Rating \n (1: Low 5: High)", ylab = "Average Quality Rating \n (1: Low 5: High)")
# mean(profData$quality)
# mean(profData$easiness)
# sd(profData$quality)
# sd(profData$easiness)


## -----------------------------------------------------------------------------
# cor(profData$easiness, profData$quality)


## ----fig.width=6, fig.height=6, fig.cap="Boxplot Exploratory Data Analysis of Categorical Variables of Interest"----
#BOXPLOTS for gender, attractiveness, discipline
a<-ggplot(profData, aes(x = factor(gender), y = quality)) +
  geom_boxplot(aes(fill = factor(gender))) +
  labs(x = "Gender", y = "Average Quality Rating \n (1: Low 5: High)", 
       title="Boxplot of Average Quality Rating by Gender", fill='Gender') +
  scale_fill_manual(values=c('lightgrey', 'lightslategray'), labels = c("female", "male")) +
  scale_x_discrete(labels = c("female", "male"))

b<-ggplot(profData, aes(x = factor(discipline), y = quality)) +
  geom_boxplot(aes(fill = factor(discipline))) +
  labs(x = "Discipline", y = "Average Quality Rating \n (1: Low 5: High)", 
       title="Boxplot of Average Quality Rating by Discipline", fill='Discipline') +
  scale_fill_manual(values=c('navajowhite4', 'ivory1','lightgrey', 'lightslategray'),
  labels = c("humanities", "social sciences", "STEM", "pre-professional")) +
  scale_x_discrete(labels = c("humanities", "social sciences", "STEM", "pre-professional"))

c<-ggplot(profData, aes(x = factor(attractiveness), y = quality)) +
  geom_boxplot(aes(fill = factor(attractiveness))) +
  labs(x = "Attractiveness", y = "Average Quality Rating \n (1: Low 5: High)", 
       title="Boxplot of Average Quality Rating by Attractiveness", fill='Attractiveness') + 
  scale_fill_manual(values=c('lightgrey', 'lightslategray'),
  labels = c("no", "yes")) +
  scale_x_discrete(labels = c("no", "yes"))
grid.arrange(a, b, c)


## ----fig.width=8, fig.height=4, fig.cap="Barplot Exploratory Data Analysis of Categorical Variables of Interest"----
par(mfrow = c(1,3))
barplot(table(profData[,1]), names=c("female", "male"), xlab="Gender", ylab="Count",main="Barplot of Gender", 
        col=c('antiquewhite3', 'lavenderblush4'))
barplot(table(profData[,6]), names=c("hum", "sosci", "STEM", "pre-prof"), xlab="Discipline", ylab="Count", main="Barplot of Discipline", col=c('navajowhite4', 'ivory1','lightgrey', 'lightslategray'))
barplot(table(profData[,5]), names=c("no", "yes"), xlab="Attractiveness", ylab="Count", main="Barplot of Attractiveness",col=c('lightgrey', 'lightslategray'))


## -----------------------------------------------------------------------------
#multiple linear regression
library(broom)
library(kableExtra)
model1 <- lm(quality ~ gender + attractiveness + easiness + discipline, data = profData)
# summary(model1)
kableExtra::kbl(tidy(model1), caption = "Regressing Quality against Gender, Attractiveness, Easiness, and Discipline", booktabs = T, linesep = "") %>%
  kableExtra::kable_styling(latex_options = "HOLD_position") %>%
  kableExtra::kable_classic() %>%
  kableExtra::row_spec(4, hline_after = TRUE) 


## -----------------------------------------------------------------------------
kableExtra::kbl(confint(model1), caption = "Two-sided Confidence Intervals for Regression Model Estimates", booktabs = T, linesep = "") %>%
  kableExtra::kable_styling(latex_options = "HOLD_position") %>%
  kableExtra::kable_classic() %>%
  kableExtra::row_spec(4, hline_after = TRUE) 


## ----fig.width=5, fig.height=5, fig.cap="Diagnostic plots from fitting Multiple Linear Regression of Quality on the four predictor variables of interest"----
par(mfrow = c(2, 2))
plot(model1)


## -----------------------------------------------------------------------------
#partial F test for gender factor
fullmodel <- lm(quality ~  easiness*factor(gender) + attractiveness + easiness + easiness*factor(discipline), data=profData)
reducedmodel <- lm(quality ~ factor(gender) + attractiveness + easiness + easiness*factor(discipline), data=profData)
# anova(reducedmodel, fullmodel)
kableExtra::kbl(anova(reducedmodel, fullmodel), caption = "Conducting Partial F Test via ANOVA to explore Dependency of Gender on the Relationship between easiness and quality ratings", booktabs = T, linesep = "") %>%
  kableExtra::kable_styling(latex_options = "HOLD_position") %>%
  kableExtra::kable_classic() %>%
  kableExtra::row_spec(2, hline_after = TRUE) 


## -----------------------------------------------------------------------------
#partial F test for discipline factor
# fullmodel2 <- lm(quality ~  gender + attractiveness + easiness + discipline, data=profData)
# reducedmodel2 <- lm(quality ~ gender+ attractiveness + easiness, data=profData)
fullmodel2 <- lm(quality ~ easiness*factor(gender) + attractiveness + easiness + easiness*factor(discipline), data=profData)
reducedmodel2 <- lm(quality ~ easiness*factor(gender) + attractiveness + easiness + factor(discipline), data=profData)
kableExtra::kbl(anova(reducedmodel2, fullmodel2), caption = "Conducting Partial F Test via ANOVA to explore Dependency of Discipline on the Relationship between easiness and quality ratings", booktabs = T, linesep = "") %>%
  kableExtra::kable_styling(latex_options = "HOLD_position") %>%
  kableExtra::kable_classic() %>%
  kableExtra::row_spec(2, hline_after = TRUE) 


## -----------------------------------------------------------------------------
kableExtra::kbl(tidy(fullmodel2), caption = "Full Model from Partial F tests Regressing Quality against Gender, Attractiveness, Easiness, and Discipline along with the additional Interaction Terms", booktabs = T, linesep = "") %>%
  kableExtra::kable_styling(latex_options = "HOLD_position") %>%
  kableExtra::kable_classic() %>%
  kableExtra::row_spec(7, hline_after = TRUE) 

