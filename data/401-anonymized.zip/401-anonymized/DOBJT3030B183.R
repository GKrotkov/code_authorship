## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
data <- read.csv("./cmu-sleep.csv")
# head(data)
# nrow(data)


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of Total Sleep Time (in minutes)."----
library(ggplot2)

ggplot(data, aes(x=TotalSleepTime)) +
  geom_histogram(binwidth=30, alpha=0.9) +
  labs(title="Histogram of Total Sleep Time",
       x="Total Sleep Time (in minutes)",
       y="Number of Students")


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of Term GPA."----------
ggplot(data, aes(x=term_gpa)) +
  geom_histogram(binwidth=0.1, alpha=0.9) +
  labs(title="Histogram of Term GPA",
       x="Term GPA",
       y="Number of Students")


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of cumulative GPA."----

ggplot(data, aes(x=cum_gpa)) +
  geom_histogram(binwidth=0.1, alpha=0.9) +
  labs(title="Histogram of Cumulative GPA",
       x="Cumulative GPA",
       y="Number of Students")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between Total Sleep Time and Term GPA."----
ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point(alpha=0.5) +
  labs(title="Scatter Plot of Total Sleep Time vs Term GPA",
       x="Total Sleep Time (in minutes)",
       y="Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between Total Sleep Time and Cumulative GPA."----
ggplot(data, aes(x=TotalSleepTime, y=cum_gpa)) +
  geom_point(alpha=0.5) +
  labs(title="Scatter Plot of Total Sleep Time vs Cumulative GPA",
       x="Total Sleep Time (in minutes)",
       y="Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Produced Coefficients on Linear Regression Model"----
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)
# summary(model)
coef(model)


## ---- fig.width=4, fig.height=3, fig.cap="Scatter Plot for Linearity Check"----

ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) + 
  geom_point() + 
  geom_smooth(method="lm", se=FALSE, color="red")



## ---- fig.width=4, fig.height=3, fig.cap="Residuals vs. Fitted for Homoscedasticity Check"----
plot(model, which = 1)


## ---- fig.width=4, fig.height=3, fig.cap="# QQ Plot for Normality Check of Residuals"----
shapiro.test(residuals(model))


## ---- fig.width=4, fig.height=3, fig.cap="Model Fit"--------------------------
summary_model <- summary(model)
# summary_model$r.squared


## ---- fig.width=4, fig.height=3, fig.cap="# Confidence Interval"--------------
confint(model, "TotalSleepTime", level = 0.95)

