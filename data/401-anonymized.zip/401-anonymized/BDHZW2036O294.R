## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
# necessary packages + reading in data 
suppressPackageStartupMessages({
  library(tidyverse)
  library(dplyr)})
sleep <- read.csv("/Users/tasnimrida/Desktop/cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Marginal Distribution of Total Sleep Time."----
options(warn = -1)
ggplot(sleep, aes(x = `TotalSleepTime`)) +
  geom_histogram(color = "black", fill = "thistle", binwidth = 10) +
  labs(x = "Total Sleep Time (minutes)")


## ---- fig.width=4, fig.height=3, fig.cap="Marginal Distribution of term_gpa."----
ggplot(sleep, aes(x = term_gpa)) +
  geom_histogram(color = "black", fill = "lightblue", binwidth = 0.1) +
  labs(x = "Term GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Marginal Distribution of cum_gpa."----
ggplot(sleep, aes(x = cum_gpa)) +
  geom_histogram(color = "black", fill = "darkseagreen", binwidth = 0.1) +
  labs(x = "Cumulative GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Total Sleep Time and Term GPA."-----
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(color = "darkblue") +
  labs(x = "Total Sleep Time (minutes)", y = "Term GPA (out of 4.0)") 


## ---- fig.width=4, fig.height=3, fig.cap="Total Sleep Time and Cumulative GPA."----
ggplot(sleep, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point(color = "darkblue") +
  labs(x = "Total Sleep Time (minutes)", y = "Cumulative GPA (out of 4.0)") 


## -----------------------------------------------------------------------------
sleep$sleep.time <- sleep$TotalSleepTime/60


## ---- fig.width=4, fig.height=3, fig.cap="Total Sleep Time and Term GPA.", message = FALSE----
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(color = "darkblue") +
  labs(x = "Total Sleep Time (minutes)", y = "Term GPA (out of 4.0)") +
  geom_smooth(method = "lm", se = FALSE, color = "red")


## -----------------------------------------------------------------------------
sleep.model <- lm(term_gpa ~ sleep.time, sleep)
summary(sleep.model)


## ----fig.width=4, fig.height=3, fig.cap="Total Sleep Time and Term GPA Residual Plot."----
ci.sleep <- confint(sleep.model, name = "sleep.time", level = 0.95)
ci.table <- data.frame(
  Coefficient = rownames(ci.sleep),
  Lower_Bound = ci.sleep[, 1],
  Upper_Bound = ci.sleep[, 2]
)
print(ci.table)


## ---- fig.width=4, fig.height=3, fig.cap="Total Sleep Time and Term GPA Residual Plot."----
sleep.resid <- resid(sleep.model)
ggplot(sleep, aes(x = sleep.time, y = sleep.resid)) +
  geom_point(color="darkgreen") +
  geom_hline(yintercept = 0, linetype = "solid", color = "red") + 
  labs(x = "Total Sleep Time (hours)", y = "Residuals") 

