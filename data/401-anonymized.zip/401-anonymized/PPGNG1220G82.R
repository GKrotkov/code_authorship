## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, echo=FALSE-----------------------------------------------
library(alr4)
library(tidyverse)
library(ggplot2)
library(broom)
library(modelsummary)
data = Rateprof


## ---- echo=FALSE, message=FALSE, fig1, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig1}Bar Chart of Instructor Gender"----
ggplot(data) + 
  geom_bar(mapping = aes(x=gender)) +
  labs(title="Instructor Gender", x="Gender", y="Count")


## ---- echo=FALSE, message=FALSE, fig2, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig2}Bar Chart of Instructor Attractiveness"----
ggplot(data) + 
  geom_bar(mapping = aes(x=pepper)) +
  labs(title="Instructor Attractiveness", x="Attractive", y="Count")


## ---- echo=FALSE, message=FALSE, fig3, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig3}Histogram of Class Easiness"----
ggplot(data, aes(x=easiness)) + 
  geom_histogram(color="black", fill="lightblue", bins=15) +
  labs(title="Class Easiness", x="Class Easiness (1-5)", y="Count")


## ---- echo=FALSE, message=FALSE, fig4, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig4}Bar Chart of Course Discipline"----
ggplot(data) + 
  geom_bar(mapping = aes(x=discipline)) +
  labs(title="Course Discipline", x="Discipline", y="Count")


## ---- echo=FALSE, message=FALSE, fig5, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig5}Histogram of Instructor Quality"----
ggplot(data, aes(x=quality)) + 
  geom_histogram(color="black", fill="lightblue", bins=10) +
  labs(title="Instructor Quality", x="Instructor Quality (1-5)", y="Count")


## ---- echo=FALSE, message=FALSE, fig6, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig6}Boxplots of Instructor Quality by Gender"----
ggplot(data, aes(x=gender, y=quality, fill=factor(gender))) +
  geom_boxplot() +
  scale_fill_discrete(name = "Gender") +
  labs(title="Instructor Quality by Gender", x="Gender", y="Quality Rating (1-5)")


## ---- echo=FALSE, message=FALSE, fig7, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig7}Boxplots of Instructor Quality by Attractiveness"----
ggplot(data, aes(x=pepper, y=quality, fill=factor(pepper))) +
  geom_boxplot() +
  scale_fill_discrete(name = "Attractive") +
  labs(title="Instructor Quality by Attractiveness", x="Attractive", y="Quality Rating (1-5)")


## ---- echo=FALSE, message=FALSE, fig8, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig8}Scatter Plot of Instructor Quality vs. Easiness"----
ggplot(data, aes(x=easiness, y=quality)) +
  geom_point() +
  labs(title="Instructor Quality Rating vs. Course Easiness Rating", x="Easiness Rating (1-5)", 
       y="Quality Rating (1-5)") +
  geom_smooth(method="lm")


## ---- echo=FALSE, message=FALSE, fig9, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig9}Boxplots of Instructor Quality by Discipline"----
ggplot(data, aes(x=discipline, y=quality, fill=factor(discipline))) +
  geom_boxplot() +
  scale_fill_discrete(name = "Discipline", 
                      labels = c("Humanities", "Social Science", "STEM", 
                                 "Pre-professional")) +
  labs(title="Instructor Quality by Discipline", x="Discipline", y="Quality Rating (1-5)")


## ---- echo=FALSE, message=FALSE, fig10, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig10}Boxplots of Class Easiness by Gender"----
ggplot(data, aes(x=gender, y=easiness, fill=factor(gender))) +
  geom_boxplot() +
  scale_fill_discrete(name = "Gender") +
  labs(title="Class Easiness by Instructor Gender", x="Instructor Gender", y="Easiness Rating (1-5)")


## ---- echo=FALSE, message=FALSE, fig11, fig.width=5, fig.height=3, fig.cap="\\label{fig:fig11}Boxplots of Class Easiness by Gender"----
ggplot(data, aes(x=discipline, y=easiness, fill=factor(discipline))) +
  geom_boxplot() +
  scale_fill_discrete(name = "Discipline", 
                      labels = c("Humanities", "Social Science", "STEM", 
                                 "Pre-professional")) +
  labs(title="Class Easiness by Discipline", x="Discipline", y="Easiness Rating (1-5)")


## ---- include=FALSE, message=FALSE--------------------------------------------
# Define linear model
model = lm(data = data, quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness)
model_sum = summary(model)
diagnostics = augment(model)


## ---- echo=FALSE, message=FALSE, fig12, fig.width=4, fig.height=4, fig.cap="\\label{fig:fig12}Residuals vs. Fitted"----
ggplot(data = diagnostics, aes(x=.fitted, y=.resid)) + geom_point() +
  labs(title = "Residuals vs. Fitted", x="Fitted", y="Residuals")


## ---- echo=FALSE, message=FALSE, fig13, fig.width=4, fig.height=4, fig.cap="\\label{fig:fig13}Cook's Distance vs. Observation"----
# Cooks Distance
ggplot(data = diagnostics, aes(x=1:366, y=.cooksd)) + geom_point() +
  labs(title="Cook's Distance vs. Observation", x="Observation", y="Cook's Distance")


## ---- echo=FALSE, message=FALSE, fig14, fig.width=4, fig.height=4, fig.cap="\\label{fig:fig14}Q-Q Plot of Residuals"----
ggplot(data, aes(sample = diagnostics$.resid)) +
  stat_qq() +
  stat_qq_line() +
  labs(title="Normal Q-Q Plot (Residuals)", x="Theoretical Quantities",
       y="Observed Quantities")


## ---- echo=FALSE, message=FALSE-----------------------------------------------
modelsummary(model)


## ---- echo=FALSE, message=FALSE-----------------------------------------------
# Partial F-test for Discipline
model.red.1 = lm(data = data, quality ~ gender + pepper + easiness + gender:easiness + discipline:easiness)
tidy(anova(model.red.1, model))


## ---- echo=FALSE, message=FALSE-----------------------------------------------
# Partial F-test for Discipline:Easiness
model.red.2 = lm(data = data, quality ~ gender + pepper + easiness + discipline + gender:easiness)
tidy(anova(model.red.2, model))

