## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=7, fig.height=3, fig.cap="Histograms of Total Sleep Time, Term GPA, and Cumulative GPA", message=FALSE----
library(ggplot2)
library(patchwork)
sleep <- read.csv("cmu-sleep.csv")
p1 <- ggplot(data=sleep, aes(x=TotalSleepTime)) + geom_histogram() +
  labs(x="Total Sleep Time (minutes)")

p2 <- ggplot(data=sleep, aes(x=term_gpa)) + geom_histogram() +
  labs(x="Term GPA")

p3 <- ggplot(data=sleep, aes(x=cum_gpa)) + geom_histogram() +
  labs(x="Cumulative GPA")

p1|p2|p3


## ---- fig.width=7, fig.height=4, fig.cap="Scatter Plots Between Variable Pairs", message=FALSE----

p1 <- ggplot(data=sleep, aes(x=TotalSleepTime,y=term_gpa)) + geom_point() +
  labs(x="Total Sleep Time (minutes)", y="Term GPA")

p2 <- ggplot(data=sleep, aes(x=TotalSleepTime,y=cum_gpa)) + geom_point() +
  labs(x="Total Sleep Time (minutes)", y="Cumulative GPA")

p3 <- ggplot(data=sleep, aes(x=cum_gpa,y=term_gpa)) + geom_point() +
  labs(x="Cumulative GPA", y="Term GPA")

p1|p2|p3


## ---- fig.width=8, fig.height=5, fig.cap="Diagnostics Plots", message=FALSE----
library(dplyr)
library(broom)
fit <- lm(term_gpa ~ TotalSleepTime + cum_gpa,data=sleep)

# Run diagnostics
p1 <- ggplot(data=data.frame(residuals=fit$residuals,predictor=sleep$TotalSleepTime),
       aes(x=predictor,y=residuals)) + geom_point() +
  labs(x="Total Sleep Time (minutes)", y="Residuals")

p2 <- ggplot(data=data.frame(residuals=fit$residuals,predictor=sleep$cum_gpa),
       aes(x=predictor,y=residuals)) + geom_point() +
  labs(x="Cumulative GPA", y="Residuals")

p3 <- ggplot(augment(fit), aes(sample = .resid)) +
  geom_qq() + geom_qq_line() +
  labs(x="Theoretical quantiles", y="Observed quantiles",
       title="Normal QQ plot of the Residuals") +
  theme(title=element_text(size=8))

p1|p2|p3


## ---- eval=FALSE--------------------------------------------------------------
## cookd <-  cooks.distance(fit)
## sleep[which.max(cookd),]
## sort(pf(cookd, 2, fit$df.residual),decreasing=TRUE)


## ---- fig.width=4, fig.height=4, fig.cap="Residuals against the Fitted Values", message=FALSE----

ggplot(augment(fit), aes(x=.fitted,y=.resid)) + geom_point() +
  labs(x="Fitted Value", y="Residual")



## ---- eval=FALSE--------------------------------------------------------------
## betaHat <- fit$coefficients["TotalSleepTime"]
## alpha <-  0.05
## se <- summary(fit)$coefficients["TotalSleepTime","Std. Error"]
## val <-  qt(1-alpha/2,df=fit$df.residual)*se
## CI <- c(betaHat - val, betaHat + val)
## 
## # slope and CI per hour of sleep
## betaHat*60
## CI*60
## 
## # slope and CI per 2 hours of sleep
## betaHat*120
## CI*120
## 
## # One-sided t-test (beta > 0)
## betaHat/se
## pt(-betaHat/se, fit$df.residual)
## 
## # Residual standard error
## summary(fit)$sigma

