## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(car)


## ---- include=FALSE-----------------------------------------------------------
sleep <- read_csv("cmu-sleep.csv")


## ----fig1, fig.width=4, fig.height=3------------------------------------------
sleep %>% ggplot()+
  geom_histogram(aes(x=TotalSleepTime),
                 color="black",fill="hotpink",binwidth=10)+
  labs(x="Total Sleep Time (minutes)",y="Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
sleep %>% ggplot()+
  geom_histogram(aes(x=TotalSleepTime/60),
                 color="black",fill="hotpink",binwidth=0.25)+
  labs(x="Total Sleep Time (hours)",y="Frequency",
       title="Histogram of Total Sleep Time in Hours")


## ---- fig.width=4, fig.height=3-----------------------------------------------
sleep %>% ggplot()+
  geom_histogram(aes(x=term_gpa),
                 color="black",fill="hotpink",binwidth=0.1)+
  labs(x="Term GPA (out of 4.0)",y="Frequency",
       title="Histogram of Term GPA")


## ---- fig.width=4, fig.height=3-----------------------------------------------
sleep %>% ggplot()+
  geom_histogram(aes(x=cum_gpa),
                 color="black",fill="hotpink",binwidth=0.1)+
  labs(x="Fall Semester GPA (out of 4.0)",y="Frequency",
       title="Histogram of Fall Semester GPA")


## ---- fig.width=4, fig.height=3-----------------------------------------------
sleep %>% ggplot()+
  geom_histogram(aes(x=(cum_gpa-term_gpa)),
                 color="black",fill="hotpink",binwidth=0.1)+
  labs(x="Fall Semester GPA (out of 4.0)",y="Frequency",
       title="Histogram of Difference in GPA")


## ---- fig.width=4, fig.height=3-----------------------------------------------
sleep$diff_gpa=sleep$cum_gpa-sleep$term_gpa
sleep %>% ggplot()+
  geom_point(aes(x=TotalSleepTime/60,y=term_gpa),color="hotpink")+ 
  labs(x="Total Sleep Time (hours)",y="Spring Semester GPA (out of 4.0)",
       title="Scatterplot of Spring Semester GPA vs. Total Sleep Time")


## ---- fig.width=5, fig.height=4-----------------------------------------------
sleep$sleep.hours <- sleep$TotalSleepTime/60
model <- lm(term_gpa~sleep.hours, data=sleep)
resid <- resid(model)
plot(sleep$sleep.hours, resid,abline(h=0,col="hotpink"),main="Residual Plot",
     xlab="Sleep Hours",ylab="Residuals")


## ----warning=FALSE,fig.width=5, fig.height=4,echo=FALSE-----------------------
qqPlot(model,main = "QQ Plot for Model Residuals",col.lines="hotpink",id=FALSE)


## -----------------------------------------------------------------------------
ci <-  data.frame(
  "Confidence Level" = paste("95%"),
  "Lower Bound" = confint(model,"sleep.hours",level=0.95)[1],
  "Upper Bound" = confint(model,"sleep.hours",level=0.95)[2]
)
knitr::kable(ci,col.names=c("Confidence Level","Lower Bound","Upper Bound"))


## -----------------------------------------------------------------------------
diff <-  data.frame(
  "Mean"=mean(sleep$term_gpa),
  "Mean with Two Hours Less Sleep"=mean(sleep$term_gpa)-2*0.1191)
knitr::kable(diff,col.names=c("Mean","Mean with Two Hours Less Sleep"))


## -----------------------------------------------------------------------------
library(modelsummary)
modelsummary(list("Model"=model), gof_map=NA, 
             fmt=fmt_decimal(digits=5))

