## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
options(warn = -1)
message <- function(...) { }
# library(dplyr)
library(ggplot2)
library(gridExtra)
sleep <-read.csv("cmu-sleep.csv")
selected_vars <- sleep[c("TotalSleepTime", "cum_gpa", "term_gpa")]


## ---- fig.width=3, fig.height=2, fig.cap="Histograms showing the distributions of variable Total Sleep Time"----
options(warn = -1)
ggplot(sleep, aes(x = TotalSleepTime)) +
      geom_histogram(fill = "lightblue", color = "black", bins=30) +
      labs(title = "Distribution of Total Sleep Time", x = "Total Sleep Time(Minutes)", y = "Amount") +
      theme(plot.title = element_text(size=10))


## -----------------------------------------------------------------------------
t1 = read.table(text="194.8 366.9 400.4 397.3 430.1 587.7")
knitr::kable(t1, caption = "Numerical Summary of Total Sleep Time", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- Warning=FALSE, fig.width=8, fig.height=3, fig.cap="Histograms showing the distributions of cumulative gpa and term gpa"----
dist1 <- ggplot(sleep, aes(x = cum_gpa)) +
      geom_histogram(fill = "lightblue", color = "black", bins=30) +
      labs(title = "Distribution of Cumulative GPA", x = "Cumulative GPA", y = "Amount") +
      theme(plot.title = element_text(size=12))

dist2 <- ggplot(sleep, aes(x = term_gpa)) +
      geom_histogram(fill = "lightblue", color = "black", bins=30) +
      labs(title = "Distribution of Term GPA", x = "Term GPA", y = "Amount") +
      theme(plot.title = element_text(size=12))

grid.arrange(dist1, dist2, ncol=2)


## -----------------------------------------------------------------------------
t2 = read.table(text="1.210 3.232 3.558 3.466 3.790 4.000")
knitr::kable(t2, caption = "Numerical Summary of Cumulative GPA", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- fig.width=4, fig.height=3, fig.cap="Histograms showing the distributions of variable term gpa"----
# ggplot(sleep, aes(x = term_gpa)) +
#       geom_histogram(fill = "lightblue", color = "black") +
#       labs(title = "Distribution of Term GPA", x = "Term GPA", y = "Amount") +
#       theme_bw()


## -----------------------------------------------------------------------------
t3 = read.table(text="0.350 3.233 3.556 3.450 3.810 4.000")
knitr::kable(t3, caption = "Numerical Summary of Term GPA", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="The Scatterplot of Term GPA versus Total Sleep Time and Cumulative GPA before transformation with a linear regression line"----
ggplot(sleep, aes(x=TotalSleepTime + cum_gpa, y=term_gpa)) +
  geom_point()+ geom_smooth(method=lm, se=FALSE) +
  labs(title="term_gpa vs TotalSleepTime and cum_gpa",
  x = "TotalSleepTime and cum_gpa",
  y = "term_gpa") + theme(plot.title = element_text(size=12))


## ---- fig.width=8, fig.height=3, fig.cap="The Distribution of Term GPA after transformation"----
expdist1 <- ggplot(sleep, aes(x = exp(term_gpa))) +
      geom_histogram(fill = "lightblue", color = "black", bins=30) +
      labs(title = "Distribution of exp(Term GPA)", x = "Exponential Transformed Term GPA", y = "Amount") +
      theme(plot.title = element_text(size=12))

expdist2 <- ggplot(sleep, aes(x = exp(cum_gpa))) +
      geom_histogram(fill = "lightblue", color = "black", bins=30) +
      labs(title = "Distribution of exp(Cumulative GPA)", x = "Exponential Transformed Cumulative GPA", y = "Amount") +
      theme(plot.title = element_text(size=12))

grid.arrange(expdist1, expdist2, ncol=2)


## ---- fig.width=4, fig.height=3, fig.cap="The Distribution of Cumulative GPA after transformation"----
# ggplot(sleep, aes(x = exp(cum_gpa))) +
#       geom_histogram(fill = "lightblue", color = "black") +
#       labs(title = "Distribution of exp(Cumulative GPA)", x = "Exponential Transformed Cumulative GPA", y = "Amount") +
#       theme(plot.title = element_text(size=12))



## -----------------------------------------------------------------------------
lm1 <- lm(exp(term_gpa) ~ TotalSleepTime + exp(cum_gpa), data = sleep)
residuals_values1 <- residuals(lm1)


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="The Scatterplot of exp(Term GPA) versus Total Sleep Time and exp(Cumulative GPA) with a linear regression line"----
ggplot(sleep, aes(x=TotalSleepTime + exp(cum_gpa), y = exp(term_gpa))) +
  geom_point()+ geom_smooth(method=lm, se=FALSE, show.legend=FALSE) +
  labs(title="exp(term_gpa) vs TotalSleepTime and exp(cum_gpa)",
  x = "TotalSleepTime and exp(cum_gpa)",
  y = "exp(term_gpa)") + theme(plot.title = element_text(size=11))


## ---- fig.width=8, fig.height=2.5, fig.cap="Residual Plots with TotalSleepTime and exp(cum_gpa) as Predictor respectively"----
res1 <- ggplot(sleep, aes(x = TotalSleepTime, y = residuals_values1)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(title = "Residual Plot with TotalSleepTime as Predictor",
       x = "TotalSleepTime",
       y = "Residuals") +
  theme(plot.title = element_text(size=12))

res2 <- ggplot(sleep, aes(x = exp(cum_gpa), y = residuals_values1)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(title = "Residual Plot with exp(cum_gpa) as Predictor",
       x = "exp(cum_gpa)",
       y = "Residuals") +
  theme(plot.title = element_text(size=12))

grid.arrange(res1, res2, ncol=2)


## ---- fig.width=8, fig.height=2.5, fig.cap="Squared Residual Plots with TotalSleepTime and exp(cum_gpa) as Predictors respectively"----
sqrres1 <- ggplot(sleep, aes(x = TotalSleepTime, y = residuals_values1^2)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(title = "Squared Residual Plot with TotalSleepTime as Predictor",
       x = "TotalSleepTime",
       y = "Squared Residuals") +
  theme(plot.title = element_text(size=10))

sqrres2 <- ggplot(sleep, aes(x = exp(cum_gpa), y = residuals_values1^2)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(title = "Squared Residual Plot with exp(cum_gpa) as Predictor",
       x = "exp(cum_gpa)",
       y = "Squared Residuals") +
  theme(plot.title = element_text(size=10))
grid.arrange(sqrres1, sqrres2, ncol=2)


## ---- fig.width=3.5, fig.height=2.5, fig.cap="Normal QQ-Plot of Residuals"----
library(ggpubr)
ggqqplot(residuals_values1) +
  labs(title = "Q-Q Plot of Residuals for term_gpa") +
  theme(plot.title = element_text(size=12))


## -----------------------------------------------------------------------------
cookd1 <- cooks.distance(lm1)
# cookd1
# which.max(cookd1)
# sort(pf(cookd1, 3, 631), decreasing = TRUE)
f_50th <- qf(0.5, 3, 631)
f_20th <- qf(0.2, 3, 631)


## ---- fig.width=3.5, fig.height=2.5, fig.cap=" Compare the cooks distance of the data to F distrubution with degree of freedom (3, 631) with a line indicating the 20th percentile in such distribution"----
# Create a data frame with Cook's distance values
cooksD_data1 <- data.frame(
  Observation = 1:length(cookd1),
  CooksD = cookd1
)

# Plotting Cook's distance using ggplot2
ggplot(cooksD_data1, aes(x = Observation, y = CooksD)) +
  geom_point() +
  geom_hline(yintercept = f_20th, color = "red") +
  labs(title = "Cook's Distance Plot for term_gpa", x = "Observation Index", y = "Cook's Distance") +
  theme(plot.title = element_text(size=12))


## -----------------------------------------------------------------------------
t4 = read.table(text="TotalSleepTime 0.026601 0.007341 3.624 0.000314 ")
knitr::kable(t4, caption = "Numerical Summary of Slope of TotalSleepTime", col.names = c("","Estimate", "Std. Error", "t value", "Pr(>|t|)"))


## -----------------------------------------------------------------------------
t5 = read.table(text="exp(cum_gpa) 0.718535 0.030541 23.527 <2e-16 ")
knitr::kable(t5, caption = "Numerical Summary of Slope of exp(cum_gpa)", col.names = c("","Estimate", "Std. Error", "t value", "Pr(>|t|)"))


## -----------------------------------------------------------------------------
t6 = read.table(text="(Intercept) -0.747750 3.012853 -0.248 0.804071 ")
knitr::kable(t6, caption = "Numerical Summary of Model Intercept", col.names = c("","Estimate", "Std. Error", "t value", "Pr(>|t|)"))

