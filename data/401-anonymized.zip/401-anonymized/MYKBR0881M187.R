## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
cmu = read.csv('cmu-sleep.csv')


## -----------------------------------------------------------------------------
tst = cmu$TotalSleepTime
cgpa = cmu$cum_gpa
tgpa = cmu$term_gpa


## -----------------------------------------------------------------------------
summary(tst)
summary(cgpa)
summary(tgpa)
sum(tgpa >= 3.7)


## -----------------------------------------------------------------------------
hist(tst, main = "Histrogram of Total Sleep Time", xlab = "Total Sleep Time (in minutes)")
hist(cgpa, main = "Histrogram of Students' GPA From Last semester", xlab = "GPA (Maximum of 4)")
hist(tgpa, main = "Histrogram of Students' GPA From Current semester", xlab = "GPA (Maximum of 4)")


## -----------------------------------------------------------------------------
plot(tst, cgpa, main = "Scatter Plot of GPA From Previous semester v.s Total Sleep Time", 
    xlab = "Total Sleep Time (in minutes)",
    ylab = "GPA of Previous Semester (Maximum of 4)")
plot(tst, tgpa, main = "Scatter Plot of GPA From Current semester v.s Total Sleep Time", 
    xlab = "Total Sleep Time (in minutes)",
    ylab = "GPA of Current Semester (Maximum of 4)")
plot(cgpa, tgpa, main = "Scatter Plot of GPA From Current semester v.s Total Sleep Time", 
    xlab = "Total Sleep Time (in minutes)",
    ylab = "GPA of Current Semester (Maximum of 4)")


## -----------------------------------------------------------------------------
sleep = dplyr::filter(cmu, TotalSleepTime > 240, term_gpa > 2.0, frac_nights_with_data > 0.5)

testlm = lm((term_gpa) ~ TotalSleepTime, data = sleep)
plot(testlm)
summary(testlm)

plot(sleep$TotalSleepTime, sleep$term_gpa)
abline(coef(testlm)[1], coef(testlm)[2])

hist(testlm$residuals)

## -----------------------------------------------------------------------------
confint(testlm, level=0.95)

## -----------------------------------------------------------------------------
0.0011891 * 120
0.0005054916  * 120
0.001872788 * 120

