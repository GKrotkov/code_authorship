## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------

library(alr4)
library(dplyr)
library(readr)
library(ggplot2)
library(grid)
library(gridExtra)
library(bestglm)
library(broom)

rate_data <- Rateprof



## -----------------------------------------------------------------------------

#summary(rate_data[,c(1,5,6,8, 11)])
#apply(rate_data[,c(8, 11)],2,sd)
#summary(factor(rate_data[,1]))
#summary(factor(rate_data[,5]))
#summary(factor(rate_data[,6]))



## -----------------------------------------------------------------------------

par(mfrow = c(2, 3))
hist(rate_data[,8], prob = TRUE, xlab = "Quality of Class", main = "")
hist(rate_data[,11], prob = TRUE, xlab = "Easiness of Class", main = "")
barplot(table(rate_data[,1]), names = c("Female", "Male"),
xlab = "Gender", ylab = "Count")
barplot(table(rate_data[,5]), names = c("No", "Yes"),
xlab = "Attractiveness", ylab = "Count")
barplot(table(rate_data[,6]), names = c("Hum.", "SocSci", "STEM", "Pre-Prof."),
xlab = "Discipline", ylab = "Count")



## -----------------------------------------------------------------------------

pairs(quality ~ gender + pepper + discipline + easiness,
data = rate_data, pch = 16, cex = 0.7)



## -----------------------------------------------------------------------------

par(mfrow = c(1,2))
boxplot(quality ~ gender, ylab = "Quality of Class", data = rate_data,
xlab = "Gender", names = c("Female", "Male"), pch = 16)
boxplot(quality ~ pepper, ylab = "Quality of Class", data = rate_data,
xlab = "Attractiveness", names = c("No", "Yes"), pch = 16)



## -----------------------------------------------------------------------------

boxplot(quality ~ discipline, ylab = "Quality of Class", data = rate_data,
xlab = "Discipline", names = c("Hum.", "SocSci", "STEM", "Pre-Prof."), pch = 16)



## -----------------------------------------------------------------------------

par(mfrow = c(1,2))
boxplot(easiness ~ gender, ylab = "Easiness", data = rate_data,
xlab = "Gender", names = c("Female", "Male"), pch = 16)
boxplot(easiness ~ discipline, ylab = "Easiness", data = rate_data,
xlab = "Discipline", names = c("Hum.", "SocSci", "STEM", "Pre-Prof."), pch = 16)



## -----------------------------------------------------------------------------

reg_model <- lm(quality ~ factor(gender) + factor(pepper) + factor(discipline) + easiness, data = rate_data)
gender_model <- lm(quality ~ factor(gender)*easiness + factor(pepper) + factor(discipline), data = rate_data)
discipline_model <- lm(quality ~ factor(discipline)*easiness + factor(pepper) + factor(gender), data = rate_data)

summary(reg_model)
#summary(gender_model)
#summary(discipline_model)



## ---- fig.width=4, fig.height=3, fig.cap="Gender:Easiness Interaction Model Diagnostics"----

ggplot(augment(gender_model), aes(x = easiness, y = .resid)) +
geom_point() +
labs(x = "Easiness", y = "Residual")
ggplot(augment(gender_model), aes(x = .fitted, y = .resid)) +
geom_point() +
labs(x = "Fitted value", y = "Residual")

ggplot(augment(gender_model), aes(x = .fitted, y = .cooksd)) +
geom_point() +
labs(x = "Fitted value", y = "Cook's distance")

ggplot(augment(gender_model), aes(sample = .resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical quantile", y = "Sample quantile")



## ---- fig.width=4, fig.height=3, fig.cap="Discipline:Easiness Interaction Model Diagnostics"----

ggplot(augment(discipline_model), aes(x = easiness, y = .resid)) +
geom_point() +
labs(x = "Easiness", y = "Residual")
ggplot(augment(discipline_model), aes(x = .fitted, y = .resid)) +
geom_point() +
labs(x = "Fitted value", y = "Residual")

ggplot(augment(discipline_model), aes(x = .fitted, y = .cooksd)) +
geom_point() +
labs(x = "Fitted value", y = "Cook's distance")

ggplot(augment(discipline_model), aes(sample = .resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical quantile", y = "Sample quantile")



## ---- fig.width=4, fig.height=3, fig.cap="CI for reg model"-------------------

#confint(reg_model, "easiness")
#confint(reg_model, "factor(gender)male")
#confint(reg_model, "factor(pepper)yes")



## -----------------------------------------------------------------------------

#anova(reg_model, gender_model)
#anova(reg_model, discipline_model)



## -----------------------------------------------------------------------------

red_aic <- AIC(reg_model)
gender_aic <- AIC(gender_model)
discpline_aic <- AIC(discipline_model)


