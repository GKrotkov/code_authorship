## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="SetUp",include=FALSE----------------
library(alr4)
library(ggplot2)
library(patchwork)
library(regressinator)
library(ggplot2)
library(palmerpenguins)
library(modelsummary)
sleep_data = read.csv('/Users/bradygess/Downloads/cmu-sleep.csv')


## ---- fig.width=12, fig.height=3, fig.cap="Histograms of Total Sleep Time and GPA's"----
p1 <- ggplot(sleep_data,aes(x=TotalSleepTime))+geom_histogram(binwidth=15)+labs(x="Average Sleep Time",y='Frequency',title = 'Average Sleep Histogram')
p2 <- ggplot(sleep_data,aes(x=term_gpa))+geom_histogram(binwidth=0.25)+labs(x="Average Sleep Time",y='Frequency',title = 'Term GPA Histogram')
p3 <- ggplot(sleep_data,aes(x=cum_gpa))+geom_histogram(binwidth=0.25)+labs(x="Cumulative GPA",y='Frequency',title = 'Cumulative GPA Histogram')
p1 | p2 | p3


## ---- fig.width=10, fig.height=2, fig.cap="Scatterplots of Total Sleep Time and GPA's"----
sp1 = ggplot(sleep_data,aes(y=term_gpa,x=TotalSleepTime))+geom_point()+labs(y='Term GPA',x='Average Sleep Time',title='Term GPA vs Average Sleep Time')
sp2 = ggplot(sleep_data,aes(y=cum_gpa,x=TotalSleepTime))+geom_point()+labs(y='Cumulatitive GPA',x='Average Sleep Time',title = 'Cumulatitive GPA vs Average Sleep Time')
sp1 | sp2


## ---- fig.width=10, fig.height=2, fig.cap="Scatterplots of log(Total Sleep Time) and GPA's"----
sp3 = ggplot(sleep_data,aes(y=term_gpa,x=log(TotalSleepTime,2)))+geom_point()+labs(y='Semester GPA',x='Log Base 10 of Average Sleep Time',title = 'Term GPA vs Log Base 2 of Average Sleep Time')
sp4 = ggplot(sleep_data,aes(y=cum_gpa,x=log(TotalSleepTime,2)))+geom_point()+labs(y='Term GPA',x='Log Base 10 of Average Sleep Time',title = 'Cumulatitve GPA vs Log Base 2 of Average Sleep Time')
sp3 | sp4


## ---- fig.width=4, fig.height=3, fig.cap="Linear Regression Models of term gpa on log of total sleep and term gpa on the log of total sleep plus cumulative GPA"----
model1 = lm(data=sleep_data,term_gpa~log(TotalSleepTime,2))
model2 = lm(data=sleep_data,term_gpa~log(TotalSleepTime,2)+cum_gpa)


## ---- fig.width=8, fig.height=3, fig.cap="Residual Plot for Model 1 and Model 2"----
ggplot(data=sleep_data,aes(x=log(TotalSleepTime,2),y=resid(model1)))+geom_point()+labs(x='X',y='Residuals',title='Residual Plot for Log Base 2 of Average Sleep Time on Term GPA')
ggplot(data=sleep_data,aes(x=log(TotalSleepTime,2),y=resid(model2)))+geom_point()+labs(x='X',y='Residuals',title = 'Residual Plot for Log(Average Sleep Time) on Term + Cum GPA')


## ---- fig.width=4, fig.height=3, fig.cap="Normal Q-Q Residual Plots for Model 1 and Model 2"----
residuals_model1 <- residuals(model1)
qqnorm(residuals_model1)
qqline(residuals_model1)
residuals_model2 <- residuals(model2)
qqnorm(residuals_model2)
qqline(residuals_model2)



## ---- fig.width=4, fig.height=3, fig.cap="Summary of Linear Regression Models",include=FALSE----
summary(model1)
summary(model2)

## ---- fig.width=4, fig.height=3, fig.cap="Summary of Linear Regression Models"----
modelsummary(list("Model 1" = model1, "Model 2" = model2),
             gof_map = c("r.squared", "nobs"))


## ---- fig.width=4, fig.height=3, fig.cap="B1 Confidence Interval for Model 1"----
x = confint(lm(data=sleep_data,term_gpa~log(TotalSleepTime,2)))
low <- x[, "2.5 %"]
high <- x[, "97.5 %"]
table_data <- data.frame(Parameter = rownames(x), '2.5' = low, '97.5' = high)
table_data

