## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(alr4)


## -----------------------------------------------------------------------------
data <- read.csv("cmu-sleep.csv")

ggplot(data, aes(x=TotalSleepTime)) + geom_histogram(aes(y=..density..), binwidth=10, fill="blue", alpha=0.7) + geom_density(color="red") + labs(title="Distribution of Total Sleep Time (in minutes)")
ggplot(data, aes(x=term_gpa)) + geom_histogram(aes(y=..density..), binwidth=0.1, fill="green", alpha=0.7) + geom_density(color="red") + labs(title="Distribution of Term GPA")
ggplot(data, aes(x=cum_gpa)) + geom_histogram(aes(y=..density..), binwidth=0.1, fill="red", alpha=0.7) + geom_density(color="blue") + labs(title="Distribution of Cumulative GPA")


## -----------------------------------------------------------------------------

ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) + geom_point(alpha=0.6, color="purple") + labs(title="Scatterplot of Total Sleep Time vs. Term GPA")


## -----------------------------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa , data=data)
summary(model)


## -----------------------------------------------------------------------------
ggplot(data, aes(x=TotalSleepTime, y=term_gpa)) + 
  geom_point(alpha=0.6, color="purple") + 
  labs(title="Scatterplot of Total Sleep Time vs. Term GPA")

ggplot(data, aes(x=model$fitted.values, y=model$residuals)) + 
  geom_point(alpha=0.6, color="blue") + 
  labs(title="Residuals vs. Fitted values") + 
  geom_hline(yintercept=0, linetype="dashed", color="red")

qqnorm(model$residuals)
qqline(model$residuals)




## -----------------------------------------------------------------------------
confint(model, level=0.95)


## -----------------------------------------------------------------------------
hours_less_sleep <- 120  
gpa_effect <- coef(model)["TotalSleepTime"] * hours_less_sleep
gpa_effect

