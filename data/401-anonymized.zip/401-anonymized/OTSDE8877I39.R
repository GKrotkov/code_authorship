## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, echo=FALSE-----------------------------------------------
library(alr4)
library(gridExtra)
library(ggplot2)
library(dplyr)


## ---- message=FALSE, echo=FALSE-----------------------------------------------
mean(Rateprof$quality)
mean(Rateprof$easiness)


## ---- fig.width=4.5, fig.height=3---------------------------------------------
hist(Rateprof$quality,main="Figure 1: Distribution of Avg Quality Rating",xlab="Average Quality Rating",nclass=18)


## ----fig.width=4, fig.height=3------------------------------------------------
ggplot(Rateprof,aes(x=gender,fill=gender))+geom_bar()+labs(title = "Figure 2: # of Profs by Gender")

## ----fig.width=3.8, fig.height=3----------------------------------------------
ggplot(Rateprof,aes(x=pepper,fill=pepper))+geom_bar()+labs(title="Figure 3: # of Profs by Attractiveness")


## ----fig.width=3.5, fig.height=3----------------------------------------------
hist(Rateprof$easiness,main="Figure 4: Distribution of Easiness",xlab="Average Quality Rating",nclass=8)

## ----fig.width=3.5, fig.height=3----------------------------------------------
ggplot(Rateprof,aes(x=discipline,fill=discipline))+geom_bar()+labs(title="Figure 5: # of Profs by Discipline")


## ----fig.width=3.5, fig.height=3----------------------------------------------
ggplot(Rateprof,aes(x=gender,y=quality,fill=gender))+geom_boxplot()+labs(title="Figure 6: Quality Ratings vs Gender")


## ----fig.width=3.5, fig.height=3----------------------------------------------
ggplot(Rateprof,aes(x=pepper,y=quality,fill=pepper))+geom_boxplot()+labs(title="Figure 7: Quality Ratings vs Attractiveness")


## ----fig.width=3.5, fig.height=3----------------------------------------------
ggplot(Rateprof,aes(x=easiness,y=quality,color=gender))+geom_point(aes(color=gender))+labs(title="Figure 8: Quality vs. Easiness",x="Easiness",y="Quality") 


## ----fig.width=3.5, fig.height=3----------------------------------------------
ggplot(Rateprof,aes(x=discipline,y=quality,fill=discipline))+geom_boxplot()+labs(title="Figure 9: Quality Ratings vs Discipline")


## ---- message=FALSE, echo=FALSE-----------------------------------------------
#maybe more here
#anova(smallmodel,bigmodel)


## -----------------------------------------------------------------------------
bigmodel<-lm(quality~gender+pepper+easiness+discipline+gender:easiness+discipline:easiness,data=Rateprof)


## -----------------------------------------------------------------------------
smallmodel<-lm(quality~gender+pepper+easiness+discipline,data=Rateprof)


## -----------------------------------------------------------------------------
anova(smallmodel,bigmodel)

