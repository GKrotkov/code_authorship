## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=6, fig.height=4, fig.cap="Scatter Plot of Sleep Time vs Cum GPA", echo=FALSE, message=FALSE----

model_term_gpa <- lm(term_gpa ~ TotalSleepTime, data = data)

se_slope <- summary(model_term_gpa)$coefficients["TotalSleepTime", "Std. Error"]

t_value <- coef(model_term_gpa)["TotalSleepTime"] / se_slope

df <- length(data$TotalSleepTime) - 2

alpha <- 0.05

p_value <- 2 * (1 - pt(abs(t_value), df))

cat("t value", t_value, "\n")
cat("df:", df, "\n")
cat("p value:", p_value, "\n")

term_gpa_confint <- confint(model_term_gpa, level = 0.95)

cat(term_gpa_confint) 


## ---- fig.width=6, fig.height=4, fig.cap="Scatter Plot of Sleep Time vs Cum GPA", echo=FALSE, message=FALSE----

model_term_gpa <- lm(term_gpa ~ TotalSleepTime, data = data)

se_slope <- summary(model_term_gpa)$coefficients["TotalSleepTime", "Std. Error"]

t_value <- coef(model_term_gpa)["TotalSleepTime"] / se_slope

df <- length(data$TotalSleepTime) - 2

alpha <- 0.05

p_value <- 2 * (1 - pt(abs(t_value), df))

cat("t value", t_value, "\n")
cat("df:", df, "\n")
cat("p value:", p_value, "\n")

term_gpa_confint <- confint(model_term_gpa, level = 0.95)

cat(term_gpa_confint)



## ---- fig.width=6, fig.height=4, fig.cap="Scatter Plot of Sleep Time vs Cum GPA", echo=FALSE, message=FALSE----

slope <- coef(model_cum_gpa)["TotalSleepTime"]

change_in_gpa <- slope * (-120) 

slope_confint <- confint(model_cum_gpa, level = 0.95)

change_in_gpa_confint <- slope_confint * (-120)

cat("Change in Cumulative GPA with 2 Hours Less Sleep:", change_in_gpa, "\n")
cat("95% Confidence Interval for the Change in Cumulative GPA:", change_in_gpa_confint, "\n")


## ---- fig.width=6, fig.height=4, fig.cap="Scatter Plot of Sleep Time vs Cum GPA", echo=FALSE, message=FALSE----

slope <- coef(model_term_gpa)["TotalSleepTime"]

change_in_gpa <- slope * (-120) 
slope_confint <- confint(model_term_gpa, level = 0.95)

change_in_gpa_confint <- slope_confint * (-120)

cat("Change in term GPA with 2 Hours Less Sleep:", change_in_gpa, "\n")
cat("95% Confidence Interval for the Change in term GPA:", change_in_gpa_confint, "\n")


## ----1, echo=FALSE, message=FALSE---------------------------------------------
library(dplyr)
library(ggplot2)

data <- read.csv("cmu-sleep.csv")


## ---- 2, fig.width=6, fig.height=4, fig.cap="Distribution of Sleep Time", echo=FALSE, message=FALSE----

ggplot(data, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 30, fill = "lightblue", color = "black") +
  labs(title = "Distribution of Sleep Time", x = "Sleep Time (minutes)", y = "Frequency")


## ---- 3, fig.width=6, fig.height=4, fig.cap="Distribution of Term GPA"--------

ggplot(data, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.2, fill = "lightblue", color = "black") +
  labs(
    title = "Distribution of Term GPA",
    x = "Term GPA",
    y = "Frequency"
  )


## ---- 4, fig.width=6, fig.height=4, fig.cap="Distribution of Cumulative GPA"----
ggplot(data, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.2, fill = "lightblue", color = "black") +
  labs(
    title = "Distribution of Cumulative GPA",
    x = "Cum GPA",
    y = "Frequency"
  )


## ---- 5, fig.width=6, fig.height=4, fig.cap="Scatter Plot of Sleep Time vs Term GPA", echo=FALSE, message=FALSE----

ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  labs(title = "Scatterplot of Sleep Time vs. Term GPA", x = "Total Sleep Time (minutes)", y = "Term GPA (units)")


## ---- fig.width=6, fig.height=4, fig.cap="Scatter Plot of Sleep Time vs Cum GPA", echo=FALSE, message=FALSE----

ggplot(data, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
  labs(title = "Scatterplot of Sleep Time vs. Cum GPA", x = "Total Sleep Time (minutes)", y = "Cum GPA (units)")


## ---- 7, fig.width=6, fig.height=4, fig.cap="Linear Regression Model of Sleep Time vs Term GPA", echo=FALSE, message=FALSE----

ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +  
  labs(title = "Linear Regression Model of Sleep Time vs. Term GPA", x = "Total Sleep Time (minutes)", y = "Term GPA (units)")



## ---- fig.width=6, fig.height=4, fig.cap="Linear Regression Model of Sleep Time vs Cum GPA", echo=FALSE, message=FALSE----

ggplot(data, aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") + 
  labs(title = "Linear Regression Model of Sleep Time vs. Cum GPA", x = "Total Sleep Time (minutes)", y = "Cum GPA (units)")


## ---- fig.width=6, fig.height=4, fig.cap="Residual for Term GPA", echo=FALSE, message=FALSE----

model_term_gpa <- lm(term_gpa ~ TotalSleepTime, data = data)
term_gpa_residuals <- resid(model_term_gpa)
term_gpa_fitted <- fitted(model_term_gpa)

plot(term_gpa_fitted, term_gpa_residuals, main = "Residual Plot for Term GPA", 
     xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "blue")



## ---- fig.width=6, fig.height=4, fig.cap="Residual For Cumulative GPA", echo=FALSE, message=FALSE----

model_cum_gpa <- lm(cum_gpa ~ TotalSleepTime, data = data)

cum_gpa_residuals <- resid(model_cum_gpa)
cum_gpa_fitted <- fitted(model_cum_gpa)

plot(cum_gpa_fitted, cum_gpa_residuals, main = "Residual Plot for C-GPA",
     xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "blue")


## ---- fig.width=6, fig.height=4, fig.cap="Table for p value of other factors", echo=FALSE, message=FALSE----
model_multiple <- lm(term_gpa ~ TotalSleepTime + study + demo_gender + demo_firstgen + 
                     demo_race + term_units + bedtime_mssd + daytime_sleep + 
                     midpoint_sleep + frac_nights_with_data, data = data)

p_values <- summary(model_multiple)$coefficients[, "Pr(>|t|)"]

p_value_table <- data.frame(P_Value = p_values)

knitr::kable(p_value_table)

