## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(sleep$TotalSleepTime, main="Frequency vs Total Sleep Time", xlab = 
       "Total Sleep Time (in minutes)", ylab="Frequency")
mean(sleep$TotalSleepTime)
median(sleep$TotalSleepTime)
hist(sleep$term_gpa, main="Frequency vs Term GPA", xlab = 
       "Term GPA (on 4.0 scale)", ylab="Frequency")
mean(sleep$term_gpa)
median(sleep$term_gpa)
hist(sleep$cum_gpa, main="Frequency vs Cumulative GPA", xlab = 
       "Cumulative GPA (on 4.0 scale)", ylab="Frequency")
mean(sleep$cum_gpa)
median(sleep$cum_gpa)


## ---- fig.width=4, fig.height=3-----------------------------------------------
library(dplyr)
library(ggplot2)
sleep %>%
  ggplot(aes(x=log(cum_gpa)))+
  geom_histogram()+
  labs(title="Distribution of log(cumulative gpa)", x="log(cumulative gpa)",
       y="Frequency")

sleep %>%
  ggplot(aes(x=log(term_gpa)))+
  geom_histogram()+
  labs(title="Distribution of log(term gpa)", x="log(term gpa)",
       y="Frequency")


## ---- fig.width=4, fig.height=3-----------------------------------------------
library(ggplot2)
library(dplyr)
sleep %>%
ggplot(aes(x= TotalSleepTime, y= term_gpa))+
  geom_point()+
  geom_smooth(method="lm")+
  labs(title="Scatterplot of Term gpa vs Total Sleep Time",
       x="Total Sleep Time", y="Term gpa")
model <- lm(term_gpa~TotalSleepTime, sleep)
summary(model)


## ---- fig.width=4, fig.height=3-----------------------------------------------
library(broom)
resid <- resid(model)
plot(sleep$TotalSleepTime, resid, xlab="Total Sleep Time", 
     ylab="Residuals",
     main = "Residuals v Predictor")
hist(resid, main="Distribution of Residuals", xlab="Residuals")+
  geom_histogram()
augment(model) |>
  ggplot(aes(x=TotalSleepTime, y=.cooksd))+
  geom_point()+
  labs(title="Cooks Distance", x="Total Sleep Time", y="Cooks Distance")


## ---- fig.width=4, fig.height=3-----------------------------------------------
library(broom)
ggplot(augment(model), aes(sample=.resid))+
  geom_qq()+
  geom_qq_line()


## -----------------------------------------------------------------------------
summary(model)


## -----------------------------------------------------------------------------
0.0019846*-120
confint(model)*-120

