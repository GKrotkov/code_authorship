## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)



## -----------------------------------------------------------------------------
data("Rateprof")


## -----------------------------------------------------------------------------
summary(Rateprof[,c("gender","pepper","discipline","quality","easiness")])
apply(Rateprof[,c("quality","easiness")],2,sd)

## ---- fig.width=3, fig.height=3, fig.cap="barplot of Instructor Gender"-------
barplot(table(Rateprof$gender),names = c("Female","Male"),xlab = "Instructor Gender", ylab = "Count")

## ---- fig.width=3, fig.height=3, fig.cap="barplot of whether insturctor is rated attractive"----
barplot(table(Rateprof$pepper),names = c("No","Yes"),xlab = "Whether insturctor is rated attractive", ylab = "Count")

## ---- fig.width=7, fig.height=3, fig.cap="barplot of disciplines the insturctor teach"----
barplot(table(Rateprof$discipline),names = c("Humanities","Social Science","STEM","Professional training"),xlab = "Discipline the instructor teach", ylab = "Count")


## ---- fig.width=3, fig.height=3, fig.cap="histogram of average quality rating"----
hist(Rateprof$quality, prob = TRUE, xlab = "Average quality rating")

## ---- fig.width=3, fig.height=3, fig.cap="histogram of average easiness rating"----
hist(Rateprof$easiness, prob = TRUE, xlab = "Average easiness rating")


## ---- fig.width=3, fig.height=3, fig.cap="pair polt of variables"-------------
pairs(quality~easiness + gender + discipline, data = Rateprof)


## ---- fig.width=3, fig.height=3, fig.cap="boxplot of average quality rating vs. gender"----
boxplot(quality~gender, ylab = "average quality rating", data = Rateprof, xlab = "gender", names = c("Female","Male"))

## ---- fig.width=3, fig.height=3, fig.cap="boxplot of average quality rating vs. pepper"----
boxplot(quality~pepper, ylab = "average quality rating", data = Rateprof, xlab = "whether the instructor is attractive", names = c("No","Yes"))

## ---- fig.width=3, fig.height=3, fig.cap="boxplot of average quality rating vs. discipline"----
boxplot(quality~discipline, ylab = "average quality rating", data = Rateprof, xlab = "which discipline the instructor teach", names = c("Humanities","Social Science","STEM","Professional training"))


## -----------------------------------------------------------------------------
model <- lm(quality ~ easiness + factor(gender) + factor(pepper) + factor(discipline) + easiness : factor(gender) + easiness : factor(discipline) , data = Rateprof)


## -----------------------------------------------------------------------------
model0 <- lm(quality ~ factor(gender) + factor(pepper) + factor(discipline) + easiness, data = Rateprof)
vif(model0)


## ---- fig.width=3, fig.height=3, fig.cap="Residuals vs Fitted Values Plot"----
plot(model, which = 1)

## ---- fig.width=3, fig.height=3, fig.cap="Normal Q-Q Plot"--------------------
plot(model, which = 2)


## -----------------------------------------------------------------------------
cooksd <- cooks.distance(model)


## ---- fig.width=3, fig.height=3, fig.cap="Cook's Distance Plot"---------------
plot(cooksd, pch = 20, main = "Cook's Distance Plot", ylab = "Cook's Distance")
abline(h = 4 / length(cooksd), col = "red", lty = 2)


## -----------------------------------------------------------------------------
anova(model)


## -----------------------------------------------------------------------------
AIC(model)
AIC(model0)


## -----------------------------------------------------------------------------
summary(model0)
confint(model0)


## -----------------------------------------------------------------------------
model0_red <- lm(quality ~ factor(gender) + factor(pepper) + easiness, data = Rateprof)
anova(model0_red,model0)

