## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## -----------------------------------------------------------------------------
library(readr)
library(dplyr)

world_bank_data <- read_csv("https://cmustatistics.github.io/data-repository/data/world-bank.csv")

filtered_data <- world_bank_data %>% filter(Year == 2015, IsCountry == 1)

head(filtered_data)

rows <- nrow(filtered_data)
print(rows)


## -----------------------------------------------------------------------------
library(ggplot2)

ggplot(filtered_data, aes(x = CO2Emissions, y = PM2.5)) + 
  geom_point() + 
  labs(x = "Carbon Dioxide Emissions (Metric tons per capita)", 
       y = "PM 2.5 Air Pollution (Micrograms per cubic meter)",
       title = "Relationship between CO2 Emissions and PM2.5 Air Pollution") +
  theme_minimal()


## -----------------------------------------------------------------------------
ggplot(filtered_data, aes(x = CO2Emissions, y = PM2.5)) + 
  geom_point() + 
  labs(x = "Carbon Dioxide Emissions (Metric tons per capita)", 
       y = "PM 2.5 Air Pollution (Micrograms per cubic meter)") +
  facet_wrap(~`Income group`) + 
  theme_minimal()

