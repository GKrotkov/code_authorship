## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(tidyverse)
library(alr4)

data <- read.csv('cmu-sleep.csv')


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))
hist(data$TotalSleepTime, main = 'Histogram of Total Sleep Time', xlab = 'Total Sleep Time (Minutes)', ylab = 'Number of Students', breaks=20)
hist(data$cum_gpa, main = 'Histogram of Cumulative GPA', xlab='Cumulative GPA 4.0 Scale', ylab='Number of Students', breaks=20)



## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))
hist(data$term_gpa, main='Histogram of Term GPA', xlab='Term GPA 4.0 Scale', ylab='Number of Students', breaks=20)
hist(data$term_units, main='Histogram of Units in Term', xlab='Number of Units', ylab='Number of Students', breaks=20)



## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))
plot(data$cum_gpa, data$term_gpa, main='Cumulative GPA vs. Term GPA', xlab='Cumulative GPA (4.0 Scale)', ylab='Term GPA (4.0 Scale)')
plot(data$daytime_sleep, data$term_gpa, main='Daytime Sleep vs. Term GPA', xlab='Term Units', ylab='Term GPA (4.0 Scale')



## -----------------------------------------------------------------------------
par(mfrow = c(1, 3))
plot(data$TotalSleepTime, data$term_gpa, main='Term GPA vs. Total Sleep Time', ylab='Term GPA (4.0 Scale)' , xlab='Total Sleep Time (minutes)')

plot(log(data$TotalSleepTime), data$term_gpa, main='Term GPA vs. log Total Sleep Time', ylab='Term GPA (4.0 Scale)', xlab='log of Total Sleep Time (mintues)')
plot(log(data$TotalSleepTime), log(data$term_gpa), main='log Term GPA vs. log Total Sleep Time', ylab='Term GPA (4.0 Scale)', xlab='log of Total Sleep Time (mintues)')


## -----------------------------------------------------------------------------
a <- data$term_gpa
b <- data$TotalSleepTime
cookslm <- lm(a ~ b, data=data)
cooksd <- cooks.distance(cookslm)
par(mfrow = c(1, 3))
plot(data$term_gpa, cooksd, main="Cooks Distance", xlab="Term GPA (4.0 Scale)", ylab="Cooks Distance")

plot(data$TotalSleepTime, data$term_gpa, main="Sleep Time vs. Term GPA", xlab="Total Sleep Time (min)", ylab="Term GPA (4.0 Scale)")
abline(cookslm, col='red')

top_x_outlier <- 2
influential <- as.numeric(names(sort(cooksd, decreasing = TRUE)[1:top_x_outlier]))
data_rm <- data[-influential, ]

cooksd_after <- lm(data_rm$term_gpa ~ data_rm$TotalSleepTime, data=data_rm)
plot(data_rm$TotalSleepTime, data_rm$term_gpa, main="Sleep Time vs GPA (No Outliers)", xlab="Total Sleep Time (min)", ylab="Term GPA (4.0 Scale)")
abline(cooksd_after, col='red')


## -----------------------------------------------------------------------------
a <- data$term_gpa
b <- data$TotalSleepTime
model <- lm(a ~ b, data=data)

plot(data$TotalSleepTime, data$term_gpa, main ="Total Sleep Time vs. Term GPA", xlab="Total Sleep Time", ylab="Term GPA")
abline(model, col="red")


## -----------------------------------------------------------------------------
par(mfrow = c(1, 2))

residuals <- residuals(model)
plot(predict(model), residuals, main='Residuals Plot', xlab="Fitted Values", ylab="Residuals")
abline(h=0, col="red", lwd=2)

qqnorm(residuals)
qqline(residuals)



## -----------------------------------------------------------------------------
#confint(model)


## -----------------------------------------------------------------------------
#summary(model)


## -----------------------------------------------------------------------------
#predict(model, newdata = data.frame(b = 400),
#interval = "confidence", level = 0.95)


#predict(model, newdata = data.frame(b = 280),
#interval = "confidence", level = 0.95)

