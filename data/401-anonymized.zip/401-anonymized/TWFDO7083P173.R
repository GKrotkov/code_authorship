## ----echo=FALSE---------------------------------------------------------------
library(knitr)
library(kableExtra)
sleep = read.csv("cmu-sleep.csv")
knitr::kable(head(sleep),align = "lccrr",caption = "Head of Dataset") %>%
    kable_styling(font_size = 10,latex_options = "scale_down")


## ----echo=FALSE,eval = FALSE--------------------------------------------------
## dim(sleep)


## ----echo=FALSE,fig.width=4, fig.height=3,fig.cap="Histogram of Average Sleeping Time"----
hist(sleep$TotalSleepTime, main = "Histogram of Average Sleeping Time", xlab = "Average total Sleeping Time (min)")


## ---- echo=FALSE,fig.width=4, fig.height=3,fig.cap="Histogram of Current Semester GPA"----
hist(sleep$term_gpa, main = "Histogram of Current Semester GPA", xlab = "Semester GPA")


## ---- echo=FALSE,fig.width=4, fig.height=3,fig.cap= "Histogram of Cumulative GPA"----
hist(sleep$cum_gpa, main = "Histogram of Cumulative GPA", xlab = "Cumulative GPA")


## ---- echo=FALSE, fig.cap="Bivariate scatterplot between average sleep time and semester GPA"----
library('ggplot2')
ggplot(sleep, aes(x = TotalSleepTime, y = 1/(max(term_gpa+1)-term_gpa))) +
  geom_point()+
  labs(y="Semester GPA", x="Total Sleeping Time (min)")


## ----echo=FALSE, fig.cap="Bivariate scatterplot between average sleep time and cumulative GPA"----
ggplot(sleep, aes(x = TotalSleepTime, y = 1/(max(cum_gpa+1)-cum_gpa))) +
  geom_point()+
  labs(y="Cumulative GPA", x="Total Sleeping Time (min)")


## ----echo=FALSE, fig.cap="Residual plots of fitted model"---------------------
gpa_transformed = 1/(max(sleep$term_gpa+1)-sleep$term_gpa)
model <- lm(gpa_transformed~TotalSleepTime, data=sleep)
ggplot(model,aes(x=TotalSleepTime, y=.resid))+
  geom_point()+
  labs(y="Residual",x="Total Sleeping Time (min)")


## ----echo=FALSE, fig.cap="Fitted linear regression model Summary"-------------
library(modelsummary)
modelsummary(model, title="Fitted linear regression model Summary")


## ---- echo=FALSE, fig.cap="Confidence interval of fitted linear regression model"----
knitr::kable(confint(model, level = 0.95), caption = "Confidence interval of fitted linear regression model")

