## ----setup, include = FALSE, message = FALSE, warning = FALSE-----------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----class_sleep, fig.cap="Figure 1: Frequency of Total Sleep Time Among Students."----

# library(dplyr)

sleep_time_data <- read.csv("cmu-sleep.csv", header=TRUE, stringsAsFactors=FALSE)

hist(sleep_time_data$TotalSleepTime, main = "Frequency of Total Average Sleep Times Among Students", xlab = "Total Average Sleep Times (min.)", breaks = 50)



## ---- fig.cap="Figure 2: Frequency of Current Semester GPA Among Students."----
hist(sleep_time_data$term_gpa, main = "Frequency of Current Semester GPA Among Students", xlab = "Current Semester GPA (on a 4.0 scale)", breaks = 50)


## ---- fig.cap="Figure 3: Frequency of Previous Cumulative GPA Among Students."----
hist(sleep_time_data$cum_gpa, main = "Frequency of Previous Cumulative GPA Among Students", xlab = "Cumulative GPA (on a 4.0 scale)", breaks = 50)


## ---- fig.cap="Figure 4: Frequency of Transformed Current Semester GPA."------
hist(2^(sleep_time_data$term_gpa), main = "Frequency of Exponentiated Current Semester GPA", xlab = "2 ^ (Current Semester GPA) (on a transformed 4.0 scale)", breaks = 50)


## ---- fig.cap="Figure 5: Frequency of Transformed Previous Cumulative GPA."----
hist(2^(sleep_time_data$cum_gpa), main = "Frequency of Exponentiated Previous Cumulative GPA", xlab = "2 ^ (Cumulative GPA) (on a transformed 4.0 scale)", breaks = 50)


## ----bivariate eda, message = FALSE, warning = FALSE, fig.cap="Figure 6: Scatterplot of Average Sleep Time against Current Semester GPA."----

library(tidyverse)
library(dplyr)

sleep_time <- sleep_time_data$TotalSleepTime
term_gpa <- sleep_time_data$term_gpa
cum_gpa <- sleep_time_data$cum_gpa

ggplot(sleep_time_data, aes(x = sleep_time, y = term_gpa)) + geom_point() + labs(title = 'Average Sleep Time vs. Current Semester GPA', x = 'Average Sleep Time (min.)', y = 'Current Semester GPA (on a 4.0 scale)', breaks = 50)

# ggplot(sleep_time_data, aes(x = sleep_time, y = cum_gpa)) + geom_point() + labs(title = 'Average Sleep Time vs. Previous Cumulative GPA', x = 'Average Sleep Time (min.)', y = 'Previous Cumulative GPA (on a 4.0 scale)', breaks = 50)


## ---- fig.cap="Figure 7: Scatterplot of Average Sleep Time against Transformed Current Semester GPA."----

ggplot(sleep_time_data, aes(x = sleep_time, y = 2^term_gpa)) + geom_point() + labs(title = 'Average Sleep Time vs. Transformed Current Semester GPA', x = 'Average Sleep Time (min.)', y = 'Transformed Current Semester GPA (on a transformed 4.0 scale)', breaks = 50)



## ----residuals, fig.cap="Figure 8: Scatterplot of Average Sleep Time against Residuals."----

lin_model <- lm(2^term_gpa ~ sleep_time)

res <- resid(lin_model)

plot(fitted(lin_model), res, main = "Plot of Residuals vs. Total Sleep Time", xlab = "Total Sleep Time (min.)", ylab = "Residuals")


## ---- fig.cap="Figure 9: Q-Q Plot of the Residuals of the Transformed Data."----
qqnorm(res)
qqline(res, col = "green")
          


## ----linear model, message = FALSE, include = FALSE---------------------------

summary(lin_model)

confint(lin_model, level = 0.95)


