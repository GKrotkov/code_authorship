## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- results="hide", message=FALSE-------------------------------------------
library(carData)
library(car)
library(effects)
library(alr4)
prof <- Rateprof
library(ggplot2)
library(patchwork)


## ---- fig.height=3, fig.cap="Distribution of quality and easiness.", message=FALSE----
p1 <- ggplot(prof, aes(x=quality))+
  geom_histogram(binwidth = 0.3)+
  ggtitle("Histogram of average quality rating")+
  xlab("Quality")+ 
  theme_minimal()+ 
  theme(plot.title = element_text(size=6))

p2 <- ggplot(prof, aes(x=easiness))+
  geom_histogram(binwidth = 0.2)+
  ggtitle("Histogram of easiness of course")+
  xlab("Easiness")+ 
  theme_minimal()+
  theme(plot.title = element_text(size=6))

p1|p2

## ---- results="hide"----------------------------------------------------------
table(prof$gender)
table(prof$pepper)
table(prof$discipline)


## ---- fig.height=3, fig.cap="Distribution of gender of instructors, attractiveness, and discipline."----
p1 <- ggplot(prof, aes(x=gender))+
  geom_bar()+
  ggtitle("Barplot of gender")+
  xlab("Gender")+ theme_minimal()+
  theme(plot.title = element_text(size=6))

p2 <- ggplot(prof, aes(pepper))+
  geom_bar()+
  ggtitle("Barplot of attractiveness")+
  xlab("Attractiveness")+ theme_minimal()+
  theme(plot.title = element_text(size=6))

p3 <- ggplot(prof, aes(discipline))+
  geom_bar()+
  ggtitle("Barplot of discipline")+
  xlab("Discipline")+ theme_minimal()+
  theme(plot.title = element_text(size=6),
        axis.text.x = element_text(size=4))

p1|p2|p3


## ---- fig.height=3, fig.cap="Bivariate EDA of easiness vs quality and gender vs quality."----
p1 <- ggplot(prof, aes(x=easiness, y=quality))+
  geom_point(alpha=0.3)+
  geom_smooth(formula = y ~ x, method="lm", se=FALSE, col="blue") +
  ggtitle("Scatter plot of easiness vs. quality")+
  xlab("Easiness") + 
  ylab("Quality")+ theme_minimal()+
  theme(plot.title = element_text(size=6))

p2 <- ggplot(prof, aes(x=gender, y=quality)) +
  geom_boxplot() +
  labs(title = "Boxplot of gender and quality", 
       y = "Average quality rating", 
       x = "Gender")+
  theme(plot.title = element_text(size=6))

p1 | p2


## ---- fig.height=3, fig.cap="Bivariate EDA of attractiveness vs quality and discipline vs quality."----
p1 <- ggplot(prof, aes(x=pepper, y=quality)) +
  geom_boxplot() +
  labs(title = "Boxplot of attractiveness and quality", 
       y = "Average quality rating", 
       x = "Attractiveness")+
  theme_minimal()+
  theme(plot.title = element_text(size=6))

p2 <- ggplot(prof, aes(x=discipline, y=quality)) +
  geom_boxplot() +
  labs(title = "Boxplot of discipline and quality", 
       y = "Average quality rating", 
       x = "Discipline of the course")+
  theme_minimal()+
  theme(plot.title = element_text(size=6),
        axis.text.x = element_text(size=6))

p1 | p2


## ---- results="hide"----------------------------------------------------------
library(leaps)
library(bestglm)

lm <- lm(quality ~ gender + pepper + easiness + discipline + easiness * gender + easiness * discipline, data = prof)
summary(lm)

## ---- fig.width=4, fig.height=3, fig.cap="Residuals plotted over fitted values."----
plot(lm, which=1)


## ---- fig.width=4, fig.height=3, fig.cap="Normal QQ plot."--------------------
plot(lm, which=2)

## ---- results='hide'----------------------------------------------------------
cookd<-cooks.distance(lm)
which.max(cookd)
cookd[182]


## ---- results="hide"----------------------------------------------------------
lm_red <- lm(quality ~ gender + pepper + easiness + discipline, data = prof)
anova(lm_red, lm)


## ---- results="hide"----------------------------------------------------------
summary(lm_red)
confint(lm_red)


## ---- results="hide"----------------------------------------------------------
lm_red2 <- lm(quality ~ gender + pepper + easiness, data = prof)
anova(lm_red2, lm_red)

