## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
Exam1Data = read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
summary(Exam1Data$TotalSleepTime)


## -----------------------------------------------------------------------------
summary(Exam1Data$term_gpa)


## -----------------------------------------------------------------------------
summary(Exam1Data$cum_gpa)


## -----------------------------------------------------------------------------
hist(Exam1Data$TotalSleepTime, main = "Figure 1: Histogram of Total Sleep Time",
     xlab = "Total Sleep Time (in minutes)", ylab = "Frequency")


hist(Exam1Data$term_gpa, main = "Figure 2: Histogram of Current Semester GPA",
     xlab = "Current Semester GPA (out of 4.0)", ylab = "Frequency")


## -----------------------------------------------------------------------------
plot(Exam1Data$TotalSleepTime, Exam1Data$term_gpa, 
     xlab = "Total Sleep Time (in minutes)", 
     ylab = "Current Semester GPA (out of 4.0)", 
     main = "Figure 3: Scatterplot of 
     Total Sleep Time and Current Semester GPA")


## -----------------------------------------------------------------------------
fitted_model = lm(term_gpa ~ TotalSleepTime + cum_gpa, data = Exam1Data)
plot(fitted_model, which = 1) # which = 1 gives the residual vs fitted values (x) 


## -----------------------------------------------------------------------------
qqnorm(residuals(fitted_model))
qqline(residuals(fitted_model))


## -----------------------------------------------------------------------------
table_with_cooks_distance = influence.measures(fitted_model)

cooks_distances = table_with_cooks_distance$cooks.distance

cooks_too_high = which(cooks_distances > 1)

if (length(cooks_too_high) > 0) {
  cat("High Cook's distances detected.") 
} else {
  cat("No Cook's distances greater than 1 are detected.\n")
}




## -----------------------------------------------------------------------------
summary(fitted_model) # used to find p-values
confint(fitted_model) # used to find CI's

# Please note that I am aware we need to avoid having R output. However, I do not know how to construct a table that indicates p-values and confidence intervals, which is all information that is needed to be shown. Also, the modelsummary() line below was recommended on Piazza to use but it could not knit to pdf, so I had to comment it out:  

# modelsummary(list("Fitted Model" = fitted_model), gof_map = c("r.squared", "nobs"))

