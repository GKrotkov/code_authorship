## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE,fig.align = "center",fig.width=4,fig.height=3)
library(alr4)
library(dplyr)
library(ggplot2)
data <- read.csv("cmu-sleep.csv")
attach(data)


## ---- echo=FALSE,fig.width=3,fig.height=3-------------------------------------
ggplot(data,aes(x=`TotalSleepTime`))+
      ggtitle("Count of TotalSleepTime")+
      geom_histogram(binwidth=10,fill = "blue")+
      labs(x= "TotalSleepTime (min)", y = "count",caption="Figure 1: Histogram of the count of TotalSleepTime (min)")


## ---- echo=FALSE,fig.width=3,fig.height=2-------------------------------------
ggplot(data,aes(x=`term_gpa`))+
      geom_histogram(binwidth=0.03,fill = "blue")+
      ggtitle("Count of TermGPA")+
      labs(x= "term_gpa (out of 4.0)", y = "count",caption="Figure 2: Histogram of the count of Term GPA (out of 4.0)")
ggplot(data,aes(x=log(`term_gpa`)))+
      geom_histogram(binwidth=0.03,fill = "blue")+
      ggtitle("Count of log(TermGPA)")+
      labs(x= "term_gpa (out of 4.0)", y = "count",caption="Figure 3: Histogram of the count of Log(Term GPA) (out of 4.0)")
ggplot(data,aes(x=exp(`term_gpa`)))+
      geom_histogram(binwidth=0.06,fill = "blue")+
      ggtitle("Count of exp(TermGPA)")+
      labs(x= "term_gpa (out of 4.0)", y = "count",caption="Figure 4: Histogram of the count of Exp(Term GPA) (out of 4.0)")


## ---- message=FALSE,fig.width=3,fig.height=2----------------------------------
par(mfrow=c(2,3))

ggplot(data,aes(x=`cum_gpa`))+
      geom_histogram(binwidth=0.03,fill = "blue")+
      ggtitle("Count of CumGPA")+
      labs(x= "cum_gpa (out of 4.0)", y = "count",caption="Figure 5: Histogram of the count of Cum GPA (out of 4.0)")
ggplot(data,aes(x=exp(`cum_gpa`)))+
      geom_histogram(binwidth=0.05,fill = "blue")+
      ggtitle("Count of exp(CumGPA)")+
      labs(x= "cum_gpa (out of 4.0)", y = "count",caption="Figure 6: Histogram of the count of Exp(Cum GPA) (out of 4.0)")


## ----echo=FALSE,fig.width=6,fig.height=4--------------------------------------
ggplot(data,aes(x=TotalSleepTime, y=exp(term_gpa)))+
      geom_point()+
      geom_smooth(method=lm, se=FALSE, aes(group=1), color='blue') +
      ggtitle("Effect of Sleep Duration on Term GPA")+
      labs(x= "Sleep Duration (minutes)", 
      y = "Term GPA (Exponential-transformed)",
      caption="Figure 7: scatterplot of effect of sleep duration on term gpa")


## ----echo=FALSE,fig.width=6,fig.height=4--------------------------------------
exp_term_gpa <- exp(term_gpa)
model<-lm(exp_term_gpa ~ TotalSleepTime, data = data)
cookd <- cooks.distance(model)
plot(cookd, type = "h", main = "Cook's Distance", ylab = "Cook's Distance")
abline(h = 0.015, col = "blue") 
mtext("Figure 8: Cook's Distance for model on TotalSleepTime and Exponential Term_GPA", side = 1, line = 4)


## ----echo=FALSE---------------------------------------------------------------
ggplot(model,aes(x=`TotalSleepTime`, y=.resid))+
geom_point(color = 'blue')+ ggtitle("Residual of Model v.s Total Sleep Time (min)")+
labs(x= "Total Sleep Time (min)", y = "Residuals",
     caption="Figure 9 Scatterplot: Residual of model v.s Total Sleep Time (min)")


## ----echo=FALSE,fig.width=6,fig.height=4--------------------------------------
qqnorm(residuals(model), main = "QQ Plot of Model Residuals")
qqline(residuals(model))
mtext("Figure 10: QQ Plot for normality of residuals from the model", side = 1, line = 4)


## -----------------------------------------------------------------------------
summary(model)


## -----------------------------------------------------------------------------
ci<-confint(model)
print(ci)

