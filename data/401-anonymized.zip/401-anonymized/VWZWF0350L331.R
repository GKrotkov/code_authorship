## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
cmu_sleep <- read.csv("~/Downloads/cmu-sleep-2.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
plot(dist ~ speed, data = cars,
     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## -----------------------------------------------------------------------------
hist(cmu_sleep$TotalSleepTime, main = "Total Sleep Time Histogram", xlab = "Minutes", ylab = "Frequency",breaks = 30)


## -----------------------------------------------------------------------------
hist(cmu_sleep$term_gpa,main = "Spring Semester GPA Histogram", xlab = "GPA", ylab = "Frequency",breaks = 20)

## -----------------------------------------------------------------------------
hist(cmu_sleep$cum_gpa,main = "Fall Semester GPA Histogram", xlab = "GPA", ylab = "Frequency",breaks = 20)


## -----------------------------------------------------------------------------
library(ggplot2)
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  geom_smooth(method="lm",formula = y ~ x,se = FALSE,color = "blue")
  labs(x = "Total Sleep Time", y = "Spring Sem GPA", title = "Scatterplot of Total Sleep Time vs. Spring Sem GPA")
model1 = lm(term_gpa~TotalSleepTime,data=cmu_sleep)


## -----------------------------------------------------------------------------
ggplot(data = cmu_sleep, aes(x = cum_gpa, y = term_gpa)) +
  geom_point() +
  geom_smooth(method="lm",formula = y ~ x,se = FALSE,color = "blue")
  labs(x = "Fall Semester GPA", y = "Spring Semester GPA", title = "Scatterplot of Fall Sem GPA vs. Spring Sem GPA")


## -----------------------------------------------------------------------------
ggplot(data = cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  geom_smooth(method="lm",formula = y ~ poly(x, 2),se = FALSE,color = "blue") +
  labs(x = "Total Sleep Time", y = "Spring Sem GPA", title = "Scatterplot of Total Sleep Time vs. Spring Sem GPA")
model2 = lm(term_gpa~poly(TotalSleepTime,2),data=cmu_sleep)


## -----------------------------------------------------------------------------
plot(cmu_sleep$term_gpa, residuals(model1), xlab = "Spring Sem GPA", ylab = "Residuals", main = "Residuals vs Spring Sem GPA")


## -----------------------------------------------------------------------------
plot(cmu_sleep$term_gpa, residuals(model2), xlab = "Spring Sem GPA", ylab = "Residuals", main = "Residuals vs Spring Sem GPA")


## ---- fig.width = 4, fig.height = 3, fig.cap = "Normal QQ-plot"---------------
plot(model1, which = 2)
plot(model2, which = 2)


## -----------------------------------------------------------------------------
hist(residuals(model1))
hist(residuals(model2))


## -----------------------------------------------------------------------------
summary(model1)


## -----------------------------------------------------------------------------
two_hour_sleep <- data.frame(TotalSleepTime = c(mean(cmu_sleep$TotalSleepTime) - 20, mean(cmu_sleep$TotalSleepTime)))


## -----------------------------------------------------------------------------
predict(model1, newdata = two_hour_sleep, interval = "confidence", level = 0.95)

