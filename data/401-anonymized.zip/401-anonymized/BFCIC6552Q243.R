## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## ---- include=FALSE, message=FALSE--------------------------------------------
library(dplyr)
library(ggplot2)
library(latex2exp)
library(modelsummary)
library(knitr)
library(GGally)

# Import dataset
rateprof <- alr4::Rateprof


## ---- out.width="50%", message=FALSE------------------------------------------
# Histogram of quality ratings
title <- ggtitle("Frequency of quality ratings")
xlabel <- xlab("Quality rating (scale of 1 to 5)")
ylabel <- ylab("Frequency")
ggplot(data = rateprof, aes(x = quality)) + 
  geom_histogram(binwidth=0.05) + title + xlabel + ylabel +
  labs(caption = "Figure 1: Quality is normally distributed") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

# Histogram of easiness
title <- ggtitle("Frequency of course easiness")
xlabel <- xlab("Easiness (scale of 1 to 5)")
ylabel <- ylab("Frequency")
ggplot(data = rateprof, aes(x = easiness)) + 
  geom_histogram(binwidth=0.05) + title + xlabel + ylabel +
  labs(caption = "Figure 2: Course easiness is normally distributed") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

# Histogram of instructor attractiveness
title <- ggtitle("Frequency of instructor attractiveness")
xlabel <- xlab("Attractive")
ylabel <- ylab("Frequency")
ggplot(data = rateprof, aes(x = pepper)) + 
  geom_bar() + 
  scale_x_discrete(labels=c("No","Yes"))+
  title + xlabel + ylabel +
  labs(caption = "Figure 3: Instructors are not found attractive on average") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

# Histogram of instructor gender
title <- ggtitle("Frequency of instructor gender")
xlabel <- xlab("Gender")
ylabel <- ylab("Frequency")
ggplot(data = rateprof, aes(x = gender)) + 
  geom_bar() + 
  scale_x_discrete(labels=c("Female","Male")) +
  title + xlabel + ylabel +
  labs(caption = "Figure 4: Genders are about equally distributed") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))


## ---- out.width="50%", message=FALSE------------------------------------------
# Histogram of discipline
title <- ggtitle("Frequency of course discipline")
xlabel <- xlab("Discipline")
ylabel <- ylab("Frequency")
ggplot(data = rateprof, aes(x = discipline)) + 
  geom_bar() + 
  scale_x_discrete(labels=c("Humanities","Social Sciences","STEM","Pre-professional")) +
  title + xlabel + ylabel +
  labs(caption = "Figure 5: Humanities are over-represented") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

# Quality and easiness
title <- ggtitle("Quality versus course easiness")
xlabel <- xlab("Average course easiness (scale of 1 to 5)")
ylabel <- ylab("Average quality (scale of 1 to 5)")
ggplot(data = rateprof, aes(x = easiness, y = quality)) + 
  geom_point() + title + xlabel + ylabel +
  labs(caption = "Figure 6: Positive relationship between quality and easiness ratings") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))


## ---- out.width="50%"---------------------------------------------------------
# Quality and discipline
title <- ggtitle("Quality versus course discipline")
xlabel <- xlab("Course discipline")
ylabel <- ylab("Average quality (scale of 1 to 5)")
ggplot(data = rateprof, aes(x = discipline, y = quality)) + 
  geom_boxplot() + 
  scale_x_discrete(labels=c("Humanities","Social Sciences","STEM","Pre-professional")) +
  title + xlabel + ylabel +
  labs(caption = "Figure 7: No significant quality difference across disciplines") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

# Easiness versus discipline
title <- ggtitle("Course easiness versus discipline")
xlabel <- xlab("Course discipline")
ylabel <- ylab("Course easiness (scale of 1 to 5)")
ggplot(data = rateprof, aes(x = discipline, y = easiness)) + 
  geom_boxplot() + 
  scale_x_discrete(labels=c("Humanities","Social Sciences","STEM","Pre-professional")) +
  title + xlabel + ylabel +
  labs(caption = "Figure 8: No significant easiness difference across disciplines") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))


## ---- out.width="50%"---------------------------------------------------------
# Quality and gender
title <- ggtitle("Quality versus instructor gender")
xlabel <- xlab("Instructor gender")
ylabel <- ylab("Average quality (scale of 1 to 5)")
ggplot(data = rateprof, aes(x = gender, y = quality)) + 
  geom_boxplot() + 
  scale_x_discrete(labels=c("Female","Male")) +
  title + xlabel + ylabel +
  labs(caption = "Figure 9: No significant quality difference between genders") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

# Easiness versus gender
title <- ggtitle("Course easiness versus instructor gender")
xlabel <- xlab("Instructor gender")
ylabel <- ylab("Course easiness (scale of 1 to 5)")
ggplot(data = rateprof, aes(x = gender, y = easiness)) + 
  geom_boxplot() + 
  scale_x_discrete(labels=c("Female","Male")) +
  title + xlabel + ylabel +
  labs(caption = "Figure 10: No significant course easiness difference between genders") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))


## ---- out.width="50%"---------------------------------------------------------
# Quality and pepper
title <- ggtitle("Quality versus instructor attractiveness")
xlabel <- xlab("Instructor attractiveness")
ylabel <- ylab("Average quality (scale of 1 to 5)")
ggplot(data = rateprof, aes(x = pepper, y = quality)) + 
  geom_boxplot() + title + xlabel + ylabel +
  labs(caption = "Figure 11: Significant difference in quality ratings based on attractiveness") +  
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))


## ---- out.width="50%"---------------------------------------------------------
model <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = rateprof)

title <- ggtitle("Residuals versus fitted values")
xlabel <- xlab("Fitted values")
ylabel <- ylab("Residuals")
ggplot(data = model, aes(x = model$fitted.values,
                         y = model$residuals)) +
  geom_point() + title + xlabel + ylabel + labs(caption = "Figure 12: Residuals appear linear, but slightly heteroskedastic") +
  theme(title = element_text(size = 15), plot.caption = element_text(size = 15))

qqnorm(model$residuals)
qqline(model$residuals)


## -----------------------------------------------------------------------------
model.summary <- summary(model)
coefs <- model.summary$coefficients
df <- as.data.frame(coefs)
knitr::kable(df, digits = 2, col.names = c("Estimate", "Std. Error", "t value", "Pr(>|t|)"),
             caption="Model Summary")

