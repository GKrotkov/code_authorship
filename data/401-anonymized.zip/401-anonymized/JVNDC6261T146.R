## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(patchwork)
library(broom)
library(modelsummary)


## -----------------------------------------------------------------------------
df <- read.csv("~/Downloads/cmu-sleep.csv")


## ----warning=FALSE------------------------------------------------------------
hist(df$TotalSleepTime,
  xlab = "Total sleep time (min)",
  ylab = "Frequency",
  main = "Students' total sleep time (minutes)")


## -----------------------------------------------------------------------------
g2 <- ggplot(df, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.5) +
  labs(x = "Cumulated GPA", y = "Count",
  title = "Students' cumulated gpa")
g2


## -----------------------------------------------------------------------------
hist(df$term_gpa,
  xlab = "Students' term gpa",
  ylab = "Frequency",
  main = "Students' term GPA")


## ----figure.wdith=10, fig.height=4--------------------------------------------
ggplot(df, aes(x = log(TotalSleepTime), y = cum_gpa)) +
  geom_point() +
  labs(x = "total sleep time",
  y = "Cumulated gpa",
  title = "Cumulated gpa vs. sleep time")


## -----------------------------------------------------------------------------
ggplot(df, aes(x = log(TotalSleepTime), y = term_gpa)) +
  geom_point()+
  geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
  labs(x = "total sleep time",
  y = "term gpa",
  title = "Term gpa vs. sleep time")


## -----------------------------------------------------------------------------
model_cum_gpa <- lm(cum_gpa ~ log(TotalSleepTime), data = df)
model_term_gpa <- lm(term_gpa ~ log(TotalSleepTime), data = df)
summary(model_cum_gpa)
summary(model_term_gpa)



## -----------------------------------------------------------------------------
modelsummary(list("termgpa"=model_term_gpa, "cum gpa"= model_cum_gpa))

## -----------------------------------------------------------------------------

cum_gpa_CI <- predict(model_cum_gpa, newdata = data.frame(TotalSleepTime = 397.3239), 
                      level = 0.95,
                      interval = "confidence")

cum_gpa_CI [1,1]
cum_gpa_CI [1,2] #lower bound
cum_gpa_CI [1,3] # upper bound


## -----------------------------------------------------------------------------
tidy_cum_gpa <- tidy(model_cum_gpa)
tidy_term_gpa <- tidy(model_term_gpa)

# Combine data into one dataframe
heavy_fits <- rbind(
  data.frame(term = "cum_gpa", estimate = residuals(model_cum_gpa)),
  data.frame(term = "term_gpa", estimate = residuals(model_term_gpa))
)

# Create the Q-Q plot
ggplot(heavy_fits, aes(sample = estimate)) +
  geom_qq() +
  geom_qq_line() +
  facet_wrap(vars(term), scales = "free_y") +
  labs(x = "Theoretical quantiles", y = "Observed quantiles", title = "Q-Q Plot for Model Residuals")

