## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo = FALSE, message=FALSE---------------------------------------------
library(ggplot2)
library(alr4)
library(car) 
library(lmtest)
library(modelsummary)
library(patchwork)
library(knitr)


## -----------------------------------------------------------------------------
# Set up the plot layout
par(mfrow=c(2, 2))  # Adjust the number of rows as needed

# Bar plot for Gender Distribution
barplot(table(Rateprof$gender), main="Gender Distribution", xlab="Gender", ylab="Count", col=c("blue", "red"))

# Bar plot for Discipline Distribution
barplot(table(Rateprof$discipline), main="Discipline Distribution", xlab="Discipline", ylab="Count", las=2)

# Histogram for Attractiveness ('pepper')
hist(as.numeric(Rateprof$pepper), main="Histogram of Attractiveness (Pepper)", xlab="Attractiveness", breaks=2)

# Histogram for Quality Ratings
hist(Rateprof$quality, main="Histogram of Quality Ratings", xlab="Quality Rating")

# Histogram for Helpfulness Ratings
hist(Rateprof$helpfulness, main="Histogram of Helpfulness Ratings", xlab="Helpfulness Rating")

# Histogram for Clarity Ratings
hist(Rateprof$clarity, main="Histogram of Clarity Ratings", xlab="Clarity Rating")

# Histogram for Easiness Ratings
hist(Rateprof$easiness, main="Histogram of Easiness Ratings", xlab="Easiness Rating")

# Reset the plotting layout to default (optional)
par(mfrow=c(1, 1))



## -----------------------------------------------------------------------------
par(mfrow=c(1, 2))

# Boxplot for Quality Ratings by Gender
boxplot(quality ~ gender, data=Rateprof, 
        main="Quality Ratings by Gender", 
        ylab="Quality Rating", xlab="Gender", 
        col=c("lightblue", "lightpink"))

# Boxplot for Quality Ratings by Discipline
boxplot(quality ~ discipline, data=Rateprof, 
        main="Quality Ratings by Discipline", 
        ylab="Quality Rating", xlab="Discipline", 
        col=rainbow(4), las=2)

# Scatterplot for Quality vs. Easiness
p1 <- ggplot(Rateprof, aes(x = easiness, y = quality)) +
   geom_point() +
    labs(title = "Quality vs. Easiness",
         x = "Easiness Rating",
         y = "Quality Rating") 
   

# Scatterplot for Quality vs. Clarity 
p2 <- ggplot(Rateprof, aes(x = clarity, y = quality)) +
    geom_point() +
    labs(title = "Quality vs. Clarity",
        x = "Clarity Rating",
        y = "Quality Rating") 
    

# Scatterplot for Quality vs. Helpfulness 
p3 <- ggplot(Rateprof, aes(x = helpfulness, y = quality)) +
   geom_point() +
    labs(title = "Quality vs. Helpfulness",
        x = "Helpfulness Rating",
        y = "Quality Rating") 
   

# Scatterplot for Quality vs. Rater Interest
p4 <- ggplot(Rateprof, aes(x = raterInterest, y = quality)) +
    geom_point() +
    labs(title = "Quality vs. Rater Interest",
        x = "Rater Interest",
         y = "Quality Rating") 


combined_plot <- p1 + p2 + p3 + p4 + plot_layout(ncol = 2, nrow = 2)

print(combined_plot)



## -----------------------------------------------------------------------------
# Convert categorical variables to factors for the regression analysis
Rateprof$gender <- factor(Rateprof$gender)
Rateprof$pepper <- factor(Rateprof$pepper)
Rateprof$discipline <- factor(Rateprof$discipline)

# Fit the initial linear model with main effects
initial_model <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

# Fit the model with interaction terms
interaction_model <- lm(quality ~ gender * easiness + discipline * easiness + pepper, data = Rateprof)

modelsummary(list("Initial Model" = initial_model, 
                  "Interaction Model" = interaction_model),
             output = "markdown") 

confint(initial_model)
confint(interaction_model)


## -----------------------------------------------------------------------------
# Compare the initial and interaction models
anova_result <- anova(initial_model, interaction_model)
kable(anova_result, caption = "ANOVA Comparison of Models")


## -----------------------------------------------------------------------------
# Model diagnostics
par(mfrow=c(1, 2))
# Plot residuals to check for homoscedasticity and independence
plot(interaction_model $residuals, ylab = "Residuals", xlab = "Fitted values", main = "Residuals vs Fitted")
abline(h = 0, col = "red")

# Q-Q plot for normality check
qqPlot(interaction_model , main = "Q-Q Plot for Model Residuals")


