## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
cmu_sleep = read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
hist(cmu_sleep$TotalSleepTime, main="Histogram of Total Sleeping Time", xlab="Total Sleep Time (min)", ylab="Count of Sleep Times (by bin)", breaks=15, col = "cadetblue2")


## -----------------------------------------------------------------------------
hist(cmu_sleep$cum_gpa, main="Histogram of Cumulative GPA", xlab="Cumulative GPA (Grade Points)", ylab="Count of Cumulative GPA (by bin)", breaks=15, col = "coral1")


## -----------------------------------------------------------------------------
hist(cmu_sleep$term_gpa, main="Histogram of Term GPA", xlab="Term GPA (Grade Points)", ylab="Count of Term GPA (by bin)", breaks=15, col = "darkolivegreen2")


## ---- fig.width=4, fig.height=4, fig.cap="Relationship between total sleeping time and term GPA"----
plot(term_gpa ~ TotalSleepTime, data = cmu_sleep,
     xlab = "Total Sleeping Time (min)", ylab = "Term GPA (GPA Units)", main = "Total Sleeping Time vs. Term GPA")


## ---- fig.width=5, fig.height=4, fig.cap="Relationship between total sleeping time and term GPA"----
plot(cum_gpa ~ TotalSleepTime, data = cmu_sleep,
     xlab = "Total Sleeping Time (min)", ylab = "Cumulative GPA (GPA Units)", main = "Total Sleeping Time vs. Cumulative GPA")


## -----------------------------------------------------------------------------
gpa_lm = lm(term_gpa ~ TotalSleepTime, data=cmu_sleep)


## ---- fig.cap = "Plot of the residuals vs. fitted values of our model"--------
plot(gpa_lm, which=1)


## -----------------------------------------------------------------------------
set.seed(1)
qqnorm(cmu_sleep$term_gpa, pch = 1, frame = FALSE)
qqline(cmu_sleep$term_gpa, col = "steelblue", lwd = 2)

