## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(readr)
cmu_sleep <- read_csv("cmu-sleep.csv")


## ----include = FALSE----------------------------------------------------------
library(ggplot2)
library(dplyr)
library(gridExtra)



## ---- fig.width=5, fig.height=3,fig.cap="Distributions of Total Sleep Time, Term GPA, and Cumulative GPA"----

histogram1= ggplot(cmu_sleep, aes(x = TotalSleepTime)) +
  geom_histogram(fill = "turquoise", color = "black",binwidth = 20) +
  labs(x = "Total Sleep Time (minutes)", y="Frequency")

histogram2= ggplot(cmu_sleep, aes(x = term_gpa)) +
  geom_histogram(fill = "lightblue", color = "black",binwidth = 0.25) +
  labs(x = "Term GPA (out of 4.0)", y="Frequency")

histogram3= ggplot(cmu_sleep, aes(x = cum_gpa)) +
  geom_histogram(fill = "darkblue", color = "black",binwidth = 0.2) +
  labs(x = "Cumulative GPA(out of 4.0)", y="Frequency")


grid.arrange(histogram1, histogram2, histogram3, ncol = 2)




## ---- fig.width=5, fig.height=3,fig.cap="Transformed (log and square root) Histograms for Term GPA and Cummulative GPA"----
cmu_sleep$log_term_gpa =log(cmu_sleep$term_gpa)
cmu_sleep$log_cum_gpa =log(cmu_sleep$cum_gpa)

histogram4= ggplot(cmu_sleep, aes(x = log_term_gpa)) +
  geom_histogram(fill = "lightblue", color = "black",binwidth = 0.1) +
  labs( x = "log(Term GPA (out of 4.0))", y="Frequency")

histogram5= ggplot(cmu_sleep, aes(x = log_cum_gpa)) +
  geom_histogram(fill = "lightblue", color = "black",binwidth = 0.1) +
  labs( x = "log(Cumulative GPA (out of 4.0))", y="Frequency")

cmu_sleep$sqrt_term_gpa =sqrt(cmu_sleep$term_gpa)
cmu_sleep$sqrt_cum_gpa =sqrt(cmu_sleep$cum_gpa)

histogram6= ggplot(cmu_sleep, aes(x = sqrt_term_gpa)) +
  geom_histogram(fill = "darkblue", color = "black",binwidth = 0.1) +
  labs( x = "sqrt(Term GPA (out of 4.0))", y="Frequency")

histogram7= ggplot(cmu_sleep, aes(x = sqrt_cum_gpa)) +
  geom_histogram(fill = "darkblue", color = "black",binwidth = 0.1) +
  labs( x = "sqrt(Cumulative GPA (out of 4.0))", y="Frequency")


grid.arrange(histogram4, histogram6, histogram5,histogram7, ncol = 2)



## ----fig.align='center', fig.pos='h', fig.width=5, fig.height=3, fig.cap="Scatterplots for Sleep Time vs Term GPA"----
scatterplot1= ggplot(cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(shape = 1, color = "turquoise") + 
  labs(
       x = "Total Sleep Time (minutes)",
       y = "Term GPA (out of 4.0)") +
  theme_minimal()+
  theme(axis.title.x = element_text(size = 7),axis.title.y = element_text(size = 7))

scatterplot2= ggplot(cmu_sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(shape = 1, color = "turquoise") + 
  labs(
       x = "Total Sleep Time (minutes)",
       y = "log (Term GPA (out of 4.0))") +
  theme_minimal()+ 
  theme(axis.title.x = element_text(size = 7),axis.title.y = element_text(size = 7))

scatterplot3= ggplot(cmu_sleep, aes(x = TotalSleepTime, y = sqrt_term_gpa)) +
  geom_point(shape = 1, color = "turquoise") + 
  labs(
       x = "Total Sleep Time (minutes)",
       y = "sqrt (Term GPA (out of 4.0))") +
  theme_minimal()+
  theme(axis.title.x = element_text(size = 7),axis.title.y = element_text(size = 7))


grid.arrange(scatterplot1,scatterplot2, scatterplot3, ncol = 2)



## ---- fig.align='center', fig.width=6, fig.height=4, fig.cap="Boxplot of Student Information vs Term GPA"----

cmu_sleep_cleaned <- na.omit(cmu_sleep)


boxplot1= boxplot_gender_split <- ggplot(cmu_sleep_cleaned, aes(x = factor(demo_gender), y = term_gpa, fill = factor(demo_gender))) +
  geom_boxplot() +
  labs(x = "Gender", y = "Term GPA (out of 4.0)") +
  scale_fill_manual(values = c("0" = "lightgreen", "1" = "darkgreen")) +
  scale_x_discrete(labels = c("0" = "Male", "1" = "Female")) +
  theme(legend.position = "none")

cmu_sleep_cleaned <- na.omit(cmu_sleep) %>%
  filter(demo_firstgen %in% c(0, 1))

boxplot2= boxplot_firstgen_split <- ggplot(cmu_sleep_cleaned, aes(x = factor(demo_firstgen), y = term_gpa, fill = factor(demo_firstgen))) +
  geom_boxplot() +
  labs( x = "First-Generation Status", y = "Term GPA (out of 4.0)") +
  scale_fill_manual(values = c("0" = "lightgreen", "1" = "darkgreen")) +
  scale_x_discrete(labels = c("0" = "Non-First-Gen", "1" = "First-Gen")) +
  theme(legend.position = "none")


cmu_sleep_cleaned <- na.omit(cmu_sleep) %>%
  filter(demo_race %in% c(0, 1))

boxplot3= boxplot_race_split <- ggplot(cmu_sleep_cleaned, aes(x = factor(demo_race), y = term_gpa, fill = factor(demo_race))) +
  geom_boxplot() +
  labs(x = "Underrepresented Status", y = "Term GPA (out of 4.0)") +
  scale_fill_manual(values = c("1" = "lightgreen", "0" = "darkgreen")) +
  scale_x_discrete(labels = c("1" = "Non-Underrepresented", "0" = "Underrepresented")) +
  theme(legend.position = "none")


grid.arrange(boxplot1,boxplot2, boxplot3, ncol = 2)



## ---- fig.align='center', fig.width=4, fig.height=3, fig.cap="Differences in GPA for Term vs Cumulative"----

ggplot(cmu_sleep, aes(x = factor(1), y = term_gpa, fill = "Term GPA")) +
  geom_boxplot(width = 0.2) +
  geom_boxplot(aes(x = factor(2), y = cum_gpa, fill = "Cumulative GPA"), width = 0.2) +
  scale_x_discrete(labels = c("Term GPA", "Cumulative GPA")) +
  labs(x = "GPA Type", y = "GPA Value") +
  scale_fill_manual(values = c("Term GPA" = "lightgreen", "Cumulative GPA" = "darkgreen"))+
  theme_minimal()


  


## ----fig.align='center',fig.width=6, fig.height=3.5,fig.cap="Diagnostics for Linear Regression: Predictor vs Residuals "----
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = cmu_sleep)
residuals <- resid(model)

plot1=plot(cmu_sleep$cum_gpa, residuals, xlab = "Cumulative GPA", ylab = "Residuals",
     main = "Residuals vs. Cumulative GPA")
abline(h = 0, col = "darkblue", lty = 2)




## ---- fig.align='center', fig.width=6, fig.height=3.5, fig.cap="Diagnostics for Linear Regression: Fitted Values vs Residuals "----
par(mfrow = c(1, 1))  
residuals <- resid(model)
plot2=plot(residuals, main = "Normal Residual Plot", xlab = "Fitted Values", ylab = "Residuals")


## ---- include = FALSE---------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = cmu_sleep)
summary(model)



