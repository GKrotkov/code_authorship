## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(alr4)
library(tidyverse)
library(dplyr)


## ---- include = FALSE---------------------------------------------------------
rate_df = Rateprof
colnames(rate_df)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Quality Distribution"----
hist(rate_df$quality, main = "Professor Quality Distribution", xlab = "Quality", cex.main = 0.8)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Clarity Distribution"----
hist(rate_df$clarity, main = "Professor Clarity Distribution", xlab = "Clarity", cex.main = 0.8)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Helpfulness Distribution"----
hist(rate_df$helpfulness, main = "Professor Helpfulness Distribution", xlab = "Helpfulness", cex.main = 0.8)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Number of Raters Distribution"----
hist(rate_df$numRaters, main = "Professor Number of Raters Distribution", xlab = "Number of Raters", cex.main = 0.7)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Number of Courses Distribution"----
hist(rate_df$numCourses, main = "Professor Number of Courses Distribution", xlab = "Number of Courses", cex.main = 0.7)


## ---- fig.width=3, fig.height=2.53, fig.cap="Professor Rater Interest Distribution"----
hist(rate_df$raterInterest, main = "Professor Rater Interest Distribution", xlab = "Rater Interest", cex.main = 0.8)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Easiness Distribution"----
hist(rate_df$easiness, main = "Professor Easiness Distribution", xlab = "Easiness", cex.main = 0.8)


## ---- fig.width=3, fig.height=2.5, fig.cap="Professor Number of Years of Rating Distribution"----
hist(rate_df$numYears, main = "Professor Number of Years of Rating Distribution", xlab = "Number of Years of Rating", cex.main =0.6)


## ---- fig.width=3, fig.height=2.5, fig.cap = "Side by Side Plot of Quality vs Gender"----
boxplot(quality ~ gender, data = rate_df,
        main = "Side by Side Plot of Quality vs Gender", xlab = "Gender", ylab = "Quality",
        col = c("Red", "Blue"), cex.main = 0.7)


## ---- fig.width=3, fig.height=2.5, fig.cap = "Side by Side Plot of Quality vs Discipline"----
boxplot(quality ~ discipline, data = rate_df,
        main = "Side by Side Plot of Quality vs Discipline", xlab = "Discipline", ylab = "Quality",
        col = c("Red", "Blue", "Green", "Yellow"), cex.main = 0.7, cex.axis = 0.5)


## ---- fig.width=3, fig.height=2.5, fig.cap = "Side by Side Plot of Quality vs Professor Attractiveness"----
boxplot(quality ~ pepper, data = rate_df,
        main = "Side by Side Plot of Quality vs Professor Attractiveness", xlab = "Professor Attractiveness", ylab = "Quality",
        col = c("Red", "Blue"), cex.main = 0.6)


## ---- include = FALSE---------------------------------------------------------
rate_df$lograte = log(rate_df$numRaters)
rate_df$logcourse = log(rate_df$numCourses)


## ---- fig.width=12, fig.height=8, fig.cap="Pairs Plot of Variables"-----------
pairs(rate_df[c("quality", "numYears", "lograte", "logcourse", "clarity", "helpfulness", "easiness", "raterInterest")])


## ---- include=FALSE-----------------------------------------------------------
rate_fit = lm(quality ~ easiness + raterInterest + discipline + pepper + gender + easiness:gender + easiness:discipline, data = rate_df)


## ---- fig.width=4, fig.height=3, fig.cap="Resdiduals vs. Fitted"--------------
plot(rate_fit, which = 1)


## ---- fig.width=4, fig.height=3, fig.cap="Cook's Distance Plot"---------------
plot(rate_fit, which = 4)


## ---- include = FALSE---------------------------------------------------------
discfull_red_fit = lm(quality ~ easiness + raterInterest + pepper + gender + easiness:gender, data = rate_df)

disc_red_fit = lm(quality ~ easiness + raterInterest + discipline + pepper + gender + easiness:gender, data = rate_df)

gend_red_fit = lm(quality ~ easiness + raterInterest + discipline + pepper + gender + easiness:discipline, data = rate_df)

summary(rate_fit)

anova(disc_red_fit, rate_fit)

anova(gend_red_fit, rate_fit)

confint(rate_fit, "pepperyes", 0.95)
confint(rate_fit, "easiness", 0.95)


anova(discfull_red_fit, rate_fit)

confint(rate_fit, "disciplineSocSci", 0.95)
confint(rate_fit, "disciplineSTEM", 0.95)
confint(rate_fit, "disciplinePre-prof", 0.95)

