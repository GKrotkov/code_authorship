## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- echo=FALSE, include = FALSE---------------------------------------------
library(ggplot2)
library(tidyverse)
data = read.csv('cmu-sleep.csv')
data = subset.data.frame(data, select = c("TotalSleepTime", "term_gpa", "cum_gpa"))


## ---- echo = FALSE, results = 'asis'------------------------------------------
data %>%
  ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(bins = 30, color = 'black', fill = 'grey') +
  labs(title = "Student Sleep Distribution",
       x = "Total Sleep Time (Minutes)",
       y = "Frequency",
       caption = "Figure 1: Average amount of sleep students obtained per night in minutes.") +
  theme(plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(hjust = 0.5))


## ---- echo = FALSE, results = 'asis'------------------------------------------
data %>%
  ggplot(aes(x = term_gpa)) +
  geom_histogram(bins = 35, color = 'black', fill = 'grey') +
  labs(title = "Student GPA Distribution During Study",
       x = "GPA (out of 4.0)",
       y = "Frequency",
       caption = "Figure 2: Student GPAs obtained during the study.") +
  theme(plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(hjust = 0.5)) +
  scale_x_continuous(breaks = seq(0, 4, by = 0.5))


## ---- echo = FALSE, results = 'asis'------------------------------------------
data %>%
  ggplot(aes(x = cum_gpa)) +
  geom_histogram(bins = 35, color = 'black', fill = 'grey') +
  labs(title = "Student Cumulative GPA Distribution",
       x = "GPA (out of 4.0)",
       y = "Frequency",
       caption = "Figure 3: Student cumulative GPAs obtained prior to the study.") +
  theme(plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(hjust = 0.5)) +
  scale_x_continuous(breaks = seq(0, 4, by = 0.5))


## ---- echo = FALSE, results = 'asis'------------------------------------------
data %>%
  ggplot(aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  labs(title = "Student GPA Distribution During Study",
       x = "Average Amount of Sleep Obtained per Night (Minutes)",
       y = "Student GPA During Study",
       caption = "Figure 4: Scatterplot depicting the relationship between student GPAs \n obtained during the study and the average amount of sleep obtained per night (in minutes).") +
  theme(plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(hjust = 0.5)) +
  scale_y_continuous(breaks = seq(0, 5, by = 0.5)) +
  geom_smooth(method = "lm", se = FALSE)


## ---- echo = FALSE, results = 'asis'------------------------------------------
data %>%
  ggplot(aes(x = TotalSleepTime, y = cum_gpa)) +
  geom_point() +
  labs(title = "Student GPA Distribution Prior to Study",
       x = "Average Amount of Sleep Obtained per Night (Minutes)",
       y = "Student GPA Prior to Study",
       caption = "Figure 5: Scatterplot depicting the relationship between student GPAs \n obtained prior to the study and the average amount of sleep obtained per night (in minutes).") +
  theme(plot.caption = element_text(hjust = 0.5),
        plot.title = element_text(hjust = 0.5)) +
  scale_y_continuous(breaks = seq(0, 5, by = 0.5)) +
  geom_smooth(method = "lm", se = FALSE)


## ---- echo = FALSE, results = 'asis', include = FALSE-------------------------
cum_fit = lm(cum_gpa ~ TotalSleepTime, data = data)
cum_gpa_coef = coef(cum_fit)["cum_gpa"]
summary(cum_fit)

term_fit = lm(term_gpa ~ TotalSleepTime, data = data)
term_gpa_coef = coef(term_fit)["term_gpa"]
summary(term_fit)


## ---- echo = FALSE, results = 'asis'------------------------------------------
# Cumulative
qqnorm(residuals(cum_fit), main = "Cumulative GPA QQ Plot",
       ylab = "Residual Amount")
qqline(residuals(cum_fit))
plot(residuals(cum_fit), 
     main = "Cumulative GPA Regression Residual Plot", 
     xlab = "Point Index",
     ylab = "Residual Value")
# Term
qqnorm(residuals(term_fit), main = "Cumulative GPA QQ Plot",
       ylab = "Residual Amount")
qqline(residuals(term_fit))
plot(residuals(term_fit), 
     main = "Term GPA Regression Residual Plot", 
     xlab = "Point Index",
     ylab = "Residual Value")


## ---- echo = FALSE, results = 'asis', include = FALSE-------------------------
# Cumulative GPA
# Upper
0.0009497 + (qt(1 - 0.05 / 2, df = 632) * 0.0003402)
# Lower
0.0009497 - (qt(1 - 0.05 / 2, df = 632) * 0.0003402)

# Term GPA
# Upper
0.0019846 + (qt(1 - 0.05 / 2, df = 632) * 0.0003834)
# Lower
0.0019846 - (qt(1 - 0.05 / 2, df = 632) * 0.0003834)


