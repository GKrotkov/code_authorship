## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(ggplot2)


## -----------------------------------------------------------------------------
?Rateprof


## -----------------------------------------------------------------------------
Rateprof$gender = factor(Rateprof$gender)
Rateprof$pepper = factor(Rateprof$pepper)
Rateprof$discipline = factor(Rateprof$discipline)


## -----------------------------------------------------------------------------
summary(Rateprof$quality)


## -----------------------------------------------------------------------------
summary(Rateprof$gender)


## -----------------------------------------------------------------------------
summary(Rateprof$pepper)


## -----------------------------------------------------------------------------
summary(Rateprof$easiness)


## -----------------------------------------------------------------------------
summary(Rateprof$discipline)


## -----------------------------------------------------------------------------
hist(Rateprof$quality, main = "Figure 1: Histogram of 
     Instructor's Quality Ratings",
     xlab = "Instructor Quality Rating (between 1 and 5)",
     ylab = "Frequency")


## -----------------------------------------------------------------------------
barplot(table(Rateprof$gender), main = "Figure 2: Histogram of
        Instructor's Genders",
     xlab = "Instructor Gender (male or female)",
     ylab = "Frequency")


## -----------------------------------------------------------------------------
barplot(table(Rateprof$pepper), main = "Figure 3: Histogram of
        Instructor's Attractiveness",
     xlab = "Instructor Attractiveness (yes or no)",
     ylab = "Frequency")


## -----------------------------------------------------------------------------
hist(Rateprof$easiness, main = "Figure 4: Histogram of Instructor's Easiness",
     xlab = "Instructor Easiness (between 1 and 5)",
     ylab = "Frequency")


## -----------------------------------------------------------------------------
barplot(table(Rateprof$discipline), main = "Figure 5: Histogram of
        Instructor's Discipline",
     xlab = "Instructor Discipline",
     ylab = "Frequency")


## -----------------------------------------------------------------------------
ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot() + 
  labs(x = "Instructor Gender (male or female)",
  y = "Quality Rating (between 1 and 5)", 
  title = "Figure 6: Relationship Between Gender and Quality Rating") 

ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot() + 
  labs(x = "Instructor Attractiveness (yes or no)",
  y = "Quality Rating (between 1 and 5)", 
  title = "Figure 7: Relationship Between Attractiveness and Quality Rating") 

ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() + 
  labs(x = "Instructor Easiness (between 1 and 5)",
  y = "Quality Rating (between 1 and 5)", 
  title = "Figure 8: Relationship Between Easiness and Quality Rating") 

ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot() + 
  labs(x = "Instructor Discipline",
  y = "Quality Rating (between 1 and 5)", 
  title = "Figure 9: Relationship Between Discipline and Quality Rating") 


## -----------------------------------------------------------------------------
full_model = lm(quality ~ gender + pepper + easiness + discipline +
                  easiness:gender + easiness:discipline, data = Rateprof)

reduced_model =  lm(quality ~ gender + pepper + easiness + 
                      discipline, data = Rateprof)

anova(reduced_model, full_model)


## -----------------------------------------------------------------------------
final_model =  lm(quality ~ gender + pepper + easiness +
                    discipline, data = Rateprof)

plot(final_model, which = 1)
plot(final_model, which = 2)
plot(final_model, which = 4)


## -----------------------------------------------------------------------------
summary(final_model)
confint(final_model)

