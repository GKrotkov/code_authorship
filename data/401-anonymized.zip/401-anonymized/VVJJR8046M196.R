## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(dplyr)
library(ggplot2)
library(gridExtra)
library(broom)
library(kableExtra)
library(MASS)
library(GGally)
library(patchwork)
library(bestglm)
library(regressinator)
library(car)
library(palmerpenguins)
library(modelsummary)
library(knitr)
library("psych")
library(grid)




## -----------------------------------------------------------------------------
data(Rateprof)
?Rateprof



## ---- echo=FALSE--------------------------------------------------------------
data <- Rateprof[, c("gender", "pepper", "discipline", "easiness", "quality")]
key <- summary(data)

kable(key, digits = 2, caption = "Key Statistics of Rateprof", format = "latex", booktabs = TRUE) %>%
  kable_styling(
    position = "center",
    font_size = 12, 
    latex_options = c("striped", "HOLD_position")
  ) %>%
  column_spec(1, bold = TRUE) 



## ----combined-plot, fig.show='hold', out.width='100%', fig.height=2, fig.width=6,echo=FALSE----
p1 <- ggplot(Rateprof, aes(x = gender)) + 
  geom_bar(fill = "steelblue") + 
  labs(title = "Gender Distribution",
       caption="Fig 1 Histogram of the count of gender")+
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"),
        plot.caption = element_text(size = 5))

p2 <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(fill = "coral") +
  labs(title = "Pepper Distribution",
       caption="Fig 2 Histogram of the count of whether prof is attractive")+
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"),
        plot.caption = element_text(size = 5))

p3 <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill = "lightgreen") +
  labs(title = "Discipline Distribution",
      caption="Fig 3 Histogram of discipline of prof" )+
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"),
        plot.caption = element_text(size = 5))


combined_plots <- (p1 | p2 | p3) & theme(plot.margin = unit(c(0, 0, 0, 0), "cm"))

combined_plots



## ----combined-plot2, fig.show='hold', out.width='100%', fig.height=3, fig.width=6,echo=FALSE----
p4 <- ggplot(Rateprof, aes(x = easiness)) + 
  geom_bar(fill = "steelblue") + 
  labs(title = "Easiness Distribution",
       caption="Fig 4 Histogram of easiness of prof")+
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"),
        plot.caption = element_text(size = 5))

p5 <- ggplot(Rateprof, aes(x = quality)) +
  geom_bar(fill = "coral") +
  labs(title = "Quality Distribution",
       caption="Fig 5 Histogram of quality of prof")+
  theme(plot.margin = unit(c(1, 1, 1, 1), "cm"),
        plot.caption = element_text(size = 5))


combined_plots2 <- (p4 | p5) & theme(plot.margin = unit(c(0, 0, 0, 0), "cm"))

combined_plots2





## ---- out.width='100%',echo=FALSE,message= FALSE------------------------------
Rateprof %>%
  dplyr::select(quality, pepper, easiness, gender, discipline) %>%
  ggpairs()



## ----echo=FALSE,message=FALSE-------------------------------------------------
set.seed(36401)
full_model <- lm(quality ~ gender+pepper+discipline+easiness+gender * easiness + pepper * easiness + discipline * easiness, data = Rateprof)
reduced_model <- lm(quality ~ gender + easiness + pepper + discipline, data = Rateprof)
anova_result <- anova(reduced_model, full_model)


## ----echo=FALSE,message=FALSE,out.width='100%', fig.height=4------------------
par(mfrow=c(1, 3))
plot(cooks.distance(reduced_model),type="h", main="Cook's Distance")
plot(reduced_model, which=1)
plot(reduced_model,which=2)

mtext("Fig 7 Diagnostis on Model", outer = TRUE, side = 1, line = -1, adj = 1, cex = 0.8)


## ----echo=FALSE,message=FALSE-------------------------------------------------
kable(anova_result, digits = 2, caption = "Anova result", format = "latex", booktabs = TRUE) %>%
  kable_styling(
    position = "center",
    font_size = 12, 
    latex_options = c("striped", "HOLD_position")
  ) %>%
  column_spec(1, bold = TRUE) 


## ----echo=FALSE,message=FALSE-------------------------------------------------
model_summary <- broom::tidy(reduced_model, conf.int = TRUE)

kable(model_summary, digits = 2, 
      caption = "Confidence Intervals for Model Coefficients", 
      format = "latex", booktabs = TRUE) %>%
  kable_styling(
    position = "center",
    font_size = 12,
    latex_options = c("striped", "HOLD_position")
  ) %>%
  column_spec(1, bold = TRUE)

