## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(dplyr)
library(ggplot2)


## ----fig.width=10, fig.height=8,fig.cap="Histograms & Boxplots and Bar plots & Pie charts of variables"----
par(mfrow=c(6,2),mar=c(3,3,3,3))


barplot(table(Rateprof$gender), main="Bar Plot of Gender", xlab="Gender", ylab="Count")
pie(table(Rateprof$gender), main="Pie Chart of Gender", labels=c("male", "female"))


hist(Rateprof$numYears, 
     main="Histogram of Instructor Rating Years (1999-2009)",
     xlab="Number of Years with Ratings",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8) 
boxplot(Rateprof$numYears, 
        main="Boxplot of Instructor Rating Years (1999-2009)",
        ylab="numYears",
        col="lightblue")


hist(Rateprof$numRaters, 
     main="Histogram of Number of Ratings",
     xlab="Number of Ratings",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8) 
boxplot(Rateprof$numRaters, 
        main="Boxplot of Number of Ratings",
        ylab="numRaters",
        col="lightblue",
        cex.lab=0.8)   


hist(Rateprof$numCourses, 
     main="Histogram of Number of Courses",
     xlab="Number of Courses",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8)  
boxplot(Rateprof$numCourses, 
        main="Boxplot of Number of Courses",
        ylab="numCourses",
        col="lightblue",
        cex.lab=0.8)  


barplot(table(Rateprof$pepper), main="Bar Plot of Pepper (whether attractive)", xlab="pepper", ylab="Count")
pie(table(Rateprof$pepper), main="Pie Chart of Pepper (whether attractive)")


barplot(table(Rateprof$discipline), 
        main="Bar Plot of Discipline", 
        xlab="Discipline", 
        ylab="Count", 
        col="lightblue", 
        xaxt='n')  
axis(1, at=1:length(table(Rateprof$discipline)), 
     labels=names(table(Rateprof$discipline)), 
     cex.axis=0.7, 
     las=2) 
pie(table(Rateprof$discipline), main="Pie Chart of Discipline")






## ----fig.width=10, fig.height=8,fig.cap="Histograms & Boxplots and Bar plots & Pie charts of variables"----
par(mfrow=c(6,2),mar=c(3,3,3,3))


dept_counts <- table(Rateprof$dept)
top_depts <- sort(dept_counts, decreasing = TRUE)[1:6]
barplot(top_depts, 
        main="Top 10 Departments by Count",
        xlab="Count",
        ylab="Department",
        las=2, 
        col="lightblue", 
        cex.axis=0.2)
bottom_38 = names(sort(dept_counts)[1:42])
Rateprof$dept_combined = as.character(Rateprof$dept)
Rateprof$dept_combined[Rateprof$dept %in% bottom_38] = 'Other'
Rateprof$dept_combined = factor(Rateprof$dept_combined)
combined_dept_counts = table(Rateprof$dept_combined)
pie(combined_dept_counts, 
    main="Pie Chart of Department", 
    cex=0.7)


hist(Rateprof$quality, 
     main="Histogram of Quality",
     xlab="Quality",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8)  
boxplot(Rateprof$quality, 
        main="Boxplot of Quality",
        ylab="quality",
        col="lightblue",
        cex.main=0.6,
        cex.lab=0.8) 


hist(Rateprof$helpfulness, 
     main="Histogram of Helpfulness",
     xlab="Helpfulness",
     ylab="Frequency",
     col="lightblue")  
boxplot(Rateprof$helpfulness, 
        main="Boxplot of Helpfulness",
        ylab="helpfulness",
        col="lightblue",
        cex.main=0.6,
        cex.lab=0.8) 


hist(Rateprof$clarity, 
     main="Histogram of Clarity",
     xlab="clarity",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8) 
boxplot(Rateprof$clarity, 
        main="Boxplot of Clarity",
        ylab="clarity",
        col="lightblue",
        cex.main=0.6,
        cex.lab=0.8) 


hist(Rateprof$easiness, 
     main="Histogram of Easiness",
     xlab="Easiness",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8) 
boxplot(Rateprof$easiness, 
        main="Boxplot of Easiness",
        ylab="easiness",
        col="lightblue",
        cex.main=0.6,
        cex.lab=0.8) 


hist(Rateprof$raterInterest, 
     main="Histogram of raterInterest",
     xlab="raterInterest",
     ylab="Frequency",
     col="lightblue",
     cex.lab=0.8,
     cex.axis=0.8) 
boxplot(Rateprof$raterInterest, 
        main="Boxplot of raterInterest",
        ylab="raterInterest",
        col="lightblue",
        cex.main=0.6,
        cex.lab=0.8)  



## ----fig.width=10, fig.height=8,fig.cap="Boxplots & Scatterplots of predictors vs. quality"----
par(mfrow=c(6,2),mar=c(3,3,3,3))

boxplot(quality ~ gender, data = Rateprof,
        main = "Gender vs. Quality",
        xlab = "Gender",
        ylab = "Quality",
        col = "lightblue") 


plot(Rateprof$numYears, Rateprof$quality,
     main = "numYears vs. quality",
     xlab = "Number of Years",
     ylab = "Quality Rating",
     pch = 19)  


plot(Rateprof$numRaters, Rateprof$quality,
     main = "numRaters vs. quality",
     xlab = "Number of Raters",
     ylab = "Quality Rating",
     pch = 19)  


plot(Rateprof$numCourses, Rateprof$quality,
     main = "numCourses vs. quality",
     xlab = "Number of Courses",
     ylab = "Quality Rating",
     pch = 19)  


boxplot(quality ~ pepper, data = Rateprof,
        main = "Pepper vs. Quality",
        xlab = "Pepper",
        ylab = "Quality",
        col = "lightblue") 


boxplot(quality ~ discipline, data = Rateprof,
        main = "Discipline vs. Quality",
        xlab = "Discipline",
        ylab = "Quality",
        col = "lightblue") 


boxplot(quality ~ dept, data = Rateprof,
        main = "Department vs. Quality",
        xlab = "Department",
        ylab = "Quality",
        col = "lightblue") 


plot(Rateprof$helpfulness, Rateprof$quality,
     main = "helpfulness vs. quality",
     xlab = "helpfulness",
     ylab = "Quality Rating",
     pch = 19)


plot(Rateprof$clarity, Rateprof$quality,
     main = "clarity vs. quality",
     xlab = "clarity",
     ylab = "Quality Rating",
     pch = 19)


plot(Rateprof$easiness, Rateprof$quality,
     main = "easiness vs. quality",
     xlab = "easiness",
     ylab = "Quality Rating",
     pch = 19)


plot(Rateprof$raterInterest, Rateprof$quality,
     main = "raterInterest vs. quality",
     xlab = "raterInterest",
     ylab = "Quality Rating",
     pch = 19)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
Rateprof$quality2 <- Rateprof$quality^2
Rateprof$helpfulness2 <- Rateprof$helpfulness^2
Rateprof$clarity2 <- Rateprof$clarity^2

Rateprof$gender <- relevel(Rateprof$gender, ref = "male")
Rateprof$discipline <- relevel(Rateprof$discipline, ref = "Hum")
Rateprof$pepper <- relevel(Rateprof$pepper, ref = "no")


## ---- echo=FALSE, include=FALSE-----------------------------------------------
model <- lm(quality2 ~ factor(gender) + factor(discipline) + factor(pepper) + helpfulness2 + clarity2 + easiness + raterInterest + easiness:factor(gender) + easiness:factor(discipline), data = Rateprof)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
cooks_dist <- cooks.distance(model)

k <- length(coef(model))
n <- nrow(Rateprof)

critical_value <- qf(0.5, df1=k, df2=n-k)
outliers <- which(cooks_dist > critical_value)

k
n-k
outliers


## ---- echo=FALSE, include=FALSE-----------------------------------------------
Rateprof_cleaned <- Rateprof[-76, ]
model_cleaned <- lm(quality2 ~ factor(gender) + factor(discipline) + factor(pepper) + helpfulness2 + clarity2 + easiness + raterInterest + easiness:factor(gender) + easiness:factor(discipline), data = Rateprof_cleaned)


## ----fig.width=10, fig.height=5,fig.cap="Residuals & QQ plots"----------------
par(mfrow=c(1,2),mar=c(3,3,3,3))

residuals <- residuals(model_cleaned)
plot(residuals ~ fitted(model_cleaned),
     xlab = "Fitted Values",
     ylab = "Residuals",
     main = "Residuals vs Fitted Values")
abline(h = 0, col = "red")

qqnorm(residuals)
qqline(residuals)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
coef_estimate_gender_female <- coef(model_cleaned)["factor(gender)female"]
conf_interval_gender_female <- confint(model_cleaned)["factor(gender)female", ]
df_residuals <- df.residual(model_cleaned)
t_value_gender_female <- summary(model_cleaned)$coefficients["factor(gender)female", "t value"]
p_value_gender_female <- summary(model_cleaned)$coefficients["factor(gender)female", "Pr(>|t|)"]
std_error_gender_female <- summary(model_cleaned)$coefficients["factor(gender)female", "Std. Error"]

coef_estimate_gender_female
conf_interval_gender_female
df_residuals
t_value_gender_female
p_value_gender_female
std_error_gender_female


## ---- echo=FALSE, include=FALSE-----------------------------------------------
coef_estimate_pepper_yes <- coef(model_cleaned)["factor(pepper)yes"]
conf_interval_pepper_yes <- confint(model_cleaned, "factor(pepper)yes")
t_value_pepper_yes <- summary(model_cleaned)$coefficients["factor(pepper)yes", "t value"]
p_value_pepper_yes <- summary(model_cleaned)$coefficients["factor(pepper)yes", "Pr(>|t|)"]
std_error_pepper_yes <- summary(model_cleaned)$coefficients["factor(pepper)yes", "Std. Error"]

coef_estimate_pepper_yes
conf_interval_pepper_yes
df_residuals
t_value_pepper_yes
p_value_pepper_yes
std_error_pepper_yes


## ---- echo=FALSE, include=FALSE-----------------------------------------------
coef_estimate_easiness <- coef(model_cleaned)["easiness"]
conf_interval_easiness <- confint(model_cleaned, "easiness")
t_value_easiness <- summary(model_cleaned)$coefficients["easiness", "t value"]
p_value_easiness <- summary(model_cleaned)$coefficients["easiness", "Pr(>|t|)"]
std_error_easiness <- summary(model_cleaned)$coefficients["easiness", "Std. Error"]


coef_estimate_easiness
conf_interval_easiness
df_residuals
t_value_easiness
p_value_easiness
std_error_easiness


## ---- echo=FALSE, include=FALSE-----------------------------------------------
model_reduced_discipline <- lm(quality2 ~ factor(gender) + factor(pepper) + helpfulness2 + clarity2 + easiness + raterInterest + easiness:factor(gender) + easiness:factor(discipline), data = Rateprof_cleaned)

anova(model_reduced_discipline, model_cleaned)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
coef_estimate_easiness_gender_int <- coef(model_cleaned)["factor(gender)female:easiness"]
conf_interval_easiness_gender_int <- confint(model_cleaned, "factor(gender)female:easiness")
t_value_easiness_gender_int <- summary(model_cleaned)$coefficients["factor(gender)female:easiness", "t value"]
p_value_easiness_gender_int <- summary(model_cleaned)$coefficients["factor(gender)female:easiness", "Pr(>|t|)"]
std_error_easiness_gender_int <- summary(model_cleaned)$coefficients["factor(gender)female:easiness", "Std. Error"]


coef_estimate_easiness_gender_int
conf_interval_easiness_gender_int
df_residuals
t_value_easiness_gender_int
p_value_easiness_gender_int
std_error_easiness_gender_int


## ---- echo=FALSE, include=FALSE-----------------------------------------------
model_reduced_easiness_discipline_int <- lm(quality2 ~ factor(gender) + factor(discipline) + factor(pepper) + helpfulness2 + clarity2 + easiness + raterInterest + easiness:factor(gender), data = Rateprof_cleaned)

anova(model_reduced_easiness_discipline_int, model_cleaned)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
summary(model_cleaned)

