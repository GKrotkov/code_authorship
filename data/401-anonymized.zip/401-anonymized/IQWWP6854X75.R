## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
suppressPackageStartupMessages({
  library(dplyr)
})


## -----------------------------------------------------------------------------
library(dplyr)
library(ggplot2)
suppressMessages(library(dplyr))
sleep=read.csv("/Users/juanyudai/Desktop/cmu-sleep.csv")


## ---- fig.width=6, fig.height=4, fig.show='asis', fig.cap="The Histogram of total sleep time", message=FALSE----
ggplot(sleep,aes(x=TotalSleepTime))+geom_histogram(binwidth = 10)+labs(title="Historgram of total sleep time",x="Total sleep time each night (minutes)")


## ---- fig.width=6, fig.height=4, fig.show='asis', fig.cap="Histogram of change in GPA (range of -4.0 to 4.0)", message=FALSE----

changeGPA<-sleep$term_gpa - sleep$cum_gpa

ggplot(sleep,aes(x=changeGPA))+geom_histogram()+labs(title="The Historgram of change in GPA",x="The change in GPA (range of -4.0 to 4.0)")



## ---- fig.width=6, fig.height=4, fig.show='asis', fig.cap="Change in GPA  vs. Total Sleep time ", message=FALSE----

ggplot(sleep,aes(x=TotalSleepTime, y=changeGPA))+geom_point()+geom_smooth(method = "lm")+labs(title="Total sleep time vs. Change in GPA",x="Total sleep time each night (min)",y="Change in semester GPA (range of -4.0 to 4.0)")



## -----------------------------------------------------------------------------
library(broom)


## ---- fig.width=6, fig.height=4, fig.show='asis', fig.cap="Residual", message=FALSE----
modelSleep<- lm(changeGPA ~ TotalSleepTime, data = sleep)
augment(modelSleep) |>ggplot(aes(x = TotalSleepTime, y = .resid)) +geom_point() +
labs(x = "Total Sleep Time (minutes)",
y = "Residual")


## ---- fig.width=7, fig.height=5, fig.show='asis', fig.cap="Normal Q-Q Plot", message=FALSE----
qqnorm(residuals(modelSleep))
qqline(residuals(modelSleep))


## -----------------------------------------------------------------------------

library(modelsummary)




## ----fig.width=7, fig.height=5,  fig.show='asis', fig.cap="Summary table of the regression model", message=FALSE----
summary_table <-modelsummary(modelSleep,gof_map = c("r.squared", "nobs"),fmt=7)
summary_table



## -----------------------------------------------------------------------------
decrease=0.0010350*120
CI=confint(modelSleep)

