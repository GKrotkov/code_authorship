## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(alr4)
library(tidyverse)
library(mlbench)
library(broom)
library(cutpointr)


## ---- include = FALSE---------------------------------------------------------
sleep <- read.csv("~/Downloads/cmu-sleep.csv")
sleep$change_in_gpa <- ((sleep$term_gpa) - (sleep$cum_gpa))
sleep
part_time <- subset(sleep, sleep$term_units < 25)
full_time <- subset(sleep, sleep$term_units >= 25)
sleep_delta <- lm(sleep$change_in_gpa ~ (sleep$TotalSleepTime))
sleep_multiple_regression <- lm(part_time$term_gpa ~ (part_time$TotalSleepTime) + (part_time$term_units) +(part_time$cum_gpa)  + part_time$midpoint_sleep)
sleep_multiple_regression2 <- lm(part_time$term_gpa ~ (part_time$TotalSleepTime) + (part_time$term_units) +(part_time$cum_gpa))
summary(sleep_multiple_regression)
summary(sleep_multiple_regression)
ggplot(sleep_multiple_regression, aes(x = .fitted, y = .resid)) + geom_point() + labs(x = "Fitted Value", y = "residual")
ggplot(sleep_multiple_regression2, aes(x = .fitted, y = .resid)) + geom_point() + labs(x = "Fitted Value", y = "residual")
ggplot( sleep_multiple_regression, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical Quantiles", y = "Sample Quantiles")
ggplot( sleep_multiple_regression2, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical Quantiles", y = "Sample Quantiles")


## ---- fig.width=4, fig.height=3, fig.cap="Change_in_GPA histogram "-----------
hist(sleep$change_in_gpa, main = "Histogram of Change in GPA", 
     xlab = "Change in a Student's GPA")


## ---- fig.width=5, fig.height=3, fig.cap="Total Sleep Time per Night"---------
hist(sleep$TotalSleepTime, main = "Histogram of Student's Average Sleep", 
     xlab = "A Student's Nightly Average Sleep Time (in minutes)")


## ---- fig.width=5, fig.height=3, fig.cap="Student's Cumulative GPA"-----------
hist(sleep$cum_gpa, main = "Histogram of a Student's Cumulative GPA", 
     xlab = "Student's Cumulative GPA (measured out of 4.0)")


## ---- fig.width=5, fig.height=3, fig.cap="Student's Course Units"-------------
hist(sleep$term_units, main = "Histogram of a Student's Course Units", 
     xlab = "Student's total Units they are taking ")


## ----message = F, warning = F, echo = FALSE, fig.width=5, fig.height=3, fig.cap="Pairs Graph of Explanatory Variables"----
library(GGally) # necessary for the ggpairs() function
library(dplyr)

suppressWarnings(
sleep |>
select(cum_gpa, TotalSleepTime, term_units) |>
ggpairs()
) 


## ---- fig.width=4, fig.height=3, fig.cap="Scatter Plot between GPA Change and Total Sleep Time for Part Time Students"----
plot(part_time$change_in_gpa~ part_time$TotalSleepTime, main = "GPA Change vs Total Sleep", xlab = "Total Time Spent Sleeping per night (in mins)", ylab = "Change in GPA")


## ---- fig.width=4.5, fig.height=3, fig.cap="GPA Change v. Total Sleep for Full Time Students"----
plot(full_time$change_in_gpa ~ full_time$TotalSleepTime, main = "Plot between GPA Change and Total Sleep", xlab = "Total Time Spent Sleeping per night (measured in mins)", ylab = "Change in GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Residuals for Part Time Students Model"----
part_time_multiple <- lm(part_time$change_in_gpa ~ (part_time$TotalSleepTime) + (part_time$term_units) +(part_time$cum_gpa))
ggplot(part_time_multiple, aes(x = .fitted, y = .resid)) + geom_point() + labs(x = "Fitted Value", y = "residual")


## ---- fig.width=3.5, fig.height=2.5, fig.cap="QQ Plot for the Regression Model fitted for Part Time Students"----
ggplot(part_time_multiple, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical Quantiles", y = "Sample Quantiles")



## ---- fig.width=3, fig.height=2.5, fig.cap="Residuals for Full-Time Students Model"----
full_time_multiple <- lm(full_time$change_in_gpa ~ (full_time$TotalSleepTime) + (full_time$term_units) +(full_time$cum_gpa))
ggplot(full_time_multiple, aes(x = .fitted, y = .resid)) + geom_point() + labs(x = "Fitted Value", y = "residual")


## ---- fig.width=3, fig.height=2.5, fig.cap="QQ Plot for the Regression Model fitted for Full Time Students"----
ggplot(full_time_multiple, aes(sample = .resid)) + geom_qq() + geom_qq_line() + labs(x = "Theoretical Quantiles", y = "Sample Quantiles")


## ---- include = FALSE---------------------------------------------------------
summary(full_time_multiple)
summary(part_time_multiple)
0.15708  - (1.97 *   0.000631)
0.15708   + (1.97 *   0.000631)
 0.001309  * 120

