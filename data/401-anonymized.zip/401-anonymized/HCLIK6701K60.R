## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(knitr)
library(kableExtra)

## Keeps figures and texts in order
# code from https://gist.github.com/burchill/8873d2ade156b27e92a238a774ce2758
knit_hooks$set(plot = function (x, options) {
  float_correct <- function(f, y, opts)  {
    if (is.null(opts$regfloat) || opts$regfloat==FALSE)
      paste0(f(y, opts), "\n\n\\FloatBarrier\n")
    else
      f(y, opts)
  }
  if (!is.null(options$out.width) || !is.null(options$out.height) ||
      !is.null(options$out.extra) || options$fig.align != "default" ||
      !is.null(options$fig.subcap)) {
    if (is.null(options$fig.scap))
      options$fig.scap = NA
    return(float_correct(hook_plot_tex, x, options))
  }
  return(float_correct(knitr:::hook_plot_md_base, x, options))
})


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(tidyverse)
library(ggplot2)
library(GGally)
data = Rateprof


## -----------------------------------------------------------------------------
kable(summary(data[,c("quality", "easiness")]), 
          caption = "Summary Table of Quality Rating and Course Easiness") %>%
            kable_styling(latex_options = c("hold_position"))
# Standard Deviations
kable(apply(data[,c("quality", "easiness")], 2, sd), 
             digits = 3,
             col.names = c("Standard Deviation"),
             caption = "Standard Deviations of 
             Quality Rating and Course Easiness") %>%
                  kable_styling(latex_options = c("hold_position"))
# Summary Tables of Factor Variables
kable(summary(factor(data[,"gender"])),
             col.names = c("Count"), 
             caption = "Summary Table of Instructor Gender") %>%
                  kable_styling(latex_options = c("hold_position"))
kable(summary(factor(data[,"pepper"])),
             col.names = c("Count"), 
             caption = "Summary Table of Instructor Attractiveness") %>%
                  kable_styling(latex_options = c("hold_position"))
kable(summary(factor(data[,"discipline"])),
             col.names = c("Count"), 
             caption = "Summary Table of Instructor Discipline") %>%
                  kable_styling(latex_options = c("hold_position"))


## ---- fig.cap="Distribution of Variables"-------------------------------------
# plots
par(mfrow = c(2,3), mar = c(5,3,3,1))
hist(data[,"quality"], prob=TRUE, xlab="Quality Rating", main="", 
     col = "slategray3")
barplot(table(data[,"gender"]), names = c("Female", "Male"), 
        xlab="Gender", ylab = "Count", col = "slategray3")
barplot(table(data[,"pepper"]), names = c("Not Attractive", "Attractive"), 
        xlab="Attractiveness", ylab = "Count", col = "slategray3")
hist(data[,"easiness"], prob=TRUE, xlab="Easiness of Courses", main="", 
     col = "slategray3")
barplot(table(data[,"discipline"]), col = "slategray3",
        xlab="Academic Discipline", ylab = "Count", las = 0)


## ---- message = FALSE, fig.cap="Pairs Plot of Variables"----------------------
pairs(quality ~ gender + pepper + easiness + discipline, data = data,
      pch = 16, cex = 0.5)


## ---- message = FALSE, fig.width = 6, fig.height = 4, fig.cap="Box Plot of Factor Variables"----
par(mfrow = c(2, 2), mar = c(3, 2, 2, 1))
boxplot(quality ~ gender, data = data, 
        ylab = "Quality Rating", xlab = "Gender", 
        names = c("Female", "Male"), col = "mistyrose",
        main = "Gender")
boxplot(quality ~ pepper, data = data, 
        ylab = "Quality Rating", xlab = "Attractiveness",
        names = c("No", "Yes"), col = "mistyrose", main = "Attractiveness")
boxplot(quality ~ discipline, data = data, 
        ylab = "Quality Rating", xlab = "Academic Discipline", 
        col = "mistyrose", main = "Academic Discipline")


## ---- message = FALSE, fig.width = 6, fig.height = 3, fig.cap="Residual Plots"----
library(patchwork)
library(broom)
model1 = lm(quality ~ easiness + factor(gender) + factor(pepper) + 
              factor(discipline), data)
eas = ggplot(augment(model1), aes(x = easiness, y = .resid)) +
        geom_point(color = "darkslategrey", size = 0.7) +
        labs(
          x = "Easiness of Class",
          y = "Residuals"
        ) + theme_bw()
fit = ggplot(augment(model1), aes(x = .fitted, y = .resid)) +
        geom_point(color = "darkslategrey", size = 0.7) +
        labs(
          x = "Fitted Values",
          y = "Residuals"
        ) + theme_bw()

eas | fit


## ---- message = FALSE, fig.width = 4, fig.height=3, fig.cap="Cook's Distance against Fitted Values for Examining Influential Points"----
ggplot(augment(model1), aes(x = easiness, y = .cooksd)) +
    geom_point(color = "darkslategrey", size = 0.7) +
    labs(
      x = "Fitted Values",
      y = "Cook's Distance"
    ) + theme_bw()


## ---- message = FALSE, fig.width = 4, fig.height=3, fig.cap="Q-Q Plot for Examining Normality of Residuals"----
ggplot(augment(model1), aes(sample = .resid)) +
    geom_qq(color = "darkslategrey", size = 0.7) +
    geom_qq_line(color = "red") +
    labs(
      x = "Theoretical Quantile",
      y = "Sample Quantile"
    ) + theme_bw()


## -----------------------------------------------------------------------------
# we need three tables: 
# 1. f-statistic, 2 dofs, p-value
model1_sum = summary(model1)

f_stat_info.df = data.frame(
  `F-statistic` = model1_sum$fstatistic[1],
  `Degrees of Freedom 1` = model1_sum$fstatistic[2],
  `Degrees of Freedom 2` = model1_sum$fstatistic[3],
  `p-value` = as.character(round(pf(model1_sum$fstatistic[1], 
                                    model1_sum$fstatistic[2], 
                                    model1_sum$fstatistic[3], 
                                    lower.tail = FALSE),39)),
  row.names = NULL
)

kable(f_stat_info.df, digits = 3, caption = "Results of Global F-test") %>%
  kable_styling(bootstrap_options = c("striped", "hover"),
                latex_options = c("hold_position"))


## -----------------------------------------------------------------------------
# 2. coefficient estimates, p-values, confidence intervals
tidy_model = tidy(model1)
model1_CI = confint(model1)
# add the confidence interval columns to tidy model for later display
tidy_model = data.frame(tidy_model, model1_CI, row.names = NULL)
# change column names
colnames(tidy_model) = c("Variables", "Esimates",
                         "Standard Error", "Statistic", "p-value",
                         "Lower 2.5%", "Upper 97.5%")
# change variable names (row names)
variables = c("Intercept", "easiness", "Gender: Male",
              "Attractiveness: Yes", "Discipline: Social Sciences",
              "Discipline: STEM", "Discipline: Pre-professional")
tidy_model = mutate(tidy_model, Variables = variables, 
                    `p-value` = ifelse(`p-value` < 0.04, "< 2.2e-16",
                                       as.character(round(`p-value`, 3))))
kable(tidy_model[,1:5], digits = 3, caption = "Summary Results of t-test") %>%
  kable_styling(bootstrap_options = c("striped", "hover"),
                latex_options = c("hold_position"))

# Table of Confidence Intervals
kable(tidy_model[,c(1,6,7)], digits = 3, 
             caption = "Table of Confidence Intervals for All Variables") %>%
  kable_styling(bootstrap_options = c("striped", "hover"),
                latex_options = c("hold_position"))

# 3. statistically significant rows of 2.
stat_sig_tidy_model = data.frame(tidy_model[2:4,], row.names = NULL)
kable(stat_sig_tidy_model, digits = 3,
             caption = "Summary of Predictors with Statistically Significant Results") %>%
  kable_styling(bootstrap_options = c("striped", "hover"),
                latex_options = c("hold_position"))


## -----------------------------------------------------------------------------
model2 = lm(quality ~ easiness + factor(gender) + factor(pepper) + 
              factor(discipline) + easiness:factor(gender) + 
              easiness:factor(discipline), data = data)
anova_out = anova(model1, model2)

anova_info = data.frame(
  `F statistic` = anova_out[2,"F"],
  `Degrees of Freedom 1` = anova_out[2,"Df"],
  `Degrees of Freedom 2` = anova_out[1,"Res.Df"],
  `p-value` = anova_out[2,"Pr(>F)"]
)

kable(anova_info, digits = 3, caption = "Results of Partial F-test") %>%
  kable_styling(bootstrap_options = c("striped", "hover"),
                latex_options = c("hold_position"))

