## ----setup, include=FALSE, messages = FALSE, warnings = FALSE-----------------
knitr::opts_chunk$set(echo = FALSE, warnings = FALSE, messages = FALSE)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(readr)
library(broom)
library(modelsummary)
library(kableExtra)
library(alr4)
library(GGally)

profs = Rateprof 
colnames(profs)[5] = "attractiveness"


## ---- fig.width= 4, fig.height= 3, fig.cap = "The average quality ratings has a left skewed distribution, with a range from 0-5. Most instructors received a rating in the 3-5. Instructors received a rating of 1 the least frequently."----
hist(x = profs$quality, xlab = "Average Quality Rating",
     main = "Distribution of Average Quality Ratings", 
    col = "cyan4")


## ---- fig.width = 4, fig.height = 3, fig.cap = "The average easiness ratings range from 1-5, with a median rating between 3-3.5. Most professors received a rating of 2.5-4. Instructors received a rating of 1 the least frequently."----
hist(x = profs$easiness, xlab = "Average Easiness Ratings of the Instructor",
     main = "Distribution of Average Easiness Ratings", 
    col = "cyan4")


## ---- fig.width = 3, fig.height = 1.75, fig.cap = "There are more male instructors than female instructors."----
par(mfrow = c(1, 2))
ggplot(profs, aes(x = gender)) +
  geom_bar(fill = "cyan4") +
  labs(title = "Instructor Count by Gender",
       x = "Gender",
       y = "Number of Instructors") +
  theme(element_blank(), element_blank(),
        axis.line = element_line(colour= "black"))



## ---- fig.width = 3, fig.height = 1.75, fig.cap = "Most instructors received a chili pepper attractiveness rating of 'no'."----

ggplot(profs, aes(x = attractiveness)) +
  geom_bar(fill = "cyan4") +
  labs(title = "Attractiveness of Instructors",
       x = "Physically Attractive?",
       y = "Number of Instructors")+
  theme(element_blank(), element_blank(),
        axis.line = element_line(colour= "black"))


## ---- fig.width= 4, fig.height = 2, fig.cap = "Humanities courses have the highest number of instructors, followed by STEM courses. Pre-professional has the lowest number of instructors, falling slightly shorter than the social science courses."----
ggplot(profs, aes(x = discipline)) +
  geom_bar(fill = "cyan4") +
  labs(title = "Number of Instructors per Disciplines",
       x = "Discipline",
       y = "Number of Instructors") +
  scale_x_discrete(labels = c("Humanities", "Social Sciences",
                                 "STEM", "Pre-Professional"))+
  theme(element_blank(), element_blank(),
        axis.line = element_line(colour= "black"))


## ---- fig.width = 6, fig.height = 3, fig.cap = "The confidence intervals for the regression lines for each attractiveness rating do not overlap, indicating that the slopes may be different between the lines. There is a positive linear relationship between easiness and quality ratings.", message = F----
ggplot(profs, aes(x = easiness, y = quality, color = attractiveness)) +
  geom_point() +
  geom_smooth(method = lm) +
  scale_colour_discrete(name = "Physicially Attractive?", labels = c("Yes", "No")) +
  labs(title = "Quality v.s. Easiness Ratings by Attractiveness",
       x = "Easiness Ratings",
       y = "Quality Ratings")


## ---- fig.width = 6, fig.height = 3, fig.cap = "STEM courses have the highest proportion of male instructors compared to the proportion of male instructors for the other disciplines. "----
ggplot(profs, aes(x = discipline)) +
  geom_bar(aes(fill = factor(gender)), position = "fill") +
  labs(title = "Proportion of Instructors Gender Given Discipline",
       x = "Discipline",
       y = "Proportion of Instructors") +
  scale_x_discrete(labels = c("Humanities", "Social Sciences", "STEM", "Pre-professional")) +
  scale_fill_discrete(name = "Gender")


## ---- fig.width = 7, fig.height = 3, fig.cap = "The residuals are randomly scattered around the line y = 0 and appear to have mostly constant variance. There are a few outliers in the range of residuals greater than 1 and less than -1.5. The residuals fall approximately along the red line for the QQ plot, indicating that they follow a multivariate Gaussian distribution."----
# resid v.s. fit plot Q1
fin_method = lm(data = profs, quality ~ easiness * attractiveness + gender * discipline)
fits = fitted(fin_method)
resids = resid(fin_method)

par(mfrow = c(1, 2))
plot(x = fits, y = resids, xlab = "Fitted Values (Quality Ratings)", ylab = "Residuals", 
     main = "Residuals vs. Fitted Values")
abline(0, 0, col = "red")

qqnorm(resids, main = "Residuals From Model 1")
qqline(resids, col = "red") 


## ---- fig.width = 7, fig.height = 3, fig.cap = "The residuals are randomly scattered around the line y = 0 and appear to have mostly constant variance. There are a few outliers in the range of residuals greater than 1 and less than -1.5. The residuals fall approximately along the red line on the QQ plot, indicating that they follow a multivariate Gaussian distribution.", fig.pos = "H"----

full4 = lm(data = profs, quality ~ easiness * attractiveness + gender + discipline)
red4 = lm(data = profs, quality ~ easiness * attractiveness)

resids4 = resid(red4)
fits4 = fitted(red4)
resids_full = resid(full4)
fits_full = fitted(full4)

par(mfrow = c(1, 2))
plot(fits_full, resids_full,xlab = "Fitted Values (Quality Ratings)", ylab = "Residuals", 
     main = "Full Model")
abline(0, 0, col = "red")

qqnorm(resids_full, main = "Full Model QQ")
qqline(resids_full, col = "red") 


## -----------------------------------------------------------------------------
knitr::kable(tidy(fin_method), digits = 4, 
             caption = "Coefficients for Model 1") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")


## ---- fig.width = 6-----------------------------------------------------------
anova_fin = anova(red4, full4)
knitr::kable(anova_fin, digits = 4, 
             caption = "Results of the Nested F-Test") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")


## -----------------------------------------------------------------------------
knitr::kable(data.frame(tidy(full4))[-c(2,3,8),], digits = 4, 
             caption = "Results of the Full Model") %>%
  kable_classic() %>%
  kable_styling(latex_options = "HOLD_position")

