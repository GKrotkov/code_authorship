## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, echo=FALSE, results="hide"-------------------------------
library(alr4)
library(ggplot2)
library(dplyr)
library(gridExtra)
library(modelsummary)


## ---- echo=FALSE, results="hide"----------------------------------------------
data(Rateprof)
head(Rateprof)


## ---- echo=FALSE, results="hide"----------------------------------------------
summary(Rateprof$quality)


## ---- echo=FALSE, results="hide"----------------------------------------------
summary(Rateprof$easiness)


## ---- echo=FALSE, results="hide"----------------------------------------------
summary(Rateprof$gender)


## ---- echo=FALSE, results="hide"----------------------------------------------
summary(Rateprof$pepper)


## ---- echo=FALSE, results="hide"----------------------------------------------
summary(Rateprof$discipline)


## ---- echo=FALSE, warning=FALSE, message = FALSE------------------------------
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(fill = "lightblue", color = "black") +
  labs(title = "Distribution of Quality Ratings")


## ---- echo=FALSE--------------------------------------------------------------
Rateprof$attractive <- ifelse(Rateprof$pepper == "yes", "Attractive", "Not Attractive")
attractive_colors <- c("Attractive" = "darkgreen", "Not Attractive" = "coral")

genderplot <- ggplot(Rateprof, aes(x = gender, fill = gender)) +
  geom_bar() +
  labs(title = "Distribution of Prof. by Gender")

attractiveplot <- ggplot(Rateprof, aes(x = attractive, fill = attractive)) +
  geom_bar() +
  scale_fill_manual(values = attractive_colors) +
  labs(title = "Distribution of Prof. Attractiveness")

easyplot <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = 0.5, fill = "lightpink", color = "black") +
  labs(title = "Distribution of Course Easiness")

disciplineplot <- ggplot(Rateprof, aes(x = discipline, fill = discipline)) +
  geom_bar() +
  labs(title = "Distribution of Prof. by Discipline")

grid.arrange(genderplot, attractiveplot, easyplot, disciplineplot, ncol = 2)


## ---- echo=FALSE--------------------------------------------------------------
Rateprof$attractive <- ifelse(Rateprof$pepper == "yes", "Attractive", "Not Attractive")

qualityGender <- ggplot(Rateprof, aes(x = gender, y = quality, fill = gender)) +
  geom_boxplot() +
  labs(title = "Quality Ratings by Gender")
#print(qualityGender)

qualityAttractive <- ggplot(Rateprof, aes(x = attractive, y = quality, fill = attractive)) +
  geom_boxplot() +
  labs(title = "Quality Ratings by Attractiveness")
#print(qualityAttractive)

qualityEasiness <- ggplot(Rateprof, aes(x = easiness, y = quality, color = gender)) +
  geom_point(aes(color = gender)) + 
  labs(title = "Quality vs. Easiness",
       x = "Easiness",
       y = "Quality") 
#print(qualityEasiness)

qualityDiscipline <- ggplot(Rateprof, aes(x = discipline, y = quality, fill = discipline)) +
  geom_boxplot() +
  labs(title = "Quality Ratings by Discipline")
#print(qualityDiscipline)

grid.arrange(qualityGender, qualityAttractive, qualityEasiness, qualityDiscipline, 
             ncol = 2
)


## ---- echo=FALSE--------------------------------------------------------------
Rateprof$attractive <- ifelse(Rateprof$pepper == "yes", "Attractive", "Not Attractive")

easinessGender <- ggplot(Rateprof, aes(x = gender, y = easiness, fill = gender)) +
  geom_boxplot() +
  labs(title = "Course Easiness by Gender")
#print(easinessGender)

easinessAttractive <- ggplot(Rateprof, aes(x = attractive, y = easiness, fill = attractive)) +
  geom_boxplot() +
  labs(title = "Course Easiness by Attractiveness")
#print(easinessAttractive)

easinessDiscipline <- ggplot(Rateprof, aes(x = discipline, y = easiness, fill = discipline)) +
  geom_boxplot() +
  labs(title = "Course Easiness by Discipline")
#print(easinessDiscipline)

grid.arrange(easinessGender, easinessAttractive, easinessDiscipline, 
             ncol = 2
)


## ---- echo=FALSE--------------------------------------------------------------
fullmodel <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = Rateprof)

par(mfrow = c(2,2))

linearity <- plot(fullmodel$fitted.values, fullmodel$residuals, main = "Residuals vs Fitted", xlab = "Fitted Values", ylab = "Residuals")
abline(h = 0, col = "red", lty = 2)

qq <- qqnorm(fullmodel$residuals); qqline(fullmodel$residuals)

cook <- plot(fullmodel, which = c(4))  # Cook's distance 

#grid.arrange(linearity, qq, cook, ncol = 2)


## ---- results='hide', echo=FALSE----------------------------------------------
reducedmodel <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
summary(reducedmodel)

## -----------------------------------------------------------------------------
#modelsummary(list("Reduced Model" = reducedmodel), stars = TRUE)


## ---- results='hide'----------------------------------------------------------
confint(reducedmodel, level = 0.95)


## ---- results='hide', echo=FALSE----------------------------------------------
fullmodel <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data = Rateprof)
summary(fullmodel)

## ---- echo=FALSE--------------------------------------------------------------
#modelsummary(list("Full Model" = fullmodel), stars = TRUE)
#gof_map = c("r.squared", "nobs", "F")
reducedmodel$aic <- AIC(reducedmodel)
fullmodel$aic <- AIC(fullmodel)
modelsummary(list("Reduced Model" = reducedmodel, "Full Model" = fullmodel),
             stars = TRUE, 
             gof_omit = "R2 Adj.|BIC|Log.Lik.|RMSE")


## ---- results='hide'----------------------------------------------------------
confint(fullmodel, level = 0.95)


## ---- results='hide', echo=FALSE----------------------------------------------
anova(reducedmodel, fullmodel)

