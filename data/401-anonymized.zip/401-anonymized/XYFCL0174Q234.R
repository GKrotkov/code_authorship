## -----------------------------------------------------------------------------
sleep=read.csv("C:\\Users\\sonja\\OneDrive\\Fall 2023\\Modern Regression\\Data Exam 1\\cmu-sleep.csv")


## -----------------------------------------------------------------------------
expTerm=exp(sleep$term_gpa)
expCum=exp(sleep$cum_gpa)


## ----fig.width=4, fig.height=3, fig.cap="Figure 1:Histogram showing a roughly normal distribution of average amount of sleep per night."----
hist(sleep$TotalSleepTime,breaks=20,main="Histogram of 
     Total Sleep Time", xlab="Total Sleep Time (Minutes)")



## ----fig.width=4, fig.height=3, fig.cap="Figure 2:A left skewed histogram of student cumulative GPA"----
hist(sleep$cum_gpa,breaks=20,main="Histogram of Cumulative 
     GPA", xlab="Cumulative GPA (out of 4.0)")


## ----fig.width=4, fig.height=3, fig.cap="Figure 3:A left skewed histogram of student term GPA"----
hist(sleep$term_gpa,breaks=20,main="Histogram of Term GPA",
     xlab="Term GPA (out of 4.0)")


## ----fig.width=4, fig.height=3, fig.cap="Figure 4:Exponentially Transformed term GPA distribution appears closer to normal"----
hist(expTerm,breaks=20,main="Exponentiated Student Term GPA"
     , xlab="Exponentiated Term GPA")


## ----fig.width=4, fig.height=3, fig.cap="Figure 5:Exponentially Transformed cumulative GPA distribution appears closer to normal"----
hist(expCum,breaks=20,main="Exponentiated Student Cumulative GPA"
     , xlab="Exponentiated Cumulative GPA")


## ----fig.width=4, fig.height=3, fig.cap="Figure 6:Term GPA versus average sleep time per night"----

plot(sleep$TotalSleepTime,sleep$term_gpa,xlab="Total Sleep Time 
     (minutes)",ylab="Term GPA (out of 4.0)")


## ----fig.width=4, fig.height=3, fig.cap="Figure 7:Term GPA versus cumulative GPA"----
plot(sleep$cum_gpa,sleep$term_gpa,xlab="Cumulative GPA
     (out of 4.0)",ylab="Term GPA (out of 4.0)")


## ----fig.width=4, fig.height=3, fig.cap="Figure 8:Exponential of term GPA versus total sleep time"----
#Exp transformations 
plot(sleep$TotalSleepTime,expTerm,xlab="Total Sleep Time
     (minutes)",ylab="Exponential of Term GPA")


## ----fig.width=4, fig.height=3, fig.cap="Figure 9:Exponential of term GPA versus exponential of cumulative GPA"----
plot(expCum,expTerm,xlab="Exponential of Cumulative GPA",
     ylab="Exponential of Term GPA")


## ----fig.width=4, fig.height=3, fig.cap="Figure 10:Residuals versus fitted plot for mulivariate linear regression"----
multi_exp_both_gpa=lm(exp(term_gpa) ~ TotalSleepTime +
                        exp(cum_gpa),data = sleep)
multi_exp_both_res=residuals(multi_exp_both_gpa)
multi_exp_both_fits=fitted(multi_exp_both_gpa)
plot(multi_exp_both_fits,multi_exp_both_res)
abline(h=0)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 11:Normal probability plot of the residuals"----
qqnorm(multi_exp_both_res)


## -----------------------------------------------------------------------------
confint(multi_exp_both_gpa,'TotalSleepTime',level=0.95)


## -----------------------------------------------------------------------------
confint(multi_exp_both_gpa,'exp(cum_gpa)',level=0.95)


## -----------------------------------------------------------------------------
meanSleep=mean(sleep$TotalSleepTime)
mean_8am=meanSleep-120
meanCum=mean(sleep$cum_gpa)
(meanTerm=mean(sleep$term_gpa))

interval <- predict(multi_exp_both_gpa, newdata =
                      data.frame(TotalSleepTime = mean_8am, cum_gpa=meanCum),
interval = "confidence", level = 0.95)
log(interval)


