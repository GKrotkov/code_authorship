## ----setup, include = FALSE, warning = FALSE----------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
#install.packages("alr4")
library("alr4")
?Rateprof
#install.packages("ggplot2")

# Load the ggplot2 package
library(ggplot2)


## ---- fig.width=4, fig.height=3, fig.cap="More male than female instructors"----
ggplot(Rateprof, aes(x = gender, fill = gender)) +
  geom_bar() +
  labs(title = "Gender Distribution of Instructors",
       x = "Gender",
       y = "Count") +
  theme_minimal() +
  scale_fill_manual(values = c("female" = "blue", "male" = "red")) +
  theme(legend.position = "top")


## ---- fig.width=4, fig.height=3, fig.cap="Few professors rated as attractive"----
ggplot(Rateprof, aes(x = pepper, fill = pepper)) +
  geom_bar() +
  labs(title = "Attractiveness of Instructors",
       x = "Attractive as rated by Students",
       y = "Count") +
  theme_minimal() +
  scale_fill_manual(values = c("no" = "blue", "yes" = "red")) +
  theme(legend.position = "none")


## ---- fig.width=4, fig.height=3, fig.cap="Roughly Normally distributed, peak at 3"----
test <- Rateprof
ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram( bins=15, fill = "skyblue", color = "black") +
  labs(title = "Histogram of Professor Easiness Ratings",
       x = "Professor Average Easiness Rating",
       y = "Frequency") +
  theme_minimal()


## ---- fig.width=4, fig.height=3, fig.cap="More humanities and stem professors"----
ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill = "skyblue", color = "black") +
  scale_x_discrete(labels = c("Hum" = "Humanities", "SocSci" = "Social Sciences", "STEM" = "STEM", "Pre-prof" = "Professional Training")) +
  labs(title = "Bar Chart of Professor Disciplines",
       x = "Discipline",
       y = "Frequency") +
  theme_minimal()


## ---- fig.width=4, fig.height=3, fig.cap="Left skew, peaks around 3.7"--------
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(bins = 12, 
                 fill = "lightblue", 
                 color = "black") + 
  labs(title = "Histogram of Professor Quality Ratings",
       x = "Average Quality Rating",
       y = "Frequency") +
  theme_minimal()


## ----fig.cap="Pairs Plot", fig.height=5, fig.width=5, message=FALSE, warning=FALSE----
library(GGally)
Gender <- Rateprof$gender
Attractive <- Rateprof$pepper
Easiness <- Rateprof$easiness
Quality <- Rateprof$quality
Discipline <- Rateprof$discipline
toPlot = data.frame(Gender, Attractive, Easiness, Discipline, Quality)
ggpairs(toPlot, lower=list(combo=wrap("facethist",  
bins=15)))


## ---- fig.width=4, fig.height=3, fig.cap="Tests of the residuals"-------------
full_model <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender + easiness:discipline, data = Rateprof)
res <- resid(full_model)
plot(fitted(full_model), res, xlab = "Fitted Values", ylab = "Residuals", main = "Residuals vs Fitted")
abline(h = 0, col = "red")  # Add a horizontal line at 0 for reference
qqnorm(res, main = "Normal Q-Q Plot")
qqline(res, col = "red")  # Add a reference line


## ---- fig.width=4, fig.height=3, fig.cap="Tests of the residuals"-------------
plot(Rateprof$gender, res, xlab = "Gender", ylab = "Residuals", main = "Residuals vs Gender")
#plot(Rateprof$pepper, residuals, xlab = "Attractiveness (Chili Pepper Rating)", ylab = "Residuals", main = "Residuals vs Attractiveness")
#plot(Rateprof$easiness, residuals, xlab = "Easiness", ylab = "Residuals", main = "Residuals vs Easiness")
#plot(Rateprof$discipline, residuals, xlab = "Discipline", ylab = "Residuals", main = "Residuals vs Discipline")



## ---- include=FALSE-----------------------------------------------------------
summary(full_model)
reduced_model_discipline <- lm(quality ~ gender + pepper + easiness + easiness:gender + easiness:discipline, data = Rateprof)
reduced_model_int_easiness_discipline <- lm(quality ~ gender + pepper + easiness + discipline + easiness:gender, data = Rateprof)
confint(full_model, "pepperyes")
confint(full_model, "easiness")
anova(reduced_model_discipline, full_model)
anova(reduced_model_int_easiness_discipline, full_model)

