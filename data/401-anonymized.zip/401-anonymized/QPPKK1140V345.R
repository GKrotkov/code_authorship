## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

## -----------------------------------------------------------------------------
library(ggplot2)


## -----------------------------------------------------------------------------
sleep <- read.csv("C:/Users/ianta/Downloads/cmu-sleep.csv")


## -----------------------------------------------------------------------------
ggplot(sleep, aes(x = TotalSleepTime)) +
  geom_histogram(fill = "blue", bins= 25) +
  labs(x = "Total Sleep Time (minutes)", y = "Frequency", title = "Distribution of Total Sleep Time")
ggplot(sleep, aes(x = term_gpa)) +
  geom_histogram(fill = "blue",bins = 25) +
  labs(x = "Term GPA (out of 4.0)", y = "Frequency", title = "Distribution of Term GPA")
ggplot(sleep, aes(x = cum_gpa)) +
  geom_histogram(fill = "blue", bins= 30) +
  labs(x = "Cumulative GPA (out of 4.0)", y = "Frequency", title = "Distribution of Cumulative GPA")
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(fill = "blue") +
  labs(x = "Total Sleep Time (minutes)", y = "Term GPA (out of 4.0)", title =  "Term GPA given Total Sleep Times")


## -----------------------------------------------------------------------------
model <- lm((term_gpa) ~ TotalSleepTime, data = sleep)
qq_data <- data.frame(Residuals = residuals(model))
ggplot(data = qq_data, aes(sample = Residuals)) +
  geom_qq() +
  labs(title = "Q-Q Plot of Term GPA Residuals", y = "Residuals")
cummodel <- lm(cum_gpa ~ TotalSleepTime, data = sleep)
qq_cum <- data.frame(Residuals = residuals(cummodel))
ggplot(data = qq_cum, aes(sample = Residuals)) +
  geom_qq()  +
  labs(title = "Q-Q Plot of Cum GPA Residuals", y = "Residuals")


## -----------------------------------------------------------------------------
expmodel <- lm((term_gpa)^3 ~ TotalSleepTime, data = sleep)
qq_data <- data.frame(Residuals = residuals(expmodel))
ggplot(data = qq_data, aes(sample = Residuals)) +
  geom_qq() +
  labs(title = "Q-Q Plot of Term GPA Residuals", y = "Residuals")
expcummodel <- lm((cum_gpa)^3 ~ TotalSleepTime, data = sleep)
qq_cum <- data.frame(Residuals = residuals(expcummodel))
ggplot(data = qq_cum, aes(sample = Residuals)) +
  geom_qq()  +
  labs(title = "Q-Q Plot of Cum GPA Residuals", y = "Residuals")


## ----include=FALSE------------------------------------------------------------
summary(expmodel)
summary(expcummodel)
confint(expmodel, level = .95)
confint(expcummodel, level = .95)

