## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, include = FALSE------------------------------------------
data <- read.csv("cmu-sleep.csv")
data
library(ggplot2)


## ---- message=FALSE, include = FALSE------------------------------------------
sleep_label = 'Average Total Sleep Time (Minutes)'
term_label = 'Student GPA (Out of 4.0)'


## ---- message=FALSE, fig.width=4, fig.height=2.3, fig.cap="How much students slept each night on average. Note the values look normally distributed."----
ggplot(data) +
  geom_histogram(aes(x = `TotalSleepTime`)) + labs(x = sleep_label, y = "Count")


## ---- message=FALSE, fig.width=4, fig.height=2.3, fig.cap="GPA of students during the studied semester. The figure shows left-skew, which could negatively affect model performance since it could make lower-GPA observations overly-influential when fitting."----
ggplot(data) +
  geom_histogram(aes(x = `term_gpa`)) + labs(x = term_label, y = "Count")


## ---- message=FALSE, fig.width=4, fig.height=2.5, fig.cap="GPA of each student given how long they slept on average. Clustering appears at higher GPAs, likely due to the left skew in GPA data."----
ggplot(data)+
       aes(x = `TotalSleepTime`, y = `term_gpa`) + geom_point() + labs(
         x = sleep_label, 
         y = term_label)


## ---- message=FALSE, include = FALSE------------------------------------------
term_gpa = data[,c("term_gpa")]
rev_term_gpa = 4-term_gpa
rev_term_label = 'Transformed GPA (Out of 2.0)'


## ---- message=FALSE, include = FALSE------------------------------------------
rev_term_sleep_fit <- lm(sqrt(rev_term_gpa) ~ `TotalSleepTime`, data = data)
term_sleep_fit <- lm(term_gpa ~ `TotalSleepTime`, data = data)
summary(rev_term_sleep_fit)


## ---- message=FALSE, fig.width=4, fig.height=3.5, fig.cap="Normal probability plot of the untransformed-data model residuals. It shows overly heavy tail for lower values, and light tail for higher values."----
#Adapted from lecture 6
qqnorm(residuals(term_sleep_fit)) 
qqline(residuals(term_sleep_fit))


## ---- message=FALSE, fig.width=4, fig.height=2.5, fig.cap="Transformed GPA of students during the studied semester. The data appears much more normally distributed compared to Figure 2. However, the spike at transformed GPA 0 could overly-influence the fitted model."----
ggplot(data) +
  geom_histogram(aes(x = sqrt(rev_term_gpa))) + labs(x = rev_term_label, y = "Count")


## ---- message=FALSE, fig.width=4, fig.height=2.5, fig.cap="Transformed GPA of each student given how long they slept on average. The observtions appear less clustered compared to the untransformed version in Figure 3."----
ggplot(data)+
       aes(x = `TotalSleepTime`, y = sqrt(rev_term_gpa)) + geom_point() + labs(
         x = sleep_label, 
         y = rev_term_label)


## ---- message=FALSE, fig.width=4, fig.height=3.5, fig.cap="Normal probability plot of the transformed-data model residuals. The tails much closer match a normal disribution compared to the fit in Figure 4."----
#Adapted from lecture 6
qqnorm(residuals(rev_term_sleep_fit)) 
qqline(residuals(rev_term_sleep_fit))


## ---- message=FALSE, fig.width=4, fig.height=2.5, fig.cap="Residuals of the transformed-data model. The residuals appear to have constant variance, zero mean, and shows few trends. The only noticible trend is a line below the main cluster, but it is small compared to the rest of the data."----
ggplot(data)+
       aes(x = `TotalSleepTime`, y = rev_term_sleep_fit$residuals) + geom_point() + labs(
         x = sleep_label, 
         y = "Residuals")


## ---- message=FALSE, fig.width=4, fig.height=2.5, fig.cap="Cook's distance of data observations. Every distance is less than 1, the threshold for which an observation would be overly influential."----
#Adapted from lecture 6
library(broom)
augment(rev_term_sleep_fit) |>
ggplot(aes(x = `TotalSleepTime`, y = .cooksd)) +
geom_point() +
labs(x = sleep_label, y = "Cook's Distance")


## -----------------------------------------------------------------------------
B0 = coef(rev_term_sleep_fit)["(Intercept)"]
B1 = coef(rev_term_sleep_fit)["TotalSleepTime"]


## ---- message=FALSE,include=FALSE---------------------------------------------
confint(rev_term_sleep_fit, "TotalSleepTime", level = 0.95)

## ----include=FALSE------------------------------------------------------------
c = B1*2
#c = sqrt(4-(g+d)) - sqrt(4-g) => d = -c^2 - 2c sqrt(4-g)
c
c^2
2*c
-6.4018*10^(-6) + 0.0051*sqrt(4-3.5)
-6.4018*10^(-6) + 0.0051*sqrt(4-1.5)
#d = -6.4018e-06 + 0.0051 * sqrt(4-g)

