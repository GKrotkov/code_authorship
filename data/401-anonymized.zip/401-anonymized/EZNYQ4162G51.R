## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(patchwork)
library(MASS)
library(sjPlot)
library(sjmisc)
library(sjlabelled)

## -----------------------------------------------------------------------------
sleep = read.csv("cmu-sleep.csv")
sleep$diff = sleep$term_gpa - sleep$cum_gpa


## ---- fig.dim = c(8,6),echo = FALSE, fig.cap = "Figure 1"---------------------
ggplot(data = sleep, aes(x = TotalSleepTime)) + 
  geom_histogram(fill = "coral", bins  = 30) + 
  labs(title = "Total Sleep", x = "Sleep Time in Minutes", y = "Frequency")


## ---- echo = FALSE, fig.cap = "Figure 2"--------------------------------------
p1 = ggplot(data = sleep, aes(x = cum_gpa)) + 
  geom_histogram(fill = "aliceblue", bins = 30) + 
  labs(title = "Cumulative GPA", x = "GPA", y = "Frequency")
p2 = ggplot(data = sleep, aes(x = term_gpa)) + 
  geom_histogram(fill = "darkslategray", bins = 30) + 
  labs(title = "Term GPA", x = "GPA",, y = "Frequency")

p1 + p2


## ---- fig.cap = "Figure 3"----------------------------------------------------
p1 = ggplot(data = sleep, aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point() + 
  labs(title = "Total Average Sleep vs Term GPA", x = "Total Average Sleep (minutes)", y = "Term GPA")

p2 = ggplot(data = sleep, aes(x = TotalSleepTime, y = cum_gpa)) + 
  geom_point() + 
  labs(title = "Total Average Sleep vs Cumulative GPA", x = "Total Average Sleep (minutes)", y = "Cumulative GPA")

p1 + p2


## ---- include = FALSE---------------------------------------------------------
control = lm((term_gpa)~ TotalSleepTime + cum_gpa, data = sleep)
summary(control)


## ---- fig.cap = "Figure 4"----------------------------------------------------
res = residuals(control)
plot(fitted(control), res)
abline(0,0)


## ---- fig.cap = "Figure 5"----------------------------------------------------
plot(control, which = 2, xlab = "Theoretical Quantities")

