## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE, fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
plot(dist ~ speed, data = cars,
     xlab = "Speed (mph)", ylab = "Stopping distance (feet)")


## ----message=FALSE, warning=FALSE---------------------------------------------
library(alr4)
library(ggplot2)
library(GGally)
library(modelsummary)
# library(broom)


## ----results=FALSE------------------------------------------------------------
head(Rateprof)


## ----fig.width=4, fig.height=3, fig.cap="Distribution of quality."------------
ggplot(data = Rateprof, aes(x = quality)) +
  geom_histogram(bins = 20) + 
  labs (
    title = "Distribution of quality"
  )


## ----fig.width=4, fig.height=3, fig.cap="Distribution of easiness."-----------
ggplot(data = Rateprof, aes(x = easiness)) +
  geom_histogram(bins = 30) + 
  labs (
    title = "Distribution of easiness"
  )


## ----fig.width=4, fig.height=3, fig.cap="Distribution of gender."-------------
ggplot(data = Rateprof, aes(x = gender)) +
  geom_bar() + 
  labs (
    title = "Distribution of gender"
  )


## ----fig.width=4, fig.height=3, fig.cap="Distribution of attractiveness."-----
ggplot(data = Rateprof, aes(x = pepper)) +
  geom_bar() + 
  labs (
    title = "Distribution of attractiveness"
  )


## ----fig.width=4, fig.height=3, fig.cap="Distribution of discipline."---------
ggplot(data = Rateprof, aes(x = discipline)) +
  geom_bar() + 
  labs (
    title = "Distribution of discipline"
  )


## ----message=FALSE, fig.cap="pairs plot of the variable we are using."--------
ggpairs(Rateprof[c("gender", "pepper", "discipline", "easiness", "quality")])


## ----results=FALSE------------------------------------------------------------
base_model <- lm(data = Rateprof, quality ~ easiness + gender + pepper + discipline)

summary(base_model)


## ----results=FALSE------------------------------------------------------------
int_model <- lm(data = Rateprof, quality ~ easiness + gender + pepper + discipline +
                                           easiness*gender + easiness*discipline)

summary(int_model)


## ----fig.cap="Model summary."-------------------------------------------------
modelsummary(list("Base Model" = base_model, "Interaction Model" = int_model),
             gof_map = c("r.squared", "nobs"))


## ---- fig.width=4, fig.height=3, fig.cap="Residual vs. fitted values for the base model."----
plot(base_model$fitted.values, resid(base_model), 
     xlab="Fitted Values", 
     ylab="Residuals", 
     main="Residuals vs Fitted")
abline(h=0, col="red")


## ---- fig.width=4, fig.height=3, fig.cap="QQ-plot for the base model."--------
qqnorm(resid(base_model))
qqline(resid(base_model))


## ---- fig.width=4, fig.height=3, fig.cap="Residual vs. Fitted Values for the model with interaction terms."----
plot(int_model$fitted.values, resid(int_model), 
     xlab="Fitted Values", 
     ylab="Residuals", 
     main="Residuals vs Fitted")
abline(h=0, col="red")


## ---- fig.width=4, fig.height=3, fig.cap="QQ-plot for the model with interaction terms."----
qqnorm(resid(int_model))
qqline(resid(int_model))


## ----results=FALSE, message=FALSE, warning=FALSE------------------------------
anova(base_model, int_model)

library(xtable)
print(xtable(anova(base_model, int_model)))

