## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(ggplot2)
library(stargazer)


## -----------------------------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Frequency of Sleep Time"------------
# hist of TotalSleepTime
# btw commonly accepted sleep time = 8 hours = 480
hist(sleep$TotalSleepTime, xlab = "Total Sleep Time (in minutes)")


## ---- fig.width=4, fig.height=3, fig.cap="Frequency of Term GPA"--------------
# hist of term_gpa
hist(sleep$term_gpa, xlab = "Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Frequency of Cumulative GPA"--------
# hist of cum_gpa
hist(sleep$cum_gpa, xlab = "Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Total Sleep Time and Term GPA Relationship"----
# term gpa scatterplot with 95% Confidence Interval
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point(alpha = 0.05, na.rm = TRUE) +
  geom_smooth(method = "lm", se = TRUE, na.rm = TRUE) +
  labs(x = "Total Sleep Time (in minutes)")


## -----------------------------------------------------------------------------
# term gpa multivariate linear regression
scterm <- lm(term_gpa ~ TotalSleepTime + cum_gpa, sleep)


## -----------------------------------------------------------------------------
stargazer(scterm, type = "text", 
          title = "Term GPA Multivariate Linear Regression", 
          column.sep.width = "1pt")


## -----------------------------------------------------------------------------
# 95% confidence interval of multivariate linear regression
stargazer(confint(scterm, level = 0.95), type = "text", title = "95% Confidence Intervals")


## -----------------------------------------------------------------------------
# list of residuals (term vs sleep)
scres <- resid(scterm)


## ---- fig.width=4, fig.height=3, fig.cap="Term GPA with Sleep and Cumulative GPA Fitted Residuals Plot"----
# residual vs. fitted plot
plot(fitted(scterm), scres, xlab = "Fitted", ylab = "Residuals")
abline(0,0)


## ---- fig.width=4, fig.height=3, fig.cap="Term GPA QQ Plot"-------------------
# qq plot for term gpa
qqnorm(sleep$term_gpa, pch = 1, frame = FALSE)
qqline(sleep$term_gpa, col = "blue", lwd = 2)


## -----------------------------------------------------------------------------
cd_scterm <- cooks.distance(scterm)


## ---- fig.width=4, fig.height=3, fig.cap="Cook's Distance Plot of Sleep Time"----
ggplot(sleep, aes(x = TotalSleepTime, y = cd_scterm)) +
  geom_point() +
  labs(x = "Total Amount of Sleep (in minutes)", y = "Cook's Distance")

