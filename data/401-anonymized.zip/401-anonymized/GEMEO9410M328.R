## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- include=FALSE-----------------------------------------------------------
library(alr4)
head(Rateprof)


## ---- include=FALSE-----------------------------------------------------------
Quality = Rateprof$quality
summary(Quality)


## ---- include=FALSE-----------------------------------------------------------
gender = Rateprof$gender
pepper = Rateprof$pepper
easiness = Rateprof$easiness
discipline = Rateprof$discipline
data = data.frame(gender,pepper,easiness,discipline,Quality)


## ---- echo=FALSE, fig.cap="Distributions of Quantitative Variables", fig.width=8, fig.height=3, fig.show='hold'----
par(mfrow = c(1,2))
hist(data$Quality, main="Histogram of Quality Ratings", xlab="Quality Rating")
hist(data$easiness, main="Boxplot for Easiness Ratings", xlab="Easiness Rating")


## ---- include=FALSE-----------------------------------------------------------
hist(Quality)

summary(data$easiness)
summary(data$gender)
# Assuming the dataset is loaded as 'data'

# Boxplot for Easiness
hist(data$easiness, main="Boxplot for Easiness Ratings")


## ---- echo=FALSE, fig.cap="Distributions of Categorical/Ordinal Variables", fig.show='hold'----
par(mfrow = c(2,2))
# Bar plots for categorical variables (Gender, Pepper, Discipline)
barplot(table(data$gender), main="Gender Distribution", xlab="Gender")
barplot(table(data$pepper), main="Distribution of Attractiveness", xlab="Attraction")
barplot(table(data$discipline), main="Discipline Distribution", xlab="Discipline")

# Histogram for Quality
#hist(data$Quality, main="Histogram of Quality Ratings", xlab="Quality Rating")



## ----echo=FALSE,  fig.cap="Pairs plot for continuous variables", fig.height=3, fig.show='hold'----
#boxplot(Quality ~ gender, data = data, main = "Quality Ratings by Gender", xlab = "Gender", ylab = "Quality Rating")

#boxplot(Quality ~ pepper, data = data, main = "Quality Ratings by Attractiveness", xlab = "Attractiveness (Pepper)", ylab = "Quality Rating")

#boxplot(Quality ~ discipline, data = data, main = "Quality Ratings by Discipline", xlab = "Discipline", ylab = "Quality Rating")

plot(data)



## ----echo=FALSE,  fig.cap="Comparative Boxplots of Quality Ratings", fig.height=4.5, fig.show='hold'----

#par(mfrow = c(1, 3), mar = c(4, 4, 2, 1))
par(mfrow = c(2,2), mar = c(3, 4, 2, 1), oma = c(4, 2, 2, 1))



boxplot(Quality ~ gender, data = data, main = "Quality by Gender", xlab = "Gender", ylab = "Quality Rating")
boxplot(Quality ~ pepper, data = data, main = "Quality by Attractiveness", xlab = "Attractiveness (Pepper)", ylab = "Quality Rating")
boxplot(Quality ~ discipline, data = data, main = "Quality by Discipline", xlab = "Discipline", ylab = "Quality Rating")


par(mfrow = c(1, 1), mar = c(5, 4, 4, 2) + 0.1)





## ----include=FALSE------------------------------------------------------------
model <- lm(Quality ~ easiness + gender + discipline + easiness:gender + easiness:discipline, data = data)

reduced_model <- lm(Quality ~ easiness + gender + discipline, data = data)
anova(reduced_model, model)



## ---- include=FALSE-----------------------------------------------------------
gender = as.numeric(gender)
pepper = as.numeric(pepper)
discipline = as.numeric(discipline)
m = lm(Quality ~ gender + pepper + easiness + discipline + pepper*discipline )
anova(m)


## ---- include=FALSE-----------------------------------------------------------
m = lm(Quality ~ gender + pepper + easiness)
anova(m)


## ---- include=FALSE-----------------------------------------------------------

### Comparison 

m = lm(Quality ~ pepper + easiness)
#summary(m)
#anova(m)


model <- lm(Quality ~ pepper + easiness + gender + discipline + easiness:gender + easiness:discipline, data = data)
#summary(model)
confint(model)
#anova(m, model)

#step_model <- step(model, direction = "both")
#summary(step_model)



## ---- include=FALSE-----------------------------------------------------------
summary(m)




## ---- include=FALSE-----------------------------------------------------------


highest5idxs = sort(cooks.distance(m), decreasing = TRUE, index.return = TRUE)$ix[1:5]
data5 = data[-highest5idxs,]
m5 = lm(Quality ~ pepper + easiness, data = data5)
anova(m5)
summary(m5)

highest10idxs = sort(cooks.distance(m), decreasing = TRUE, index.return = TRUE)$ix[1:10]
data10 = data[-highest10idxs,]
m10 = lm(Quality ~ pepper + easiness, data = data10)
anova(m10)
summary(m10)





## ---- echo=FALSE, warning=FALSE,  fig.cap="Scatterplots for Quality Ratings", fig.show='hold'----
par(mfrow = c(1,2))

plot(data10$easiness ,data10$Quality ,  main = "Easiness vs. Quality rating", xlab = "Easiness", ylab = "Quality rating")+ abline(m10, col = "red")



colors <- ifelse(data10$gender == "male", "blue", "red") 

plot(data10$easiness, data10$Quality, col = colors, main = "Easiness vs. Quality by Gender", xlab = "Easiness", ylab = "Quality rating")

# Adding a regression line if m10 is the model
abline(m10, col = "red")

legend("bottomright", legend = c("Male", "Female"), col = c("blue", "red"), pch = 1)






## ---- echo=FALSE, fig.height=3.5, warning=FALSE,  fig.cap="Scatterplots for Quality Ratings", fig.show='hold'----
colors <- ifelse(data10$discipline == "Hum", "red",
                 ifelse(data10$discipline == "SocSci", "blue",
                        ifelse(data10$discipline == "STEM", "green",
                               "purple")))  # "purple" for Pre-prof

plot(data10$easiness, data10$Quality, col = colors, main = "Easiness vs. Quality by Discipline", xlab = "Easiness", ylab = "Quality rating")


abline(m10, col = "black")  

legend("bottomright", legend = c("Hum", "SocSci", "STEM", "Pre-prof"), col = c("red", "blue", "green", "purple"), pch = 1)


## ---- echo=FALSE,  fig.cap="Residual Plots"-----------------------------------

par(mfrow = c(1,2))
plot(fitted(m10), residuals(m10), main="Residuals vs Fitted Values", 
     xlab="Fitted Values", ylab="Residuals")


# QQ Plot to check for normality of errors
qqnorm(residuals(m10), main="Q-Q Plot of Residuals")




## ---- include=FALSE-----------------------------------------------------------
# One-sample t-test
t_test_result <- t.test(residuals(m10), mu=0)
print(t_test_result)


## ---- fig.width=10, fig.height=4, fig.cap="Diagnostic Plots", include=FALSE----
# One-sample t-test
t_test_result <- t.test(residuals(m10), mu=0)
print(t_test_result)

# QQ Plot to check for normality of errors
qqnorm(residuals(m10), main="Q-Q Plot of Residuals")

