## ----setup, include = FALSE, echo=FALSE, warning=FALSE------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(tidyverse)
library(tools)
library(gridExtra)
library(broom)

Rateprof_subset = Rateprof %>%
 select(gender, discipline, pepper, easiness, quality)


## ----graph_fns, echo=FALSE----------------------------------------------------
histogram_fn = function(predictor, bias = "", data = Rateprof) {

  if (bias != "") {
    p = data %>%
      ggplot(aes(x = .data[[predictor]], fill = factor(.data[[bias]]))) +
        geom_histogram(bins = 20) +
        facet_wrap(~.data[[bias]]) +
        scale_x_continuous(labels = function(x) toTitleCase(as.character(x))) +
        labs(title = paste("Histogram of", toTitleCase(predictor), "by", toTitleCase(bias)), 
          x = paste(toTitleCase(predictor), "(Rating 1-5)"), 
          y = "Number of Professors")
  } else {
    p = data %>%
      ggplot(aes(x = .data[[predictor]])) +
      geom_histogram(bins = 35, fill = "lightgreen") +
      scale_x_continuous(labels = function(x) toTitleCase(as.character(x))) +
      labs(title = paste("Distribution of", toTitleCase(predictor)), 
        x = paste(toTitleCase(predictor), "(Rating 1-5)"), 
        y = "Number of Professors")
  }
  
  p = p + theme(plot.title = element_text(hjust = 0.5), 
    axis.title.x = element_text(hjust = 0.5),
    axis.title.y = element_text(hjust = 0.5)
  )

 return(p)
}


barchart_fn = function(predictor, data = Rateprof) {
  p = data %>%
    ggplot(aes_string(x = predictor, fill = predictor)) +
    geom_bar() +
    scale_fill_discrete(name = toTitleCase(predictor),
              labels = function(x) toTitleCase(as.character(x))) +
    scale_x_discrete(labels = function(x) toTitleCase(x))
 
 if (predictor == "pepper") {
  p = p + scale_fill_manual(values = c("red", "green"), 
                            name = "Is Attractive (Pepper Score)", 
                labels = function(x) toTitleCase(as.character(x))) +
    labs(title = "Attractive Bar Chart", 
         x = "Is Attractive (Pepper)", 
         y = "Number of Professors")
 } else {
  p = p + labs(title = paste(toTitleCase(predictor), "Bar Chart"), 
               x = toTitleCase(predictor), 
               y = "Number of Professors")
 }

  p = p + guides(fill = "none") #remove fill legend
 
  p = p + theme(plot.title = element_text(hjust = 0.5), 
                axis.title.x = element_text(hjust = 0.5),
                axis.title.y = element_text(hjust = 0.5)
  )
 
 return(p)
}


scatterplot_fn = function(predictor = "", x = "easiness", y = "quality", data = Rateprof) {
 if (predictor == "") {
  p = data %>%
   ggplot(aes_string(x = x, y = y)) + 
   geom_point(alpha = 0.5) +
   labs(title = paste("Scatterplot of",  toTitleCase(y), "vs.", 
              toTitleCase(x)), 
      x = paste(toTitleCase(x), "(Rating 1-5)"), 
      y = paste(toTitleCase(y), "(Rating 1-5)"))
 } else {
  p = data %>%
   ggplot(aes_string(x = x, y = y, color = predictor)) + 
   geom_point(alpha = 0.5) +
   labs(title = paste("Scatterplot of",  toTitleCase(y), "vs.", 
              toTitleCase(x), "Based on",  toTitleCase(predictor)), 
      x = paste(toTitleCase(x), "(Rating 1-5)"), 
      y = paste(toTitleCase(y), "(Rating 1-5)")) +
   scale_color_discrete(name =toTitleCase(predictor), 
              labels = function(x)  toTitleCase(as.character(x)))

  if (predictor == "pepper") {
   p = p + scale_color_manual(values = c("red", "green"), 
                 name = "Is Attractive (Pepper)", 
                 labels = function(x)  toTitleCase(as.character(x)))
  }
 }

    p = p + theme(plot.title = element_text(hjust = 0.5), 
    axis.title.x = element_text(hjust = 0.5),
    axis.title.y = element_text(hjust = 0.5)
  )
 
 return(p)
}

boxplot_fn = function(x, y, data = Rateprof) {
 p = data %>%
  ggplot(aes_string(x = x, y = y, color = x)) + 
  geom_boxplot() +
  scale_color_discrete(name =  toTitleCase(x), 
             labels = function(x)  toTitleCase(as.character(x))) +
  scale_x_discrete(labels = function(x) toTitleCase(x))

 if (x == "pepper") {
  p = p + scale_color_manual(values = c("red", "green"), 
                name = "Is Attractive (Pepper Score)", 
                labels = function(x)  toTitleCase(as.character(x))) +
    labs(title = paste("Boxplot of Attractiveness", "\n", "Distributed Among", 
             toTitleCase(y)), 
     x = "Is Attractive (Pepper Score)", 
     y = paste(toTitleCase(y), "(Rating 1-5)"))
 } else {
   p = p + labs(title = paste("Boxplot of",  toTitleCase(x), "\n", "Distributed Among", 
         toTitleCase(y)), 
     x = toTitleCase(x), 
     y = paste(toTitleCase(y), "(Rating 1-5)"))
 }

  p = p + guides(color = "none") #remove the color legend

  p = p + theme(plot.title = element_text(hjust = 0.5), 
                axis.title.x = element_text(hjust = 0.5),
                axis.title.y = element_text(hjust = 0.5)
  )
 
 return(p)
}


## ----univariate_histogram_eda, echo=FALSE, message=FALSE, fig.width=8, fig.height=3, fig.cap = "Histograms of Relevant Numeric Variables"----
grid.arrange(histogram_fn("quality"), histogram_fn("easiness"), ncol=2)


## ---- barchart_eda, echo=FALSE, message=FALSE, warning=FALSE, fig.align='center', fig.width=8, fig.height=2.5, fig.cap = "Bar Charts of Relevant Factor Variables"----
barchart1 = barchart_fn("gender")
barchart2 = barchart_fn("pepper")
barchart3 = barchart_fn("discipline")

grid.arrange(barchart1, barchart2, barchart3, ncol = 3)


## ---- scatterplot_eda, message=FALSE, fig.align='center',  fig.width=8, fig.height=2.5, fig.cap = "Scatterplot of Quality vs. Easiness"----
scatterplot_fn()


## ---- gender_boxplots_eda, message=FALSE,  fig.width=8, fig.height=2.5, fig.cap = "Boxplots of Gender Among Quality and Easiness"----
grid.arrange(boxplot_fn("gender", "quality"), boxplot_fn("gender", "easiness"), ncol = 2)


## ---- pepper_boxplots_eda, message=FALSE,  fig.width=8, fig.height=2.5, fig.cap = "Boxplots of Attractiveness Among Quality and Easiness"----
grid.arrange(boxplot_fn("pepper", "quality"), boxplot_fn("pepper", "easiness"), ncol = 2)


## ---- discipline_boxplots_eda, message=FALSE,  fig.width=8, fig.height=2.5, fig.cap = "Boxplots of Discipline Among Quality and Easiness"----
grid.arrange(boxplot_fn("discipline", "quality"), boxplot_fn("discipline", "easiness"), ncol=2)


## ----research_model, echo=FALSE-----------------------------------------------
research_model = lm(quality ~ gender + pepper * easiness + discipline, data=Rateprof)


## ----residual_predictors, echo=FALSE, message=FALSE, warning=FALSE, fig.width=8, fig.height=3, fig.cap = "Residual Analysis of Predictors"----
residual_plot_fn = function(predictor, residuals = research_model$residuals, 
                   data = Rateprof, x_axis_name = toTitleCase(predictor)) {
  plot(data[,predictor], residuals, 
     xlab = x_axis_name,
     ylab = "Residuals", 
     main = paste("Residuals vs.", toTitleCase(predictor)))
}

par(mfrow = c(1, 4))
residual_plot_fn("gender")
residual_plot_fn("pepper")
residual_plot_fn("easiness", x_axis_name = "Easiness (Rating 1-5)")
residual_plot_fn("discipline")


## ----residual_fitted, echo=FALSE, message=FALSE, warning=FALSE, fig.width=8, fig.height=3, fig.cap = "Residual Analysis of Response"----
ggplot(augment(research_model), aes(x = .fitted, y = .resid)) +
  geom_point(alpha=0.5) +
  labs(x = "Fitted values", y = "Residual values", 
       title = "Residual values vs. Fitted values") + 
  geom_abline(intercept = 5, slope = -0.98, col="purple")


## ----cooks_dist_plot, echo=FALSE, message=FALSE, warning=FALSE, fig.width=8, fig.height=6, fig.cap = "Cook's Distance of Predictors"----
cooks_dist_fn = function(predictor, x_axis_name = toTitleCase(predictor), aug = augment(research_model)) {
  aug %>%
    ggplot(aes(x = .data[[predictor]], y = .cooksd)) +
    geom_point(alpha = 0.5) +
    labs(x = x_axis_name, y = "Cook's distance", 
         title = paste("Cook's Distance of", toTitleCase(predictor)))
}

grid.arrange(cooks_dist_fn("gender"), 
             cooks_dist_fn("easiness", x_axis_name = "Easiness (Rating 1-5)"),
             cooks_dist_fn("pepper"), 
             cooks_dist_fn("discipline"))


## ----qq_plot, echo=FALSE, message=FALSE, warning=FALSE, fig.width=8, fig.height=3, fig.cap = "Normal Q-Q Plot to Show Normality Assumption"----
ggplot(augment(research_model), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles", 
       title = "Normal Q–Q Plot of Residuals of the Model")


## ----collinearity, echo=FALSE-------------------------------------------------
Rateprof_subset_dummy = Rateprof_subset
Rateprof_subset_dummy[, c('gender', 'pepper', 'discipline')] <- sapply(Rateprof_subset[, c('gender', 'pepper', 'discipline')], unclass) - 1

cor_df = data.frame(cor(Rateprof_subset_dummy[,-5]))

knitr::kable(cor_df, caption = "Correlation Matrix of Predictors")


## ---- echo=FALSE, warning=FALSE-----------------------------------------------
model = lm(quality ~ gender + pepper + discipline + easiness, data=Rateprof)

partial_f_test_fn = function(predictor, full_model = model, 
                             data=Rateprof_subset) {
 reduced_formula = as.formula(paste("quality ~", 
        paste(setdiff(names(data[,-5]), predictor), collapse = " + ")))
 reduced_model = lm(reduced_formula, data = data)
 result = anova(reduced_model, full_model)
 result
}

partial_f_test_fn_interactions <- function(predictor1, predictor2, 
                                           reduced_model = model, 
                                           data = Rateprof_subset) {
 interaction_term = paste(predictor1, predictor2, sep = " * ")
 beginning_part = paste("quality ~", 
           paste(setdiff(names(data), c("quality", predictor1, predictor2)), collapse = " + "))
 full_formula <- paste(beginning_part, interaction_term, sep = " + ")
 full_model <- lm(full_formula, data = data)
 result <- anova(reduced_model, full_model)
 return(result)
}


## ----partial_f_gender, echo=FALSE, warning=FALSE------------------------------
options(knitr.kable.NA = '')
knitr::kable(partial_f_test_fn("gender"), caption = "Partial F-Test of Gender")


## ----partial_f_pepper, echo=FALSE, warning=FALSE------------------------------
knitr::kable(partial_f_test_fn("pepper"), caption = "Partial F-Test of Attractiveness (Pepper)")


## ----partial_f_easiness, echo=FALSE, warning=FALSE----------------------------
knitr::kable(partial_f_test_fn("easiness"), caption = "Partial F-Test of Easiness")


## ----partial_f_discipline, echo=FALSE, warning=FALSE--------------------------
knitr::kable(partial_f_test_fn("discipline"), caption = "Partial F-Test of Discipline")


## ----partial_f_gender:discipline, echo=FALSE, warning=FALSE-------------------
knitr::kable(partial_f_test_fn_interactions("gender", "discipline"), caption = "Partial F-Test of Gender:Discipline Interaction Term")


## ----partial_f_pepper:discipline, echo=FALSE, warning=FALSE-------------------
knitr::kable(partial_f_test_fn_interactions("pepper", "discipline"), 
             caption = "Partial F-Test of Pepper:Discipline Interaction Term")


## ----partial_f_gender:pepper, echo=FALSE, warning=FALSE-----------------------
knitr::kable(partial_f_test_fn_interactions("gender", "pepper"), caption = "Partial F-Test of Gender:Pepper Interaction Term")


## ----partial_f_gender:easiness, echo=FALSE, warning=FALSE---------------------
knitr::kable(partial_f_test_fn_interactions("gender", "easiness"), caption = "Partial F-Test of Gender:Easiness Interaction Term")


## ----partial_f_pepper:easiness, echo=FALSE, warning=FALSE---------------------
knitr::kable(partial_f_test_fn_interactions("pepper", "easiness"), caption = "Partial F-Test of Pepper:Easiness Interaction Term")


## ----partial_f_discipline:easiness, echo=FALSE, warning=FALSE-----------------
knitr::kable(partial_f_test_fn_interactions("discipline", "easiness"),
             caption = "Partial F-Test of Discipline:Easiness Interaction Term", 
             na = "")


## ----research_model_summary, echo=FALSE---------------------------------------
knitr::kable(summary(research_model)$coefficients, caption = "Results of Chosen Model", digits = 3)
knitr::kable(confint(research_model), caption = "Results of 95% CIs of Coefficients", digits = 3)

