## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(knitr)
library(ggplot2)
sleep = read.csv('cmu-sleep.csv', header = TRUE)

## ---- results = FALSE---------------------------------------------------------
# TotalSleepTime 
summary(sleep$TotalSleepTime)


## -----------------------------------------------------------------------------
t1 = read.table(text="194.8  366.9  400.4  397.3  430.1  587.7 ")
knitr::kable(t1, caption = "Numerical Summary of Total Sleep Time", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student’s Sleep Time (minutes)."----
hist(sleep$TotalSleepTime, 
     xlab="Sleep Time (minutes)",
     ylab="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Student’s Sleep Time (minutes)."----
boxplot(sleep$TotalSleepTime, ylab="Sleep Time (minutes)")


## ---- results = FALSE---------------------------------------------------------
# term_gpa
summary(sleep$term_gpa)


## -----------------------------------------------------------------------------
t1 = read.table(text="0.350  3.233  3.556  3.450  3.810  4.000 ")
knitr::kable(t1, caption = "Numerical Summary of Term GPA", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student’s Term GPA (out of 4.0)."----
hist(sleep$term_gpa, 
     xlab="Student's Term GPA (out of 4.0)",
     ylab="Frequency")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Student’s Term GPA (out of 4.0)."----
boxplot(sleep$term_gpa, ylab="Student's Term GPA (out of 4.0)")


## ---- results = FALSE---------------------------------------------------------
# term_gpa
summary(sleep$cum_gpa)


## -----------------------------------------------------------------------------
t1 = read.table(text="1.210  3.232  3.558  3.466  3.790  4.000 ")
knitr::kable(t1, caption = "Numerical Summary of Cumulative GPA", col.names = c("Min.", "1st Qu.", "Median ", "Mean", "3rd Qu.", "Max."))


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student’s Cumulative GPA (out of 4.0)."----
hist(sleep$cum_gpa,
     xlab="Student's Cumulative GPA (out of 4.0)",
     ylab="Frequency") 


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Student’s Cumulative GPA (out of 4.0)."----
boxplot(sleep$cum_gpa, ylab="Student's Cumulative GPA (out of 4.0)")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Total Sleep Time vs. Term GPA"----
# TotalSleepTime vs term_gpa
plot(sleep$TotalSleepTime, sleep$term_gpa, 
     xlab="Total Sleep Time (minutes)",
     ylab="Term GPA")
abline(lm(sleep$term_gpa ~ sleep$TotalSleepTime), col="red")


## -----------------------------------------------------------------------------
sleep_lm = lm(term_gpa ~ TotalSleepTime, data = sleep)
sleep_lm_summary = summary(sleep_lm)
df=as.data.frame(coef(sleep_lm_summary))
knitr::kable(df, digits = 5, caption="Coeficients of term_gpa ~ TotalSleepTime")


## -----------------------------------------------------------------------------
t1 = read.table(text="0.04246   0.04224  0.03696  0.03403  0.04184  0.03228 ")
knitr::kable(t1, caption = "R squared based on transformation of term_gpa", col.names = c("CubeRoot", "SquareRoot", "Square", "Cube", "Log", "Exponential"))


## -----------------------------------------------------------------------------
t1 = read.table(text="0.0457  0.0444  0.03407  0.02846  0.04841  0.0009302")
knitr::kable(t1, caption = "R squared based on transformation of TotalSleepTime", col.names = c("CubeRoot", "SquareRoot", "Square", "Cube", "Log", "Exponential"))


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of log of Total Sleep Time vs. Term GPA."----
# Log of TotalSleepTime vs term_gpa
plot(log(sleep$TotalSleepTime), sleep$term_gpa, 
     xlab="Log of Total Sleep Time (minutes)",
     ylab="Term GPA")
abline(lm(sleep$term_gpa ~ log(sleep$TotalSleepTime)), col="red")


## -----------------------------------------------------------------------------
sleep_lm3 = lm(term_gpa ~ log(TotalSleepTime), data = sleep)
sleep_lm3_summary = summary(sleep_lm3)
df=as.data.frame(coef(sleep_lm3_summary))
knitr::kable(df, digits = 5, caption="Coeficients of term_gpa ~ log of TotalSleepTime")


## ---- results = FALSE---------------------------------------------------------
sleep_cookdistance = cooks.distance(sleep_lm3)
which.max(cooks.distance(sleep_lm3))


## ---- fig.width=4, fig.height=3, fig.cap="Cook's Distance."-------------------
plot(sleep_cookdistance, pch = 19,  xlab = "Index", ylab = "Cook's Distance")


## ---- fig.width=4, fig.height=3, fig.cap="Residuals versus Total Sleep Time."----
residuals = residuals(sleep_lm3)
plot(x = log(sleep$TotalSleepTime), y = residuals, pch = '.', xlab = "Log of Total Sleep Time (minutes)")
abline(h = 0, col = 'red')


## ----fig.width=4, fig.height=3, fig.cap="Normal Q-Q Plot"---------------------
qqnorm(residuals(sleep_lm3))
qqline(residuals(sleep_lm3), col = "red", lwd = 2)


## -----------------------------------------------------------------------------
coef_totalsleeptime <- coef(sleep_lm3)["log(TotalSleepTime)"]
se_totalsleeptime <- summary(sleep_lm3)$coefficients["log(TotalSleepTime)", "Std. Error"]

t_stat <- coef_totalsleeptime / se_totalsleeptime

df <- nrow(sleep) - 2 
p_value <-pt(q=5.670158, df=632, lower.tail=FALSE)

test.values <- c(t_stat, df, p_value)
test.data <- matrix(test.values, ncol=3, byrow = TRUE)
colnames(test.data) <- c("t-statistic","Degrees of Freedom","One-tailed p-value")
test.data.df <- as.data.frame(test.data)
knitr::kable(test.data.df, digits = 10, caption="Results")


## -----------------------------------------------------------------------------
knitr::kable(confint(sleep_lm3), digits = 5, caption = "Confidence interval of slope after transform")


## -----------------------------------------------------------------------------
knitr::kable(confint(sleep_lm), digits = 5, caption = "Confidence interval of slope before transform")


## ---- results='hide'----------------------------------------------------------
-2*60*0.0019846
-2*60*00.001231758
-2*60*0.00273754

