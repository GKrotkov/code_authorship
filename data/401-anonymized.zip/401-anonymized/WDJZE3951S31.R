## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ----message=FALSE,include=FALSE----------------------------------------------
library(alr4)
library(dplyr)
library(ggplot2)
library(gridExtra)
rateprof <- Rateprof
rateprof$pepper <- ifelse(tolower(rateprof$pepper) == 'no', 'No', 
            ifelse(tolower(rateprof$pepper) == 'yes', 'Yes', rateprof$pepper))
rateprof$gender <- ifelse(tolower(rateprof$gender) == 'male', 'Male', 
      ifelse(tolower(rateprof$gender) == 'female', 'Female', rateprof$gender))


## ----echo=FALSE,fig.height=2.5,fig.width=7------------------------------------
#gender+disc
gen <- rateprof %>% ggplot(aes(x=gender))+geom_bar(aes(fill=gender),color="black")+
  labs(x="Gender",y="Count",title="Distribution of Professor Gender")+
  scale_fill_manual(name="Gender",values=c("Female"="deeppink","Male"="skyblue"))
pep <- rateprof %>% ggplot(aes(x=pepper))+geom_bar(aes(fill=pepper),color="black")+
  labs(x="Status",y="Count",title="Distribution of Pepper Status")+
  scale_fill_manual(name="Pepper Status",values=c("Yes"="red","No"="white"))
grid.arrange(gen,pep,ncol=2)


## ----fig.width=7, fig.height=2.5,echo=FALSE-----------------------------------
#easiness+disc
eas <- rateprof %>% ggplot(aes(x=easiness))+geom_histogram(bins=15,color="black",
  fill="deeppink")+labs(x="Easiness Score (1-5)",y="Count",
                       title="Distribution of Easiness Score")
disc <- rateprof %>% ggplot(aes(x=discipline))+geom_bar(aes(fill=discipline),color="black")+
  labs(x="Discipline",y="Count",title="Distribution of Course Discipline")+
  scale_fill_manual(values=c("orange","chartreuse","purple","yellow"),
    labels=c("Hum"="Humanities","SocSci"="Social Science",
    "STEM"="STEM","Pre-prof"="Pre-professional"),name="Discipline")
grid.arrange(eas,disc,ncol=2)


## ----fig.width=5, fig.height=2.5----------------------------------------------
#gender + pepper
rateprof %>% ggplot(aes(x=gender,fill=gender))+
  geom_bar(position="dodge",color="black")+
  labs(x="Gender",y="Count",title="Distribution of Professor Gender by Pepper Status")+
  scale_fill_manual(values=c("Female"="pink","Male"="skyblue"))+
  facet_wrap(~pepper)


## ----fig.width=6, fig.height=2.5----------------------------------------------
#pepper + discipline
rateprof %>% ggplot(aes(x=discipline))+geom_bar(aes(fill=discipline),color="black")+
  labs(x="Discipline",y="Count",title="Distribution of Course Discipline by Pepper Status")+
  scale_fill_manual(values=c("orange","chartreuse","purple","yellow"),
    labels=c("Hum"="Humanities","SocSci"="Social Science",
                             "STEM"="STEM","Pre-prof"="Pre-professional"),
    name="Discipline")+facet_wrap(~pepper)


## ----fig.width=6, fig.height=2.5----------------------------------------------
#gender + easiness
rateprof %>% ggplot(aes(x=easiness,fill=gender))+
  geom_histogram(aes(y=after_stat(density)),bins=15,color="black")+
  labs(x="Easiness Score (1-5)",y="Density",
  title="Distribution of Easiness Score by Gender")+
  facet_wrap(~gender)


## ----fig.width=4, fig.height=2.5----------------------------------------------
#pepper + easiness
rateprof %>% ggplot(aes(x=easiness,fill=pepper))+
  geom_histogram(aes(y=after_stat(density)),bins=15,color="black")+
  labs(x="Easiness Score (1-5)",y="Density",
  title="Distribution of Easiness Score by Pepper Status")+
  scale_fill_manual(values=c("Yes"="red","No"="white"))+
  facet_wrap(~pepper)+
  theme(legend.position = "none")


## ----fig.width=5, fig.height=2.5----------------------------------------------
#discipline + gender
rateprof %>% ggplot(aes(x=discipline))+geom_bar(aes(fill=discipline),color="black")+
  labs(x="Discipline",y="Count",title="Distribution of Course Discipline by Gender")+
  scale_fill_manual(values=c("orange","chartreuse","purple","yellow"),
    labels=c("Hum"="Humanities","SocSci"="Social Science",
                             "STEM"="STEM","Pre-prof"="Pre-professional"),
    name="Discipline")+facet_wrap(~gender)


## ----fig.width=5, fig.height=2.5----------------------------------------------
#discipline + easiness
rateprof %>% ggplot(aes(x=easiness,fill=discipline))+
  geom_histogram(aes(y=after_stat(density)),bins=15,color="black")+
  labs(x="Easiness Score (1-5)",y="Density",
       title="Distribution of Easiness Score by Discipline")+
  scale_fill_manual(values=c("orange","chartreuse","purple","yellow"))+
  facet_wrap(~discipline,
  labeller = labeller(discipline=c("Hum"="Humanities","SocSci"="Social Science",
                             "STEM"="STEM","Pre-prof"="Pre-professional")))+
  theme(legend.position = "none")


## ----fig.width=4, fig.height=2.5----------------------------------------------
#quality
rateprof %>% ggplot(aes(x=quality))+geom_histogram(bins=15,color="black",
  fill="deeppink")+labs(x="Quality Score (1-5)",y="Count",
                       title="Distribution of Quality Score")


## ----fig.width=5, fig.height=2.5----------------------------------------------
#discipline + quality
rateprof %>% ggplot(aes(x=quality,fill=discipline))+
  geom_histogram(aes(y=after_stat(density)),bins=10,color="black")+
  labs(x="Quality Score (1-5)",y="Density",
       title="Distribution of Quality Score by Discipline")+
  scale_fill_manual(values=c("orange","chartreuse","purple","yellow"))+
  facet_wrap(~discipline,
  labeller = labeller(discipline=c("Hum"="Humanities","SocSci"="Social Science",
                             "STEM"="STEM","Pre-prof"="Pre-professional")))+
  theme(legend.position = "none")


## ----fig.width=5, fig.height=2.5----------------------------------------------
#pepper + easiness
rateprof %>% ggplot(aes(x=quality,fill=pepper))+
  geom_histogram(aes(y=after_stat(density)),bins=15,color="black")+
  labs(x="Quality Score (1-5)",y="Density",
  title="Distribution of Quality Score by Pepper Status")+
  scale_fill_manual(values=c("Yes"="red","No"="white"))+
  facet_wrap(~pepper)+
  theme(legend.position = "none")


## ----fig.width=4, fig.height=2.5----------------------------------------------
#gender vs. quality
rateprof %>% ggplot(aes(x=quality,fill=gender))+
  geom_histogram(aes(y=after_stat(density)),bins=10,color="black")+
  labs(x="Quality Score (1-5)",y="Density",
  title="Distribution of Quality Score by Gender")+
  facet_wrap(~gender)


## ----fig.width=4, fig.height=2.5----------------------------------------------
#easiness vs. quality
rateprof %>% ggplot(aes(x=easiness,y=quality))+geom_point(aes(color=gender,shape=gender))+
  labs(x="Easiness Score (1-5)",y="Quality Score (1-5)",title=
         "Quality Score vs. Easiness Score")+facet_wrap(~discipline)


## ----message=FALSE,echo=FALSE-------------------------------------------------
m1 <- lm(quality~pepper+easiness+gender+discipline,data=rateprof)
m2 <- lm(quality~pepper+easiness*gender+easiness*discipline,data=rateprof)
m3 <- lm(quality~pepper+easiness*gender+discipline,data=rateprof)
m4 <- lm(quality~pepper+easiness*discipline+gender,data=rateprof)


## ----fig.width=3, fig.height=3,message=FALSE----------------------------------
library(gridExtra)
grid.arrange(
  plot(m1, which = 1,main="Model 1 Residuals"), 
  plot(m2, which = 1,main="Model 2 Residuals"),
  plot(m3, which = 1,main="Model 3 Residuals"),
  plot(m4, which = 1,main="Model 4 Residuals"),
  ncol = 2
)


## -----------------------------------------------------------------------------
createQQPlot <- function(model, main_title) {
  residuals <- residuals(model)
  qq <- ggplot(data.frame(residuals = residuals), aes(sample = residuals)) +
    stat_qq() +
    stat_qq_line() +
    ggtitle(main_title) +
    theme_minimal()
  return(qq)
}
qqplot_m1 <- createQQPlot(m1, "Model 1 QQPlot")
qqplot_m2 <- createQQPlot(m2, "Model 2 QQPlot")
qqplot_m3 <- createQQPlot(m3, "Model 3 QQPlot")
qqplot_m4 <- createQQPlot(m4, "Model 4 QQPlot")

grid.arrange(qqplot_m1, qqplot_m2, qqplot_m3, qqplot_m4, ncol = 2)


## ----echo=FALSE---------------------------------------------------------------
ss1 <- sum(residuals(m1)^2)
ss2 <- sum(residuals(m2)^2)
ss3 <- sum(residuals(m3)^2)
ss4 <- sum(residuals(m4)^2)
f1 <- ((ss1-ss2)/(df.residual(m1)-df.residual(m2)))/(ss2/df.residual(m2))
f2 <- ((ss1-ss3)/(df.residual(m1)-df.residual(m3)))/(ss3/df.residual(m3))
f3 <- ((ss1-ss4)/(df.residual(m1)-df.residual(m4)))/(ss4/df.residual(m4))
p1<-1-pf(f1,df.residual(m1)-df.residual(m2),df.residual(m2))
p2<-1-pf(f2,df.residual(m1)-df.residual(m3),df.residual(m3))
p3<-1-pf(f3,df.residual(m1)-df.residual(m4),df.residual(m4))
results_table <- data.frame(
  Variable = c("Sum of Squares for Model 1", "Sum of Squares for Model 2", "Sum of Squares for Model 3", "Sum of Squares for Model 4", "F Statistic for Model 2", "F Statistic for Model 3", "F Statistic for Model 4", "P-value for Model 2", "P-value for Model 3", "P-value for Model 4"),
  Value = c(ss1, ss2, ss3, ss4, f1, f2, f3, p1, p2, p3)
)
knitr::kable(results_table)


## -----------------------------------------------------------------------------
ci <-  data.frame(
  "Lower Bound - Gender" = confint(m1,"genderMale",level=0.95)[1],
  "Upper Bound - Gender" = confint(m1,"genderMale",level=0.95)[2],
  "Lower Bound - Attractiveness" = confint(m1,"pepperYes",level=0.95)[1],
  "Upper Bound - Attractiveness" = confint(m1,"pepperYes",level=0.95)[2],
  "Lower Bound - Easiness" = confint(m1,"easiness",level=0.95)[1],
  "Upper Bound - Easiness" = confint(m1,"easiness",level=0.95)[2],
  "Lower Bound - Social Science" = confint(m1,"disciplineSocSci",level=0.95)[1],
  "Upper Bound - Social Science" = confint(m1,"disciplineSocSci",level=0.95)[2],
  "Lower Bound - STEM" = confint(m1,"disciplineSTEM",level=0.95)[1],
  "Upper Bound - STEM" = confint(m1,"disciplineSTEM",level=0.95)[2],
  "Lower Bound - Pre-professional" = confint(m1,"disciplinePre-prof",level=0.95)[1],
  "Upper Bound - Pre-professional" = confint(m1,"disciplinePre-prof",level=0.95)[2]
)
cit <- t(ci)
knitr::kable(cit,col.names=c("Boundary","Value"))

