## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(dplyr)
library(ggplot2)
library(patchwork)
library(kableExtra)
library(broom)
data = read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
# create a table of summary statistics for the important variables
cols = c("Min.", "1st Qu.", "Median", "Mean", "3rd Qu.", "Max.")
rows = c("TotalSleepTime", "term_gpa", "cum_gpa")
sleeptimes = as.vector(summary(data$TotalSleepTime))
term_gpas = as.vector(summary(data$term_gpa))
cum_gpas = as.vector(summary(data$cum_gpa))
summaries = c(sleeptimes, term_gpas, cum_gpas)
tab = matrix(data=summaries, ncol=length(sleeptimes), byrow=TRUE)
colnames(tab) <- cols
rownames(tab) <- rows
tab <- round(tab, digits=2)
tab %>%
  kbl(booktabs = T,
      caption="Summary statistics of total sleep time, term GPA, and cumulative GPA.") %>%
  kable_classic(full_width=F, html_font="Cambria") %>%
  kable_styling(latex_options = "HOLD_position")


## ---- fig.width=10, fig.height=10, fig.cap="Histograms of TotalSleepTime, term_gpa, and cum_gpa. TotalSleepTime has a bell shape, whereas term_gpa and cum_gpa are left-skewed."----
# create histograms for variables of interest
p1 = ggplot(data=data, aes(x=TotalSleepTime)) +
  geom_histogram(bins=30) +
  labs(x="Total sleep time (minutes)", y="Frequency",
       title="Histogram of total sleep time")
p2 = ggplot(data=data, aes(x=term_gpa)) +
  geom_histogram(bins=30) +
  labs(x="Term GPA", y="Frequency", title="Histogram of term GPA")
p3 = ggplot(data=data, aes(x=cum_gpa)) +
  geom_histogram(bins=30) +
  labs(x="Cumulative GPA", y="Frequency", title="Histogram of cumulative GPA")
p1 + p2 + p3 + plot_layout(ncol=3, heights=c(5, 5, 5))


## ---- fig.width=10, fig.height=10, fig.cap="Scatter plots of the 3 variables. Relationship between total sleep times and term/cumulative GPAs are unclear, but there is a clear linear relationship between term and cumulative GPAs."----
# create scatter plots
p1 = ggplot(data=data, aes(x=TotalSleepTime, y=term_gpa)) +
  geom_point(alpha=0.5) +
  labs(x="Total Sleep Time (minutes)", y="term GPA",
       title="term GPA vs. total sleep time")

p2 = ggplot(data=data, aes(x=TotalSleepTime, y=cum_gpa)) +
  geom_point(alpha=0.5) +
  labs(x="Total Sleep Time (minutes)", y="cumulative GPA",
       title="cumulative GPA vs. total sleep time")

p3 = ggplot(data=data, aes(x=cum_gpa, y=term_gpa)) +
  geom_point(alpha=0.5) +
  labs(x="cumulative GPA", y="term GPA",
       title="term GPA vs. cumulative GPA")
p1 + p2 + p3 + plot_layout(ncol=3, heights=c(5,5,5))


## ----  fig.height=5, fig.cap="Residual plots of total sleep time and cumulative GPA. Variances are equal for total sleep time, but not for cumulative GPA."----
# fit a linear regression
reg <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data=data)

# create residual plots
p1 = ggplot(data=data, aes(x=TotalSleepTime, y=reg$residuals)) +
  geom_point(alpha=0.5) +
  labs(x="Total sleep time (mins)", y="Residuals") +
  geom_hline(yintercept=0, color="red") +
  labs(title="residuals vs. total sleep time")

p2 = ggplot(data=data, aes(x=cum_gpa, y=reg$residuals)) +
  geom_point(alpha=0.5) +
  labs(x="Cumulative GPA", y="Residuals") +
  geom_hline(yintercept=0, color="red") +
  labs(title="residuals vs. cumulative GPA")

p1 | p2


## -----------------------------------------------------------------------------
# create a table that summarizes the linear regression output, along with CIs.
summary_table = tidy(reg)
summary_table <- cbind(summary_table, confint(reg)[, 1:2])
summary_table <- summary_table[, -1]
summary_table <- round(summary_table, digits=6)
colnames(summary_table)[c(3, 5, 6)] = c("t-statistic", "CI.Lower", "CI.Upper")
summary_table %>%
  kbl(booktabs = T,
      caption="Summary of linear regression") %>%
  kable_classic(full_width=F, html_font="Cambria") %>%
  kable_styling(latex_options = "HOLD_position")


## ---- results='hide'----------------------------------------------------------
t = summary_table$`t-statistic`[2]
critical_t = qt(1 - 0.05, 631)
t > critical_t

