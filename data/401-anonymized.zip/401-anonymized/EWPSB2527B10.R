## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(ggplot2)
library(dplyr)

dataset = read.csv("/Users/nanditha/Downloads/cmu-sleep.csv")


## -----------------------------------------------------------------------------
dataset$difference_gpa = dataset$term_gpa - dataset$cum_gpa


## -----------------------------------------------------------------------------
summary(dataset$term_gpa)


## -----------------------------------------------------------------------------
summary(dataset$cum_gpa)


## -----------------------------------------------------------------------------
summary(dataset$TotalSleepTime)


## -----------------------------------------------------------------------------
summary(dataset$difference_gpa)


## -----------------------------------------------------------------------------
ggplot(dataset, aes(x= TotalSleepTime)) +
geom_histogram(color = "black", fill = "red", bins = 50) + 
labs(x = "Sleep Time per Night (in mins)", y = "Frequency", title = "Histogram of Sleep Time")


## -----------------------------------------------------------------------------
ggplot(dataset, aes(x= term_gpa)) +
geom_histogram(color = "black", fill = "pink", bins =50) + 
labs(x = "Term GPA (out of 4.0)", y = "Frequency", title = "Histogram of Student's Term GPA")


## -----------------------------------------------------------------------------
ggplot(dataset, aes(x= cum_gpa)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Cumulative GPA (out of 4.0)", y = "Frequency", title = "Histogram of Student's Cumulative GPA")


## ---- echo=FALSE--------------------------------------------------------------
ggplot(dataset, aes(x = TotalSleepTime, y = term_gpa)) + geom_point() + labs(title = "Term GPA vs. Total Sleep Time", x = "Average Hours of Sleep (in minutes)", y = "Term GPA")


## ---- echo=FALSE--------------------------------------------------------------
ggplot(dataset, aes(x = TotalSleepTime, y = cum_gpa)) + geom_point() + labs(title = "Cumulative GPA vs Total Sleep Time", x = "Average Hours of Sleep per night (in minutes)", y = "Cumulative GPA")


## ---- echo=FALSE--------------------------------------------------------------
ggplot(dataset, aes(x = TotalSleepTime, y = difference_gpa)) + geom_point() + labs(title = "Difference in GPA vs Total Sleep Time", x = "Average Hours of Sleep (in minutes) ", y = "GPA Difference (Term - Cum GPA)")


## -----------------------------------------------------------------------------
lm_model = lm(difference_gpa ~ TotalSleepTime, dataset)
summary(lm_model)


## -----------------------------------------------------------------------------
lm_model_log = lm(difference_gpa ~ log(TotalSleepTime), dataset)
summary(lm_model_log)


## ---- echo=FALSE--------------------------------------------------------------
Residuals = residuals(lm_model_log)
ggplot(dataset, aes(x = TotalSleepTime, y = Residuals)) + geom_point()


## ---- echo=FALSE--------------------------------------------------------------
summary(lm_model_log)


## ---- echo=FALSE--------------------------------------------------------------
confint(lm_model_log)

