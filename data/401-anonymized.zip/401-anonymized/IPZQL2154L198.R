## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(ggplot2)


## ---- echo = FALSE------------------------------------------------------------
hist(Rateprof$quality, 
     main = "Frequency of Average Instruction Quality", 
     xlab = "Average Instruction Quality (1 - worst to 5 - best)", 
     ylab = "Number of Professors", 
     sub = "Figure 1: Unimodal and skewed left. No apparent outliers.")


## ---- echo = FALSE------------------------------------------------------------
par(mfrow = c(2, 1))

plot(Rateprof$gender, 
     main = "Frequency of Gender", 
     xlab = "Gender", 
     ylab = "Number of Professors", 
     sub = "Figure 2: More male professors overall.", 
     names.arg = c("Female", "Male"))

plot(Rateprof$pepper, 
     main = "Frequency of Attractiveness", 
     xlab = "Attractiveness", 
     ylab = "Number of Professors", 
     sub = "Figure 3: More non-attractive professors overall.", 
     names.arg = c("No", "Yes"))


## ---- echo = FALSE------------------------------------------------------------
par(mfrow = c(2, 1))

hist(Rateprof$easiness, 
     main = "Frequency of Average Course Difficulty", 
     xlab = "Average Course Difficulty (1 - most difficult to 5 - least difficult)", 
     ylab = "Number of Professors", 
     sub = "Figure 4: Unimodal, relatively symmetric, and bell-shaped. No apparent outliers.")

plot(Rateprof$discipline, 
     main = "Frequency of Discipline", 
     xlab = "Discipline", 
     ylab = "Number of Professors", 
     sub = "Figure 5: Most common is humanities and least common is professional training.")


## ---- echo = FALSE------------------------------------------------------------
ggplot(Rateprof, aes(x = easiness)) + 
  geom_point(aes(y = quality, color = gender, shape = discipline)) + 
  labs(title = "Instruction Quality vs. Course Difficulty by Gender and Discipline", 
       x = "Average Course Difficulty (1 - difficult to 5 - easy)", 
       y = "Average Instruction Quality (1 - worst to 5 - best)", 
       subtitle = "Figure 6: Positive, linear, and with slightly uneven gender scatter. No interaction.") + 
  scale_color_discrete(name = "Gender", 
                       labels = c("Female", "Male")) + 
  scale_shape_discrete(name = "Discipline")


## ---- echo = FALSE------------------------------------------------------------
ggplot(Rateprof, aes(x = easiness)) + 
  geom_point(aes(y = quality, color = pepper)) + 
  labs(title = "Instruction Quality vs. Course Difficulty by Attractiveness", 
       x = "Average Course Difficulty (1 - difficult to 5 - easy)", 
       y = "Average Instruction Quality (1 - worst to 5 - best)", 
       subtitle = "Figure 7: Relatively positive and linear with uneven attractiveness scatter.") + 
  scale_color_discrete(name = "Attractiveness", 
                       labels = c("No", "Yes"))


## ---- include = FALSE---------------------------------------------------------
model = lm(quality ~ pepper + easiness + gender + discipline, 
           data = Rateprof)

residuals = resid(model)


## ---- echo = FALSE------------------------------------------------------------
qqnorm(residuals, 
       sub = "Figure 8: Close to the Q-Q line, excluding the ends.")
qqline(residuals)


## ---- echo = FALSE------------------------------------------------------------
plot(fitted(model), residuals, 
     main = "Residuals vs. Fitted Values", 
     xlab = "Fitted Values", 
     ylab = "Residuals", 
     sub = "Figure 9: Scattered randomly around zero with possible heteroskedasticity.")


## ---- include = FALSE---------------------------------------------------------
model1 = lm(quality ~ pepper + easiness * gender + discipline, 
           data = Rateprof)
summary(model1)

model2 = lm(quality ~ pepper + easiness * discipline + gender, 
           data = Rateprof)
summary(model2)


## ---- include = FALSE---------------------------------------------------------
summary(model)

confint(model)


## ---- include = FALSE---------------------------------------------------------
anova(model, model1)
anova(model, model2)

