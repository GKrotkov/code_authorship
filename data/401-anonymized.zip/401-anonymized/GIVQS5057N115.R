## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(gridExtra)
library(alr4)
library(GGally)
library(tidyverse)


## -----------------------------------------------------------------------------
ratings = Rateprof
ratings = ratings[, 1:12]


## -----------------------------------------------------------------------------
# Adding squared value to dataframe
ratings$qual_sq = ratings$quality^2

st_plot = ratings %>%
  ggplot(aes(x=quality)) +
  geom_histogram(breaks=seq(1,5,0.25), fill="springgreen4", color="black") +
  xlim(1,5) +
  labs(x="Quality Rating")
sq_plot = ratings %>%
  ggplot(aes(x=qual_sq)) +
  geom_histogram(breaks=seq(1,25,1.25), fill="springgreen4", color="black") +
  xlim(1,25) +
  labs(x="Quality Rating Squared")


## ---- fig.width=4.5, fig.height=1.75, fig.cap="Distributions of Average Professor Quality and Square of Average Professor Quality"----
grid.arrange(st_plot, sq_plot, ncol=2)


## -----------------------------------------------------------------------------
h_plot = ratings %>%
  ggplot(aes(x=helpfulness)) +
  geom_histogram(breaks=seq(1,5,0.25), fill="springgreen4", color="black") +
  xlim(1,5) +
  labs(x="Helpfulness Rating")

c_plot = ratings %>%
  ggplot(aes(x=clarity)) +
  geom_histogram(breaks=seq(1,5,0.25), fill="springgreen4", color="black") +
  xlim(1,5) +
  labs(x="Clarity Rating")

e_plot = ratings %>%
  ggplot(aes(x=easiness)) +
  geom_histogram(breaks=seq(1,5,0.25), fill="springgreen4", color="black") +
  xlim(1,5) +
  labs(x="Easiness Rating")

i_plot = ratings %>%
  ggplot(aes(x=raterInterest)) +
  geom_histogram(breaks=seq(1,5,0.25), fill="springgreen4", color="black") +
  xlim(1,5) +
  labs(x="Interest Rating")


## ---- fig.width=4.5, fig.height=3.5, fig.cap="Distribution of Average Professor Helpfulness"----
grid.arrange(h_plot, c_plot, e_plot, i_plot)


## -----------------------------------------------------------------------------
# Adding squared values to dataframe
ratings$help_sq = ratings$helpfulness^2
ratings$clar_sq = ratings$clarity^2
help_sq_plot = ratings %>%
  ggplot(aes(x=help_sq)) +
  geom_histogram(breaks=seq(1,25,1.25), fill="springgreen4", color="black") +
  xlim(1,25) +
  labs(x="Helpfulness Rating Squared")

clar_sq_plot = ratings %>%
  ggplot(aes(x=clar_sq)) +
  geom_histogram(breaks=seq(1,25,1.25), fill="springgreen4", color="black") +
  xlim(1,25) +
  labs(x="Clarity Rating Squared")


## ---- fig.width=4.25, fig.height=1.75, fig.cap="Distributions of Square of Average Professor Helpfulness and Clarity"----
grid.arrange(help_sq_plot, clar_sq_plot, ncol=2)


## -----------------------------------------------------------------------------
pep_plot = ratings %>%
  ggplot(aes(x=pepper)) +
  geom_bar(fill="springgreen4", color="black") +
  labs(x="Pepper (Attractiveness)")
gen_plot = ratings %>%
  ggplot(aes(x=gender)) +
  geom_bar(fill="springgreen4", color="black") +
  labs(x="Gender")
dis_plot = ratings %>%
  ggplot(aes(x=discipline)) +
  geom_bar(fill="springgreen4", color="black") +
  labs(x="Discipline")


## ---- fig.width=6.375, fig.height=1.75, fig.cap="Distribution of Attractivness, Gender, and Discipline"----
grid.arrange(pep_plot, gen_plot, dis_plot, ncol=3)


## -----------------------------------------------------------------------------
pairs = ratings %>%
  select(qual_sq, help_sq, clar_sq, easiness, raterInterest)


## ---- fig.width=6.5, fig.height=6.5, fig.cap="Bivariate Distributions of Student Rated Variables", message=FALSE----
pairs %>% ggpairs


## ---- fig.width=6, fig.height=2.5, fig.cap="Distribution of Easiness given Gender and Discipline"----
ratings %>%
  ggplot(aes(x=discipline, y=easiness, fill=gender)) +
  geom_boxplot(alpha=0.5)


## ---- include=FALSE-----------------------------------------------------------
two.way <- aov(easiness ~ gender + discipline, data = ratings)
summary(two.way)


## ---- fig.width=6, fig.height=4, fig.cap="Normal QQ Plot of Residuals"--------
par(mfrow=c(2,2))
plot(two.way, cex=0.25)


## ---- include=FALSE-----------------------------------------------------------
lin_mod = lm(qual_sq ~ gender+pepper+easiness*discipline, data=ratings)
summary(lin_mod)


## ---- fig.width=3.5, fig.height=2, fig.cap="Residuals vs Fit", message=FALSE----
tibble(fits = fitted(lin_mod), 
       residuals = residuals(lin_mod)) %>%
  ggplot(aes(x = fits, y = residuals)) +
  geom_point(alpha = 0.5) +
  geom_smooth() +
  geom_hline(yintercept = 0, 
             linetype = "dashed",
             color = "red")


## ---- fig.width=3.5, fig.height=3.5, fig.cap="Normal QQ Plot of Residuals"----
qqnorm(resid(lin_mod))
qqline(resid(lin_mod))


## -----------------------------------------------------------------------------
summary(two.way)


## -----------------------------------------------------------------------------
df = broom::tidy(lin_mod)
df = df %>%
  rename(
    Term = term,
    Estimate = estimate,
    standardError = std.error,
    tStatistic = statistic,
    pValue = p.value
  )
df$Term[1] = "Intercept"
df$Term[2] = "Gender (Male)"
df$Term[3] = "Attractiveness (Yes)"
df$Term[4] = "Easiness"
df$Term[5] = "Discipline (Social Science)"
df$Term[6] = "Discipline (STEM)"
df$Term[7] = "Discipline (Pre-professional)"
df$Term[8] = "Easiness : Discipline (Social Science)"
df$Term[9] = "Easiness : Discipline (STEM)"
df$Term[10] = "Easiness : Discipline (Pre-professional)"
knitr::kable(df, digits=4)


## ---- include=FALSE-----------------------------------------------------------
confint(lin_mod)
summary(lin_mod)


## ---- include=FALSE-----------------------------------------------------------
full_mod = lin_mod
anova(full_mod)
red_mod = lm(qual_sq ~ gender+pepper+easiness, data=ratings)
anova(red_mod)


## ---- include=FALSE-----------------------------------------------------------
RSS_red = 7269.8
RSS_full = 7163.2
k = 6
n = nrow(ratings)
q = 10
numerator = (RSS_red - RSS_full)/k
denominator = RSS_full/(n-q)

f_statistic = numerator/denominator
pf(f_statistic, k, n-q, lower.tail=FALSE)

