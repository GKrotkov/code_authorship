## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
library(ggplot2)
library(broom)
knitr::opts_chunk$set(echo = FALSE)
knitr::opts_chunk$set(fig.pos = "H", out.extra = "")


## -----------------------------------------------------------------------------
cmusleep <- read.csv("cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Average Sleep Time for Students in 1 Month", fig.align='center'----
hist(cmusleep$TotalSleepTime, 
     xlab = "Average Sleep Time (mins)",
     main = "")


## ---- fig.width=4, fig.height=3, fig.cap="Semester GPA for Students", fig.align='center'----
hist(cmusleep$term_gpa,
     main = "",
     xlab = "Semester GPA (4.0 scale)")


## ---- fig.width=4, fig.height=3, fig.cap="GPA vs Sleep Time for Students", warning=FALSE, message=FALSE, fig.align='center'----
ggplot(cmusleep, aes(x=TotalSleepTime, y =term_gpa)) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(x="Average Sleep Time (mins)", 
       y = "Semester GPA (4.0 scale)", 
       title = "") 



## ---- include=FALSE-----------------------------------------------------------
lm1 <- lm(term_gpa ~ TotalSleepTime, data = cmusleep)


## ---- fig.width=4, fig.height=3, fig.cap= "Residual vs Average Sleep Time for Students", fig.align='center'----
ggplot(augment(lm1), aes(x = TotalSleepTime, y = .resid)) +
  geom_point() +
  labs(x = "Average Sleep Time (mins) ", 
       y = "Residual", 
       title = "")


## ---- fig.width= 4, fig.height=3, fig.cap= "Q-Q Plot for Residuals", fig.align='center'----

ggplot(augment(lm1), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantiles", y = "Sample quantiles")


## ---- include = FALSE---------------------------------------------------------
cookd <- cooks.distance(lm1)
which.max(cookd)
cookd[471]


## ---- include=FALSE-----------------------------------------------------------
.00274*60*2
.00123*60*2
.00199*60*2


