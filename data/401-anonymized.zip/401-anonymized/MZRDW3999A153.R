## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, include=FALSE--------------------------------------------
library(ggplot2)
library(dplyr)
library(tidyverse)
library(regressinator)
library(broom)


## ---- include=FALSE-----------------------------------------------------------
data <- read.csv("cmu-sleep.csv", header=TRUE, stringsAsFactors=FALSE)
termgpa <- data$term_gpa
totalsleep <- data$TotalSleepTime


## ---- fig.width=8, fig.height=5, fig.cap="Time students slept in minutes"-----
hist(totalsleep, main = "Sleep Time of all students", xlab = "Sleep Time (in minutes)")


## ---- fig.width=8, fig.height=3, fig.cap="GPA Students recieve that specific term"----
fig.align = 'center'
hist(termgpa, main = "Term GPA", xlab = "Term GPA (on a 4.0 scale)")


## ---- fig.width=8, fig.height=3, fig.cap="GPA Students recieve that specific term^4"----
fig.align = 'center'
hist(termgpa^4, main = "Term GPA", xlab = "Term GPA^4 (on a 4.0 scale)")


## ---- fig.width=8, fig.height=3, fig.cap="Time asleep (in minutes) against Term GPA^4 (4.0 scale)"----
fig.align = 'center'
ggplot(data, aes(x = totalsleep, y = (termgpa)^4)) + geom_point() + labs(title = 'Time sleep at night vs. Term GPA^4', x = 'Time alseep (minutes)', y = 'Term GPA (4.0 scale)^4')


## ---- fig.width=8, fig.height=3, fig.cap="Time asleep (in minutes) against Term GPA (4.0 scale)"----
fig.align = 'center'
ggplot(data, aes(x = totalsleep, y = (termgpa))) + geom_point() + labs(title = 'Time sleep at night vs. Term GPA', x = 'Time alseep (minutes)', y = 'Term GPA (4.0 scale)')


## ---- include=FALSE-----------------------------------------------------------
linmodel <- lm((termgpa)^4 ~ (totalsleep))
linmodel_2 <- lm((termgpa) ~ (totalsleep))
summary(linmodel)
cor(((termgpa)), totalsleep)


## ---- fig.width=8, fig.height=4, fig.cap="Residuals of Linear Model"----------
fig.align = 'center'
ggplot(augment(linmodel), aes(x = totalsleep, y = .resid)) +
geom_point() +
labs(x = "Total Sleep (minutes)", y = "Residual")


## ---- fig.width=8, fig.height=4, fig.cap="Figure 7: Q-Q Plot of proposed linear model"----
fig.align = 'center'
residuals_model <- resid(linmodel)
qqnorm(residuals_model)
qqline(residuals_model, col= "blue")


## ---- include=FALSE-----------------------------------------------------------
sum(residuals_model)


## ---- include=FALSE-----------------------------------------------------------
confint(linmodel)

