## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
data <- read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
suppressMessages(library(ggplot2))
suppressMessages(library(dplyr))
suppressMessages(library(gridExtra))


## ---- fig.width=4, fig.height=3, fig.cap="Over view of students' total sleep time (minutes)."----
ggplot(data, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 25, color = "grey") +
  labs(x = "Total Sleep Time (minutes)", y = "Count") +
  ggtitle("Distribution of Total Sleep Time")


## ---- fig.width=4, fig.height=3, fig.cap="Over view of students' term GPAs (out of 4.0)."----
ggplot(data, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.25, color = "grey") +
  labs(x = "Term GPA (/4.0)", y = "Count") +
  ggtitle("Distribution of Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Over view of students' cumulative GPAs (out of 4.0)."----
ggplot(data, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.25, color = "grey") +
  labs(x = "Cumulative GPA (/4.0)", y = "Count") +
  ggtitle("Distribution of Cumulative GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between students' average total sleep time and term GPAs.."----
ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(alpha = .75) +
  labs(x = "Total Sleep Time (minutes /night)", y = "Term GPA (/4.0)") +
  ggtitle("Term GPA vs. Total Sleep Time")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between students' cumulative GPAs and term GPAs (out of 4.0)."----
ggplot(data, aes(x = cum_gpa, y = term_gpa)) +
  geom_point(alpha = .75) +
  geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed") +
  labs(x = "Cumulative GPA (/4.0)", y = "Term GPA (/4.0)") +
  ggtitle("Cumulative GPA vs. Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Relationship between student's GPA difference and total sleep time."----
ggplot(data, aes(x = TotalSleepTime, y = term_gpa - cum_gpa)) +
  geom_point(alpha = .75) +
  labs(x = "Total Sleep Time (minutes)", y = "GPA difference") +
  ggtitle("GPA difference vs. Total Sleep Time")


## -----------------------------------------------------------------------------
lm.tvs = lm(term_gpa ~ TotalSleepTime, data = data)
intercept <- coef(lm.tvs)[1]
slope <- coef(lm.tvs)[2] 
line.tvs <- geom_abline(intercept = intercept, slope = slope, color = "red")
#confint(lm.tvs)
#summary(lm.tvs)


## ---- fig.width=8, fig.height=3, fig.cap="Attempt to apply a linear regression model on total sleep time and term GPAs."----
plot.tvs <- ggplot(data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(alpha = .75) +
  labs(x = "Total Sleep Time (minutes /night)", y = "Term GPA (/4.0)") +
  ggtitle("Linear Regression of GPA vs. Sleep Time")
plot1<- plot.tvs + line.tvs

residuals <- residuals(lm.tvs)
qq_data <- data.frame(
  Theoretical_Quantiles = qnorm(ppoints(length(residuals))),
  Sample_Quantiles = quantile(residuals, probs = ppoints(length(residuals)))
)

plot2 <- ggplot(data = qq_data, aes(x = Theoretical_Quantiles, y = Sample_Quantiles)) +
  geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed") + 
  geom_point(alpha = 0.75) +  
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles", title = "Corresponding Q-Q Plot")
grid.arrange(plot1, plot2, ncol = 2)


## ---- fig.width=8, fig.height=3, fig.cap="Linear regression model on total sleep time and GPA change."----
lm.tvc = lm(3 * (term_gpa - cum_gpa) ~ TotalSleepTime, data = data)
intercept <- coef(lm.tvc)[1]
slope <- coef(lm.tvc)[2] 
line.tvc <- geom_abline(intercept = intercept, slope = slope, color = "red")

plot.tvc <- ggplot(data, aes(x = TotalSleepTime, y = 3*(term_gpa - cum_gpa))) +
  geom_point(alpha = .75) +
  labs(x = "Total Sleep Time (minutes /night)", y = "GPA Change (/4.0)") +
  ggtitle("GPA Change vs. Total Sleep Time")
plot3<- plot.tvc + line.tvc

residuals <- residuals(lm.tvc)
qq_data <- data.frame(
  Theoretical_Quantiles = qnorm(ppoints(length(residuals))),
  Sample_Quantiles = quantile(residuals, probs = ppoints(length(residuals)))
)

plot4 <- ggplot(data = qq_data, aes(x = Theoretical_Quantiles, y = Sample_Quantiles)) +
  geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed") + 
  geom_point(alpha = 0.75) +  
  labs(x = "Theoretical Quantiles", y = "Sample Quantiles", title = "Corresponding Q-Q Plot")
grid.arrange(plot3, plot4, ncol = 2)


## -----------------------------------------------------------------------------
# confint(lm.tvc)
# summary(lm.tvc)
cooksd <- cooks.distance(lm.tvc)
# which (cooks.distance(lm.tvc) > 1)


## ---- fig.width=4, fig.height=3, fig.cap="Distribution of individual data point's Cook Distance"----
ggplot(data.frame(cooksd), aes(x = cooksd)) +
  geom_histogram(binwidth = 0.01, color = "grey") +
  labs(title = "Distribution of Cook's Distance", x = "Cook's Distance", y = "Count")

