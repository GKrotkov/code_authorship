## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
df = read.csv("cmu-sleep.csv")


## ---- include = FALSE---------------------------------------------------------
TotalSleepTime = df$TotalSleepTime
Cum_gpa = df$cum_gpa
Term_gpa = df$term_gpa
hist(df$term_gpa)
summary(df$term_gpa)
sd(df$term_gpa)
min(df$term_gpa)
lterm_gpa = log(4.1-df$term_gpa)
hist(lterm_gpa)
summary(lterm_gpa)
sd(lterm_gpa)
min(lterm_gpa)
ltotalSleepTime = log(df$TotalSleepTime)
lcum_gpa = log(4.1-df$cum_gpa)
summary(lcum_gpa)
sd(lcum_gpa) 


## ---- fig.width=10, fig.height=4, fig.cap="Histogram showing the distribution of Term GPA"----
par(mfrow = c(1,2))
hist(Term_gpa, main = "Distribution of Term GPA", xlab = "Term GPA (out of 4.0)", col = "blue")
hist(lterm_gpa, main = "Distribution of log(4.1-Term_GPA)", xlab = "log(4.1-Term_GPA)", col = "blue")


## ---- include = FALSE---------------------------------------------------------
summary(TotalSleepTime)
sd(TotalSleepTime)


## ---- fig.width=10, fig.height=4, fig.cap="Histogram showing the distribution of Total Sleep Time"----
par(mfrow = c(1,2))
hist(TotalSleepTime, main = "Distribution of Total Sleep Time", xlab = "Total Sleep Time (in minutes)", col = "blue")

hist(ltotalSleepTime, main = "Distribution of log(Total Sleep Time)", xlab = "log(Total Sleep Time)", col = "blue")


## ---- fig.width=10, fig.height=4, fig.cap="Histogram showing the distribution of cum gpa"----
par(mfrow = c(1,2))
hist(df$cum_gpa, main = "Distribution of Cum Gpa", xlab = "Cum gpa", col = "blue")
hist(log(4.1-df$cum_gpa), main = "Distribution of log(4.1- Cum Gpa)", xlab = "log(4.1-Cum gpa)", col = "blue")
lcum_gpa = log (4.1- df$cum_gpa)


## ---- fig.width=10, fig.height=4, fig.cap="Pairs plot for transformed and not transfomred variables"----
pairs(~ lterm_gpa + TotalSleepTime + lcum_gpa)


## ----fig.width=10, fig.height=4, fig.cap="TotalSleepTime vs Term GPA", warning=FALSE, message=FALSE----
par(mfrow = c(1,2))
m = lm(Term_gpa ~ TotalSleepTime)
plot(TotalSleepTime, Term_gpa, main = "Total Sleep Time vs Term GPA", xlab = "Total Sleep Time (minutes)", ylab = "Term GPA") + abline(m, col = "red")

m.trans = lm(lterm_gpa ~ TotalSleepTime + lcum_gpa) #for log domain reason there is one infinity in each of the log vectors
plot(lterm_gpa~ TotalSleepTime , main = "Total Sleep Time vs log(4.1-Term GPA)", xlab = "Total Sleep Time (minutes)", ylab = "log(4.1 - Term GPA)") + abline(m.trans, col = "red")


## ---- include=FALSE-----------------------------------------------------------
anova(m)
anova(m.trans)

summary(m)
summary(m.trans)


## ----message=FALSE, warning=FALSE, fig.width=10, fig.height=5, fig.cap="Cooks distance plots"----
par(mfrow = c(1,2))
highest3idxs = sort(cooks.distance(m.trans), decreasing = TRUE, index.return = TRUE)$ix[1:3]
highest5idxs = sort(cooks.distance(m.trans), decreasing = TRUE, index.return = TRUE)$ix[1:5]
df3 = df[-highest3idxs,]
df5 = df[-highest5idxs,]

Term_gpa3 = df3$term_gpa
TotalSleepTime3 = df3$TotalSleepTime
Cum_gpa3 = df3$cum_gpa
lterm_gpa3 = log(4.1 - Term_gpa3)
lcum_gpa3 = log(4.1 - Cum_gpa3)

m3 = lm(Term_gpa3 ~ TotalSleepTime3 + Cum_gpa3)
lm3 = lm(lterm_gpa3 ~ TotalSleepTime3 + lcum_gpa3)

Term_gpa5 = df5$term_gpa
TotalSleepTime5 = df5$TotalSleepTime
Cum_gpa5 = df5$cum_gpa
lterm_gpa5 = log(4.1 - Term_gpa5)
lcum_gpa5 = log(4.1 - Cum_gpa5)

m5 = lm(Term_gpa5 ~ TotalSleepTime5 + Cum_gpa5)
lm5 = lm(lterm_gpa5 ~ TotalSleepTime5 + lcum_gpa5)

plot(log(4.1-df3$term_gpa)~ df3$TotalSleepTime, main = "Largest 3 Cook's Distances Removed ", xlab = "Total Sleep Time", ylab = "log(4.1-Term gpa)") + abline(lm3, col = "red")

plot(log(4.1-df5$term_gpa)~ df5$TotalSleepTime, main = "Largest 5 Cook's Distances Removed", xlab = "Total Sleep Time", ylab = "log(4.1-Term gpa) (minutes)") + abline(lm5, col = "red")


## ---- include=FALSE-----------------------------------------------------------
anova(m3)
anova(lm3)
anova(m5)
anova(lm5)

summary(m3)
summary(lm3)
summary(m5)
summary(lm5)


## ---- fig.width=10, fig.height=4, fig.cap="Diagnostic Plots", eval=FALSE------
## # One-sample t-test
## t_test_result <- t.test(residuals(lm5), mu=0)
## print(t_test_result)
## 
## 


## ---- fig.width=10, fig.height=4, fig.cap="Residual Plots"--------------------
# Finalized model:
# log(4.1-term_gpa) = .4016 - .0015xTotal Sleep time + .7552xlog(4.1- cum gpa)
par(mfrow = c(1,3))

plot(TotalSleepTime5, residuals(lm5), main="Residuals vs Total Sleep Time", 
     xlab="Total Sleep Time (minutes)", ylab="Residuals")
abline(h=0, col="red")
plot(fitted(lm5), residuals(lm5), main="Residuals vs Fitted Values", 
     xlab="Fitted Values", ylab="Residuals")
abline(h=0, col="red")


# QQ Plot to check for normality of errors
qqnorm(residuals(lm5), main="Q-Q Plot of Residuals"); qqline(residuals(lm5))


## ----include=FALSE------------------------------------------------------------
predict(lm5, newdata = data.frame(c(100)), interval = "confidence", level = .9)
#MODEL: 
#lg(4.1-Term GPA)=
#            .4016- .0015* T.sleep + .7552*lg(cumGPA)
#95%CI: estimate +/- 1.96*SE
#Intercept beta0:
#0.4016 +/- 1.96*0.1789 


## ---- include = FALSE---------------------------------------------------------
c(0.4106-1.96*0.1789,0.4106+1.96*0.1789)


## ---- include = FALSE---------------------------------------------------------
#Total sleep time beta1:
#-0.00149+/-1.96*0.00045
c(-0.00149-1.96*0.00045,-0.00149+1.96*0.00045)


## ---- include = FALSE---------------------------------------------------------
# Log(4.1- cum gpa) beta2:
# 0.75519+/-1.96*0.0301
c(0.75519-1.96*0.0301,0.75519+1.96*0.0301)
# Log(4.1- cum gpa) beta2:
# 0.75519+/-1.96*0.0301


## ---- include = FALSE---------------------------------------------------------
# By looking at the best model we have discovered:
# log(4.1-term_gpa) = .4016 - .0015xTotal Sleep time + .7552xlog(4.1- cum gpa)

