## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE, message = FALSE----------------------------------------
library(tidyverse)
library(ggplot2)
library(dplyr)
library(car)
sleep <- read.csv("cmu-sleep.csv")


## ---- fig.width = 5, fig.height = 4, echo = FALSE, fig.cap = "Average sleep duration for the students"----
sleep %>%
  ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(fill = "lavender", color = "black", bins = 30) +
  labs(title = "Histogram of Average Sleep Duration",
       x = "Total Sleep Time (minutes)",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 5, fig.height = 4, echo = FALSE, fig.cap = "GPA for the ongoing semester for the students"----
sleep %>%
  ggplot(aes(x = term_gpa)) +
  geom_histogram(fill = "mistyrose", color = "black", bins = 30) +
  labs(title = "Histogram of GPA for the Ongoing Semester",
       x = "Term GPA",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))



## ---- fig.width = 5, fig.height = 4, echo = FALSE, fig.cap = "Cumulative GPA up to the previous semester for the students"----
sleep %>%
  ggplot(aes(x = cum_gpa)) +
  geom_histogram(fill = "lightcyan", color = "black", bins = 30) +
  labs(title = "Histogram of Cumulative GPA up to the Previous Semester",
       x = "Cumulative GPA",
       y = "Frequency") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 5, fig.height = 4, echo = FALSE, fig.cap = "Term GPA each student received with the total sleep duration in minutes"----
sleep %>%
  ggplot(aes(x = term_gpa, y = TotalSleepTime)) +
  geom_point(color = "lightpink")  +
  labs(title = "Scatterplot of Term GPA vs. Total Sleep Time",
       x = "Term GPA",
       y = "Total Sleep Time (minutes)") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- fig.width = 5, fig.height = 4, echo = FALSE, fig.cap = "Cumulative GPA each student received with the total sleep duration in minutes"----
sleep %>%
  ggplot(aes(x = cum_gpa, y = TotalSleepTime)) +
  geom_point(color = "lightblue")  +
  labs(title = "Scatterplot of Cumulative GPA vs. Total Sleep Time",
       x = "Cumulative GPA",
       y = "Total Sleep Time (minutes)") +
  theme(plot.title = element_text(size = 7, hjust = 0.5),
        axis.title.x = element_text(size = 6),
        axis.title.y = element_text(size = 6))


## ---- include = FALSE---------------------------------------------------------
summary(sleep$TotalSleepTime)
summary(sleep$term_gpa)
summary(sleep$cum_gpa)


## ---- include = FALSE---------------------------------------------------------
model = lm(term_gpa~TotalSleepTime, data = sleep)
fits = fitted(model)
res = residuals(model)
plot(fits, res, pch = 16,
     xlab = "Fits", ylab = "Residuals")
abline(h = 0)
durbinWatsonTest(model)
qqnorm(res)
qqline(res)


## ---- include = FALSE---------------------------------------------------------
summary(model)
confint(model)

