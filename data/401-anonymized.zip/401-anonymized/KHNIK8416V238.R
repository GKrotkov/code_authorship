## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
sleep <- read.csv("/Users/vg2/Desktop/cmu-sleep.csv")


## -----------------------------------------------------------------------------
head(sleep)


## -----------------------------------------------------------------------------
hist(sleep$TotalSleepTime,
      main = "The average time the student spent asleep each night (minutes)",
      xlab = "The average time the student spent asleep each night (minutes)",
      col = "lightblue",
      border = "black",
)


## -----------------------------------------------------------------------------
hist(sleep$term_gpa,
      main = "The student GPA in the semester being studied",
      xlab = "The student GPA in the semester being studied",
      col = "lightblue",
      border = "black",
)


## -----------------------------------------------------------------------------
hist(sleep$cum_gpa,
      main = "The student GPA for semesters before the one being studied",
      xlab = "The student GPA for semesters before the one being studied",
      col = "lightblue",
      border = "black",
)


## -----------------------------------------------------------------------------
plot(sleep$TotalSleepTime, sleep$term_gpa,
     main = "The student term GPA against total sleep time",
     xlab = "The student total sleep time",
     ylab = "The student term GPA",
     col = "blue",
     pch =16
)


## -----------------------------------------------------------------------------
model <- lm(sleep$term_gpa ~ sleep$TotalSleepTime, data = sleep)
summary(model)


## -----------------------------------------------------------------------------
plot(model)


## -----------------------------------------------------------------------------
confint(model)


## -----------------------------------------------------------------------------
0.0019846 * (-120)

