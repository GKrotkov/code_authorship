## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(ggplot2)
library(gridExtra)
library(alr4)
library(knitr)
data(Rateprof)


## ---- message=FALSE, fig.width=6, fig.height=3, fig.cap="Histograms of Distributions of Variables"----
dist_gender <- ggplot(Rateprof, aes(x = gender)) + 
  geom_bar(fill = "lightblue", color = "black") +
  labs(title = "Distribution of Instructor Gender",
       x = "Gender", y = "Value") + 
  theme(plot.title = element_text(size=6),
        axis.title = element_text(size=6))

dist_pepper <- ggplot(Rateprof, aes(x = pepper)) + 
  geom_bar(fill = "lightblue", color = "black") +
  labs(title = "Distribution of Attractiveness Rating",
       x = "pepper", y = "Value") + 
  theme(plot.title = element_text(size=6),
        axis.title = element_text(size=6))

dist_easiness <- ggplot(Rateprof, aes(x = easiness)) +
      geom_histogram(fill = "lightblue", color = "black") +
      labs(title = "Distribution of Easiness Rating", 
           x = "easiness", y = "Value") +
      theme(plot.title = element_text(size=6),
            axis.title = element_text(size=6))

dist_discipline <- ggplot(Rateprof, aes(x = discipline)) + 
  geom_bar(fill = "lightblue", color = "black") +
  labs(title = "Distribution of Instructor Discipline",
       x = "discipline", y = "Value") + 
  theme(plot.title = element_text(size=6),
        axis.title = element_text(size=6))

dist_quality <- ggplot(Rateprof, aes(x = quality)) +
      geom_histogram(fill = "lightblue", color = "black") +
      labs(title = "Distribution of Quality Rating", 
           x = "quality", y = "Value") +
      theme(plot.title = element_text(size=6),
            axis.title = element_text(size=6))

grid.arrange(dist_gender, dist_pepper, dist_easiness, dist_discipline,
             dist_quality, ncol=3)


## ---- message=FALSE, fig.width=3.2, fig.height=2.4, fig.cap="The Scatterplot of quality versus easiness with a linear regression line"----
scat_easiness <- ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() + geom_smooth(method = lm, se = FALSE) +
  labs(title = "Quality vs Easiness",
       x = "Easiness", y = "Quality") +
  theme_bw() + theme(plot.title = element_text(size = 10),
                     axis.title = element_text(size = 10))

grid.arrange(scat_easiness, ncol=1)


## ---- message=FALSE, fig.width=8, fig.height=3, fig.cap="The boxplots of quality versus gender, pepper and discipline"----
box_gender <- ggplot(Rateprof, aes(x = factor(gender), y = quality, 
                                fill = factor(gender))) +
  geom_boxplot() + labs(title = "Quality vs Gender",
                        x = "Gender", y = "Quality") +
  theme_bw() + theme(plot.title = element_text(size = 8),
                     axis.title = element_text(size = 8))

box_pepper <- ggplot(Rateprof, aes(x = factor(pepper), y = quality, 
                                fill = factor(pepper))) +
  geom_boxplot() + labs(title = "Quality vs pepper",
                        x = "Pepper", y = "Quality") +
  theme_bw() + theme(plot.title = element_text(size = 8),
                     axis.title = element_text(size = 8))

box_discipline <- ggplot(Rateprof, aes(x = factor(discipline), y = quality, 
                                fill = factor(discipline))) +
  geom_boxplot() + labs(title = "Quality vs Discipline",
                        x = "Discipline", y = "Quality") +
  theme_bw() + theme(plot.title = element_text(size = 8),
                     axis.title = element_text(size = 8))

grid.arrange(box_gender, box_pepper, box_discipline, ncol=2)


## -----------------------------------------------------------------------------
model_reduced3 <- lm(quality ~ easiness + gender + discipline + pepper, data = Rateprof)
model_reduced1 <- lm(quality ~ easiness * gender + discipline + pepper, data = Rateprof)
model_reduced2 <- lm(quality ~ easiness * discipline + gender + pepper, data = Rateprof)
# model_reduced3 <- lm(quality ~ easiness + gender + discipline, data = Rateprof)

# Fit the Full Model (with interaction terms)
model_full <- lm(quality ~ easiness * gender + easiness * discipline + pepper, data = Rateprof)


## ---- message=FALSE, fig.width=6, fig.height=4, fig.cap="Residual versus Fitted Values Plot and Normal QQ-Plot"----
# par(mfrow=c(2, 4))
library(ggpubr)

# Data frame with predicted values and residuals for all models
residual_data_full <- data.frame(
  Predicted = predict(model_full),
  Residuals = residuals(model_full)
)

residual_data_reduced3 <- data.frame(
  Predicted = predict(model_reduced3),
  Residuals = residuals(model_reduced3)
)

residual_data_reduced1 <- data.frame(
  Predicted = predict(model_reduced1),
  Residuals = residuals(model_reduced1)
)

residual_data_reduced2 <- data.frame(
  Predicted = predict(model_reduced2),
  Residuals = residuals(model_reduced2)
)


# full residuals and qq plot
res_full <- ggplot(residual_data_full, aes(x = Predicted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residual Plot model_full", x = "model_full fitted values", y = "Residuals") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

qq_full <- ggqqplot(residuals(model_full)) +
  labs(title = "Q-Q Plot for model_full") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

# reduced residuals and qq plot
res_red3 <- ggplot(residual_data_reduced3, aes(x = Predicted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residual Plot model_reduced3", x = "model_reduced3 fitted values", y = "Residuals") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

qq_red3 <- ggqqplot(residuals(model_reduced3)) +
  labs(title = "Q-Q Plot for model_reduced3") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

res_red1 <- ggplot(residual_data_reduced1, aes(x = Predicted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residual Plot model_reduced1", x = "model_reduced1 fitted values", y = "Residuals") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

qq_red1 <- ggqqplot(residuals(model_reduced1)) +
  labs(title = "Q-Q Plot for model_reduced1") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

# reduced2 residuals and qq plot
res_red2 <- ggplot(residual_data_reduced2, aes(x = Predicted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(title = "Residual Plot model_reduced2", x = "model_reduced2 fitted values", y = "Residuals") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

qq_red2 <- ggqqplot(residuals(model_reduced2)) +
  labs(title = "Q-Q Plot for model_reduced2") +
  theme(plot.title = element_text(size=5), axis.title = element_text(size=5))

grid.arrange(res_full, qq_full, res_red3, qq_red3, res_red1, qq_red1, res_red2, qq_red2, ncol=4)



## -----------------------------------------------------------------------------
cookd_full <- cooks.distance(model_full)
cookd_red3 <- cooks.distance(model_reduced3)
cookd_red1 <- cooks.distance(model_reduced1)
cookd_red2 <- cooks.distance(model_reduced2)
# which.max(cookd_full)

# f_50th_full <- qf(0.5, 7, 357) # q, n-q n=364
f_20th_full <- qf(0.2, 7, 357)
f_20th_red3 <- qf(0.2, 5, 359)
f_20th_red1 <- qf(0.2, 6, 358)
f_20th_red2 <- qf(0.2, 6, 358)


## ---- message=FALSE, fig.width=5.4, fig.height=3.6, fig.cap="Compare the cooks distance of the data to F distribution with a line indicating the 20th percentile in such distribution"----
# Create a data frame with Cook's distance values
cooksData_full <- data.frame(
  Observation = 1:length(cookd_full),
  CooksD = cookd_full
)

cooksData_red3 <- data.frame(
  Observation = 1:length(cookd_red3),
  CooksD = cookd_red3
)

cooksData_red1 <- data.frame(
  Observation = 1:length(cookd_red1),
  CooksD = cookd_red1
)

cooksData_red2 <- data.frame(
  Observation = 1:length(cookd_red2),
  CooksD = cookd_red2
)

# Plotting Cook's distance
cook_full <- ggplot(cooksData_full, aes(x = Observation, y = CooksD)) +
  geom_point() + geom_hline(yintercept = f_20th_full, color = "red") +
  labs(title = "Cook's Distance Plot for model_full", 
       x = "Observation Index", y = "Cook's Distance") +
  theme(plot.title = element_text(size=8), axis.title = element_text(size=8))

cook_red3 <- ggplot(cooksData_red3, aes(x = Observation, y = CooksD)) +
  geom_point() + geom_hline(yintercept = f_20th_red3, color = "red") +
  labs(title = "Cook's Distance Plot for model_reduced3", 
       x = "Observation Index", y = "Cook's Distance") +
  theme(plot.title = element_text(size=8), axis.title = element_text(size=8))

cook_red1 <- ggplot(cooksData_red1, aes(x = Observation, y = CooksD)) +
  geom_point() + geom_hline(yintercept = f_20th_red1, color = "red") +
  labs(title = "Cook's Distance Plot for model_reduced1", 
       x = "Observation Index", y = "Cook's Distance") +
  theme(plot.title = element_text(size=8), axis.title = element_text(size=8))

cook_red2 <- ggplot(cooksData_red2, aes(x = Observation, y = CooksD)) +
  geom_point() + geom_hline(yintercept = f_20th_red2, color = "red") +
  labs(title = "Cook's Distance Plot for model_reduced2", 
       x = "Observation Index", y = "Cook's Distance") +
  theme(plot.title = element_text(size=8), axis.title = element_text(size=8))

grid.arrange(cook_full, cook_red3, cook_red1, cook_red2, ncol=2)


## ---- message=FALSE-----------------------------------------------------------
final <- step(model_reduced3, direction = "both", trace = 0)
# summary(final)
model_final_summary <- summary(final)
coefficients_table <- model_final_summary$coefficients
coefficients_df <- as.data.frame(coefficients_table)

model_summary_df <- data.frame(
  Term = c("(Intercept)", "easiness", "gendermale", "pepperyes"),
  Estimate = c(1.67028, 0.55064, 0.17364, 0.63741),
  Std.Error = c(0.15340, 0.04584, 0.06966, 0.10712),
  "t value" = c(10.888, 12.012, 2.493, 5.950),
  "Pr(>|t|)" = c("< 2e-16", "< 2e-16", "0.0131", "6.32e-09")
)

# Generate the table using kable
# kable_table <- kable(model_summary_df, digits = 4)
# print(kable_table)

# kable(coefficients_df, caption = "Linear Regression Results", 
#       col.names = c("", "Estimate", "Std. Error", "t value", "Pr(>|t|)"))


## ---- message=FALSE, warning=FALSE, fig.cap="Predicting quality rating with easiness, gender and pepper. Values in parentheses are standard errors."----
library(modelsummary)
modelsummary(list("Model" = model_reduced3, "Stepped Model" = final),
             gof_map = c("r.squared", "nobs"))


## -----------------------------------------------------------------------------
conf_intervals <- confint(final, level = 0.95)

# Print the confidence intervals
# print(conf_intervals)

