## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and s.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(ggplot2)
library(knitr)
library(broom)
library(modelsummary)


## -----------------------------------------------------------------------------
prof <- alr4::Rateprof


## ---- fig.width=4, fig.height=2.5, fig.pos = "H", fig.cap="Histogram of average quality ratings, from 1 (worst) to 5 (best). The distribution is left-skewed with a median of roughly 3.5."----
hist(prof$quality, main = "Histogram of Average Quality Ratings", xlab="Average Quality Ratings (1, worst to 5, best)", ylab="Frequency", breaks = 20, col = "lightblue")


## ---- fig.width=8, fig.height=2.5, fig.pos = "H", fig.cap="(left) Histogram of gender of professors. There is a slightly higher proportion of males, with 159 female professors and 207 male professors. Figure 2b: (right) Histogram of attractiveness of professors, based on pepper score. There is a much larger proportion of No responses, ie unattractive."----
par(mfrow = c(1, 2))

barplot(table(prof$gender), col = "lightblue", main = "Histogram of Gender", ylab="Frequency")
barplot(table(prof$pepper), col = "lightblue", main = "Histogram of Attractiveness", ylab="Frequency")

par(mfrow = c(1, 1))



## ---- fig.width=4, fig.height=2.5, fig.pos = "H", fig.cap="Histogram of easiness of course, from 1 (worst) to 5 (best). The distribution of average easiness ratings appears to be roughly uniform with a mean of 3."----
hist(prof$easiness, main = "Histogram of Easiness", xlab="Easiness Rating (1, worst to 5, best)", ylab="Frequency", breaks = 20, col = "lightblue")


## ---- fig.width=5, fig.height=2.5, fig.pos = "H", fig.cap="Histogram of discipline of professors. The distribution of disciplines is roughly equally distributed, with more humanities and STEM professors."----
barplot(table(prof$discipline), col = "lightblue", main = "Histogram of Discipline", ylab="Frequency")


## ---- fig.width=5, fig.height=2.2, fig.pos = "H", fig.cap="Scatterplot of average quality ratings vs gender. There appears to be no association between average quality rating and gender."----
df <- data.frame(Factor = prof$gender, Numeric = prof$quality)
ggplot(df, aes(x = Factor, y = Numeric)) +
  geom_point(position = position_jitter(width = 0.3),  
             size = 3) +
  labs(title = "Scatterplot of Average Quality Ratings vs Gender",
       x = "Gender",
       y = "Average Quality Ratings")


## ---- fig.width=5, fig.height=2.25, fig.pos = "H", fig.cap="Scatterplot of average quality ratings vs attractiveness, measured by pepper rating. Professors with a Yes pepper score seem to have higher average quality ratings."----
df <- data.frame(Factor = prof$pepper, Numeric = prof$quality)
ggplot(df, aes(x = Factor, y = Numeric)) +
  geom_point(position = position_jitter(width = 0.3),  
             size = 3) +
  labs(title = "Scatterplot of Average Quality Ratings vs Attractiveness",
       x = "Attractiveness (pepper score)",
       y = "Average Quality Ratings")


## ---- fig.width=6, fig.height=2.5, fig.pos = "H", fig.cap="Scatterplot of average quality ratings vs easiness ratings. There appears to be a positive linear relationship between the average quality rating and the average easiness rating."----
ggplot(prof, aes(x=easiness, y = quality)) + geom_point() + xlab("Easiness Ratings (1, worst to 5, best)") + ylab("Average Quality Ratings (1, worst to 5, best)") + labs(title="Scatterplot of Average Quality Ratings vs Easiness Ratings")



## ---- fig.width=5, fig.height=2.4, fig.pos = "H", fig.cap="Scatterplot of average quality ratings vs discipline. There appears to be no association between average quality rating and discipline"----
df <- data.frame(Factor = prof$discipline, Numeric = prof$quality)
ggplot(df, aes(x = Factor, y = Numeric)) +
  geom_point(position = position_jitter(width = 0.3),  
             size = 3) +
  labs(title = "Scatterplot of Average Quality Ratings vs Discipline",
       x = "Discipline",
       y = "Average Quality Ratings")


## ---- fig.width=4, fig.height=2, fig.cap="Scatterplot of residuals vs fited values. The residuals appear to be centered around 0 and have constant variance."----
lin_reg <- lm(prof$quality ~ factor(prof$gender) + factor(prof$pepper) + prof$easiness + factor(prof$discipline) + prof$easiness:factor(prof$gender) + prof$easiness:factor(prof$discipline), data = prof)

resid <- data.frame(Observation = lin_reg$fitted.values, Residuals = residuals(lin_reg))

ggplot(resid, aes(x = Observation, y = Residuals)) + geom_point() + labs(x = "Fitted Values", y = "Residuals") + ggtitle("Scatterplot of Residuals vs Fitted Values")


## ---- fig.width=4, fig.height=2.3, fig.cap="QQ Plot. The residuals appear to be normally distributed."----
qqnorm(lin_reg$residuals)
qqline(lin_reg$residuals)


## ---- fig.width=3, fig.height=2, fig.cap="Summary from linear regression model."----
modelsummary(lin_reg, caption = "Summary from linear regression model, where we fit a multiple regression model to predict average quality rating.")


## ---- fig.width=4, fig.height=3, fig.cap="Summary from ANOVA ouput. We see that the interaction terms not in our reduced model are not statistically significant in predicting the quality rating."----
reduced_lin_reg <- lm(prof$quality ~ factor(prof$gender) + factor(prof$pepper) + prof$easiness + factor(prof$discipline), data = prof)

anova_result <- anova(reduced_lin_reg, lin_reg)
#print(anova_result)

