## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(ggplot2)
library(readr)
library(kableExtra)
library(regressinator)
library(dplyr)
library(GGally) 
library(gridExtra)
library(bestglm)
library(modelsummary)


## ---- message = FALSE, warning = FALSE, echo = FALSE--------------------------
data <- as.data.frame(alr4::Rateprof)
par(mfrow = c(2, 3))
hist(data$easiness, 
     xlab = 'Easiness (1-5)', 
     ylab = 'Frequency', 
     main = 'Easiness')
hist(data$quality, 
     xlab = 'Quality (1-5)', 
     ylab = 'Frequency', 
     main = 'Quality')
barplot(table(data$gender), 
     xlab = 'Gender', 
     ylab = 'Frequency', 
     main = 'Gender')
barplot(table(data$pepper), 
     xlab = 'Pepper', 
     ylab = 'Frequency', 
     main = 'Pepper')
barplot(table(data$discipline), 
     xlab = 'Discipline', 
     ylab = 'Frequency', 
     main = 'Discipline')


## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width ="70%", fig.align='center'----
plot(x = data$easiness, y = data$quality, xlab = 'Easiness (1-5)', 
     ylab = 'Quality (1-5)', main = "Scatter Plot of Quality vs Easiness")


## ---- message = FALSE, warning = FALSE, echo = FALSE--------------------------
par(mfrow = c(1, 3))
boxplot(data = data, quality ~ gender, xlab = "Gender", ylab = "Quality")
boxplot(data = data, quality ~ pepper, xlab = "Pepper", ylab = "Quality")
boxplot(data = data, quality ~ discipline, xlab = "Discipline", ylab = "Quality")


## ---- message = FALSE, warning = FALSE, echo = FALSE--------------------------
par(mfrow = c(1, 3))
boxplot(data = data, easiness ~ gender, xlab = "Gender", ylab = "Easiness")
boxplot(data = data, easiness ~ pepper, xlab = "Pepper", ylab = "Easiness")
boxplot(data = data, easiness ~ discipline, xlab = "Discipline", ylab = "Easiness")


## ---- message = FALSE, warning = FALSE, echo = FALSE--------------------------
par(mfrow = c(1, 2))
model <- lm(quality ~ easiness + factor(gender) + factor(pepper) + factor(discipline) + easiness:gender + easiness:discipline, data = data)
residuals <- residuals(model)
plot(x = model$fitted.values, y = residuals, xlab = "Fitted Values", ylab = "Residuals", main = "Residuals vs Fitted Values")
plot2 <- qqnorm(model$residuals)
qqline(model$residuals)


## ---- message = FALSE, warning = FALSE, echo = FALSE, out.width ="70%", fig.align='center'----
#cooks distance
cooksd <- cooks.distance(model)
barplot(cooksd, main = "Cook's Distance Plot", xlab = "Observation Index", ylab = "Cook's Distance")


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
red_model <- lm(data = data, quality ~ easiness + factor(gender) + factor(pepper) + factor(discipline))
summary(red_model)
confint(red_model, level = 0.95)


## ---- message = FALSE, warning = FALSE, include = FALSE-----------------------
summary(model)
AIC(red_model)
anova(red_model, model)

