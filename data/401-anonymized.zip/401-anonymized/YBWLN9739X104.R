## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message = FALSE---------------------------------------------------------
library(alr4)


## ---- fig.height = 4, fig.width = 5, fig.cap="Histogram of the Quality rating variable to check its distribution."----
hist(Rateprof$quality, main = "Figure1: Quality Distribution", xlab = "Quality Rating")


## ---- fig.height=4, fig.width=5, fig.cap="Histogram of the Easiness rating variable to check for a normal distribution."----
hist(Rateprof$easiness, main = "Figure 2: Easiness Distribution", xlab = "Easiness Rating")


## ---- fig.width=5, fig.height=4-----------------------------------------------
barplot(table(Rateprof$gender), main = "Figure 3: Distribution of Gender among Professors", xlab = "Gender", col = "skyblue")


## ---- fig.width=5, fig.height=4-----------------------------------------------
barplot(table(Rateprof$discipline), main = "Figure 4: Distribution of Discipline", xlab = "Discipline", col = "lightgreen")


## ---- fig.cap="Comparing the Easiness Rating between Professors' disciplines."----
plot(Rateprof$discipline,Rateprof$easiness, xlab = "Disciplines", ylab = "Easiness Rating", main = "Figure 5: Discipline vs Easiness Boxplot")


## ---- fig.cap="Comparing the Easiness Rating between Professors' genders."----
plot(Rateprof$gender,Rateprof$easiness, xlab = "Gender", ylab = "Easiness Rating", main = "Figure 6: Gender vs Easiness Boxplot")


## -----------------------------------------------------------------------------
plot(Rateprof$easiness, Rateprof$quality, main = "Figure 7: Scatterplot of Easiness vs. Quality", xlab = "Easiness Rating", ylab = "Quality Rating")


## -----------------------------------------------------------------------------
quality_additive_model = lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
summary(quality_additive_model)


## -----------------------------------------------------------------------------
quality_interaction = lm(quality ~ gender * easiness * discipline + pepper, data = Rateprof)
summary(quality_interaction)


## -----------------------------------------------------------------------------
plot(quality_additive_model$fitted.values, resid(quality_additive_model), main = "Figure 8: Residuals vs. Fitted", xlab = "Fitted Values", ylab = "Residuals")


## -----------------------------------------------------------------------------
qqnorm(resid(quality_additive_model), main = "Figure 9: QQ-Plot of Residuals")
qqline(resid(quality_additive_model))


## -----------------------------------------------------------------------------
plot(cooks.distance(quality_additive_model), pch = 20, main = "Figure 10: Cook's Distance Plot", ylab = "Cook's Distance", xlab = "Observation Index")


## -----------------------------------------------------------------------------
plot(quality_interaction$fitted.values, resid(quality_interaction), main = "Figure 11: Residuals vs. Fitted", xlab = "Fitted Values", ylab = "Residuals")


## -----------------------------------------------------------------------------
qqnorm(resid(quality_interaction), main = "Figure 12: QQ-Plot of Residuals")
qqline(resid(quality_interaction))


## -----------------------------------------------------------------------------
plot(cooks.distance(quality_interaction), pch = 20, main = "Figure 13: Cook's Distance Plot", ylab = "Cook's Distance", xlab = "Observation Index")


## -----------------------------------------------------------------------------
ci_model1 = confint(quality_additive_model)


## -----------------------------------------------------------------------------
ci_model2 = confint(quality_interaction)


## -----------------------------------------------------------------------------
coefficients_model1 = coef(quality_additive_model)
se_model1 = summary(quality_additive_model)$coefficients[, "Std. Error"]
effect_sizes_model1 = coefficients_model1 / se_model1


## -----------------------------------------------------------------------------
coefficients_model2 = coef(quality_interaction)
se_model2 = summary(quality_interaction)$coefficients[, "Std. Error"]
effect_sizes_model2 = coefficients_model2 / se_model2

