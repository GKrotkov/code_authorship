## ----setup, include = FALSE, echo = FALSE-------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo = FALSE------------------------------------------------------------
library(dplyr)
library(ggplot2)
sleep <- read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
sleep %>%
ggplot(aes(x = TotalSleepTime)) + 
  geom_histogram(fill = "orange", bins = 30) + 
  labs(x= "Total amount of sleep in minutes", y = "Count", title = "Histogram of student total amount of sleep")


## -----------------------------------------------------------------------------
sleep %>%
ggplot(aes(x = term_gpa)) + 
  geom_histogram(fill = "blue",bins = 30) + 
  labs(x= "term gpa", y = "Count", title = "Histogram of student term gpa")




## -----------------------------------------------------------------------------
sleep %>%
ggplot(aes(x = cum_gpa)) + 
  geom_histogram(fill = "red", bins = 30) + 
  labs(x= "Cumulative gpa", y = "Count", title = "Distribution of student cumulative GPA")



## -----------------------------------------------------------------------------
sleep %>%
ggplot(aes(x = TotalSleepTime, y=term_gpa)) + 
  geom_point(color = "blue") + 
  labs(x= "Total sleep in minutes", y = "Term GPA", title = "Distribution of student total amount of sleep vs Term GPA")


## -----------------------------------------------------------------------------
sleep %>%
ggplot(aes(x = TotalSleepTime, y=cum_gpa)) + 
  geom_point(color = "red") + 
  labs(x= "Total sleep in minutes", y = "Cumulative GPA", title = "Scatterplot of student total amount of sleep vs Cumulative GPA")


## -----------------------------------------------------------------------------
sleep %>%
ggplot(aes(x = term_gpa, y=cum_gpa)) + 
  geom_point(color = "purple") + 
  labs(x= "Term gpa", y = "Cumulative GPA", title = "Scatterplot of Term GPA vs Cumulative GPA")


## -----------------------------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime+(cum_gpa^3), data = sleep)
summary(model)


## -----------------------------------------------------------------------------
qqnorm(model$residuals)
qqline(model$residuals, col = "blue")


## -----------------------------------------------------------------------------
res = model$residuals
xval = sleep$TotalSleepTime

plot(x= xval, y= res, xlab = "x", ylab = "residuals", main = "residuals vs x")
abline(h=0, lty=2)

