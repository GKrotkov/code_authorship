## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)

## -----------------------------------------------------------------------------
data<-read.csv("cmu-sleep.csv")
library(ggplot2)
suppressPackageStartupMessages(library(car))
library(modelsummary)


## -----------------------------------------------------------------------------
hist(data$TotalSleepTime,
main="Average Nightly Sleep",
xlab="In Minutes",
freq=TRUE
)
summary(data$TotalSleepTime)


## -----------------------------------------------------------------------------
hist(data$term_gpa,
main="GPA in the Spring Semester ",
xlab="Out of 4.0",
freq=TRUE
)
summary(data$term_gpa)


## -----------------------------------------------------------------------------
hist(data$cum_gpa,
main="GPA in the Fall Semester ",
xlab="Out of 4.0",
freq=TRUE
)
summary(data$cum_gpa)


## -----------------------------------------------------------------------------
ggplot(data=data,aes(x=TotalSleepTime,y=term_gpa)) +geom_point() + labs(x="Average Nightly Sleep (In Minutes)",y="Spring GPA(out of 4)")


## -----------------------------------------------------------------------------
ggplot(data=data,aes(x=cum_gpa,y=term_gpa)) +geom_point() + labs(x="Fall GPA (out of 4)",y="Spring GPA(out of 4)")


## -----------------------------------------------------------------------------
m1<-lm(term_gpa~TotalSleepTime+cum_gpa,data=data)
summary(m1)
vif(m1)
qqPlot(m1)
plot(residuals(m1) ~data$TotalSleepTime)
confint(m1,level = .95)
modelsummary(m1,fmt = 4)

