## -----------------------------------------------------------------------------
library(alr4)
library(bestglm)
rate = Rateprof


## -----------------------------------------------------------------------------
hist(rate$quality, main = "Histogram of Quality", 
     xlab = "Quality", breaks = 20
     )
hist(rate$easiness, main = "Histogram of Easiness", xlab = "Easiness")
pie(x = c(sum(rate$gender == "male"), sum(rate$gender == "female")),
    labels = c("male", "female"))
pie(x = c(sum(rate$pepper == "no"), sum(rate$pepper == "yes")),
    labels = c("no", "yes"))
dis_table = table(rate$discipline)
pie(dis_table)


t = table(rate$discipline)
t
per = t / 366
per


## -----------------------------------------------------------------------------
rate$pepper = as.factor(rate$pepper)

lm1 = lm(quality ~ gender + pepper + discipline + easiness, data = rate)
summary(lm1)


X = rate[, c("gender", "pepper", "discipline", "easiness")]
y = rate$quality
Xy = as.data.frame(cbind(X, y))
lm_all = bestglm(Xy = Xy,
                 method = "backward",
                 IC = "AIC")
lm_all

lm1 = lm(quality ~ gender + pepper + easiness, data = rate)
summary(lm1)


## -----------------------------------------------------------------------------
table(rate$gender, rate$pepper)

table(rate$gender, rate$discipline)

table(rate$pepper, rate$discipline)



## -----------------------------------------------------------------------------
full = lm(quality ~ gender + pepper + discipline + easiness, data = rate)
reduced = lm(quality ~ gender + pepper + easiness, data = rate)
anova(reduced, full)

full = lm(quality ~ gender + pepper + discipline + easiness, data = rate)
reduced = lm(quality ~ pepper + discipline + easiness, data = rate)
anova(reduced, full)

## -----------------------------------------------------------------------------
lm_all = lm(quality ~ gender + pepper + discipline + easiness, data = rate)


## -----------------------------------------------------------------------------
plot(rate$easiness, rate$quality,
     main = "Scatter plot of Quality versus Easiness",
     xlab = "Easiness", ylab = "Quality")

