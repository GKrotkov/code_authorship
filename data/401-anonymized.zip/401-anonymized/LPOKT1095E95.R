## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
#install.packages("alr4")
library(alr4)
data("Rateprof")
library(ggplot2)
library(gridExtra)


## ---- fig.width=3, fig.height=2, fig.cap="Distribution of Quality Ratings"----
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram(binwidth = 0.25, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(x = "Quality Rating",
       y = "Frequency") +
  theme_minimal()



## ---- fig.width=5, fig.height=3,fig.cap="Univariate EDA on Gender, Attractiveness, Easiness, and Discipline "----

plot3= ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram(binwidth = 0.25, fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title= "Easiness",
       x = "Easiness Rating",
       y = "Frequency") +
  theme_minimal()

plot1= ggplot(Rateprof, aes(x = gender)) +
  geom_bar(fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Gender",
       x = "Gender",
       y = "Count") +
  theme_minimal()

plot4=ggplot(Rateprof, aes(x = discipline)) +
  geom_bar(fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Discipline",
       x = "Discipline",
       y = "Count") +
  theme_minimal()

plot2=ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Attractiveness Ratings",
       x = "Attractiveness Rating",
       y = "Count") +
  theme_minimal()



grid.arrange(plot1, plot2, plot3,plot4, ncol = 2)


## ---- fig.width=5.5, fig.height=4.5,fig.cap="Bivariate EDA on Gender, Attractiveness, Easiness, and Discipline"----


plot1= ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot(fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Gender",
       x = "Gender",
       y = "Quality Rating") +
  theme_minimal()

plot2=ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot(fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Attractiveness",
       x = "Attractiveness",
       y = "Quality Rating") +
  theme_minimal()


plot3= ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point(color = "skyblue", alpha = 0.7) +
  labs(title = "Easiness",
       x = "Easiness Rating",
       y = "Quality Rating") +
  theme_minimal()


plot4=ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "skyblue", color = "black", alpha = 0.7) +
  labs(title = "Quality Ratings by Discipline",
       x = "Discipline",
       y = "Quality Rating") +
  theme_minimal()


grid.arrange(plot1, plot2, plot3,plot4, ncol = 2)






## -----------------------------------------------------------------------------
model <- lm(quality ~ gender + pepper + easiness + discipline + gender*easiness +discipline*easiness, data = Rateprof)


## ----fig.align='center',fig.width=6, fig.height=3.5,fig.cap="Diagnostics for Regression: Residuals vs Fitted"----
plot(model, which = 1)


## ----fig.align='center',fig.width=6, fig.height=5.5,fig.cap="Diagnostics for Regression: Residuals vs Each Predictor"----

par(mfrow = c(2, 2))

plot(model$residuals ~ Rateprof$gender, main = "Residuals vs. Gender", xlab = "Gender", ylab = "Residuals")
plot(model$residuals ~ Rateprof$pepper, main = "Residuals vs. Attractiveness", xlab = "Attractiveness (Pepper)", ylab = "Residuals")
plot(model$residuals ~ Rateprof$easiness, main = "Residuals vs. Easiness", xlab = "Easiness", ylab = "Residuals")
plot(model$residuals ~ Rateprof$discipline, main = "Residuals vs. Discipline", xlab = "Discipline", ylab = "Residuals")



## ----fig.align='center',fig.width=6, fig.height=3.5,fig.cap="Diagnostics for Regression: QQ-Plot "----
plot(model, which = 2)


## ----fig.align='center',fig.width=6, fig.height=3.5,fig.cap="Diagnostics for Regression: Cook's Distance "----
plot(model, which = 4)


## -----------------------------------------------------------------------------
library(modelsummary)
model1= lm(quality ~ gender + pepper + easiness + discipline , data = Rateprof)

model2= lm(quality ~ gender + pepper + easiness + discipline + gender*easiness +discipline*easiness, data = Rateprof)



## -----------------------------------------------------------------------------
partial_f_test <- anova(model1, model2, test = "F")



## -----------------------------------------------------------------------------
#summary(model1)


## -----------------------------------------------------------------------------

con1= confint(model1, "gendermale", level = 0.95)
con2=confint(model1, "pepperyes", level = 0.95)
con3=confint(model1, "easiness", level = 0.95)
con4=confint(model1, "Intercept", level = 0.95)



