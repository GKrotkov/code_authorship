## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
data <- read.csv("cmu-sleep.csv")
library(ggplot2)
library(pastecs)


## ---- fig.width=8, fig.height=3.5, fig.cap="Histogram of time slept at night."----

hist(data$TotalSleepTime, xlab="Average time slept at night (minutes)", main="Histogram of average time slept at night")


## ---- fig.width=8, fig.height=3.5, fig.cap="Distribution of GPA during study."----
hist(data$term_gpa, xlab="GPA during study (out of 4.0)", main="Histogram of GPA during study")


## ---- fig.width=8, fig.height=3.5, fig.cap="Distribution of cumulative GPA before study."----
hist(data$cum_gpa, xlab="Cumulative GPA before study (out of 4.0)", main="Histogram of cumulative GPA before study")

## ---- include=FALSE-----------------------------------------------------------
stat.desc(data$TotalSleepTime)
stat.desc(data$term_gpa)
stat.desc(data$cum_gpa)


## ---- fig.width=8, fig.height=4, fig.cap="Plot of average sleep time vs Term GPA."----
plot(term_gpa~TotalSleepTime, data, xlab = "Average sleep time (minutes)", ylab= "Term GPA", main="Average sleep time vs Term GPA")


## ---- include=FALSE-----------------------------------------------------------
data <- data[data$term_gpa > 1,]
data$term_gpa.transformed <- log(data$term_gpa)
data$TotalSleepTime.hours <- data$TotalSleepTime / 60


## ---- fig.width=8, fig.height=3.5, fig.cap="Transformed distribution of GPA during study."----
hist(data$term_gpa.transformed, xlab="Transformed GPA during study", main="Transformed histogram of GPA during study")


## ---- fig.width=8, fig.height=3.5, fig.cap="Plot of average sleep time vs transformed term GPA."----
plot(term_gpa.transformed~TotalSleepTime.hours, data, xlab = "Average sleep time (hours)", ylab= "Transformed term GPA", main="Average sleep time vs Transformed term GPA")


## ---- include=FALSE-----------------------------------------------------------
any(is.infinite(data$term_gpa.transformed))
line <- lm(term_gpa.transformed~TotalSleepTime, data)
sm <- summary(line)
sm


## ---- include=FALSE-----------------------------------------------------------
conf <- confint(line)
conf
exp(conf)
2*exp(conf)
res <- sm$residuals


## ---- fig.width=8, fig.height=3.5, fig.cap="Plot of average sleep time vs residuals."----
plot(res~TotalSleepTime.hours, data, xlab = "Average sleep time (hours)", ylab= "residuals", main="Average sleep time vs residuals")

