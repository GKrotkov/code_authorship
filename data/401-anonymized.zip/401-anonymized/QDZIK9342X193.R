## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
install.packages('modelsummary', repos="http://cran.us.r-project.org")
library(modelsummary)
library(broom)


## ----data---------------------------------------------------------------------
setwd("/Users/lincoleli/Downloads")
data <- read.csv("cmu-sleep.csv")
library(ggplot2)


## ----sleeptime overview, include=FALSE----------------------------------------

sleep_time <- data$TotalSleepTime
summary_sleep<-summary(sleep_time)



## ----histogramofsleeptime, message=FALSE, fig.width=4, fig.height=3, fig.align='center'----

ggplot(data, aes(x=sleep_time))+
  geom_histogram()+
  labs(
    title="Students' Sleep Times",
    x="Total Sleep Time (minutes)",
    caption="Figure 1. Shows distribution of students' sleep times"
  )



## ----termgpa overview, include=FALSE------------------------------------------

term_gpa <- (data$term_gpa)
summary(term_gpa)



## ----termgpa, fig.width=4, fig.height=3, fig.align='center'-------------------

ggplot(data, aes(x=(term_gpa)))+
  geom_histogram(bins=15)+
  labs(
    title="Students' Term GPAs",
    x="Term GPA (out of 4.0)",
    caption="Figure 2. Shows distribution of students' spring term GPAs"
  )



## ----cumgpa overview, include=FALSE-------------------------------------------

cum_gpa <- data$cum_gpa
summary(cum_gpa)



## ----termgpa vs. sleep, fig.width=4, fig.height=3, fig.align='center'---------

ggplot(data, aes(x=sleep_time, y=(term_gpa)))+
  geom_point()+
  labs(
    title="Term GPA vs. Total Sleep Time",
    x="Total Sleep Time (minutes)",
    y="Term GPA (out of 4.0)",
    caption="Figure 3. students' average sleep times vs. their term GPAs"
  )



## ----transformed term gpa, fig.width=4, fig.height=3, fig.align='center'------

term_gpa <- (data$term_gpa)
ggplot(data, aes(x=exp(term_gpa)))+
  geom_histogram(bins=15)+
  labs(
    title="Students' Term GPAs",
    x="exp(Term GPA) (out of 4.0)",
    caption="Figure 4. students' term GPAs transformed by exp to reduce skew"
  )



## ----termgpa vs. sleep transformed, fig.width=4, fig.height=3, fig.align='center'----

ggplot(data, aes(x=sleep_time, y=exp(term_gpa)))+
  geom_point()+
  labs(
    title="exp(Term GPA) vs. Total Sleep Time",
    x="Total Sleep Time (minutes)",
    y="exp(Term GPA) (out of 4.0)",
    caption="Figure 5. scatterplot of students' current term GPAs vs. sleep time transformed by exp "
  )



## ----term gpa vs sleep fit, fig.width=4, fig.height=3, fig.align='center', message=FALSE----

ggplot(data, aes(x=sleep_time, y=exp(term_gpa)))+
  geom_point()+
  labs(
    title="exp(Term GPA) vs. Total Sleep Time",
    x="Total Sleep Time (minutes)",
    y="exp(Term GPA) (out of 4.0)",
    caption="Figure 6. scatterplot in Figure 7 fitted with simple linear regression model"
  )+
  geom_smooth(method=lm)

fitted <- lm(exp(term_gpa)~sleep_time)



## ---- include=FALSE-----------------------------------------------------------

summary(fitted)



## ----residuals, fig.width=4, fig.height=3, fig.align='center', message=FALSE----

ggplot(data, aes(x=sleep_time, y=(fitted$residuals)))+
  geom_point()+
  labs(
    title="Residual Analysis",
    x="Total Sleep Time (minutes)",
    y="Residuals",
    caption="Figure 7. scatterplot of residuals fitted model vs. predictor variable"
  )+
  geom_smooth(method=lm)



## ----qq plot, fig.width=4, fig.height=3, fig.align='center'-------------------

ggplot(augment(fitted), aes(sample=(fitted$residuals)))+
  geom_qq()+
  geom_qq_line()+
  labs(
    x="Theoretical quantiles",
    y="Sample quantiles",
    caption="Figure 8. normal probability plot"
  )



## ----fit summary, echo=FALSE--------------------------------------------------

summary_table<-modelsummary(summary(fitted))

modelsummary(fitted, statistic = c("T={statistic}", "SE={std.error}", "conf.int"),
             conf_level = 0.95, gof_map = c("r.squared", "nobs"), caption="Summary Table of Estimates for Regression Model")




## ----one sided test, include=FALSE--------------------------------------------

CI <- confint(fitted, level=0.95)
tval <- qt(0.95, df=df.residual(fitted))
tval
pval <- pt(-4.591, df=df.residual(fitted))
pval


