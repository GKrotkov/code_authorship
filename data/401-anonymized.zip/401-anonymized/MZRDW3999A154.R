## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE, include=FALSE--------------------------------------------
library(ggplot2)
library(dplyr)
library(tidyverse)
library(regressinator)
library(broom)
library(gridExtra)


# Previous libraries we have used
library(alr4)
library(GGally)
library(bestglm)
library(MASS)
library(car)


## ---- include=FALSE-----------------------------------------------------------
# Introduction
#– Explain the context and motivate the problem
#– Give the goals of the analysis and the specific things we want to learn
#– Briefly describe where the data came from
#– Briefly state the results, including the size of any associations or effects you found


## ---- include=FALSE-----------------------------------------------------------
prof_data <- Rateprof
nrow(prof_data)


## ---- fig.width=8, fig.height=5, fig.cap="Univariate EDA of variables of interest"----
par(mfrow = c(3, 2))
barplot(table(prof_data[,1]), names = c("Female", "Male"),
xlab = "Gender", ylab = "Count")
barplot(table(prof_data[,5]), names = c("No", "Yes"),
xlab = "Attractive (according to pepper rating)", ylab = "Count")
hist(prof_data[,11], prob = FALSE, xlab = "Easiness", main = "")
barplot(table(prof_data[,6]), names = c("Hum", "SocSci", "STEM", "Pre-prof"),
xlab = "Discipline", ylab = "Count")
hist(prof_data[,8], prob = FALSE, breaks = 15, xlab = "Quality", main = "")




## ---- include=FALSE-----------------------------------------------------------
summary(prof_data[,c(1,5,11,6, 8)])
apply(prof_data[,c(11, 8)],2,sd)


## ---- fig.width=10, fig.height=4, fig.cap="Bivariate EDA"---------------------

plot1 <- ggplot(prof_data, aes(x = easiness, y = quality, color = gender)) +
  geom_point(shape = 20, size = 2) +
  labs(x = "Easiness (1 to 5 scale)", y = "Quality (1 to 5 scale)",
       title = "Easiness vs. Quality by Gender") +
  scale_color_manual(values = c("hotpink", "blue")) 

plot2 <- ggplot(prof_data, aes(x = easiness, y = quality, color = discipline)) +
  geom_point(shape = 20, size = 2) +
  labs(x = "Easiness (1 to 5 scale)", y = "Quality (1 to 5 scale)",
       title = "Easiness vs. Quality by Discipline") +
  scale_color_manual(values = c("cyan", "black", "blue", "magenta")) 

plot3 <- ggplot(prof_data, aes(x = easiness, y = quality, color = pepper)) +
  geom_point(shape = 20, size = 2) +
  labs(x = "Easiness (1 to 5 scale)", y = "Quality (1 to 5 scale)",
       title = "Easiness vs. Quality by Attractiviness (pepper rating)") +
  scale_color_manual(values = c("orange", "red")) 

grid.arrange(plot1, plot2, plot3,   ncol = 3)

#gender, pepper, easiness, discipline, quality



## ---- fig.width=8, fig.height=5, fig.cap="Bivariate EDA for Non-Continuous Varaible"----
par(mfrow = c(2,2))
boxplot(quality ~ gender, ylab = "Quality of course (1-5 scale)", data = prof_data,
xlab = "Quality v. Gender", names = c("Female", "Male"),
pch = 16)
boxplot(quality ~ pepper, ylab = "Quality of course (1-5 scale)", data = prof_data,
xlab = "Quality v. Attractive (according to pepper rating)", names = c("No", "Yes"),
pch = 16)
boxplot(quality ~ discipline, ylab = "Quality of course (1-5 scale)", data = prof_data,
xlab = "Quality v. Discipline", names = c("Hum", "SocSci", "STEM", "Pre-prof"),
pch = 16)


## ---- include=FALSE-----------------------------------------------------------
interaction_none <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data = prof_data)


interaction_gender <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(gender):easiness, data = prof_data)

interaction_discipline <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(discipline):easiness, data = prof_data)

interaction_both <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + factor(discipline):easiness + factor(gender):easiness, data = prof_data)


## ---- fig.width=6, fig.height=4, fig.cap="Residuals of Linear Models"---------
fig.align = 'center'
par(mfrow = c(2,2))

residuals_none <- residuals(interaction_none)
plot(fitted(interaction_none), residuals_none, xlab = "Fitted Values (No Interactions)", ylab = "Residuals", col = "black")

residuals_gender <- residuals(interaction_gender)
plot(fitted(interaction_gender), residuals_gender, xlab = "Fitted Values (Gender Interaction)", ylab = "Residuals", col = "blue")

residuals_discipline <- residuals(interaction_discipline)
plot(fitted(interaction_discipline), residuals_discipline, xlab = "Fitted Values (Discipline Interaction)", ylab = "Residuals", col = "red")

residuals_both <- residuals(interaction_both)
plot(fitted(interaction_both), residuals_both, xlab = "Fitted Values (Both Interactions)", ylab = "Residuals", col = "purple")



## ---- fig.width=8, fig.height=4, fig.cap="Q-Q Plot of Linear models"----------
fig.align = 'center'
par(mfrow = c(2,2))
qqnorm(residuals_none, main = "Normal Q-Q Plot for no interactions")
qqline(residuals_none, col= "blue")

qqnorm(residuals_gender, main = "Normal Q-Q Plot for gender interaction")
qqline(residuals_gender, col= "blue")

qqnorm(residuals_discipline, main = "Normal Q-Q Plot for discipline interactions")
qqline(residuals_discipline, col= "blue")

qqnorm(residuals_both, main = "Normal Q-Q Plot for both interactions")
qqline(residuals_both, col= "blue")



## ---- include=FALSE-----------------------------------------------------------
sum(residuals_none)
sum(residuals_gender)
sum(residuals_discipline)
sum(residuals_both)


## ---- include = FALSE---------------------------------------------------------
partial_f_test_gender <- anova(interaction_none, interaction_gender)
print(partial_f_test_gender)

partial_f_test_discipline <- anova(interaction_none, interaction_discipline)
print(partial_f_test_discipline)

partial_f_test_both <- anova(interaction_none, interaction_both)
print(partial_f_test_both)


## ---- include=FALSE-----------------------------------------------------------
#The Vice Provost also suspects that the relationship between easiness and quality rating may depend on the instructor’s gender and discipline, and would like you to test this.We suggest you approach this by building a model to predict quality rating using these predictors. 

#Determine which associations are statistically significant and test the Vice Provost’s suspicion.
  #For any significant associations, the Vice Provost would like to know how big they are: 
  #how much do they affect the quality rating? 
  #Summarize your findings and give clear interpretations of your results in a style that the Vice Provost can      understand.


## ---- include=FALSE-----------------------------------------------------------
#Conclusion
#– Summarize your conclusions in non-statistical terms: what are your answers for the Vice
#Provost? Can you make any recommendations about course evaluations?

#– Note any limitations or problems, and how they affect your results
#– Note what could be done to improve your analysis, if anything


