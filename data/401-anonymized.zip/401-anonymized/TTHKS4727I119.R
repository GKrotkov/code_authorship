## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(dplyr)
library(alr4)
library(ggplot2)
library(GGally)
library(readr)
library(modelsummary)
library(bestglm)


## -----------------------------------------------------------------------------
relevant_Rateprof <- Rateprof [, c("gender","pepper","discipline","quality",
                                   "easiness")]

relevant_Rateprof %>%
ggplot(aes(x= quality)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Quality Rating (1 = worst, 5 = best)", y = "Frequency", title = 
       "Histogram of Quality Ratings for Professors")

summary(relevant_Rateprof$quality)


## -----------------------------------------------------------------------------
relevant_Rateprof %>%
ggplot(aes(x= easiness)) +
geom_histogram(color = "black", fill = "lightblue", bins = 50) + 
labs(x = "Easiness Rating (1 = most difficult, 5 = most easy)", y = "Frequency", title = 
       "Histogram of Easiness Rating")

summary(relevant_Rateprof$easiness)


## -----------------------------------------------------------------------------
gender_stats<- summary(relevant_Rateprof$gender)
relevant_Rateprof %>%
ggplot(aes(x= gender)) +
geom_bar(color = "black", fill = "lightblue") + 
labs(x = "Gender", y = "Frequency", title = 
       "Barplot of Gender")


## -----------------------------------------------------------------------------
attractive_stats<- summary(relevant_Rateprof$pepper)
relevant_Rateprof %>%
ggplot(aes(x= pepper)) +
geom_bar(color = "black", fill = "lightblue") + 
labs(x = "Attractiveness", y = "Frequency", title = 
       "Histogram of Attractiveness via Pepper")


## -----------------------------------------------------------------------------
discipline_stats<- summary(relevant_Rateprof$discipline)
relevant_Rateprof %>%
ggplot(aes(x= discipline)) +
geom_bar(color = "black", fill = "lightblue") + 
labs(x = "Discipline", y = "Frequency", title = "Histogram of Disciplines")


## -----------------------------------------------------------------------------
par(mfrow = c(1,3))
boxplot(relevant_Rateprof$quality ~ relevant_Rateprof$gender, xlab = "Gender",
        ylab= "Quality Rating", main = "Boxplot of Quality Rating 
        by Gender of Professor")
boxplot(relevant_Rateprof$quality ~ relevant_Rateprof$pepper, xlab = "Attractive", ylab = "Quality Rating", main = "Boxplot of Quality Rating 
        by Attractiveness")
boxplot(relevant_Rateprof$quality ~ relevant_Rateprof$discipline, xlab = "Attractive", ylab = "Quality Rating", main = "Boxplot of Quality Rating 
        by Discipline")


## -----------------------------------------------------------------------------
relevant_Rateprof %>%
ggplot(aes(x=easiness, y= quality, color = discipline, shape = gender)) +
  geom_point()+
labs(x = "Easiness (1 = easiest, 5 = hardest)", y = "Quality Rating (1 = worst, 5 = best)", title = "Easiness vs. Quality")


## -----------------------------------------------------------------------------
full_model <- lm(quality ~ easiness + gender + pepper + discipline + easiness:gender + gender:discipline, data = relevant_Rateprof)

model_test_no_easiness_interaction <- lm(quality ~ easiness + gender + pepper + discipline + gender:discipline, data = relevant_Rateprof)

model_test_no_discipline_interaction <- lm(quality ~ easiness + gender + pepper + discipline +  easiness:gender, data = relevant_Rateprof)


## -----------------------------------------------------------------------------
stepwise_model <- step(full_model, direction = "both", trace = 0)
stepwise_model
stepwise_model <- lm(quality ~ easiness + gender + pepper, data = relevant_Rateprof)


## -----------------------------------------------------------------------------
par(mfrow = c(1,2))
plot(full_model, which = 1,)
plot(full_model, which = 2,)


## -----------------------------------------------------------------------------
modelsummary(list("Full Model" = full_model, "Gender:Easiness" = model_test_no_discipline_interaction, "Gender:Discipline" = model_test_no_easiness_interaction, "Stepwise Model" = stepwise_model),
             gof_map = c("r.squared", "nobs", "p.value"))


## -----------------------------------------------------------------------------
full_model_summary <- summary(full_model)
confint_full_model <- confint(full_model)

genderDis_summary <- summary(model_test_no_easiness_interaction)
genderDis_confint <- confint(model_test_no_easiness_interaction)

genderEasiness_summary <- summary(model_test_no_discipline_interaction)
genderEasiness_confint <- confint(model_test_no_discipline_interaction)

stepwise_summary <- summary(stepwise_model)
stepwise_confint <- confint(stepwise_model)


## -----------------------------------------------------------------------------
full_stepwise <- anova(full_model, stepwise_model)
full_stepwise$"Pr(>F)"[2]


## -----------------------------------------------------------------------------
full_genderEasiness <- anova(full_model, model_test_no_discipline_interaction)
full_genderEasiness$"Pr(>F)"[2]


## -----------------------------------------------------------------------------
full_genderDiscipline <- anova(full_model, model_test_no_easiness_interaction)
full_genderDiscipline$"Pr(>F)"[2]

