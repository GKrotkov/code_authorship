## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(ggplot2)
library(broom)
library(car)
library(GGally)
library(dplyr)
library(modelsummary)
library(patchwork)
data("Rateprof")



## ----message=FALSE------------------------------------------------------------
hist(Rateprof$quality, main = "Histogram of average quality rating", xlab = "Average quality rating, between 1-5", ylab = "Frequency")

hist(Rateprof$easiness, main = "Histogram of average easiness rating", xlab = "Average easiness rating, between 1-5", ylab = "Frequency")


## ----fig.width = 7,message=FALSE----------------------------------------------

p1 <- ggplot(Rateprof, aes(x = gender)) +
  geom_bar() +
  labs(
       x = "Gender",
       y = "Count")
p2 <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar() +
  labs(
       x = "Pepper, Whether attractive or not",
       y = "Count")
p3 <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar() +
  labs(
       x = "Course Discipline",
       y = "Count")

p1+p2+p3


## ---- fig.width = 7-----------------------------------------------------------

u1 <-ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot() +
  labs(
       x = "Instructor Gender",
       y = "Average quality rating, between 1-5")

u2<-ggplot(Rateprof, aes(x =  pepper, y = quality )) +
geom_boxplot() +
labs( x = "Whether attractive or not", y = "Average quality rating, between 1-5")

u3<-ggplot(Rateprof, aes(x =  discipline, y = quality)) +
geom_boxplot() +

labs(, x = "Discipline", y = "Average quality rating, between 1-5")

u1+u2+u3


## -----------------------------------------------------------------------------
rating_model <- lm(quality ~ gender + pepper + easiness + discipline ,data=Rateprof)
#summary(rating_model)

suspect_model <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + discipline:easiness, data= Rateprof)
#summary(suspect_model)




## -----------------------------------------------------------------------------

s1 <-ggplot(augment(suspect_model), aes(x = .fitted, y = .resid))+ geom_point() + labs(x = "Fitted Value" , y = "Residual")
s2 <-ggplot(augment(suspect_model), aes(x = gender, y = .resid))+ geom_point() + labs(x = "Fitted Value" , y = "Residual")
s3 <-ggplot(augment(suspect_model), aes(x = pepper, y = .resid))+ geom_point() + labs(x = "Fitted Value" , y = "Residual")
s4 <-ggplot(augment(suspect_model), aes(x = easiness, y = .resid))+ geom_point() + labs(x = "Fitted Value" , y = "Residual")
s5 <- ggplot(augment(suspect_model), aes(x = discipline, y = .resid))+ geom_point() + labs(x = "Fitted Value" , y = "Residual")

s6 <-ggplot(augment(suspect_model), aes(sample = .resid))+ geom_qq() + geom_qq_line() + labs(x = "Theoretical quantiles", y = "Sample quantiles")
s7 <- ggplot(augment(suspect_model), aes(x = .fitted, y = .cooksd))+ geom_point() + labs(x = "Fitted Value" , y = "Cook's Distance")
s8 <-ggplot(augment(suspect_model), aes(x = .hat, y = .std.resid)) + geom_point() + labs(x = "Leverage", y = "Standardized Residuals")

s1+s2+s3+s4+s5+s6+s7+s8


## -----------------------------------------------------------------------------
#confint(rating_model)


## -----------------------------------------------------------------------------
modelsummary(list("Reduced Model" = rating_model, "Full Model" = suspect_model),
             gof_map = c("r.squared", "nobs"))


## ----fig.cap="Anova"----------------------------------------------------------
anova(rating_model,suspect_model)

#AIC(rating_model)
#AIC(suspect_model)

