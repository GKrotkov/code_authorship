## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- results=FALSE-----------------------------------------------------------
data <- read.csv("cmu-sleep.csv")


## ---- results=FALSE-----------------------------------------------------------
library(ggplot2)
nrow(data)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's Total Sleep Time."----
ggplot(data = data, aes(x = TotalSleepTime)) +
  geom_histogram(fill = "royalblue", bins = 30) +
  labs(
    title = "Distribution of Student's Total Sleep Time",
    subtitle = "per night on average",
    x = "Total sleep time in minutes"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's current semester GPA."----
ggplot(data = data, aes(x = term_gpa)) +
  geom_histogram(fill = "royalblue", bins = 30) +
  labs(
    title = "Distribution of Student's Semester GPA",
    subtitle = "on the scale out of 4.0",
    x = "GPA (out of 4.0)"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's previous semester GPA."----
ggplot(data = data, aes(x = cum_gpa)) +
  geom_histogram(fill = "royalblue", bins = 30) +
  labs(
    title = "Distribution of Student's Previous GPA",
    subtitle = "on the scale out of 4.0",
    x = "GPA (out of 4.0)"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's Semester GPA transformed by log(5-term_gpa)."----
ggplot(data = data, aes(x = log(5-term_gpa))) +
  geom_histogram(fill = "royalblue", bins = 30) +
  labs(
    title = "Distribution of Student's Semester GPA",
    subtitle = "Transformed, on the scale out of 4.0",
    x = "log of (5-GPA (out of 4.0))"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Student's previous GPA transformed by log(5-cum_gpa)."----
ggplot(data = data, aes(x = log(5-cum_gpa))) +
  geom_histogram(fill = "royalblue", bins = 30) +
  labs(
    title = "Distribution of Student's Previous GPA",
    subtitle = "Transformed, on the scale out of 4.0",
    x = "log of (5 - GPA (out of 4.0))"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot for Total Sleep Time vs. Student's semester GPA "----
ggplot(data = data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() +
  labs(
    title = "Semester GPA vs. Total Sleep Time",
    x = "Total Sleep Time (minutes)",
    y = "Semester GPA (out of 4.0)"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot for Total Sleep Time vs. Student's semester GPA, transformed"----
ggplot(data = data, aes(x = TotalSleepTime, y = log(5-term_gpa))) +
  geom_point() +
  labs(
    title = "Semester GPA vs. Total Sleep Time",
    subtitle = "With transformed GPA variable",
    x = "Total Sleep Time (minutes)",
    y = "log(5-Semester GPA (out of 4.0))"
  )
  


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot for student's previous GPA vs. current semester GPA"----
ggplot(data = data, aes(x = term_gpa, y = cum_gpa)) +
  geom_point() +
  labs(
    title = "Semester GPA vs. Previous GPA",
    x = "GPA (out of 4.0), current semester",
    y = "GPA (out of 4.0), previous semester"
  )


## ---- results=FALSE-----------------------------------------------------------
lm.data <- lm(data = data, term_gpa ~ TotalSleepTime)
summary(lm.data)


## ---- results=FALSE-----------------------------------------------------------
confint(lm.data, "TotalSleepTime", level=0.95)


## ---- results=FALSE-----------------------------------------------------------
confint(lm.data, "(Intercept)", level=0.95)


## ---- results=FALSE-----------------------------------------------------------
0.0019846*-120


## ----fig.width=4, fig.height=3, fig.cap="Residual plot"-----------------------
res = resid(lm.data)
plot(fitted(lm.data), res, main = "Residual Plot")
abline(0,0)


## ----fig.width=4, fig.height=3, fig.cap="QQ-plot for the residuals"-----------
qqnorm(res)
qqline(res)


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot for Total Sleep Time vs. Student's semester GPA, transformed"----
ggplot(data = data, aes(x = log(bedtime_mssd), y = term_gpa)) +
  geom_point() +
  labs(
    title = "Semester GPA vs. Bedtime Variability",
    subtitle = "With transformed Bedtime variability variable",
    x = "log(bedtime variability)",
    y = "Semester GPA (out of 4.0)"
  )

