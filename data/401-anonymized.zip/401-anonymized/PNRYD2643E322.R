## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
# referenced stack overflow to figure out that i needed to specify the repo as such
# install.packages("alr4", repos="http://cran.us.r-project.org")
# install.packages("ggplot2", repos="http://cran.us.r-project.org") 
# install.packages("bestglm", repos="http://cran.us.r-project.org") 
# install.packages("broom", repos="http://cran.us.r-project.org") 
install.packages("modelsummary", repos="http://cran.us.r-project.org") 
library(alr4)
library(ggplot2)
library(bestglm)
library(broom)
library(modelsummary)


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of Quality Ratings. Notice that the ratings are slightly skewed left."----
ggplot(Rateprof, aes(x=quality)) + geom_histogram() + labs(x = "Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Gender vs. Quality Ratings. Notice how male professors have a slightly higher average rating than female professors. We will later like to check the significance of a difference and whether it could be due to correlations of gender and other factors."----
ggplot(Rateprof, aes(x=gender,y=quality))+geom_boxplot()+labs(x="Gender",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Attractiveness vs. Quality Ratings. From this graph, we suspect that attractive professors tend to receive higher ratings, but this will be further investigated."----
ggplot(Rateprof, aes(x=pepper,y=quality))+geom_boxplot()+labs(x="Attractive Or Not",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of Years of Ratings Acquired per Instructor. Notice that most professors have been rated for 11 years."----
ggplot(Rateprof, aes(x=numYears)) + geom_bar() + labs(x = "Years of Ratings Acquired (years)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of the Number of Courses Taught that Have Been Rated. Notice that the ratings are slightly skewed right, which is fine for our analysis."----
ggplot(Rateprof, aes(x=numCourses)) + geom_bar() + labs(x = "Number of Courses Taught that Have Been Rated (courses)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of Professors Across Disciplines. Note the good number of observations for each, allowing us to draw conclusions about different disciplines."----
ggplot(Rateprof, aes(x=discipline)) + geom_bar() + labs(x = "Discipline")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Quality Ratings Across Disciplines. Note that disciplines tend to have slightly different average ratings, but we will need to test the significance of these differences."----
ggplot(Rateprof, aes(x=discipline,y=quality))+geom_boxplot()+labs(x="Discipline",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of Easiness Ratings. Note the approximately symmetric distribution."----
ggplot(Rateprof, aes(x=easiness)) + geom_histogram() + labs(x = "Easiness Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between Easiness Ratings and Quality Ratings. Note the positive correlation, suggesting that professors teaching easier courses are rated more highly."----
ggplot(Rateprof, aes(x=easiness,y=quality))+geom_point()+labs(x="Easiness Rating (from 1-5)",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Distribution of Student Interest. Note the symmetric distribution."----
ggplot(Rateprof, aes(x=raterInterest)) + geom_histogram() + labs(x = "Student Interest (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between Student Interest and Quality Ratings. Note the positive associations."----
ggplot(Rateprof, aes(x=raterInterest,y=quality))+geom_point()+labs(x="Student Interest (from 1-5)",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between Student Interest and Easiness Ratings. Note that the association is not very strongly positive."----
ggplot(Rateprof, aes(x=raterInterest,y=easiness))+geom_point()+labs(x="Student Interest (from 1-5)",y="Easiness (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between Easiness and Quality Ratings, colored by Attractiveness. Notice that there doesn't seem to be a huge delineation between different attractiveness levels and the easiness-quality rating relationship."----
ggplot(Rateprof, aes(x=easiness,y=quality,color=pepper))+geom_point()+labs(x="Easiness Rating (from 1-5)",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between Easiness and Quality Ratings, colored by Gender. Notice that there doesn't seem to be a huge delineation between different genders and the easiness-quality rating relationship."----
ggplot(Rateprof, aes(x=easiness,y=quality,color=gender))+geom_point()+labs(x="Easiness Rating (from 1-5)",y="Quality Rating (from 1-5)")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="The final model. Notice the selection of variables."----
Rateprof$gender <- factor(Rateprof$gender)
Rateprof$pepper <- factor(Rateprof$pepper)
Rateprof$discipline <- factor(Rateprof$discipline)
Rateprof$dept <- factor(Rateprof$dept)
Rateprof$quality_rating <- Rateprof$quality
Rateprof <- Rateprof[,-8]
Rateprof <- Rateprof[c("gender","numYears","numCourses","pepper","discipline","dept","easiness","raterInterest","quality_rating")]
final_model <- lm(quality_rating ~ numYears + numCourses + pepper + discipline + easiness + raterInterest + gender + discipline*easiness + gender*easiness + gender:discipline:easiness, Rateprof)
modelsummary(final_model)


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between fitted values and residuals. Note the desired ranom shape."----
ggplot(augment(final_model), aes(x=.fitted,y=.resid)) + geom_point() + labs(x="Fitted Values", y = "Residuals")


## ---- message=FALSE, fig.width=4, fig.height=3, fig.cap="Associations between fitted values and Cook's distances. Notice that the Cook's distances are all quite small."----
ggplot(augment(final_model), aes(x=.fitted,y=.cooksd)) + geom_point()+labs(x="Fitted Values", y="Cook's distances")

