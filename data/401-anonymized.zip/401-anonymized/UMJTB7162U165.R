## -----------------------------------------------------------------------------
library(ggplot2)
sleep = read.csv("/Users/Arrshia/Library/Mobile Documents/com~apple~CloudDocs/Modern Regression (36-401)/cmu-sleep.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the average time the student spent asleep each night in minutes."----
# EDA - sleep time histogram
ggplot(data = sleep, mapping = aes(x = TotalSleepTime)) + 
  geom_histogram(binwidth = 15, color = "black", fill = "#458cff") +
  labs(title = "Histogram of Sleep Time", x = "Sleep Time (Minutes)") 


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of the students' GPA (out of 4.0) for the classes they took in the Spring Semester."----
# EDA - spring semester GPA histogram
ggplot(data = sleep, mapping = aes(x = term_gpa)) + 
  geom_histogram(binwidth = 0.15, color = "black", fill = "#458cff") +
  labs(title = "Histogram of Students' GPA", x = "Students' GPA (out of 4.0)") 


## ---- fig.width=4, fig.height=3, fig.cap="Scatter plot to show the relationship between students' sleep time in minutes and their GPA (out of 4.0)."----
# EDA - sleep time, GPA scatter plot
ggplot(data = sleep, mapping = aes(x = TotalSleepTime, y = term_gpa)) + 
  geom_point(color = "black") +
  labs(title = "Scatter Plot of Sleep Time to their GPA", 
       x = "Sleep Time (Minutes)", y = "Students' GPA (out of 4.0)") 


## -----------------------------------------------------------------------------
sleeplm = lm(term_gpa ~ TotalSleepTime, data = sleep)
summary(sleeplm)

confint(sleeplm)


## ---- fig.width=4, fig.height=3, fig.cap="Quantile-normal plot of the residuals from the linear regression analysis."----
res = residuals(sleeplm)
fits = fitted(sleeplm)
qqnorm(res)
qqline(res)


## ---- fig.width=4, fig.height=3, fig.cap="Residual vs. Fit plot."-------------
plot(fits, res)
abline(h=0)

