## ----setup, include=TRUE------------------------------------------------------
library(dplyr)
cmu <- read.csv("cmu-sleep.csv")
dim(cmu)
head(cmu)

## ---- echo=FALSE--------------------------------------------------------------
library(ggplot2)

Time <- ggplot(cmu, aes(x = TotalSleepTime)) +
geom_histogram(binwidth = 15, fill = "purple", color = "turquoise") +
labs(title = "Distribution of Sleep Time at Night", 
     x = "Total Sleep Time (minutes)", 
     y = "Student Count")

Time

## -----------------------------------------------------------------------------
Daytime <- ggplot(cmu, aes(x = daytime_sleep)) +
geom_histogram(binwidth = 15, fill = "pink", color = "green") +
labs(title = "Distribution of Sleep During Daytime", 
     x = "Total Nap Time (minutes)", 
     y = "Student Count")

Daytime

## -----------------------------------------------------------------------------
Term_gpa <- ggplot(cmu, aes(x = term_gpa)) +
geom_histogram(binwidth = .3, fill = "orange", color = "red") +
labs(title = "Distribution of Term GPA", 
     x = "Term GPA", 
     y = "Student Count")

Term_gpa


## ---- echo=FALSE--------------------------------------------------------------
library(ggplot2)
ggplot(cmu, aes(x = TotalSleepTime, y = term_gpa)) +
geom_point(color = "hotpink") +
labs(title = "Scatterplot of Sleep Time vs. Term GPA",
     x = "Total Sleep Time (minutes)",
     y = "Term GPA") +
  geom_point(data = cmu[which.min(cmu $ term_gpa), ], aes(x = TotalSleepTime, y = term_gpa), color = "brown") +
  annotate("text", x = cmu$TotalSleepTime[which.min(cmu $ term_gpa)], 
           y = cmu$term_gpa[which.min(cmu $ term_gpa)], 
           label = "Lowest Point", vjust = -1, hjust = 1, color = "brown")



## ---- echo=FALSE--------------------------------------------------------------
ggplot(cmu, aes(x = TotalSleepTime, y = cum_gpa)) +
geom_point(color = "orange") +
labs(title = "Scatterplot of Sleep Time vs. Fall GPA",
     x = "Total Sleep Time (minutes)",
     y = "Fall GPA")+
  geom_point(data = cmu[which.min(cmu $ cum_gpa), ], aes(x = TotalSleepTime, y = cum_gpa), color = "brown") +
  annotate("text", x = cmu $ TotalSleepTime[which.min(cmu $ cum_gpa)], 
           y = cmu$cum_gpa[which.min(cmu $ cum_gpa)], 
           label = "Lowest Point", vjust = -1, hjust = 1, color = "brown")


## -----------------------------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime, data = cmu)

ggplot(data = cmu, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(color = "green") +
  geom_smooth(method = "lm", se = FALSE, color = "gold") +
  labs(title = "Regression Plot of Sleep Time vs. Term GPA",
       x = "Total Sleep Time (minutes)",
       y = "Term GPA") +
  geom_text(aes(label = paste("R-squared =", round(summary(model)$r.squared, 3))),
            x = 250, y = 3.0, size = 4, color = "red")


## ---- echo=FALSE--------------------------------------------------------------
term_fit <- lm(term_gpa ~ TotalSleepTime,
data = cmu)
coef(term_fit)



## ---- echo=FALSE--------------------------------------------------------------
summary(term_fit)

## -----------------------------------------------------------------------------
residuals <- data.frame(fitted = model $ fitted.values, residuals = model $ residuals)

ggplot(data = residuals, aes(x = fitted, y = residuals)) +
  geom_point() +
  geom_hline(yintercept = 0) +
  labs(title = "Fitted vs Residuals", x = "Fitted values", y = "Residuals")

## -----------------------------------------------------------------------------
qqnorm(model $ residuals, main = "Q-Q Plot")

qqline(model $ residuals)

## -----------------------------------------------------------------------------
sum <- summary(model)

est <- sum $ coefficients["TotalSleepTime", "Estimate"]
std_error <- sum $ coefficients["TotalSleepTime", "Std. Error"]
t_value <- sum $ coefficients["TotalSleepTime", "t value"]

CI_lower <- est - (2.06 * std_error) 
CI_upper <- est + (2.06 * std_error)

CI_lower
CI_upper

