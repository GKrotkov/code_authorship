## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)


## ---- message=FALSE-----------------------------------------------------------
library(alr4)
library(dplyr)
ratings = Rateprof


## ---- message=FALSE-----------------------------------------------------------
names(ratings)[5] ="attractive"

par(mfrow = c(3, 2))
hist(ratings[,8], prob = TRUE, xlab = "Quality Rating (1-5)", main = "Histogram 1: Frequency of Quality Ratings")
hist(log(ratings[,8]), prob = TRUE, xlab = "Log of Quality Rating", 
        main = "Histogram 2: Frequency of Log Quality Ratings")
hist(ratings[,11], prob = TRUE, xlab = "Easiness", main = "Histogram 3: Frequency of Easiness Ratings")
barplot(table(ratings[,5]), names = c("No", "Yes"),
xlab = "Attractive?", ylab = "Count", main ="Barplot 1: Frequency of Attractiveness Ratings")
barplot(table(ratings[,6]), names = c("Hum", "SocSci", "STEM", "Pre-Prof"),
xlab = "Discipline", ylab = "Count", main ="Barplot 2: Frequency of Discipline")
barplot(table(ratings[,1]), names = c("Female", "Male"),
xlab = "Gender", ylab = "Count", main ="Barplot 3: Frequency of Gender")


## ---- message=FALSE-----------------------------------------------------------
plot(x = ratings$easiness, y = ratings$quality, xlab = "Easiness Rating", ylab="Quality Rating", main = "Scatterplot 1: Pair Plots of Bivariate Associations between Variables")


## ---- message=FALSE-----------------------------------------------------------
par(mfrow = c(3, 2))
par(cex.main =0.8)
boxplot(quality ~ attractive, ylab = "Quality Rating", data = ratings,
xlab = "Attractive?", names = c("No", "Yes"), pch = 16, main = "Boxplot 1: Association between Attractivess and Quality Rating")

boxplot(quality ~ discipline, ylab = "Quality Rating", data = ratings,
xlab = "Discipline", names = c("Hum","SocSci","STEM","Pre-Prof"), pch = 16, main = "Boxplot 2: Association between Discipline and Quality Rating")

boxplot(quality ~ gender, ylab = "Quality Rating", data = ratings,
xlab = "Gender", names = c("Female", "Male"), pch = 16, main = "Boxplot 3: Association between Gender and Quality Rating")

boxplot(easiness ~ gender, ylab = "Easiness Rating", data = ratings,
xlab = "Gender", names = c("Female", "Male"), pch = 16, main = "Boxplot 4: Association between Easiness Rating and Gender")

boxplot(easiness ~ discipline, ylab = "Easiness Rating", data = ratings,
xlab = "Discipline", names = c("Hum","SocSci","STEM","Pre-Prof"), pch = 16, main = "Boxplot 5: Association between Easiness Rating and Discipline")


## ---- message=FALSE-----------------------------------------------------------
library(pander)
ratings$attractive = factor(ratings$attractive)
ratings$gender = factor(ratings$gender)
ratings$discipline = factor(ratings$discipline)

full_model_gender = lm(quality ~ easiness + attractive + gender + discipline, data = ratings)
reduced_model_gender = lm(quality ~ easiness + attractive + discipline, data = ratings)

anova_table_gender = anova(reduced_model_gender, full_model_gender)

full_model_discipline = lm(quality ~ easiness + attractive + gender + discipline, data = ratings)
reduced_model_discipline = lm(quality ~ easiness + attractive + gender, data = ratings)

anova_table_discipline = anova(reduced_model_discipline, full_model_discipline)

pander(anova_table_gender, caption = "Analysis of Variance Table for F Test of Gender")
pander(anova_table_discipline, caption = "Analysis of Variance Table for F Test of Discipline")



## ---- message=FALSE-----------------------------------------------------------
full_model = lm(quality ~ easiness + attractive + gender + discipline + easiness*gender + easiness*discipline, data = ratings)

summary_full = summary(full_model)
pander(summary_full, caption = "Summary of Full Linear Model for T Test")



## ---- message=FALSE-----------------------------------------------------------
library(bestglm)
matrix = model.matrix(quality ~ easiness + attractive + gender + discipline + easiness:gender + easiness:discipline, data = ratings)
matrix_no_int = matrix[,-1]
matrix_combined = cbind(matrix_no_int, ratings$quality)
df = as.data.frame(matrix_combined)
bestglm_model = bestglm(df, IC = "AIC", method = "exhaustive")
pander(summary(bestglm_model$BestModel), caption = "Summary of BestGLM Model using AIC for T Test")

step_model = step(full_model, k = 2, direction = "both", trace = 0)
pander(summary(step_model), caption = "Summary of Step Model for T Test")


## ---- message=FALSE-----------------------------------------------------------
aic_matrix = cbind(extractAIC(bestglm_model$BestModel), extractAIC(step_model), extractAIC(full_model))
rownames(aic_matrix) = c("Df", "AIC")
colnames(aic_matrix) = c("BestGLM Model", "Step Model", "Original Model")
pander(aic_matrix, caption = "Comparison of AIC Values Across Various Models")


## ---- message=FALSE-----------------------------------------------------------
best_model = bestglm_model$BestModel
pander(confint(best_model), caption = "95% Confidence Intervals for Variables in BestGLM Model")


## -----------------------------------------------------------------------------
library(regressinator)
library(tidyr)
library(ggplot2)
library(broom)

quality_residuals = residuals(best_model)

par(mfrow = c(2, 1))

p1 = augment(best_model) |>
  ggplot(aes(x = easiness, y = .resid)) +
  geom_point() +
  labs(x = "Easiness Rating", y = "Residuals") + 
  ggtitle("Scatterplot 2: Residuals of Linear Model by Easiness Rating")
p1

boxplot(quality_residuals ~ gender, ylab = "Residuals", data = ratings, xlab = "Gender", names = c("Female","Male"), pch = 16, main = "Boxplot 6: Residuals of Linear Model by Easiness Rating")

boxplot(quality_residuals ~ attractive, ylab = "Residuals", data = ratings, xlab = "Attractive?", names = c("No","Yes"), pch = 16, main = "Boxplot 7: Residuals of Linear Model by Attractiveness")



## -----------------------------------------------------------------------------
linearity = augment(best_model) |>
  ggplot(aes(sample = .std.resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantile", y = "Sample quantile") + 
  ggtitle("Scatterplot 3: Normal Q-Q Plot for the Linear Model")
linearity

