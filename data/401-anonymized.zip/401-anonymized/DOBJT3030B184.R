## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library(alr4)
data <- Rateprof


## ---- fig.width=4, fig.height=3, fig.cap="Bar Plot of Gender"-----------------
barplot(table(data$gender), main = "Bar Plot of Gender", xlab = "Gender", ylab =
          "Count")


## ---- fig.width=4, fig.height=3, fig.cap="Bar Plot of Attractiveness (Pepper)"----
barplot(table(data$pepper), main = "Bar Plot of Attractiveness (Pepper)", 
        xlab = "Attractiveness", ylab = "Count")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Easiness Ratings"------
hist(data$easiness, main = "Histogram of Easiness Ratings", xlab = "Easiness
     Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Bar Plot of Discipline"-------------
barplot(table(data$discipline), main = "Bar Plot of Discipline", 
        xlab = "Discipline", ylab = "Count", las = 2)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Quality Ratings"-------
hist(data$quality, main = "Histogram of Quality Ratings", 
     xlab = "Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Easiness vs Quality"----
library(ggplot2)
ggplot(data, aes(x = easiness, y = quality)) + 
    geom_point() + 
    ggtitle("Scatterplot of Easiness vs Quality") +
    xlab("Easiness") + ylab("Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Gender vs Quality"-------
ggplot(data, aes(x = gender, y = quality)) + 
    geom_boxplot() +
    ggtitle("Boxplot of Gender vs Quality") +
    xlab("Gender") + ylab("Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Attractiveness vs Quality"----
ggplot(data, aes(x = pepper, y = quality)) + 
    geom_boxplot() +
    ggtitle("Boxplot of Attractiveness vs Quality") +
    xlab("Attractiveness (Pepper)") + ylab("Quality Rating")


## ---- fig.width=4, fig.height=3, fig.cap="Boxplot of Discipline vs Quality"----
ggplot(data, aes(x = discipline, y = quality)) + 
    geom_boxplot() +
    ggtitle("Boxplot of Discipline vs Quality") +
    xlab("Discipline") + ylab("Quality Rating")


## ---- fig.width=4, fig.height=4, fig.cap="Modeling"---------------------------
model <- lm(quality ~ gender + pepper + easiness + gender:easiness + discipline, 
            data = data)

coefficients <- summary(model)$coefficients 
confint(model)

anova(model)

par(mfrow = c(2, 2))
plot(model)  
library(car)  
vif(model) 
shapiro.test(resid(model))
library(lmtest)
bptest(model)

