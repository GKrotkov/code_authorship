## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
# PAPER PRE-WORK

# Importing libraries
library(tidyverse, gridExtra)
library(patchwork)
library(GGally)
library(modelsummary)
library(stats)

# Importing data and creating necessary variables
sleep = read.csv("C:/Users/Victoria Chen/OneDrive/Documents/23_24/36-401/cmu-sleep.csv")
cmu_sleep = select(sleep, TotalSleepTime, term_gpa, cum_gpa)
cmu_sleep_mod = mutate(cmu_sleep, log1_term_gpa = log(term_gpa + 1), 
                                  log1_cum_gpa = log(cum_gpa + 1))
cmu_sleep_mod = select(cmu_sleep_mod, TotalSleepTime, log1_term_gpa,
                                      log1_cum_gpa)

# Rice Rule, Bin Picking (from 36-315)
# Citation: https://en.wikipedia.org/wiki/Histogram
getRiceBinNum <- function(x) {
  n = length(x)
  k = ceiling(2 * n^(1/3))
  return(k)
}


## ---- fig.width=3, fig.height=2, fig.cap="Spring average sleep time for Carnegie Mellon students."----
cmu_sleep_mod %>%
  ggplot(aes(x = TotalSleepTime)) +
  geom_histogram(bins = getRiceBinNum(cmu_sleep_mod$TotalSleepTime)) +
  labs(x = "Average Sleep Time per Night (mins)", y = "Number of Students")


## ---- fig.width=3, fig.height=2, fig.cap="Log-transformed spring term GPA for Carnegie Mellon students"----
cmu_sleep_mod %>%
  ggplot(aes(x = log1_term_gpa)) +
  geom_histogram(bins = getRiceBinNum(cmu_sleep_mod$log1_term_gpa)) +
  labs(x = "Log of (Spring Term GPA + 1)", y = "Number of Students")


## -----------------------------------------------------------------------------
# Removal of outlier point
cmu_sleep_mod = cmu_sleep_mod[-which.min(cmu_sleep_mod$log1_term_gpa),]


## ---- fig.width=4, fig.height=3, fig.cap="Pairs plot of variables involved in study."----
ggpairs(cmu_sleep_mod)


## ---- fig.width=3, fig.height=2, fig.cap="QQ Plot of TotalSleepTime residuals."----
cmu_sleep_mod %>%
  ggplot(aes(sample = TotalSleepTime)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Observed Quantiles")


## ---- fig.width=3, fig.height=2, fig.cap="QQ Plot of Log(term_gpa + 1) residuals."----
cmu_sleep_mod %>%
  ggplot(aes(sample = log1_term_gpa)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical Quantiles", y = "Observed Quantiles")


## ---- fig.width=4, fig.height=3, fig.cap="Residual plot of residuals vs. fitted values."----
# Creation of Model
model = lm(log1_term_gpa ~ TotalSleepTime, data = cmu_sleep_mod)

# Getting residuals and fitted values
resids = resid(model)
fitted_vals = model$fitted.values

# Plotting residual plot
resid_plot_df = data.frame(fitted_vals, resids)
resid_plot_df %>%
  ggplot(aes(x = fitted_vals, y = resids)) +
  geom_point() +
  geom_hline(yintercept = 0, color = "red") +
  labs(x = "Fitted Values", y = "Residuals")


## ---- include = FALSE, eval = FALSE-------------------------------------------
## # Citation: 36401 Lecture 6
## cook_dists = cooks.distance(model)
## 
## # Calculating percentiles
## # Result: Highest percentile is approx 30th, which is a non-issue
## head(sort(pf(cook_dists, 2, 9), decreasing = TRUE))


## ---- fig.width=3, fig.height=4, fig.cap="Linear regression model parameters."----
modelsummary(list("Model" = model), gof_map = c("r.squared", "nobs"))


## ---- include = FALSE, eval = FALSE-------------------------------------------
## # Checking significance for model parameters
## summary(model)
## 
## # Confidence Interval Calculation for beta_1
## confint(model, "TotalSleepTime", level = 0.95)
## 
## # Conversion of log(GPA + 1) to GPA
## exp(0.0005328) - 1
## exp(0.06394) - 1

