## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ---- message = FALSE, include = FALSE----------------------------------------
library(ggplot2)
library(dplyr)
library(broom)


## ----total_sleep_time,   out.width="50%", fig.align='center', fig.cap="Frequency of Average Sleep Times Among Students",  echo=FALSE----

df <- read.csv("C:/Users/jenny/OneDrive/Documents/cmu-sleep.csv")
sleep <- df$TotalSleepTime
hist(
  sleep,
  main = "Histogram of Average Sleep Time",     
  xlab = "Average Sleep Time (minutes)",           
  ylab = "Frequency",                     
  col = "grey",                         
  breaks = 20                           
)



## ----term_histogram,  out.width="50%", fig.align='center', fig.cap="Frequency of Current Term GPA Among Students", echo=FALSE----
term <- df$term_gpa
hist(
  term,
  main = "Histogram of Current Term GPA",     
  xlab = "Current Term GPA (on a 4.0 scale)",           
  ylab = "Frequency",                     
  col = "grey",                         
  breaks = 20                           
)


## ----transformed_term_histogram,  out.width="50%", fig.align='center', fig.cap="Frequency of Transformed Current Term GPA Among Students", echo=FALSE----
term_2 <- 2^(term)
hist(
  term_2,
  main = "Histogram of Exponentiated Current Term GPA",     
  xlab = "2^(Current Term GPA) (on a 16.0 scale)",           
  ylab = "Frequency",                     
  col = "grey",                         
  breaks = 20                           
)


## ----gpa_vs_sleep,  out.width="50%", fig.align='center', fig.cap="Scatterplot of Average Sleep Time Against Current Term GPA", echo=FALSE----
plot(sleep, term, 
     xlab = "Average Sleep Time (minutes)", 
     ylab = "Current Term GPA (on a 4.0 scale)",
     main = "Average Sleep Time vs. Current Term GPA",
     pch = 16,    
     cex = 0.5,
     col = "black" 
     
)


## ----transformed_gpa_vs_sleep,  out.width="50%", fig.align='center', fig.cap="Scatterplot of Average Sleep Time Against Transformed Current Term GPA", echo=FALSE----
plot(sleep, term_2, 
     xlab = "Average Sleep Time (minutes)", 
     ylab = "2^(Current Term GPA) (on a 16.0 scale)",
     main = "Average Sleep Time vs. Exponentiated Current Term GPA",
     pch = 16,    
     cex = 0.5,
     col = "black" 
     
)


## ----residual_plot,  out.width="50%", fig.align='center', fig.cap="Scatterplot of Average Sleep Time against Residuals of Transformed Current Term GPA Data", echo=FALSE----

model <- lm(term_2~sleep)
res <- resid(model)

plot(fitted(model), res,
     xlab = "Average Sleep Time (minutes)", 
     ylab = "Residuals",
     main = "Scatterplot of Sleep Duration vs. Residuals of Transformed Data",
     )


## ----qq_plot,  out.width="50%", fig.align='center', fig.cap="Q-Q Plot of the Residuals from the Transformed Current Term GPA Data", echo=FALSE----
qqnorm(res)
qqline(res, col = "red")


## ---- message = FALSE, include=FALSE------------------------------------------
summary(model)
correlation <- cor(term_2, sleep)
correlation
conf_interval <- confint(model, level = 0.95)
conf_interval

