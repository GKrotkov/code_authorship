## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
df <- read.csv("cmu-sleep.csv")


## -----------------------------------------------------------------------------
df <- df[, c("TotalSleepTime", "term_gpa", "cum_gpa")]
head(df)


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of TotalSleepTime"--------
hist(df$TotalSleepTime, ylim = c(0, 150), breaks = seq(150, 600, by = 25), xlab = "Average Sleep Time in Minutes", main = NULL)


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of cum_gpa"---------------
custom_breaks <- seq(0, 4, by = 0.5)
hist(df$cum_gpa, xlab = "GPA (out of 4.0)", xlim = c(0, 4), breaks = seq(0, 4, by = 0.25), xaxt = "n", main = NULL)
custom_labels <- sprintf("%.1f", custom_breaks)
axis(1, at = custom_breaks, labels = custom_labels)


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of exp(cum_gpa)"----------
hist(exp(df$cum_gpa), xlab = "Exponential of GPA", main = NULL)


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of term_gpa"--------------
hist(df$term_gpa, xlab = "GPA (out of 4.0)", xlim = c(0, 4), breaks = seq(0, 4, by = 0.25), xaxt = "n", main = NULL)
custom_labels <- sprintf("%.1f", custom_breaks)
axis(1, at = custom_breaks, labels = custom_labels)


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of exp(term_gpa)"---------
hist(exp(df$term_gpa), xlab = "Exponential of GPA", main = NULL)


## ---- fig.width=6, fig.height=4, fig.cap="Histogram of gpa_diff"--------------
df$gpa_diff <- df$term_gpa - df$cum_gpa
hist(df$gpa_diff, breaks = seq(-2.0, 2.0, by = 0.25), xlab = "GPA Difference", main = NULL)


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot of exp(cum_gpa) vs TotalSleepTime"----
plot(df$TotalSleepTime, exp(df$cum_gpa), xlab = "Average Sleep Time in Minutes", ylab = "Exponential of GPA")
abline(lm(exp(cum_gpa) ~ TotalSleepTime, data = df))


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot of exp(term_gpa) vs TotalSleepTime"----
plot(df$TotalSleepTime, exp(df$term_gpa), xlab = "Average Sleep Time in Minutes", ylab = "Exponential of GPA")
abline(lm(exp(term_gpa) ~ TotalSleepTime, data = df))


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot of gpa_diff vs TotalSleepTime"----
plot(df$TotalSleepTime, df$gpa_diff, xlab = "Average Sleep Time in Minutes", ylab = "GPA Difference")
abline(lm(gpa_diff ~ TotalSleepTime, data = df))


## -----------------------------------------------------------------------------
library(modelsummary)
model <- lm(gpa_diff ~ TotalSleepTime, data = df)


## -----------------------------------------------------------------------------
modelsummary(list("Model" = model), gof_map = c("r.squared", "nobs"))


## -----------------------------------------------------------------------------
confint(model)


## -----------------------------------------------------------------------------
predict(model, newdata = data.frame(TotalSleepTime = -120), interval = "confidence", level = 0.95)


## ---- fig.width=6, fig.height=4, fig.cap="Scatterplot of Residuals vs TotalSleepTime"----
plot(df$TotalSleepTime, model$residuals, xlab = "Average Sleeping Time in Minutes", ylab = "Residuals")


## ---- fig.width=6, fig.height=4, fig.cap="QQ plot of Residuals vs TotalSleepTime"----
qqnorm(model$residuals) 
qqline(model$residuals)

