## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(ggplot2)
library(patchwork)
library(gridExtra)
library(ggpubr)
head(Rateprof)
Rateprof$gender <- factor(Rateprof$gender)
Rateprof$pepper <- factor(Rateprof$pepper)
Rateprof$discipline <- factor(Rateprof$discipline)


## ---- fig.width=5, fig.height=5, fig.cap="Above are histograms describing the distributions of our four predictor variables: gender, attractiveness, easiness, and discipline. We note that most of the professors are deemed not attractive and the distributions of gender and discipline are roughly equal.  The distribution of the average easiness rating is centered around 3.", echo = FALSE, results = 'hide', warning = F, message = F----
p1 <- ggplot(Rateprof, aes(x = gender)) +
  geom_bar(bins = 2) +
  labs(x = "Gender", 
       y = "Count")

p2 <- ggplot(Rateprof, aes(x = pepper)) +
  geom_bar(bins = 2) +
  labs(x = "Attractiveness", 
       y = "Count")

p3 <- ggplot(Rateprof, aes(x = easiness)) +
  geom_histogram() +
  labs(x = "Easiness", 
       y = "Count")

p4 <- ggplot(Rateprof, aes(x = discipline)) +
  geom_bar() +
  labs(x = "Discipline", 
       y = "Count")

# grid.arrange(p1, p2, arrangeGrob(p3, p4, ncol=2), nrow = 2)
ggarrange(p1, p2, p3, p4, 
          labels = c("A", "B", "C", "D"),
          ncol = 2, nrow = 2)




## ---- fig.width=4, fig.height=3, fig.cap="Distribution of professor quality ratings.", echo = FALSE, results = 'hide', warning = FALSE, message = FALSE----
ggplot(Rateprof, aes(x = quality)) +
  geom_histogram() +
  labs(x = "Quality", 
       y = "Count")


## ---- fig.width=4, fig.height=3, fig.cap="Pairwise plots of the four predictor variables.  We notice some potential relationships between three of the four predictor varibales and average quality rating: gender, attractiveness, and easiness.", message=FALSE----
library(GGally)
library(dplyr)

Rateprof |>
  select(quality, gender, pepper, easiness, discipline) |>
  ggpairs()


## ---- include = FALSE---------------------------------------------------------
library(broom)
test_fit <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
summary(test_fit)
head(augment(test_fit))


## ---- fig.width=4, fig.height=3, fig.cap="Above are resisdual plots against each of the four predictor variables of interest.  We note that each of the plots show residuals centered around 0."----

g1 <- ggplot(augment(test_fit), aes(x = gender, y = .resid)) + 
  geom_boxplot() +
  labs(x = "Gender",
       y = "Residual")

g2 <- ggplot(augment(test_fit), aes(x = pepper, y = .resid)) + 
  geom_boxplot() +
  labs(x = "Attractiveness",
       y = "Residual")

g3 <- ggplot(augment(test_fit), aes(x = easiness, y = .resid)) + 
  geom_point() +
  labs(x = "Easiness",
       y = "Residual")

g4 <- ggplot(augment(test_fit), aes(x = discipline, y = .resid)) + 
  geom_boxplot() +
  labs(x = "Discipline",
       y = "Residual")

ggarrange(g1, g2, g3, g4, 
          labels = c("A", "B", "C", "D"),
          ncol = 2, nrow = 2)



## ---- fig.width=4, fig.height=3, fig.cap="Residuals plotted against the fitted values from the full model."----

ggplot(augment(test_fit), aes(x = .fitted, y = .resid)) +
  geom_point() +
  labs(x = "Fitted Value", 
       y = "Residual")



## ---- include = FALSE---------------------------------------------------------
full_model_gen <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

red_model_gen <- lm(quality ~ pepper + easiness + discipline, data = Rateprof)

anova(red_model_gen, full_model_gen)


## ---- include = FALSE---------------------------------------------------------
full_model_pep <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

red_model_pep <- lm(quality ~ gender  + easiness + discipline, data = Rateprof)

anova(red_model_pep, full_model_pep)


## ---- include = FALSE---------------------------------------------------------
full_model_easy <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

red_model_easy <- lm(quality ~ gender + pepper + discipline, data = Rateprof)

anova(red_model_easy, full_model_easy)


## ---- include = FALSE---------------------------------------------------------
full_model_dis <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)

red_model_dis <- lm(quality ~ gender + pepper + easiness, data = Rateprof)

anova(red_model_dis, full_model_dis)


## ---- include = FALSE---------------------------------------------------------
model_size <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)
summary(model_size)
confint(model_size)


## ---- include = FALSE---------------------------------------------------------

model_prov_all <- lm(quality ~ easiness + gender + pepper + discipline + easiness:gender + easiness:discipline, data = Rateprof)
summary(model_prov_all)

confint(model_prov_all)


