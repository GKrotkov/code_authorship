## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
data = read.csv('cmu-sleep.csv')


## -----------------------------------------------------------------------------
nrow(data)



## -----------------------------------------------------------------------------

hist(data$TotalSleepTime, main = "Frequency of Average Sleep Time of Students", 
     xlab = "Average Sleep Time of Students (minutes)", ylab = "Frequency")



## -----------------------------------------------------------------------------

hist(data$term_gpa, main = "Frequency of Term GPA", 
     xlab = "Term GPA of Students", ylab = "Frequency")



## -----------------------------------------------------------------------------

hist(data$cum_gpa, main = "Frequency of Cumulative GPA of Students", 
     xlab = "Cumulative GPA of Students", ylab = "Frequency")



## -----------------------------------------------------------------------------
plot(data$TotalSleepTime, data$term_gpa, main = "Average Sleep Time vs. Term GPA", 
     xlab = "Average Sleep Time of Students(minutes)", ylab = "Term GPA")


## -----------------------------------------------------------------------------
model <- lm(data$term_gpa ~ data$TotalSleepTime, data = data)

residuals <- residuals(model)

plot(data$TotalSleepTime, residuals, 
     main = "Residuals vs Average Total Sleep Time",
     xlab = "Average Total Sleep Time (minutes)",
     ylab = "Residuals")

