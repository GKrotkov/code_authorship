## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
word_csv=read.csv("/Users/dhruvkrishnan/Desktop/cmu-sleep.csv")



## -----------------------------------------------------------------------------
library(ggplot2)
ggplot(word_csv, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth = 30, fill = "blue", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Total Sleep Time", x = "Total Sleep Time (minutes)", y = "Frequency")

# Calculate the statistics
mean_val = mean(word_csv$TotalSleepTime)
median_val = median(word_csv$TotalSleepTime)
sd_val = sd(word_csv$TotalSleepTime)
q1 = quantile(word_csv$TotalSleepTime, 0.25)
q3 = quantile(word_csv$TotalSleepTime, 0.75)
iqr_val = q3 - q1

# Plot the histogram with annotations for the above statistics
hist_plot = ggplot(word_csv, aes(x = TotalSleepTime)) +
  geom_histogram(binwidth=10, fill="blue", color="white", alpha=0.7) +
  geom_vline(aes(xintercept=mean_val), color="red", linetype="dashed", size=0.5) + 
  geom_vline(aes(xintercept=median_val), color="green", linetype="dashed", size=0.5) +
  geom_vline(aes(xintercept=q1), color="purple", linetype="dotted", size=0.5) +
  geom_vline(aes(xintercept=q3), color="purple", linetype="dotted", size=0.5) +
  annotate("text", x = mean_val, y = 10, label = sprintf("Mean = %.2f", mean_val), vjust = -1, color = "red") +
  annotate("text", x = median_val, y = 10, label = sprintf("Median = %.2f", median_val), vjust = -2, color = "green") +
  annotate("text", x = q1, y = 10, label = sprintf("Q1 = %.2f", q1), vjust = 3, hjust=1, color = "white") +
  annotate("text", x = q3, y = 10, label = sprintf("Q3 = %.2f", q3), vjust = 3, hjust=-0.1, color = "white") +
  labs(title="Histogram of Total Sleep Time with Descriptive Statistics", x="Total Sleep Time (minutes)", y="Frequency")

print(hist_plot)



## ---- -1----------------------------------------------------------------------
library(ggplot2)
ggplot(word_csv, aes(x = term_gpa)) +
  geom_histogram(binwidth = 0.2, fill = "green", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Term GPA", x = "Term GPA (scaled to 4.0)", y = "Frequency")


## ---- -32435354---------------------------------------------------------------

library(ggplot2)
ggplot(word_csv, aes(x = cum_gpa)) +
  geom_histogram(binwidth = 0.2, fill = "coral", color = "black", alpha = 0.7) +
  labs(title = "Histogram of Cumulative GPA", x = "Cumulative GPA (scaled to 4.0)", y = "Frequency")



## ---- -3245354----------------------------------------------------------------
# Create a scatterplot with green-colored points
ggplot(word_csv, aes(x = TotalSleepTime, y = (term_gpa))) +
  geom_point(color = "blue") +
  labs(title = "Linear-Scatterplot of Term GPA (scaled to 4.0) vs. Total Sleep Time", 
       x = "Total Sleep Time (minutes)", 
       y = "Term GPA (scaled to 4.0)") +
  theme_minimal()





## ----2934194024---------------------------------------------------------------
library(modelsummary)
model_term = lm(term_gpa ~ TotalSleepTime, data = word_csv)
modelsummary(list("Simple Linear Regression Model" = model_term),
             gof_map = c("r.squared", "nobs"))
plot(model_term,,which=1:2)



## ----293494024----------------------------------------------------------------
# One-sample t-test on TotalSleepTime
t_result = t.test(word_csv$TotalSleepTime, mu = 0)
print(t_result)


