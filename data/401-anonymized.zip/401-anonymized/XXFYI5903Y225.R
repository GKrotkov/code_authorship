## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
# Load packages and libraries
setwd("/Users/aditimannem/Library/Mobile Documents/com~apple~CloudDocs/36-401")
library(alr4)
library(ggplot2)
library(broom)


## ---- include=FALSE-----------------------------------------------------------
head(Rateprof)


## ---- include=FALSE-----------------------------------------------------------
summary(Rateprof[c("quality","easiness", "gender", "pepper", "discipline")])

## ---- include=FALSE-----------------------------------------------------------
apply(Rateprof[c("quality","easiness", "gender", "pepper", "discipline")],2,sd)


## -----------------------------------------------------------------------------
par(mfrow=c(2,3))
hist(Rateprof$quality, main = "F1: Distribution of Professor Rating", xlab = "Quality")
hist(Rateprof$easiness, main = "F2: Distribution of Easiness", xlab = "Easiness")
barplot(table(Rateprof$gender), names = c("Female", "Male"), xlab = "Gender", ylab = "Count", main = "F3: Bar Plot of Gender")
barplot(table(Rateprof$pepper), names = c("No", "Yes"), xlab = "Attractiveness", ylab = "Count", main = "F4: Bar Plot of Attractiveness")
barplot(table(Rateprof$discipline), names = c("Hum", "SocSci", "STEM", "Pre-prof"), xlab = "Discipline", ylab = "Count", main = "F5: Bar Plot of Discpline")


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
pairs(Rateprof[c("quality","gender","pepper","easiness","discipline")], main = "F6: Pairs plots of response and preictors")


## -----------------------------------------------------------------------------
par(mfrow=c(1,3))
boxplot(Rateprof$quality ~ Rateprof$gender, main = "F7: Boxplot of Quality and Gender", xlab = "Gender", ylab = "Quality")
boxplot(Rateprof$quality ~ Rateprof$pepper, main = "F8: Boxplot of Quality and Attractiveness", xlab = "Attractiveness", ylab = "Quality")
boxplot(Rateprof$quality ~ Rateprof$discipline, main = "F9: Boxplot of Quality and Discipline", xlab = "Discipline", ylab = "Quality")


## ---- include=FALSE-----------------------------------------------------------
overall_fit = lm(Rateprof$quality ~ factor(Rateprof$gender) + factor(Rateprof$pepper) + Rateprof$easiness + factor(Rateprof$discipline),
    data = Rateprof)


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
p1 <- augment(overall_fit) |> 
  ggplot(aes(x = Rateprof$easiness, y = .resid)) +
  geom_point() +
  labs(x = "Easiness", y = "Residual")
p1


## ---- fig.width=5, fig.height=4, fig.align='center'---------------------------
par(mfrow=c(1,2))
plot(overall_fit, which=c(2,1))


## ---- include=FALSE-----------------------------------------------------------
summary(overall_fit)

## ---- include=FALSE-----------------------------------------------------------
confint(overall_fit)


## ---- include=FALSE-----------------------------------------------------------
red_model_1 = lm(Rateprof$quality ~ factor(Rateprof$gender) + factor(Rateprof$pepper) + Rateprof$easiness,
    data = Rateprof)


## ---- include=FALSE-----------------------------------------------------------
anova(red_model_1, overall_fit)


## ---- include=FALSE-----------------------------------------------------------
red_model_2 = lm(Rateprof$quality ~ factor(Rateprof$gender) + factor(Rateprof$pepper) + factor(Rateprof$discipline),
    data = Rateprof)


## ---- include=FALSE-----------------------------------------------------------
anova(red_model_2, overall_fit)


## ---- include=FALSE-----------------------------------------------------------
red_model_3 = lm(Rateprof$quality ~ factor(Rateprof$gender) + Rateprof$easiness + factor(Rateprof$discipline),
    data = Rateprof)


## ---- include=FALSE-----------------------------------------------------------
anova(red_model_3, overall_fit)


## ---- include=FALSE-----------------------------------------------------------
red_model_4 = lm(Rateprof$quality ~ factor(Rateprof$pepper) + Rateprof$easiness + factor(Rateprof$discipline),
    data = Rateprof)


## ---- include=FALSE-----------------------------------------------------------
anova(red_model_4, overall_fit)


## ---- include=FALSE-----------------------------------------------------------
int_discipline = lm(Rateprof$quality ~ factor(Rateprof$gender) + factor(Rateprof$pepper) + Rateprof$easiness + factor(Rateprof$discipline) + Rateprof$easiness:Rateprof$discipline,
    data = Rateprof)
summary(int_discipline)


## ---- include=FALSE-----------------------------------------------------------
int_gender = lm(Rateprof$quality ~ factor(Rateprof$gender) + factor(Rateprof$pepper) + Rateprof$easiness + factor(Rateprof$discipline) + Rateprof$easiness:Rateprof$gender,
    data = Rateprof)
summary(int_gender)

