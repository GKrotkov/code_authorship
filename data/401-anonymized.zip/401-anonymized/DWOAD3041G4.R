## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- warning=FALSE, echo = FALSE, message=FALSE------------------------------
library(regressinator)
library(alr4)
library(dplyr)
library(ggplot2)
library(broom)
library(patchwork)


## ---- error = TRUE, message = FALSE-------------------------------------------
data(Rateprof, package = 'alr4')


## ---- echo = FALSE, message= FALSE--------------------------------------------
h1 <- ggplot(Rateprof, aes(x = gender)) +
geom_bar(width = 0.5, fill = "cornflowerblue", color = "black", position = "dodge") +
labs(x = "Gender (Yes or No)", title = "Gender Histogram")


## ---- echo = FALSE, message= FALSE--------------------------------------------
h2 <- ggplot(Rateprof, aes(x = pepper)) +
geom_bar(width = 0.5, fill = "lightpink", color = "black", position = "dodge") +
labs(x = "Attractiveness (yes or no)", title = "Attractiveness Histogram")



## ---- echo = FALSE, message= FALSE--------------------------------------------
h3 <- ggplot(Rateprof, aes(x = quality)) +
geom_histogram(fill = "lightblue", color = "black") +
labs(x = "Quality Rating (1 to 5)", title = "Quality Histogram") 



## ---- echo = FALSE, message= FALSE--------------------------------------------
h4 <- ggplot(Rateprof, aes(x = discipline)) +
geom_bar(fill = "forestgreen", color = "black", position = "dodge") +
theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
labs(x = "Discipline", title = "Discipline Histogram") 



## ---- echo = FALSE, message= FALSE--------------------------------------------
h5 <- ggplot(Rateprof, aes(x = easiness)) +
geom_histogram(fill = "orange", color = "black") +
labs(x = "Easiness Rating (1 to 5)", title = "Easiness Histogram") 
h1 | h2 | h3| h4 | h5


## ---- echo = FALSE, message= FALSE--------------------------------------------
qualityAttractiveness <- ggplot(Rateprof, aes(x = pepper, y = quality, color = pepper)) +
  geom_boxplot(fill = "lightblue", color = "black", outlier.shape = NA) +  # Hide outliers
  geom_jitter(aes(color = pepper), width = 0.2, height = 0, alpha = 0.7) +  # Add jittered points
  labs(title = "Quality vs. Attractiveness", x = "Attractiveness", y = "Quality") +
  theme_minimal()

qualityGender <- ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot(fill = "lightblue", color = "black", outlier.shape = NA) +  # Hide outliers
  geom_jitter(aes(color = gender), width = 0.2, height = 0, alpha = 0.7) +  # Add jittered points
  labs(x = "Gender", y = "Quality Rating", title = "Quality Rating by Gender") +
  theme_minimal()

qualityDiscipline <- ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot(fill = "lightblue", color = "black", outlier.shape = NA) +  # Hide outliers
  geom_jitter(aes(color = discipline), width = 0.2, height = 0, alpha = 0.7) +  # Add jittered points
  labs(x = "Discipline", y = "Quality Rating", title = "Quality Rating by Discipline") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

qualityAttractiveness | qualityGender | qualityDiscipline


## ---- echo = FALSE, message= FALSE--------------------------------------------
qualityEasiness <- ggplot(Rateprof, aes(y = quality,
x = easiness)) +
geom_point() +
labs(y = "Quality",
x = "easiness",
title = "Quality with Easiness")


qualityEasinessWithDisciplineGender <- ggplot(Rateprof, aes(x = easiness, y = quality, color = discipline, shape = gender)) +
  geom_point(alpha = 0.7) +
  geom_smooth(method = "lm", se = FALSE, color = "black", linetype = "dashed") +
  labs(title = "Quality with Easiness by Discipline and Gender", x = "Easiness", y = "Quality") +
  theme_minimal()


qualityEasiness | qualityEasinessWithDisciplineGender



## ---- echo = FALSE, message = FALSE-------------------------------------------
#pairs(quality ~ easiness + discipline + gender,
#data = Rateprof, pch = 16, cex = 0.7)


## ---- include = FALSE, echo = FALSE-------------------------------------------
library(modelsummary)
quality_fit <- lm(quality ~ easiness + discipline + gender, data = Rateprof)
#summary(quality_fit)
#vif(quality_fit)
#modelsummary(list("Model 1" = quality_fit),
#             gof_map = c("r.squared", "nobs"))


## ---- echo = FALSE------------------------------------------------------------
quality_easiness <- lm(quality ~ easiness, data = Rateprof)
#summary(quality_easiness)
#modelsummary(list("Model 2" = quality_easiness),
#             gof_map = c("r.squared", "nobs"))


## ---- echo= FALSE-------------------------------------------------------------
#model_q3 <- lm(term_gpa ~ TotalSleepTime + cum_gpa + daytime_sleep + study + demo_gender + term_units, data = sleep)
#modelsummary(list("Model 3" = model_q3),
#             gof_map = c("r.squared", "nobs"))

quality_attractiveness <- lm(quality ~ pepper, data = Rateprof)
#summary(quality_attractiveness)
#modelsummary(list("Model 3" = quality_attractiveness),
#             gof_map = c("r.squared", "nobs"))


## ---- message = FALSE, echo= FALSE--------------------------------------------
qual_model <- lm(quality ~ easiness + discipline + gender + pepper, data = Rateprof)

p1 <- augment(qual_model) %>%
ggplot(aes(x = easiness, y = .resid)) +
geom_point() +
labs(x = "Easiness", y = "Residual")

p2 <- augment(qual_model) %>%
ggplot(aes(x = pepper, y = .resid)) +
geom_point() +
labs(x = "Attractiveness", y = "Residual")

p3 <- augment(qual_model) %>%
ggplot(aes(x = discipline, y = .resid)) +
geom_point() +
labs(x = "discipline", y = "Residual")

p4 <- augment(qual_model) %>%
ggplot(aes(x = gender, y = .resid)) +
geom_point() +
labs(x = "fitted", y = "Residual")

p5 <- augment(qual_model) %>%
ggplot(aes(x = .fitted, y = .resid)) +
geom_point() +
labs(x = "fitted", y = "Residual")
#There is more of a clear mean for easiness in comparison to the residual plot for the other categorical variables which are harder to read and no signs of trends.


p6 <- augment(qual_model) %>%
  ggplot(aes(sample = .std.resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantile", y = "Sample quantile")

p5
p6


## ---- message= FALSE, echo= FALSE---------------------------------------------
model_reduced <- lm(quality ~ easiness, data = Rateprof)
model_full <- lm(quality ~ easiness + gender + discipline, data = Rateprof)

anova_comparison <- anova(model_reduced, model_full)


## ---- error = FALSE-----------------------------------------------------------
reduced_ql_fit <- lm(quality~easiness, data = Rateprof)
anova(reduced_ql_fit, quality_fit)


## ---- echo = FALSE------------------------------------------------------------
quality_discipline <- lm(quality ~ discipline, data = Rateprof)
#summary(quality_discipline)

#modelsummary(list("Model 4" = quality_discipline),
             #gof_map = c("r.squared", "nobs"))


quality_gender <- lm(quality ~ gender, data = Rateprof)
#modelsummary(list("Model 5" = quality_gender),
             #gof_map = c("r.squared", "nobs"))
#summary(quality_gender)

modelsummary(list("Model 1" = quality_fit, "Model 2" = quality_easiness, 
                  "Model 3" = quality_attractiveness, "Model 4" = quality_discipline,
                  "Model 5" = quality_gender),
             gof_map = c("r.squared", "nobs"))



