## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
cmusleep = read.csv('cmu-sleep.csv')



## ---- fig.width=4, fig.height=4, fig.cap="Histogram of Total Sleep Time"------

hist(cmusleep$TotalSleepTime,
     main = "Histogram of Total Sleep Time" , 
     xlab = "Total Sleep Time (in minutes)")



## ---- results='hide'----------------------------------------------------------
mean(cmusleep$TotalSleepTime)
sd(cmusleep$TotalSleepTime)
median(cmusleep$TotalSleepTime)
min(cmusleep$TotalSleepTime)
max(cmusleep$TotalSleepTime)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of Term GPA "-------------

hist(cmusleep$term_gpa,
     main = "Histogram of Term GPA" , 
     xlab = "Term GPA  (out of 4.0)")


## ---- results='hide'----------------------------------------------------------
mean(cmusleep$term_gpa)
sd(cmusleep$term_gpa)
median(cmusleep$term_gpa)
min(cmusleep$term_gpa)
max(cmusleep$term_gpa)


## ---- fig.width=4, fig.height=4, fig.cap="Histogram of Cummulative GPA"-------

hist(cmusleep$cum_gpa,
     main = "Histogram of Cummulative GPA" , 
     xlab = "Cummulative GPA (out of 4.0)")



## ---- results='hide'----------------------------------------------------------
mean(cmusleep$cum_gpa)
sd(cmusleep$cum_gpa)
median(cmusleep$cum_gpa)
min(cmusleep$cum_gpa)
max(cmusleep$cum_gpa)


## ---- fig.width=4, fig.height=4, fig.cap="Scatter Plot of Term GPA compared with Total Sleep Time"----

plot(cmusleep$TotalSleepTime, cmusleep$term_gpa,
     main = "Term GPA Compared to Total Sleep Time",
     xlab = "Total Sleep Time (in minutes)",
     ylab = "Term GPA (out of 4.0)")

abline(lm(term_gpa ~ TotalSleepTime, data = cmusleep), col = "red")



## ---- fig.width=5, fig.height=4, fig.cap="Scatter Plot of Cumulative GPA compared with Total Sleep Time"----

plot(cmusleep$TotalSleepTime, cmusleep$cum_gpa,
     main = "Cumulative GPA Compared to Total Sleep Time",
     xlab = "Total Sleep Time (in minutes)",
     ylab = "Cumulative GPA (out of 4.0)")

abline(lm(cum_gpa ~ TotalSleepTime, data = cmusleep), col = "blue")



## ---- results='hide'----------------------------------------------------------

sleep_lm <- lm(term_gpa ~ TotalSleepTime, data = cmusleep)
residuals <- residuals(sleep_lm)



## ---- fig.width=4, fig.height=4, fig.cap="QQ Plot of Residuals"---------------

plot(sleep_lm,
     which=2)



## ---- fig.width=4, fig.height=4, fig.cap="Scatterplot of Residuals Compared with Fitted Values (Total Sleep Time)"----

plot(sleep_lm, which = 1)



## ---- results='hide'----------------------------------------------------------
summary(sleep_lm)


## ---- results='hide'----------------------------------------------------------
2.6610500 + 0.0019846 * (397.3239 - 120) 


## ---- results='hide'----------------------------------------------------------

2.6610500 + 0.0019846 * (397.3239)
3.449579 - 3.211427

