## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
library(alr4)
library(ggplot2)
hist(Rateprof$quality, main="Distribution of Quality Rating", 
     xlab="Quality (1 to 5)",
     ylab="Frequency")

## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
library(alr4)
library(ggplot2)
hist(Rateprof$easiness, main="Distribution of Easiness Rating", 
     xlab="Easiness (1 to 5)",
     ylab="Frequency")


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=3, fig.height=3-----
library(alr4)
library(ggplot2)
ggplot(Rateprof, aes(x=gender))+
  geom_bar()+
  labs(title="Distribution of instructor 
       gender", 
       x="Instructor Gender (Female or Male)", y="Frequency")
ggplot(Rateprof, aes(x=discipline))+
  geom_bar()+
  labs(title="Distribution of discipline", x="Discipline", y="Frequency")


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
library(alr4)
library(ggplot2)
ggplot(Rateprof, aes(x=pepper))+
  geom_bar()+
  labs(title="Distribution of Attractiveness", 
       x="Attractive (No or Yes)", y="Frequency")


## ---- include=FALSE-----------------------------------------------------------
mean(Rateprof$quality)
median(Rateprof$quality)
mean(Rateprof$easiness)
median(Rateprof$easiness)


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
library(GGally)
Rateprof |>
  dplyr:: select(easiness, gender,quality, discipline, pepper) |>
  ggpairs()+
  labs(title="Pairs Plot")


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=3, fig.height=3-----
plot(quality~gender, data=Rateprof, main="Boxplot of quality 
     ratings by gender")


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
plot(quality~discipline, data=Rateprof, main="Boxplot of quality 
     ratings by discipline")
plot(quality~pepper, data=Rateprof, main="Boxplot of quality 
     ratings by attractiveness")


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
library(broom)
mod <- lm(quality~easiness + discipline + gender + pepper, Rateprof)
plot(residuals(mod),
 main="Residual plot", xlab="Fitted values", ylab="Residuals")
hist(residuals(mod))
augment(mod) |>
  ggplot(aes(x=easiness, y=.cooksd))+
  geom_point()+
  labs(title="Cooks Distance Plot", x="Easiness", y="Cooks Distance")


## ---- echo=FALSE, warning=FALSE, message=FALSE, fig.width=4, fig.height=3-----
ggplot(augment(mod), aes(sample=.resid))+
  geom_qq()+
  geom_qq_line()+
  labs(title="Normal Probability Plot", x="Theoretical quantities",
       y="Observed Quantities")


## ---- include=FALSE-----------------------------------------------------------
summary(mod)
confint(mod)


## ---- include=FALSE-----------------------------------------------------------
reducedmod1 <- lm(quality~ easiness + factor(gender) + factor(pepper),
                 Rateprof)
fullmod1 <- lm(quality~ easiness + factor(gender) + factor(pepper) + 
               easiness:factor(discipline), 
              Rateprof)
reducedmod2 <- lm(quality~ easiness + factor(gender) + factor(pepper),
                 Rateprof)
fullmod2 <- lm(quality~ easiness + factor(gender) + factor(pepper) + 
                easiness:factor(gender), 
              Rateprof)
anova(reducedmod1, fullmod1)
anova(reducedmod2, fullmod2)

