## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)

# fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."


## ---- include=FALSE-----------------------------------------------------------
library(tinytex)
library(tidyverse)
library(dplyr)
library(alr4)


## -----------------------------------------------------------------------------
# Rateprof

rating <- Rateprof$quality
gender <- Rateprof$gender
attractive <- Rateprof$pepper
easy <- Rateprof$easiness
discipline <- Rateprof$discipline


## ---- include=FALSE-----------------------------------------------------------
summary(gender)
summary(attractive)
summary(easy) # between 1 to 5
summary(discipline) # Hum, SocSci, STEM, and pre-prof
summary(rating) # between 1 to 5


## ---- fig.width=5, fig.height=3, fig.cap='Distributions of Easiness and Quality Ratings.'----
# figure 1
par(mfrow=c(1,2))

hist(easy, xlab='Easiness Rating', main='Easiness', col='pink')
hist(rating, xlab='Quality Rating', main='Quality', col='pink')


## ---- fig.width=5, fig.height=4, fig.cap='Pairs plot of predictor and response variables, showing relationships between all variables.'----
# figure 2
for.pairs <- Rateprof[c('gender', 'pepper', 'easiness', 'discipline', 'quality')]
pairs(for.pairs)


## ---- fig.width=10, fig.height=5, fig.cap='Boxplots of Gender, Attractiveness, and Discipline vs Quality Rating.'----
# figure 3
par(mfrow=c(1,3))
boxplot(rating ~ gender, col='pink', main='Gender vs Quality', 
        xlab='Gender', ylab='Quality Rating')
boxplot(rating ~ attractive, col='pink', main='Attractiveness vs Quality', 
        xlab='Attractive', ylab='Quality Rating')
boxplot(rating ~ discipline, col='pink', main='Discipline vs Quality', 
        xlab='Discipline', ylab='Quality Rating')


## ---- include=FALSE-----------------------------------------------------------
linear.prof <- lm(rating ~ factor(gender) + factor(attractive) + 
                    easy + factor(discipline) + easy:factor(gender) + 
                    easy:factor(discipline), Rateprof)

summary(linear.prof)


## ---- fig.width=10, fig.height=5,fig.cap='Residual plots to test model assumptions.'----
# figure 4
par(mfrow=c(1,2))

plot(linear.prof$fitted.values, linear.prof$residuals, main='Residuals vs Fitted Values', 
     xlab='x', ylab='Residuals')


qqnorm(linear.prof$residuals, col='blue', main='Q-Q plot')
qqline(linear.prof$residuals, col='red', lwd=1)


## ---- include=FALSE-----------------------------------------------------------
reduced <- lm(rating ~ factor(gender) + factor(attractive) + 
                    easy + factor(discipline), Rateprof)

anova(reduced, linear.prof)


## ---- include=FALSE-----------------------------------------------------------
confint(linear.prof, level=0.95)

