## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE,
                      fig.pos = 'H',
                      fig.align = 'center', 
                      fig.width = 6, 
                      fig.height = 4
                      )


## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(tidyverse)
library(gridExtra)
library(modelsummary)
library(bestglm)
library(GGally)

rateProf = Rateprof


## ----  fig.cap = "Quality"----------------------------------------------------
ggplot(rateProf, aes(x = quality)) + geom_histogram(bins = 18, fill = "blue") + 
  labs(title = "Class Quality", x = "Average Quality", y = "Count")


## ----  fig.cap = "Discipline"-------------------------------------------------
ggplot(rateProf, aes(x = factor(discipline))) + geom_bar(aes(fill = factor(discipline))) + 
  labs(title = "Discipline Frequencies", x = "Discipline", y = "Count", fill = "Discipline")


## ---- fig.cap = "Gender"------------------------------------------------------
ggplot(rateProf, aes(x = factor(gender))) + geom_bar(aes(fill = factor(gender))) + 
  labs(title = "Gender Frequencies", x = "Gender", y = "Count", fill = "Gender")


## ----  fig.cap = "Easiness"---------------------------------------------------
ggplot(rateProf, aes(x = easiness)) + geom_histogram(bins = 15, fill = "yellow") + 
  labs(title = "Average Easiness of Class", x = "Average Easiness", y = "Frequency")


## ---- fig.cap = "Attractiveness"----------------------------------------------
ggplot(rateProf, aes(x = factor(pepper))) + geom_bar(aes(fill = factor(pepper))) + 
  labs(title = "Attractiveness Distribution", fill = "Attractiveness", x = "Attractiveness", y = "Count")


## ---- echo = FALSE,fig.cap = "Discipline against Quality"---------------------
ggplot(rateProf, aes(x = factor(discipline), y = quality)) + 
  labs(title = "Discipline vs Quality", fill = "Discipline", x =  "Discipline", y = "Quality") +
  geom_boxplot(aes(fill = factor(discipline))) 


## ---- fig.cap = "Gender against Quality"--------------------------------------
ggplot(rateProf, aes(x = factor(gender), y = quality)) +
  labs(title = "Gender vs Quality", x =  "Gender", y = "Quality", fill = "Gender") +
  geom_boxplot(aes(fill = factor(gender)))


## ---- fig.cap = "Easiness against Quality", fig.width = 7, fig.height = 5-----
ggplot(rateProf, aes(x = easiness, y = quality)) + 
  geom_point(color = "purple") + 
  labs(title = "Easiness vs Quality", x = "Avg Easiness", y = "Avg Quality") + 
  theme_bw()


## ---- fig.cap = "Attractiveness against Quality"------------------------------
ggplot(rateProf, aes(x = factor(pepper), y = quality)) + 
  labs(title = "Prof Attractiveness vs Quality", x =  "Attractiveness", y = "Quality") +
  geom_boxplot(aes(fill = factor(pepper)))


## -----------------------------------------------------------------------------
model = lm(quality~easiness * discipline * pepper * gender, rateProf)
steper = step(model, trace=0, direction="both")
reducedModel = lm(rateProf, formula = quality ~ easiness + pepper + gender + easiness:pepper)


## ---- fig.cap = "Redcued Model Residual Plot", fig.width = 7, fig.height = 5----
plot(reducedModel, which = 1)


## ---- fig.cap = "Redcued Model QQ Plot", fig.width = 7, fig.height = 5--------
plot(reducedModel, which = 2)


## -----------------------------------------------------------------------------
fullLM = lm(quality ~ easiness * gender * discipline, rateProf)
reducedLM = lm(quality ~ easiness, rateProf)


## ---- include = FALSE---------------------------------------------------------
anova(reducedLM, fullLM)

