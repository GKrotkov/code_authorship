## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, warning = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(ggplot2)
library(GGally) 
library(dplyr)
library(broom)
library(sjPlot)
library(sjmisc)
library(sjlabelled)
library(bestglm)
data <- Rateprof


## ---- echo=FALSE, message=FALSE, fig.cap="Numerical variable distributions", fig.show="hold", fig.height=3, fig.width=4, out.width="50%"----

hist(data$quality,
    main = "Professor Quality Rating Distribution", xlab = "rating",
    prob = TRUE, cex.main = 0.8, cex.axis = 0.8, cex.lab = 0.8)

hist(data$easiness,
    main = "Class Easiness Rating Distribution", xlab = "rating",
    prob = TRUE, cex.main = 0.8, cex.axis = 0.8, cex.lab = 0.8)

## ---- echo=FALSE, message=FALSE, fig.cap="Categorical variable distributions", fig.show="hold", fig.height=3, fig.width=4, out.width="33%"----

barplot(table(data$gender),
    main = "Professor Gender Distribution", xlab = "gender",
    cex.main = 0.8, cex.axis = 0.8, cex.lab = 0.8)

barplot(table(data$pepper),
    main = "Professor Attractiveness Distribution", xlab = "attractive",
    cex.main = 0.8, cex.axis = 0.8, cex.lab = 0.8)

barplot(table(data$discipline),
    main = "Class Discipline Distribution", xlab = "discipline",
    cex.main = 0.8, cex.axis = 0.8, cex.lab = 0.8, cex.names=0.9)



## ---- echo=FALSE, message=FALSE, fig.cap="Relationship between professor rating and class easiness", fig.height=3.75, fig.width=5, fig.align="center"----
plot(data$easiness, data$quality, main="Professor Rating vs. Class Easiness", xlab="class easiness", ylab="professor rating", pch=19, cex.main=0.8, cex.lab=0.8)


## ---- echo=FALSE, message=FALSE, fig.cap="Response variable distributions", fig.show="hold", fig.height=4, fig.width=5, out.width="33%"----
boxplot(data$quality ~ data$gender, main="Professor Rating vs. Professor Gender", xlab="gender", ylab="professor rating")
boxplot(data$quality ~ data$pepper, main="Professor Rating vs. Professor Attractiveness", xlab="attractiveness", ylab="professor rating")
boxplot(data$quality ~ data$discipline, main="Professor Rating vs. Class Discipline", xlab="discipline", ylab="professor rating")


## ---- echo=FALSE, message=FALSE, fig.cap="Class easiness distributions", fig.show="hold", fig.height=4, fig.width=5, out.width="33%"----
boxplot(data$easiness ~ data$gender, main="Class Easiness vs. Professor Gender", xlab="gender", ylab="easiness")
boxplot(data$easiness ~ data$pepper, main="Class Easiness vs. Professor Attractiveness", xlab="attractiveness", ylab="easiness")
boxplot(data$easiness ~ data$discipline, main="Class Easiness vs. Class Discipline", xlab="discipline", ylab="easiness")


## ---- echo=FALSE, include=FALSE-----------------------------------------------
fit1 <- lm(quality ~ easiness + pepper + easiness:pepper + easiness:gender + easiness:discipline, data)
summary(fit1)

beta0 <- coef(fit1)["(Intercept)"]
beta0_ci <- confint(fit1, "(Intercept)", level = 0.95)
beta1 <- coef(fit1)["easiness"]
beta1_ci <- confint(fit1, "easiness", level = 0.95)
beta2 <- coef(fit1)["pepperyes"]
beta2_ci <- confint(fit1, "perpperyes", level = 0.95)
beta3 <- coef(fit1)["easiness:pepperyes"]
beta3_ci <- confint(fit1, "easiness:pepperyes", level = 0.95)
beta4 <- coef(fit1)["easiness:gendermale"]
beta4_ci <- confint(fit1, "easiness:gendermale", level = 0.95)
beta5<- coef(fit1)["easiness:disciplineSocSci"]
beta5_ci <- confint(fit1, "easiness:disciplineSocSci", level = 0.95)
beta6 <- coef(fit1)["easiness:disciplineSTEM"]
beta6_ci <- confint(fit1, "easiness:disciplineSTEM", level = 0.95)
beta7 <- coef(fit1)["easiness:disciplinePre-prof"]
beta7_ci <- confint(fit1, "easiness:disciplinePre-prof", level = 0.95)


fit1_red <- lm(quality ~ easiness + pepper + easiness:pepper + easiness:gender, data)

test <- anova(fit1_red, fit1)
test



## ---- echo = FALSE, fig.show="hold", fig.height=3.5, fig.width=5, out.width="50%"----
plot(data$pepper, resid(fit1), ylab = "Residuals", xlab = "Instructor attractiveness", main="Residual Plot")

plot(data$gender, resid(fit1), ylab = "Residuals", xlab = "Instructor gender", main="Residual Plot")


## ---- echo = FALSE, fig.align="center", fig.height=3.7, fig.width=5, out.width="50%"----
plot(data$easiness, resid(fit1), ylab = "Residuals", xlab = "Class easiness", main="Residual Plot")


## ---- echo = FALSE, fig.align="center", fig.height=4, fig.width=5, out.width="50%"----
plot(augment(fit1)$.fitted, augment(fit1)$.resid, ylab="Residual", xlab="Fitted value", main="Residual Plot")


## ---- echo = FALSE, fig.align="center", fig.height=4, fig.width=5, out.width="50%"----
qqnorm(residuals(fit1), cex.axis = 0.8, cex.lab = 0.8)
qqline(residuals(fit1))


## ---- echo = FALSE, fig.show="hold", fig.height=3.5, fig.width=4, out.width="33%"----

augment(fit1) |>
ggplot(aes(x = easiness, y = .cooksd)) +
geom_point() +
labs(x = "Class easiness", y = "Cook's distance")

augment(fit1) |>
ggplot(aes(x = gender, y = .cooksd)) +
geom_point() +
labs(x = "Professor gender", y = "Cook's distance")

augment(fit1) |>
ggplot(aes(x = pepper, y = .cooksd)) +
geom_point() +
labs(x = "Professor attractivenes", y = "Cook's distance")


## ----echo = FALSE, message=FALSE, include=FALSE-------------------------------
best_fit <- lm(quality ~ easiness + pepper + gender, data)
summary(best_fit)

bestmod <- bestglm(data[, c(1,5,6,11,8)], IC = "AIC")
bestmod

tab_model(best_fit, terms=c("(Intercept)", "easiness", "pepperyes", "gendermale"), pred.labels=c("Intercept (alpha0)", "easiness (alpha1)", "pepper=yes (alpha2)", "gender=male (alpha3)"))
tab_model(fit1, terms=c("(Intercept)", "easiness", "pepperyes", "easiness:pepperyes"), pred.labels=c("Intercept (beta0)", "easiness (beta1)", "pepper=yes (beta2)", "easiness:pepper=yes (beta3)"))

