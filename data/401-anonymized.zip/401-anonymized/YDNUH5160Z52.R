## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
sleep <- read.csv("cmu-sleep.csv")
library(tidyverse)
library(ggplot2)
library(patchwork)
library(broom)
library(ggpubr)


## ---- include = FALSE---------------------------------------------------------
summary(sleep$TotalSleepTime)
summary(sleep$term_gpa)
summary(sleep$cum_gpa)


## ---- fig.width=6, fig.height=3, fig.cap="Histogram displaying Distributions of explanatory variables", message=FALSE----
sleep_hist <- ggplot(sleep, aes(x = TotalSleepTime)) +
  geom_histogram(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Sleep Time",
    x = "Sleep Time (in minutes)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

termgpa_hist <- ggplot(sleep, aes(x = term_gpa)) +
  geom_histogram(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Current GPA",
    x = "GPA (out of 4.0)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

cumgpa_hist <- ggplot(sleep, aes(x = cum_gpa)) +
  geom_histogram(color = "darkblue", fill = "lightblue") +
  labs(
    title = "Distribution of Cumulative GPA",
    x = "GPA (out of 4.0)",
    y = "Count"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

sleep_hist | termgpa_hist | cumgpa_hist


## ---- include = FALSE---------------------------------------------------------
sleep <- sleep %>%
  mutate(
    exp_termGPA = exp(term_gpa),
    exp_cumGPA = exp(cum_gpa)
  )


## ---- fig.width=6, fig.height=3, fig.cap="Scatterplot displaying relationship between predictor and response variables", message=FALSE----
scatplot1 <- ggplot(sleep, aes(x = TotalSleepTime, y = exp_termGPA)) +
  geom_point() +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(
    title = "Exponentiated TermGPA vs. Average Sleep Time",
    x = "Average Sleep Time",
    y = "Exponentiated Term GPA"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

scatplot2 <- ggplot(sleep, aes(x = exp_cumGPA, y = exp_termGPA)) +
  geom_point() +
  geom_smooth(method = lm, se = FALSE, color = "red") +
  labs(
    title = "Exponentiated TermGPA vs. Exponentiated CumGPA",
    x = "Exponentiated Cumulative GPA",
    y = "Exponentiated Term GPA"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

scatplot1 | scatplot2


## ---- include = FALSE---------------------------------------------------------
lm_fit <- lm(exp_termGPA ~ TotalSleepTime + exp_cumGPA, data = sleep)
summary(lm_fit)

residuals <- resid(lm_fit)
squared_residuals <- residuals^2
fitted <- fitted(lm_fit)

resid_data <- data.frame(
  Residuals = residuals,
  Squared_Residuals = squared_residuals,
  Fitted = fitted
)


## ---- fig.width=4, fig.height=3, fig.cap="Residuals plot for the fitted model"----
ggplot(resid_data, aes(x = Fitted, y = Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(
    title = "Residual Plot for Multivariate Linear Model",
    x = "Fitted Values", y = "Residuals"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )


## ---- fig.width=4, fig.height=3, fig.cap="Squared residuals plot for the fitted model"----
ggplot(resid_data, aes(x = Fitted, y = Squared_Residuals)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(
    title = "Squared Residual Plot for Multivariate Linear Model",
    x = "Fitted Values", y = "Squared Residuals"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )


## ---- fig.width=4, fig.height=3, fig.cap="Normal Q-Q plot for the fitted model"----
ggplot(
  augment(lm_fit),
  aes(sample = .resid)
) +
  geom_qq() +
  geom_qq_line(color = "red") +
  labs(
    title = "Normal Q-Q Plot for Multivariate Linear Model",
    x = "Theoretical quantiles", y = "Sample quantiles"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(size = 8),
    axis.title = element_text(size = 8)
  )

