## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
data = read.csv("cmu-sleep.csv")
summary(data$TotalSleepTime)
sd(data$TotalSleepTime)
summary(data$term_gpa)
sd(data$term_gpa)
summary(data$term_gpa - data$cum_gpa)
sd(data$term_gpa - data$cum_gpa)


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of TotalSleepTime (avg min/night)."----
hist(data$TotalSleepTime, main = "Histogram of TotalSleepTime", xlab = "TotalSleepTime (avg min/night)", breaks = 20)


## ---- fig.width=3, fig.height=3, fig.cap="Boxplot of TotalSleepTime (avg min/night)."----
boxplot(data$TotalSleepTime, main = "Total Sleep Time Boxplot")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of term_gpa."-------------
hist(data$term_gpa, main = "Histogram of term_gpa", xlab = "Term GPA (out of 4.0)", breaks = 20)


## ---- fig.width=3, fig.height=3, fig.cap="Boxplot of term_gpa."---------------
boxplot(data$term_gpa, main = "Term GPA Boxplot")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of gpa change."-----------
hist(data$term_gpa - data$cum_gpa, main = "Histogram of gpa change", xlab = "term GPA - cum GPA ", breaks = 20)


## ---- fig.width=3, fig.height=3, fig.cap="Boxplot of gpa change."-------------
boxplot(data$term_gpa - data$cum_gpa, main = "GPA Change Boxplot")


## ---- fig.width=4, fig.height=3, fig.cap="term gpa vs. total sleep time."-----
plot(term_gpa ~ TotalSleepTime, data = data,
     xlab = "Total Sleep Time (min/night)", ylab = "Term GPA (out of 4.0)")


## ---- echo=FALSE, include=FALSE-----------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime, data = data)
summary(model)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
squared_model <- lm((term_gpa)^2 ~ TotalSleepTime, data = data)
summary(squared_model)

exp_model <- lm(exp(term_gpa) ~ TotalSleepTime, data = data)
summary(exp_model)

threshold <- 1.5
residuals <- residuals(model)
outliers <- abs(residuals) > threshold
data_no_outliers <- data[!outliers, ]
model_no_outliers <- lm(term_gpa ~ TotalSleepTime, data = data_no_outliers)
summary(model_no_outliers)
dim(data)
dim(data_no_outliers)


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot with Regression Line."----
plot(data$TotalSleepTime, data$term_gpa, font.main = 2, main = "Scatterplot with term_gpa vs. TotalSleepTime", xlab = "TotalSleepTime", ylab = "term_gpa")
abline(model, col = "red") 

## ---- echo=FALSE, include=FALSE-----------------------------------------------
squared_residuals <- residuals(squared_model)
plot(data$TotalSleepTime, squared_residuals, main = "Residuals vs. TotalSleepTime", xlab = "TotalSleepTime", ylab = "Residuals")

exp_residuals <- residuals(exp_model)
plot(data$TotalSleepTime, exp_residuals, font.main = 2, main = "Residuals of Exp Transformed Data", xlab = "TotalSleepTime", ylab = "Residuals of exp(term_gpa)")

residuals_no_outliers <- residuals(model_no_outliers)
plot(data_no_outliers$TotalSleepTime, residuals_no_outliers, main = "Residuals vs. TotalSleepTime", xlab = "TotalSleepTime", ylab = "Residuals")




## ---- fig.width=4, fig.height=3, fig.cap="Residuals vs. TotalSleepTime."------
residuals <- residuals(model)
plot(data$TotalSleepTime, residuals, main = "Residuals vs. TotalSleepTime", xlab = "TotalSleepTime", ylab = "Residuals")


## ---- echo=FALSE, include=FALSE-----------------------------------------------
squared_fitted_values <- predict(squared_model)
plot(squared_fitted_values, squared_residuals, main = "Residuals vs. Fitted Values For Squared Transformed Data", xlab = "Fitted Values", ylab = "Residuals")

exp_fitted_values <- predict(exp_model)
plot(exp_fitted_values, exp_residuals, font.main = 2, main = "Residuals vs. Fitted Values (Exp Transformed)", xlab = "Fitted Values", ylab = "Residuals")


## ---- fig.width=4, fig.height=3, fig.cap="Residuals vs. Fitted Values."-------
fitted_values <- predict(model)
plot(fitted_values, residuals, main = "Residuals vs. Fitted Values", xlab = "Fitted Values", ylab = "Residuals")


## ---- echo=FALSE, include=FALSE-----------------------------------------------
qqnorm(squared_residuals)
qqline(squared_residuals)

qqnorm(exp_residuals)
qqline(exp_residuals)


## ---- fig.width=4, fig.height=3, fig.cap="QQ Plot."---------------------------
qqnorm(residuals)
qqline(residuals)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
conf_interval <- confint(model, "TotalSleepTime")
conf_interval


## ---- echo=FALSE, include=FALSE-----------------------------------------------
multi_model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = data)
summary(multi_model)


## ---- echo=FALSE, include=FALSE-----------------------------------------------
model_change_in_GPA <- lm(term_gpa - cum_gpa ~ TotalSleepTime, data = data)
summary(model_change_in_GPA)

