## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)



library(alr4)
library(GGally)
library(dplyr)
library(ggplot2)




## ---- include=FALSE-----------------------------------------------------------
data(Rateprof)




## ----fig.width=3.5, fig.height=2.5--------------------------------------------
suppressWarnings({library(patchwork)})

qualityHist <- ggplot(Rateprof, aes(x = quality)) + geom_histogram(binwidth = 0.2, color = "black", fill = "blue") + labs(x = "Average quality Rating", y = "Count", title = "Quality histogram")

qualityLogHist <- ggplot(Rateprof, aes(x = log(quality))) + geom_histogram(binwidth = 0.2, color = "black", fill = "blue") + labs(x = "Average quality Log Rating", y = "Count", title = "Quality Log histogram")

easinessHist <- ggplot(Rateprof, aes(x = easiness)) + geom_histogram(binwidth = 0.2, color = "black", fill = "blue") + labs(x = "Average Easiness Rating", y = "Count", title = "Easiness histogram")


qualityHist 
easinessHist
qualityLogHist



## ----fig.width=3.5, fig.height=2.5--------------------------------------------
library(patchwork)



genderBar <- ggplot(Rateprof, aes(x = gender)) + geom_bar(color = "black", fill = "blue") + labs(x = "Gender", y = "Count", title = "Gender Bar graph")

DisciplineBar <- ggplot(Rateprof, aes(x = discipline)) + geom_bar(color = "black", fill = "blue") + labs(x = "Discipline", y = "Count", title = "Discipline Bar graph")

pepperBar <- ggplot(Rateprof, aes(x = pepper)) + geom_bar(color = "black", fill = "blue") + labs(x = "Pepper", y = "Count", title = "Pepper Bar graph")


DisciplineBar 
genderBar
pepperBar




## ----fig.width=3.5, fig.height=2.5--------------------------------------------

eqGender <- ggplot(Rateprof,
       aes(x = easiness, y = quality, color = gender))+
  geom_point() + 
  labs(x = "Average Easiness Rating", y = "Average quality Rating", color = "Gender")



eqGender 

eqDiscipline <- ggplot(Rateprof,
       aes(x = easiness, y = quality, color = discipline))+
  geom_point() + 
  labs(x = "Average Easiness Rating", y = "Average quality Rating", color = "Discipline")



eqDiscipline




## ----fig.width=3.5, fig.height=2.5--------------------------------------------

gq <- ggplot(Rateprof,
       aes(x = gender, y = quality)) + 
  geom_boxplot() + 
  labs(x = "Gender", y = "Average Quality Rating")

dq <- ggplot(Rateprof,
       aes(x = discipline, y = quality)) + 
  geom_boxplot() + 
  labs(x = "discipline", y = "Average Quality Rating")

pq <- ggplot(Rateprof,
       aes(x = pepper, y = quality)) + 
  geom_boxplot() + 
  labs(x = "pepper", y = "Average Quality Rating")

gq
dq
pq




## ----fig.width=5, fig.height=4------------------------------------------------




Rateprof |>
  select(quality,helpfulness, clarity, easiness,raterInterest) |>
  ggpairs()




## ----fig.width=4, fig.height=3, include=FALSE---------------------------------
finalMod <- lm(quality ~ pepper + easiness + gender, data = Rateprof)


finalMod2 <- lm(quality ~ gender + easiness * pepper, data = Rateprof)


finalMod3 <- lm(quality ~ pepper + easiness * gender, data = Rateprof)

finalMod4 <- lm(quality ~ easiness * discipline, data = Rateprof)

finalMod5 <- lm(quality ~ easiness * gender, data = Rateprof)




## ----fig.width=5, fig.height=4------------------------------------------------
plot(finalMod,which = 2)



## ----fig.width=5, fig.height=4------------------------------------------------
plot(finalMod2,which = 2)



## ----fig.width=5, fig.height=4------------------------------------------------
plot(finalMod3,which = 2)



## ---- include = FALSE---------------------------------------------------------
library(bestglm)

Rateprof$gender <- factor(Rateprof$gender)
Rateprof$pepper <- factor(Rateprof$pepper)
Rateprof$discipline <- factor(Rateprof$discipline)

bestmod <- bestglm(Rateprof[,c(11,6,5,1,8)],IC = "AIC")

bestmod



## ---- include = FALSE---------------------------------------------------------

anova(finalMod,finalMod2,finalMod3)
summary(finalMod2)
confint(finalMod2)



