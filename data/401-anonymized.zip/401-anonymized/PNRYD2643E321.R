## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(ggplot2)
library(broom)
library(GGally)
library(dplyr)
sleep_data <- read.csv('cmu-sleep.csv')
sleep_data$TotalSleepTimeShrunk <- sleep_data$TotalSleepTime/60
part_time <- subset(sleep_data, term_units < 36)
full_time <- subset(sleep_data, term_units >= 36)
overall_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, sleep_data)
cumulative_gpa_and_sleep_lm <- lm(term_gpa ~ cum_gpa + TotalSleepTimeShrunk, sleep_data)
square_lm <- lm(term_gpa**2 ~ TotalSleepTimeShrunk, sleep_data)


## ---- message = FALSE, fig.width=3.5, fig.height=3, fig.cap="A plot of students' cumulative GPAs. Note the left skew."----
ggplot(sleep_data,aes(x=cum_gpa))+geom_histogram()+labs(x="Cumulative GPA on a 4.0-Point Scale (points)")


## ---- message = FALSE, fig.width=3.5, fig.height=3, fig.cap="A plot of students' end-of-semester GPAs. Note the left skew."----
ggplot(sleep_data,aes(x=term_gpa))+geom_histogram()+labs(x="Term GPA on a 4.0-Point Scale (points)")


## ---- message = FALSE, fig.width=3.5, fig.height=3, fig.cap="Plots of cumulative vs. term GPA. Note the positive association trend."----
ggplot(sleep_data,aes(x=cum_gpa,y=term_gpa)) + geom_point() + labs(x="Cumulative GPA on a 4.0-Point Scale (points)",y="Term GPA on a 4.0-Point Scale (points)")


## ---- message = FALSE, fig.width=3.5, fig.height=3.5, fig.cap="A plot of students' average time slept per night. Note the data's symmetry."----
ggplot(sleep_data,aes(x=TotalSleepTimeShrunk))+geom_histogram()+labs(x="Average Time Slept Per Night (hours)")


## ---- message = FALSE, fig.width=3.5, fig.height=3.5, fig.cap="A plot of students' time slept vs. term GPAs. Note the positive association trend."----
ggplot(sleep_data,aes(x=TotalSleepTimeShrunk,y=term_gpa)) + geom_point()+labs(x="Average Time Slept Per Night (hours)",y="Term GPA on a 4.0-Point Scale (points)")


## ---- message = FALSE, fig.width=3.5, fig.height=3.5, fig.cap="A plot of students' time slept vs. term GPAs squared. Note the clearer positive association trend (compared to when term GPA was not squared."----
ggplot(sleep_data,aes(x=TotalSleepTimeShrunk,y=term_gpa**2)) + geom_point()+labs(x="Average Time Slept Per Night (hours)",y="Term GPA Squared (points squared)")


## ---- message = FALSE, warning = FALSE, fig.width=3.5, fig.height=3.5, fig.cap="A plot of the number of units taken by students over the semester of interest. Note the large gap between full-time and part-time students, where 36 units seems to be a good dividing criterion."----
ggplot(sleep_data,aes(x=term_units))+geom_bar()+labs(x="Number of Units Taken (units)")


## ---- message = FALSE, fig.width=3.7, fig.height=3.5, fig.cap="A plot of trends indicating part-time students' sleep and GPA trends. There are not too many students with lower GPAs."----
ggplot(part_time,aes(x=TotalSleepTimeShrunk,y=term_gpa)) + geom_point() + labs(x="Part-Time Students' Avg Nightly Time Slept (hrs)", y="Term GPA for Part-Time Students (points)")


## ---- message = FALSE, fig.width=3.7, fig.height=3.5, fig.cap="A plot of trends indicating full-time students' sleep and GPA trends. There seem to be more students (than part-time) with lower GPAs, but the overall positive association between sleep and GPA still seems to be present."----
ggplot(full_time,aes(x=TotalSleepTimeShrunk,y=term_gpa)) + geom_point() + labs(x="Full-Time Students' Avg Nightly Time Slept (hrs)", y="Term GPA for Full-Time Students (points)")


## ---- message = FALSE, fig.width=3.7, fig.height=3.5, fig.cap="Residuals from predicting GPA from sleep schedules. Notice that the range of residuals seems to become narrower as sleep increases."----
ggplot(augment(overall_lm),aes(x=TotalSleepTimeShrunk,y=.resid)) + geom_point() + labs(x="Students' Avg Nightly Time Slept (hours)", y="Residual from GPA Predictions")


## ---- message = FALSE, fig.width=3.7, fig.height=3.5, fig.cap="QQ-Plots Comparing Residual Trends for Term GPA. Note the bound on residuals as the theoretical quantiles get large."----
ggplot(augment(overall_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()+labs(x="Theoretical Quantiles", y="Sample Quantiles")


## ---- message = FALSE, fig.width=3.7, fig.height=3.5, fig.cap="QQ-Plots Comparing Residual Trends for Term GPA Squared. Note that even for the squared model, there is a bound on residuals as theoretical quantiles get large, and the shape of the residuals is not as linear as we'd hope for."----
ggplot(augment(square_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()+labs(x="Theoretical Quantiles", y="Sample Quantiles")


## ---- include = FALSE---------------------------------------------------------
# Here is the rest of the code used throughout the project (in a separate R file) but not used in the final analysis. 
# Some sources were used for basic syntax, and their links have been provided. 
# I also used the class lecture notes for syntax (augment, etc.).
# removing warnings in RMarkdown: https://stackoverflow.com/questions/23189012/how-do-i-suppress-the-warning-from-including-a-library-when-using-knitr-in-r
# package install error: https://stackoverflow.com/questions/46773476/error-in-libraryggplot2-there-is-no-package-called-ggplot2
# https://ggplot2.tidyverse.org/
# install.packages("ggplot2", repos="http://cran.us.r-project.org") 
# install.packages("GGally", repos="http://cran.us.r-project.org") 
# install.packages("dplyr", repos="http://cran.us.r-project.org") 
# library(ggplot2)
# library(broom)
#library(GGally)
# library(dplyr)
# sleep_data <- read.csv('cmu-sleep.csv')
# head(sleep_data)
# head(subset(sleep_data, term_units >= 20 & term_units <= 36)) # prints 0
# # syntax for getting summary statistics: https://statisticsglobe.com/summary-statistics-data-frame-r
# summary(sleep_data)
# ggplot(sleep_data,aes(x=demo_race))+geom_bar()
# ggplot(sleep_data,aes(x=demo_gender))+geom_bar()
# ggplot(sleep_data,aes(x=demo_firstgen))+geom_bar()
# ggplot(sleep_data,aes(x=bedtime_mssd))+geom_histogram()
# ggplot(sleep_data,aes(x=TotalSleepTime))+geom_histogram()
# ggplot(sleep_data,aes(x=midpoint_sleep))+geom_histogram()
# ggplot(sleep_data,aes(x=frac_nights_with_data))+geom_histogram()
# ggplot(sleep_data,aes(x=daytime_sleep))+geom_histogram()
# ggplot(sleep_data,aes(x=cum_gpa))+geom_histogram()
# ggplot(sleep_data,aes(x=term_gpa))+geom_histogram()
# ggplot(sleep_data,aes(x=term_units))+geom_histogram()
# ggplot(sleep_data,aes(x=Zterm_units_ZofZ))+geom_histogram()
# ggplot(sleep_data,aes(x=TotalSleepTime,y=term_gpa)) + geom_point()
# ggplot(sleep_data,aes(x=TotalSleepTime,y=term_gpa)) + geom_point()
# some transformations on interesting plots
# ggplot(sleep_data,aes(x=term_gpa**2))+geom_histogram()
# ggplot(sleep_data,aes(x=TotalSleepTime,y=term_gpa**2)) + geom_point()
# adding columns https://www.statology.org/r-add-a-column-to-dataframe/
# sleep_data$TotalSleepTimeShrunk <- sleep_data$TotalSleepTime/60 # 
# ggplot(sleep_data,aes(x=TotalSleepTimeShrunk,y=term_gpa)) + geom_point() # plot looks the same
# data subsetting https://ggplot2-book.org/facet.html
# part_time <- subset(sleep_data, term_units < 36)
# full_time <- subset(sleep_data, term_units >= 36)
# ggplot(part_time,aes(x=TotalSleepTime,y=term_gpa)) + geom_point() + labs(x="part time sleep", y="part time gpa")+geom_smooth(method="lm")
# ggplot(full_time,aes(x=TotalSleepTime,y=term_gpa)) + geom_point() + labs(x="full time sleep", y="full time gpa")+geom_smooth(method="lm")
# possibly some differences
# gender_0 <- subset(sleep_data, demo_gender==0)
# gender_1 <- subset(sleep_data, demo_gender==1)
# ggplot(gender_0,aes(x=TotalSleepTime,y=term_gpa)) + geom_point() + labs(x="gender_0 sleep", y="gender_0 gpa")+geom_smooth(method="lm")
# ggplot(gender_1,aes(x=TotalSleepTime,y=term_gpa)) + geom_point() + labs(x="gender_1 sleep", y="gender_1 gpa")+geom_smooth(method="lm")
# race_0 <- subset(sleep_data, demo_race==0)
# race_1 <- subset(sleep_data, demo_race==1)
# ggplot(race_0,aes(x=TotalSleepTime,y=term_gpa)) + geom_point() + labs(x="race_0 sleep", y="race_0 gpa")+geom_smooth(method="lm")
# ggplot(race_1,aes(x=TotalSleepTime,y=term_gpa)) + geom_point() + labs(x="race_1 sleep", y="race_1 gpa")+geom_smooth(method="lm")
# sd syntax https://www.digitalocean.com/community/tutorials/find-standard-deviation-in-r
# sd(sleep_data$term_gpa)
# ggplot(sleep_data,aes(x=(term_gpa-3.450)/0.5004669))+geom_histogram()  # didn't really help

# Fitting models
# overall_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, sleep_data)

# average_sleep <- mean(sleep_data$TotalSleepTimeShrunk) # 6.622065
# stdev_sleep <- sd(sleep_data$TotalSleepTimeShrunk) # 0.8476121
# average_sleep 
# stdev_sleep 
# average_sleep - 2 * stdev_sleep # 4.92684 
# average_sleep + 2 * stdev_sleep # 8.317289

# part_time_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, part_time)
# full_time_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, full_time)
# gender_0_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, gender_0)
# gender_1_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, gender_1)
# race_0_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, race_0)
# race_1_lm <- lm(term_gpa ~ TotalSleepTimeShrunk, race_1)
# summary(overall_lm)
# summary(part_time_lm)
# summary(full_time_lm)
# summary(gender_0_lm)
# summary(gender_1_lm)
# summary(race_0_lm)
# summary(race_1_lm)
# 95% CI for overall_lm for B_1
# 0.1191 - qt(0.975,632)*0.0230
# 0.1191 + qt(0.975,632)*0.0230
# 95% CI for overall_lm for 2*B_1
# 2*(0.1191 - qt(0.975,632)*0.0230) 
# 2*(0.1191 + qt(0.975,632)*0.0230)
# there seems to be evidence convincing us that slope is nonzero
# it seems so small, but if you think about it, range of GPA is so small too
# mean(sleep_data$term_gpa) # 3.449598
# sd(sleep_data$term_gpa) # 0.5004669
# can we count what percent of our data is between what intervals?
# plot residuals
# cooks.distance(overall_lm)
# which.max(cooks.distance(overall_lm))
# track CI across different factors -- full/part time, race, gender
# repeat models for square terms
# square_lm <- lm(term_gpa**2 ~ TotalSleepTimeShrunk, sleep_data)
# summary(square_lm) # R^2 = 0.03 --> even less
# 95% CI for square_lm for slope of sleep
# 0.6934 - qt(0.975,632)*0.1408
# 0.6934 + qt(0.975,632)*0.1408
# cooks.distance(square_lm)
# which.max(cooks.distance(square_lm))
# make residual plots
# ggplot(augment(square_lm),aes(x=TotalSleepTimeShrunk,y=.resid)) + geom_point() + labs(x="sleep time shrunk", y="gpa squared residual")+geom_smooth(method="lm")
# ggplot(augment(overall_lm),aes(x=TotalSleepTimeShrunk,y=.resid)) + geom_point() + labs(x="sleep time shrunk", y="gpa residual")+geom_smooth(method="lm")
# ggplot(augment(overall_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line() 
# ggplot(augment(square_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(part_time_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(full_time_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(gender_0_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(gender_1_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(race_0_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(race_1_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# ggplot(augment(overall_lm),aes(x=.fitted,y=.resid))+geom_point() # fitted value vs. residual --> higher gpa = smaller residual since capped until 4.0 GPA
# just using cumulative gpa as a predictor
# ggplot(sleep_data,aes(x=cum_gpa,y=term_gpa)) + geom_point() + labs(x="cumulative gpa",y="term gpa")+geom_smooth(method="lm")
# cum_term_gpa_lm <- lm(term_gpa ~ cum_gpa, sleep_data)
# summary(cum_term_gpa_lm) # R^2 = 0.4071
# ggplot(augment(cum_term_gpa_lm),aes(sample=.resid)) + geom_qq() + geom_qq_line()
# multiple regression with cumulative gpa and sleep
# cumulative_gpa_and_sleep_lm <- lm(term_gpa ~ cum_gpa + TotalSleepTimeShrunk, sleep_data)
# summary(cumulative_gpa_and_sleep_lm) # R^2 = 0.4245
# 95% CI for cumulative_gpa_and_sleep_lm for slope of sleep
# 0.07845 - qt(0.975,631)*0.01794
# 0.07845 + qt(0.975,631)*0.01794
# 95% CI for cumulative_gpa_and_sleep_lm for slope of cum_gpa
# 0.71296 - qt(0.975,631)*0.03475
# 0.71296 + qt(0.975,631)*0.03475

# ggplot(augment(cumulative_gpa_and_sleep_lm),aes(sample=.resid))+geom_qq()+geom_qq_line()
# multiple regression with all of the variables
# multiple_lm <- lm(term_gpa ~ cum_gpa + TotalSleepTimeShrunk + term_units, sleep_data) # demo_gender + demo_race + demo_firstgen + bedtime_mssd + midpoint_sleep
# summary(multiple_lm) # R^2 = 0.4034
# ggplot(augment(multiple_lm),aes(sample=.resid))+geom_qq()+geom_qq_line()
# associations 
# sleep_data |> select(term_gpa, cum_gpa, demo_race, demo_gender, demo_firstgen, bedtime_mssd, TotalSleepTimeShrunk, midpoint_sleep, frac_nights_with_data, daytime_sleep, term_units) |> ggpairs()

