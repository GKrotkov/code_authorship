## ---- fig.width=8, fig.height=3, fig.cap="Histograms for change in GPA and total sleep time, which both resemble a normal distribution", echo=FALSE----
data = read.csv("cmu-sleep.csv")
par(mfrow=c(1, 2))
change_gpa = data$term_gpa - data$cum_gpa
data$change_gpa = change_gpa
hist(data$change_gpa, breaks=20, main="Histogram of Change in GPA", xlab = "Change in GPA", ylab = "Frequency")
hist(data$TotalSleepTime, breaks=20, main="Histogram of Total Sleep Time", xlab = "Total Sleep Time (in minutes)", ylab = "Frequency")


## ---- fig.width=4, fig.cap="At a glance, there appears to be little relationship between total sleep time and change in GPA", echo=FALSE----
knitr::include_graphics("C:/Users/janic/Desktop/Janice/CMU/Senior/401/Data Exam 1/sleep time vs. change in GPA.png")


## ---- echo=FALSE, fig.height=3, fig.width=6, fig.cap="Histogram of residuals for change in GPA, which also resemble a normal distribution"----
model = lm(change_gpa ~ TotalSleepTime, data = data)
model_summary = summary(model)
fitted.values = predict(model)
residuals = data$change_gpa - fitted.values
hist(residuals, xlab = "Residuals for Actual change in GPA and the Predicted change in GPA", main="")


## ---- echo=FALSE, fig.height=3.5, fig.cap="There is no relationship between fitted values and residuals for change in GPA"----
residuals = data$change_gpa - fitted.values
plot(fitted.values, residuals, xlab = "Fitted values for Change in GPA According to Fitted Model", ylab = "Residuals")


## ---- echo=FALSE--------------------------------------------------------------
confidence = confint(model,level=.95)

## ---- echo=FALSE--------------------------------------------------------------
mean_TotalSleep <- mean(data$TotalSleepTime) - 120
new.data <- data.frame(TotalSleepTime = mean_TotalSleep)
predicted <- predict(model, newdata = new.data, interval="prediction", level=.95)

