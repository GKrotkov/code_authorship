## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(ggplot2)
library(dplyr)
library(alr4)
library(purrr)
library(knitr)
library(GGally)
getwd()
data <- data.frame(Rateprof)


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(data, aes(x = gender)) + geom_bar() + 
  ggtitle('Plot of Gender')


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(data, aes(x = pepper)) + geom_bar() + xlab("Attractiveness Vote Consensus") +
  ggtitle('Plot of Attractiveness')


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$easiness, breaks = 20, main = 'Histogram of Average Easiness', xlab='Average easiness rating (1 = worst to 5 = best)')


## ---- fig.width=4, fig.height=3-----------------------------------------------
qqnorm(data$easiness, main = 'Normal Q-Q Plot of Average Easiness')


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(data, aes(x = discipline)) + geom_bar() + xlab("Discipline") +
  ggtitle('Plot of Discipline')


## ---- fig.width=4, fig.height=3-----------------------------------------------
hist(data$quality, breaks = 25, main = 'Histogram of Average Quality', xlab='Average Quality (1 = worst to 5 = best)')


## ---- fig.width=4, fig.height=3-----------------------------------------------
qqnorm(data$quality, main = 'Normal Q-Q Plot of Average Quality')


## ---- fig.width=4, fig.height=3-----------------------------------------------
plot(x=data$easiness,y=data$quality,
     main= "Course Easiness v.s. Average Quality", xlab = "Average Easieness rating (1 = worst to 5 = best)",
     ylab="Average Quality")
abline(lm(data$quality~data$easiness))


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(data, aes(x = gender, y = quality)) + geom_boxplot() + 
  xlab('Gender') + 
  ggtitle('Box Plot of Quality by Gender')


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(data, aes(x = pepper, y = quality)) + geom_boxplot() + 
  xlab('Attractiveness Consensus') + 
  ggtitle('Box Plot of Quality by Attractiveness')


## ---- fig.width=4, fig.height=3-----------------------------------------------
ggplot(data, aes(x = discipline, y = quality)) + geom_boxplot() + 
  xlab('Discipline') + 
  ggtitle('Box Plot of Quality by Discipline')


## ---- results = FALSE---------------------------------------------------------
bias_model <- lm(quality~gender+pepper+easiness+discipline,data=data)
summary(bias_model)
extractAIC(bias_model)


## ---- results = FALSE---------------------------------------------------------
step <- step(bias_model, direction = "both", trace = 0)
summary(step)
extractAIC(step)


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of Residuals Vs. Fitted Values"----
plot(step, which = 1,)


## ---- fig.width=4, fig.height=3, fig.cap="Normal Quantile-Quantile Plot"------
plot(step, which = 2,)


## ---- results = FALSE---------------------------------------------------------
full_model <- lm(quality~gender+easiness+easiness:gender+easiness:discipline,data=data)
red_model<- lm(quality~gender+easiness,data=data)
summary(full_model)
anova(red_model, full_model)

