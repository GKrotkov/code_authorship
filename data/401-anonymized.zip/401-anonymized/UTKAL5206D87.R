## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=2.5, fig.cap="Distribution of Average Total Sleep Time (Measured in Minutes)", message=FALSE----
library(readr)
library(ggplot2)

sleep_data = read_csv("cmu-sleep.csv")
ggplot(sleep_data, aes(x = TotalSleepTime)) +
  geom_histogram(fill="purple", color="black") +
  labs(x = "Average Time Slept (In Minutes)", 
       y = "Frequency")



## ---- fig.width=4, fig.height=2.5, fig.cap="Distribution of Term GPAs. (Out of 4.0)", message=FALSE----
ggplot(sleep_data, aes(x = term_gpa)) +
  geom_histogram(fill="limegreen", color="black") +
  labs(x = "Term GPA (Out of 4.0)", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Distribution of Cumulative GPAs. (Out of 4.0)", message=FALSE----
ggplot(sleep_data, aes(x = cum_gpa)) +
  geom_histogram(fill="lightblue", color="black") +
  labs(x = "Cumulative GPA (Out of 4.0)", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Distribution of GPA Changes from Fall to Spring Semester. (Out of 4.0)", message=FALSE----
change_gpa = sleep_data$term_gpa - sleep_data$cum_gpa
ggplot(sleep_data, aes(x = change_gpa)) +
  geom_histogram(fill="pink", color="black") +
  labs(x = "GPA Change (Out of 4.0)", 
       y = "Frequency")


## ---- fig.width=4, fig.height=2.5, fig.cap="Average Sleep Time (Minutes) vs. Term GPA (Out of 4.0)", message=FALSE----
ggplot(sleep_data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(color="darkgreen") +
  labs(x = "Average Time Slept (In Minutes)", 
       y = "Term GPA (Out of 4.0)")


## ---- fig.width=4, fig.height=2.5, fig.cap="Average Sleep Time (Minutes) vs. Change in GPA (Out of 4.0)", message=FALSE----
ggplot(sleep_data, aes(x = TotalSleepTime, y = change_gpa)) +
  geom_point(color="darkgreen") +
  labs(x = "Average Time Slept (In Minutes)", 
       y = "Change in GPA (Out of 4.0)")


## ---- fig.width=4, fig.height=2.5, fig.cap="Sleep vs. Term GPA Fitted Linear Model", message=FALSE----
ggplot(sleep_data, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point(color="darkgreen") +
  geom_smooth(method = "lm", color = "red") +
  labs(x = "Average Time Slept (In Minutes)", 
       y = "Term GPA (Out of 4.0)")

term_lm = lm(term_gpa ~ TotalSleepTime, data=sleep_data)
#confint(term_lm)
# CI for B1: [0.001231758, 0.00273754] Center: 0.001984649

#summary(term_lm)
# B0 = 2.661, B1 = 0.0019846
# B1 Hypothesis test: df = 632, t-value = 5.176, p < 3.04e-07


## ---- fig.width=4, fig.height=2.5, fig.cap="Resdidual Plot for Sleep vs. Term GPA", message=FALSE----
ggplot(sleep_data, aes(x = TotalSleepTime, y = residuals(term_lm))) + 
  geom_point(color = "darkgreen") +
  labs(x = "TotalSleepTime", 
       y = "Residual")


## ---- fig.width=4, fig.height=2.5, fig.cap="Sleep vs. Change in GPA Fitted Linear Model", message=FALSE----
ggplot(sleep_data, aes(x = TotalSleepTime, y = change_gpa)) +
  geom_point(color="darkgreen") +
  geom_smooth(method = "lm", color = "red") +
  labs(x = "Average Time Slept (In Minutes)", 
       y = "Change in GPA (Out of 4.0)")

change_lm = lm(change_gpa ~ TotalSleepTime, data=sleep_data)
#confint(change_lm)
# CI for B1: [0.0004211362, 0.001648811] Center: 0.0010349736

#summary(change_lm)
# B0 = -0.4272175, B1 = 0.0010350
# B1 Hypothesis test: df = 632, t-value = 3.311, p <  0.000983


## ---- fig.width=4, fig.height=2.5, fig.cap="Resdidual Plot for Sleep vs. Change in GPA", message=FALSE----
ggplot(sleep_data, aes(x = TotalSleepTime, y = residuals(change_lm))) + 
  geom_point(color = "darkgreen") +
  labs(x = "TotalSleepTime", 
       y = "Residual")

