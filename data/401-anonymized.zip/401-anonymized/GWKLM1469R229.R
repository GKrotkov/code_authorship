## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)
library(insight)
library(ggplot2)
library(broom)
library(patchwork)
library(psych) 
require(gridExtra)


## ----eval=FALSE, include=FALSE------------------------------------------------
## print(Rateprof)
## summary(Rateprof)


## ----hists, fig.cap = "Histograms and Box Plots of Possible Predictors", fig.align = "center"----
  
easinessHist<-ggplot(Rateprof, aes(x=easiness)) + 
  geom_histogram( fill="turquoise", binwidth = .1)+ ggtitle("Figure 1A: Histogram and Table of Easiness") +
  xlab("Easiness (Out of 5)") + ylab("Number of Ratings") 


genderPlot <- ggplot(Rateprof, aes(x = gender, fill = gender)) + geom_bar() + labs(x = "Gender", y = "Count", title = "Figure 1B: Histogram of Gender")


attractivenessPlot <- ggplot(Rateprof, aes(x = pepper, fill = pepper)) + geom_bar() + labs(x = "Attractiveness?", y = "Count", title = "Figure 1C: Histogram of Attractivess")


discPlot <- ggplot(Rateprof, aes(x = discipline, fill = discipline)) + geom_bar() + labs(x = "Discipline", y = "Count", title = "Figure 1D: Histogram of Discipline")


grid.arrange (easinessHist, genderPlot, attractivenessPlot,discPlot, nrow = 2, ncol = 2 )


## ----quality hist, echo = FALSE,out.width = "75%", out.height= "75%", fig.cap = "Histogram of Quality",fig.align = "center"----
qualPlot <- ggplot(Rateprof, aes(x = quality, fill = quality)) + geom_histogram( fill="turquoise", binwidth = .1) + labs(x = "Quality", y = "Count")
qualPlot


## ----box plots, fig.cap = "Box Plots against Easiness and Quality", fig.height=6, fig.align = "center"----
attVsEas <- ggplot(Rateprof, aes(x=pepper, y= easiness,fill = pepper)) + 
  geom_boxplot() +labs(x = "Attractiveness (pepper scale)", y = "Easiness", title = "Figure 3A: Attractiveness vs Easiness")+theme(plot.title = element_text(size=12))

discVsEas <- ggplot(Rateprof, aes(x=discipline, y= easiness,fill = discipline)) + 
  geom_boxplot() +labs(x = "Discipline", y = "Easiness", title = "Figure 3C: Discipline vs Easiness")+theme(plot.title = element_text(size=12), legend.text=element_text(size=10),legend.title = element_text( size=10))

gendVsEas <- ggplot(Rateprof, aes(x=gender, y= easiness,fill = gender)) + 
  geom_boxplot() +labs(x = "Gender", y = "Easiness", title = "Figure 3E: Gender vs Easiness")+theme(plot.title = element_text(size=12))

attVsQual <- ggplot(Rateprof, aes(x=pepper, y= quality,fill = pepper)) + 
  geom_boxplot() +labs(x = "Attractiveness (pepper scale)", y = "Quality", title = "Figure 3B: Attractiveness vs Quality")+theme(plot.title = element_text(size=12))

discVsQual <- ggplot(Rateprof, aes(x=discipline, y= quality,fill = discipline)) + 
  geom_boxplot() +labs(x = "Discipline", y = "Quality", title = "Figure 3D: Discipline vs Quality")+theme(plot.title = element_text(size=12), legend.text=element_text(size=10),legend.title = element_text( size=10))


gendVsQual <- ggplot(Rateprof, aes(x=gender, y= quality,fill = gender)) + 
  geom_boxplot() +labs(x = "Gender", y = "Quality", title = "Figure 3F: Gender vs Quality")+theme(plot.title = element_text(size=12))

grid.arrange(attVsEas,attVsQual, discVsEas, discVsQual, gendVsEas,gendVsQual, nrow = 3, ncol = 2)


## ----easiness vs qual, fig.cap = "Easiness vs Quality Scatter Plot",fig.align = "center", out.width = "75%", out.height= "75%"----
ggplot(Rateprof, aes(x=easiness, y=quality)) + labs(x = "Easiness (out of 5)", y = "Quality", title = "Easiness vs Quality Scatter Plot") + geom_point(shape = 20,color = "blue")


## ----fits, include=FALSE------------------------------------------------------
partialFit <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline), data = Rateprof)
fullFit <- lm(quality ~ factor(gender) + factor(pepper) + easiness + factor(discipline) + easiness *factor(gender) + easiness *factor(discipline), data = Rateprof)
summary(partialFit)
summary(fullFit)


## ----residual analysis, fig.cap = "Residual Analysis of Partial Fit"----------
res <- ggplot(augment(partialFit), aes(x = .fitted, y = .resid)) +
geom_point() + ggtitle("Fitted Values vs Residuals")+
labs(x = "Fitted Values",
y = "Residual Values") + theme(plot.title = element_text(size = 8))

#qq plot of normal term fit
qq <- ggplot(augment(partialFit),
aes(sample = .resid)) +
geom_qq() +
geom_qq_line() +
labs(x = "Theoretical Quantiles", y = "Sample Quantiles")+ ggtitle("QQ Plot for Partial Fit")+ theme(plot.title = element_text(size = 10))

grid.arrange(res, qq, ncol=2)


## ----term summary, fig.cap= "Partial Model Statistics"------------------------
w


## ----f test, include=FALSE----------------------------------------------------
anova(partialFit,fullFit)


