## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## -----------------------------------------------------------------------------
library("alr4")
library("ggplot2")
library("tidyverse")
library("modelsummary")
message = FALSE


## -----------------------------------------------------------------------------
library(modelsummary) 
data <- Rateprof


## -----------------------------------------------------------------------------
plot(data$gender,
  main ="Figure1: Distribution of Instructors' Gender",
  xlab = "Gender",
  ylab = "Frequency",
  col = "DarkGreen")


## -----------------------------------------------------------------------------
plot(data$pepper,
  main ="Figure2: Distribution of Instructors' Attractiveness",
  xlab = "Attractive (yes/no)",
  ylab = "Frequency",
  col = "DarkGreen")


## -----------------------------------------------------------------------------
hist(data$easiness,
  main = "Figure3: Distribution of Instructors' Easiness",
  xlab = "Easiness (1-5, Higher Indicating Easier)",
  ylab = "Frequency",
  col = "DarkGreen",
  breaks = 30)


## -----------------------------------------------------------------------------
plot(data$discipline,
  main = "Figure4: Distribution of Instructors' Discipline",
  xlab = "Discipline",
  ylab = "Frequency",
  col = "DarkGreen")


## -----------------------------------------------------------------------------
hist(data$quality,
  main = "Figure5: Distribution of Instructors' Quality",
  xlab = "Quality (1-5, Higher Indicating Better)",
  ylab = "Frequency",
  col = "DarkGreen",
  breaks = 30)


## -----------------------------------------------------------------------------
x = data$easiness
y = data$quality 
plot(x = x,
     y = y,
     main = "Figure6: Scatterplot of Instructors' Easiness vs. Quality",
     xlab = "Easiness (1-5, Higher Indicating Easier)",
     ylab = "Quality (1-5, Higher Indicating Better)",
      col = "DarkGreen")


## -----------------------------------------------------------------------------
boxplot(quality ~ gender, data = Rateprof, col = c("Darkgreen", "Lightgreen"), 
        main = "Figure7: Gender vs Quality", 
        xlab = "Gender", 
        ylab = "Quality", 
        names = c("Female", "Male"))


## -----------------------------------------------------------------------------
boxplot(quality ~ pepper, data = Rateprof, col = c("Darkgreen", "Lightgreen"), 
        main = "Figure8: Attractive vs Quality", 
        xlab = "Attractive", 
        ylab = "Quality", 
        names = c("No", "Yes"))


## -----------------------------------------------------------------------------
Full_Model <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + gender:discipline, data = Rateprof) 


## -----------------------------------------------------------------------------
plot(Full_Model, which = 1)


## -----------------------------------------------------------------------------
plot (Full_Model, which = 2)


## -----------------------------------------------------------------------------
Full_Model <- lm(quality ~ gender + pepper + easiness + discipline + gender:easiness + gender:discipline, data = Rateprof) 


## -----------------------------------------------------------------------------
Model_With_Gender_Easiness <- lm(quality ~ gender + pepper + easiness + discipline +gender:easiness, data = Rateprof)



## -----------------------------------------------------------------------------
Model_With_Gender_Discipline <- lm(quality ~ gender + pepper + easiness + discipline + gender:discipline, data = Rateprof)



## -----------------------------------------------------------------------------
No_Inter_Model <- lm(quality ~ gender + pepper + easiness + discipline, data = Rateprof)


## -----------------------------------------------------------------------------
table <- data.frame(
  FullAIC = AIC(Full_Model),
  EasinessAIC = AIC(Model_With_Gender_Easiness),
  DisciplineAIC = AIC(Model_With_Gender_Discipline),
  NoInteractionAIC = AIC(No_Inter_Model))

table


## -----------------------------------------------------------------------------

modelsummary(list("No Interaction" = No_Inter_Model),
             gof_map = c("r.squared", "nobs"),
             fig.width=10,
             echo=FALSE)

