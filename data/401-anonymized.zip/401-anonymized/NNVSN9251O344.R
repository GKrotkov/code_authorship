## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = FALSE)
library(DBI)
library(RSQLite)
library(dplyr)
library(tidyverse)
library(patchwork)
library(MASS)
library(regressinator)
library(GGally)
library(ggplot2)
library(palmerpenguins)
library(bestglm)
library(alr4)
library(car)
library(broom)
library(modelsummary)
# library(flextable)


## ---- fig.width=5.5, fig.height=6---------------------------------------------
par(mfrow = c(3, 2))
barplot(table(Rateprof$gender), names = c("Female", "Male"),
        xlab = "Gender (Fig. 1)", ylab = "Count")
barplot(table(Rateprof$pepper), names = c("No", "Yes"),
        xlab = "Consensus on instructor attractiveness (Fig. 2)", ylab = "Count")
hist(Rateprof$easiness,
     xlab = "Average easiness rating of a course (Fig. 3)", main = "")
barplot(table(Rateprof$discipline), names = c("Hum", "SocSci", "STEM", "Pre-prof"),
        xlab = "Instructor's discipline (Fig. 4)", ylab = "Count")
hist(Rateprof$quality,
     xlab = "Average quality rating of a professor (Fig. 5)", main = "")

## ---- fig.width=5.5, fig.height=4---------------------------------------------
knitr::kable(rbind("gender" = summary(factor(Rateprof$gender))), digits = 2)
knitr::kable(rbind("pepper" = summary(factor(Rateprof$pepper))), digits = 2)
knitr::kable(rbind("discipline" = summary(factor(Rateprof$discipline))), digits = 2)

datfb <- rbind("easiness rating" = summary(Rateprof$easiness),
               "quality rating" = summary(Rateprof$quality))
knitr::kable(datfb, digits = 2)
# apply(Rateprof[,c("easiness","quality")], 2, sd)


## ---- fig.width=5.5, fig.height=4---------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(x = "Avg. easiness rating (Fig. 6)",
       y = "Avg. quality rating")


## ---- fig.width=5, fig.height=3.5---------------------------------------------
boxplot(quality ~ gender, ylab = "Quality", data = Rateprof,
        xlab = "Gender (Fig. 7)", names = c("Female", "Male"), pch = 16)


## ---- fig.width=5, fig.height=3.5---------------------------------------------
boxplot(quality ~ pepper, ylab = "Quality", data = Rateprof,
        xlab = "Attractive? (Fig. 8)", names = c("Yes", "No"), pch = 16)


## ---- fig.width=5, fig.height=3.5---------------------------------------------
boxplot(quality ~ discipline, ylab = "Quality", data = Rateprof,
        xlab = "Discipline (Fig. 9)", pch = 16)


## ---- fig.width=5, fig.height=3.5---------------------------------------------
ggplot(Rateprof, aes(x = easiness, y = quality, color = factor(gender))) +
  geom_smooth(method = "lm", se = FALSE) +
  labs(x = "easiness (Fig. 10)") +
  facet_wrap(~discipline)


## ---- echo = FALSE------------------------------------------------------------
hist((Rateprof$quality)^2,
     xlab = "Average quality rating of a professor", main = "")


## ---- echo = FALSE------------------------------------------------------------
fit_1 <- lm((quality)^2 ~ factor(gender) + factor(pepper) + factor(discipline) + easiness,
            data = Rateprof) # simple model
fit_2 <- lm((quality)^2 ~ easiness * (factor(gender) + factor(pepper) + factor(discipline)),
            data = Rateprof) # complex model
modelsummary(list("Model 1 (simple)" = fit_1, "Model 2 (complex)" = fit_2),
             gof_map = c("r.squared", "nobs", "p.val"))


## ---- fig.width=5, fig.height=3.5---------------------------------------------
p1 <- ggplot(augment(fit_2), aes(x = easiness, y = .resid)) +
  geom_point() +
  labs(x = "Avg. easiness rating (Fig. 11)", y = "Residual")

p2 <- ggplot(augment(fit_2), aes(x = .fitted, y = .resid)) +
geom_point() +
labs(x = "Fitted value (Fig. 12)", y = "Residual")

p1 | p2


## ---- fig.width=5, fig.height=3.5---------------------------------------------
# QQ plot -- distribution of the residuals
p4 <- ggplot(augment(fit_2), aes(sample = .resid)) +
  geom_qq() +
  geom_qq_line() +
  labs(x = "Theoretical quantile (Fig. 13)", y = "Sample quantile")
p4


## -----------------------------------------------------------------------------
# summary(fit_1)
# confint(fit_1)


## ---- echo = FALSE------------------------------------------------------------
# anova(fit_1, fit_2)
knitr::kable(anova(fit_1, fit_2))


## ---- echo = FALSE------------------------------------------------------------
aic.df <- as.data.frame(extractAIC(fit_1)[2]) # simple
aic.df <- cbind(aic.df, extractAIC(fit_2)[2]) # complex
knitr::kable(aic.df)

