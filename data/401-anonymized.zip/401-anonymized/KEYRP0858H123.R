## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(tidyverse)
library(ggplot2)
library(stargazer)
library(alr4)
library(bestglm)


## ---- include = FALSE---------------------------------------------------------
Rateprof


## ---- fig.width=4, fig.height=3, fig.cap="Professors' Course Quality"---------
# histogram of quality
hist(Rateprof$quality, xlab = "Quality (from 1 to 5, worst to best)", main = NULL)


## ---- fig.width=4, fig.height=3, fig.cap="Female and Male Professors"---------
# plot of gender
plot(Rateprof$gender, xlab = "Gender",
     col = c("darkorange1","deepskyblue3"))


## ---- fig.width=4, fig.height=3, fig.cap="Conventionally Attractive Professors"----
# plot of attractiveness
 plot(Rateprof$pepper, xlab = "Attractiveness (Yes or No)")


## -----------------------------------------------------------------------------
attractiveRateprof <- Rateprof[which(Rateprof$pepper == "yes"),]


## ---- fig.width=4, fig.height=3, fig.cap="Number of Attractive Female and Male Professors"----
table(attractiveRateprof$gender)


## ---- fig.width=4, fig.height=3, fig.cap="Professors' Course Easiness"--------
# hist of easiness
hist(Rateprof$easiness, xlab = "Easiness (from 1 to 5, worst to best)", 
     main = NULL)


## ---- fig.width=5, fig.height=4, fig.cap="Professors' Discipline"-------------
# plot of discipline
plot(Rateprof$discipline, xlab = "Discipline", 
     col = c("steelblue1", "sienna", "yellowgreen", "violetred"))
legend(x = "topright", box.col = "black", legend = c("Hum = Humanities", "SocSci = Social Science", 
                         "STEM = STEM", "Pre-prof = Professional Training"), cex = 0.5)


## ---- fig.width=4, fig.height=3, fig.cap="Easiness and Quality Relationship (by Discipline)"----
# scatterplot
Rateprof %>%
  ggplot(aes(x = easiness, y = quality)) + 
  geom_point(aes(color = discipline), alpha = 0.5, na.rm = TRUE) +
  geom_smooth(method = "lm", se = TRUE, na.rm = TRUE) +
  labs(x = "Easiness", y = "Quality")


## ---- fig.width=4, fig.height=3, fig.cap="Easiness and Quality Relationship (by Gender)"----
# scatterplot
Rateprof %>%
  ggplot(aes(x = easiness, y = quality)) + 
  geom_point(aes(color = gender), alpha = 0.5, na.rm = TRUE) +
  geom_smooth(method = "lm", se = TRUE, na.rm = TRUE) +
  labs(x = "Easiness", y = "Quality")


## -----------------------------------------------------------------------------
# chisq test of independence
chisq.test(table(Rateprof$gender, Rateprof$discipline))


## -----------------------------------------------------------------------------
# full model
lm1 <- lm(quality ~ gender * discipline + pepper + easiness, data = Rateprof)


## -----------------------------------------------------------------------------
# reduced, final model
gpe <- lm(quality ~ gender + pepper + easiness, data = Rateprof)


## -----------------------------------------------------------------------------
# partial F test
# reduced = gpe, full = lm1
anova(gpe, lm1)


## -----------------------------------------------------------------------------
# list of residuals (term vs sleep)
residgpe <- resid(gpe)


## ---- fig.width=4, fig.height=3, fig.cap="Quality with Gender, Attractiveness, and Easiness Fitted Residuals Plot"----
# residual vs. fitted plot
plot(fitted(gpe), residgpe, xlab = "Fitted", ylab = "Residuals")
abline(0,0)


## ---- fig.width=4, fig.height=3, fig.cap="Quality QQ Plot"--------------------
# qq plot for term gpa
qqnorm(Rateprof$quality, pch = 1, frame = FALSE)
qqline(Rateprof$quality, col = "blue", lwd = 2)


## -----------------------------------------------------------------------------
cdgpe <- cooks.distance(gpe)


## ---- fig.width=4, fig.height=3, fig.cap="Cook's Distance Plot of Sleep Time"----
Rateprof %>%
  ggplot(aes(x = easiness, y = cdgpe)) +
  geom_point() +
  labs(x = "Easiness", y = "Cook's Distance")


## -----------------------------------------------------------------------------
stargazer(gpe, type = "text", align = TRUE,
          title = "Course Quality Multivariate Linear Regression", 
          column.sep.width = "1pt")


## ---- include = FALSE---------------------------------------------------------
summary(gpe)


## -----------------------------------------------------------------------------
# 95% confidence interval of multivariate linear regression
stargazer(confint(gpe, level = 0.95), type = "text", title = "95% Confidence Intervals")

