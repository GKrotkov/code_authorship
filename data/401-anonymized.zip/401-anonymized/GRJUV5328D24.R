## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
sleep <- read.csv("cmu-sleep-1.csv")


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of `TotalSleepTime` variable."----
library(ggplot2)
ggplot(sleep, aes(x=TotalSleepTime)) + geom_histogram(binwidth=20, fill="black", color="white") + labs(title = "Histogram of Total Sleep Time", x="Total Sleep Time (minutes)", y="Frequency")

## ---- include=FALSE-----------------------------------------------------------
summary(sleep$TotalSleepTime)
IQR <- 430.1 - 366.9
outlier <- 1.5*IQR
366.9 - outlier
430.1 + outlier


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of `term_gpa` variable."----
ggplot(sleep, aes(x=term_gpa)) + geom_histogram(bins=30, fill="black", color="white") + labs(title = "Histogram of a Student's Current Semester GPA", x="GPA (current semester)", y="Frequency")


## ---- include=FALSE-----------------------------------------------------------
summary(sleep$term_gpa)
IQR2 <- 3.810 - 3.233
outlier2 <- 1.5*IQR2
3.233 - outlier2
3.810 + outlier2


## ---- fig.width=4, fig.height=3, fig.cap="Histogram of `cum_gpa` variable."----
ggplot(sleep, aes(x=cum_gpa)) + geom_histogram(bins=30, fill="black", color="white") + labs(title = "Histogram of a Student's Cumulative GPA", x="GPA (cumulative)", y="Frequency")


## ---- include=FALSE-----------------------------------------------------------
summary(sleep$cum_gpa)
IQR3 <- 3.790 - 3.232
outlier3 <- 1.5*IQR3
3.232 - outlier3
3.790 + outlier3


## -----------------------------------------------------------------------------
knitr::include_graphics("401summarydata.png")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of `term_gpa` vs `TotalSleepTime`."----
ggplot(sleep, aes(x = TotalSleepTime, y = term_gpa)) +
  geom_point() + geom_smooth(method=lm, formula=y~x, se=TRUE, col='red', linetype='dashed') +
  labs(title="Scatterplot of Current Semester GPA vs Total Sleep Time", x = "Total Sleep Time", y = "GPA (current semester)")


## ---- fig.width=4, fig.height=3, fig.cap="Scatterplot of `cum_gpa` vs `TotalSleepTime`."----
ggplot(sleep, aes(x = TotalSleepTime, y = cum_gpa)) + geom_point() + geom_smooth(method=lm, formula=y~x, se=TRUE, col='red', linetype='dashed') + labs(title="Scatterplot of Cumulative GPA vs Total Sleep Time", x = "Total Sleep Time", y = "GPA (cumulative)")


## ---- fig.width=4, fig.height=3, fig.cap="Residual Plot for model 1. Displays linearity assumption and constant variance assumption"----
sleep.current.lm <- lm(term_gpa ~ TotalSleepTime, data = sleep)
plot(sleep.current.lm, which=1)


## ---- fig.width=4, fig.height=3, fig.cap="Q-Q plot for model 1. Displays normality assumption"----
plot(sleep.current.lm, which=2)


## ---- fig.width=4, fig.height=3, fig.cap="Cook's distance plot showing outlier from the model"----
cooksd2 <- cooks.distance(sleep.current.lm)
plot(cooksd2, pch = 19, main = "Cook's distance plot")
abline(h = 4 / length(cooksd2), col = "red")


## -----------------------------------------------------------------------------
library(modelsummary)
model1 <- lm(term_gpa ~ TotalSleepTime, data = sleep)

model2 <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)

modelsummary(list("Model 1" = model1, "Model 2" = model2),
             gof_map = c("r.squared", "nobs"))



## ---- include=FALSE-----------------------------------------------------------
model <- lm(term_gpa ~ TotalSleepTime + cum_gpa, data = sleep)
summary(model)

plot(model, which=1)
plot(model, which=2)

#looked up how to make cooks distance model in R (https://rpubs.com/DragonflyStats/Cooks-Distance)
cooksd <- cooks.distance(model)
plot(cooksd, pch = 19, main = "Cook's distance plot")
abline(h = 4 / length(cooksd), col = "red")



## ---- include=FALSE-----------------------------------------------------------
logmodel <- lm(term_gpa ~ log(TotalSleepTime) + cum_gpa, data = sleep)
summary(logmodel)
plot(logmodel, which=1)
plot(logmodel, which=2)

cooksd2 <- cooks.distance(logmodel)
plot(cooksd2, pch = 19, main = "Cook's distance plot")
abline(h = 4 / length(cooksd2), col = "red")


## ---- include=FALSE-----------------------------------------------------------
sleep.current.lm <- lm(term_gpa ~ TotalSleepTime, data = sleep)
summary(sleep.current.lm)

plot(sleep.current.lm, which=1)
plot(sleep.current.lm, which=2)
cooksd3 <- cooks.distance(sleep.current.lm)
plot(cooksd3, pch = 19, main = "Cook's distance plot")
abline(h = 4 / length(cooksd3), col = "red")


## ---- include=FALSE-----------------------------------------------------------
confint(model)
confint(sleep.current.lm)

mean(sleep$term_gpa)

new.dat <- data.frame(TotalSleepTime=mean(sleep$TotalSleepTime)-120)
predict(sleep.current.lm, newdata = new.dat, interval = 'confidence')

predict(sleep.current.lm, newdata = new.dat, interval = 'prediction')

