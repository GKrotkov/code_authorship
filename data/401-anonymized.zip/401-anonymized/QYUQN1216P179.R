## ---- include=FALSE-----------------------------------------------------------
library(tidyverse)
library(dplyr)
library(tinytex)
library(ggplot2)


## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include=FALSE-----------------------------------------------------------
sleep <- read_csv("cmu-sleep.csv")

total.sleep <- sleep$TotalSleepTime #X
gpa <- sleep$term_gpa #Y
e.gpa <- exp(gpa)


## ---- include=FALSE-----------------------------------------------------------
summary(total.sleep)
summary(gpa)


## ---- fig.dim=c(8,4), fig.cap='Distributions of Total Sleep Time and GPA'-----
# figure 1
par(mfrow=c(1,3))
hist(total.sleep, main="Total Sleep Time", 
     xlab='Total Sleep Time (minutes)', col='magenta')

hist(gpa, main='GPA', 
     xlab = 'GPA (out of 4.0)', col='magenta')

hist(e.gpa, main='Transformed GPA', col='magenta', xlab='exp(GPA)')


## ---- fig.dim=c(8,4), fig.cap='Total Sleep vs. Original GPA and Transformed GPA'----
# figure 2
par(mfrow=c(1,2))
plot(total.sleep, gpa, main='No Transformation', xlab='Total Sleep in minutes', 
     ylab='GPA (out of 4.0)')
plot(total.sleep, e.gpa, main='With Transformation', 
     xlab='Total Sleep in minutes', ylab='exp(GPA)')


## ---- include=FALSE-----------------------------------------------------------
lm.sleep <- lm(e.gpa ~ total.sleep, data=sleep)
summary(lm.sleep)
confint(lm.sleep, level=0.95)

bad.lm <- lm(gpa ~ total.sleep, data=sleep)


## ---- fig.dim=c(8,4), fig.cap='Residuals Plots with Original and Transformed GPA'----
# figure 3
par(mfrow=c(1,2))
plot(bad.lm$fitted.values, bad.lm$residuals, main='Original', 
     xlab='x', ylab='Residuals')
plot(lm.sleep$fitted.values, lm.sleep$residuals, xlab='x', ylab='Residuals',
     main='Transformed')


## ---- fig.dim=c(8,4), fig.cap='Residual Q-Q Plots'----------------------------
# figure 4
par(mfrow=c(1,2))

qqnorm(bad.lm$residuals, col='blue', main='Q-Q plot (original GPA)')
qqline(bad.lm$residuals, col='red', lwd=1)

qqnorm(lm.sleep$residuals, col='blue', main='Q-Q Plot (transformed GPA)')
qqline(lm.sleep$residuals, col='red', lwd=1)


## ---- include=FALSE-----------------------------------------------------------
# determine the average GPA effect when students get 2 hours less sleep

predict(lm.sleep, interval="confidence", 
        newdata = data.frame(total.sleep = mean(total.sleep) - 120), level=0.95)

predict(lm.sleep, interval="confidence", 
        newdata = data.frame(total.sleep = mean(total.sleep)), level=0.95)

# 95% CI for beta1 value
confint(lm.sleep, level=0.95)

