## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 1"---------------------------
sleep <- read.csv("cmu-sleep.csv")

hist(sleep$TotalSleepTime,
     xlab="Minutes",
     ylab="Number of Students",
     main="Total Sleep Time per Night")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 2"---------------------------
hist(sleep$term_gpa,
     xlab="Term GPA",
     ylab="Number of Students",
     main="Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 3"---------------------------
hist(2^sleep$term_gpa,
     xlab="2^(Term GPA)",
     ylab="Number of Students",
     main="Exponential Transformation Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 4"---------------------------
hist(sleep$cum_gpa,
     breaks=6,
     xlab="Cumulative GPA",
     ylab="Number of Students",
     main="Cumulative GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 5"---------------------------
plot(sleep$TotalSleepTime, sleep$term_gpa,
     xlab = "Sleep Time in minutes",
     ylab = "Term GPA",
     main= "Sleep Time vs Term GPA")


## ---- fig.width=4, fig.height=3, fig.cap="Figure 6"---------------------------
#still not an obvious relationship, but the data seems to be more spread out, so this would be a better relationship to model
plot(sleep$TotalSleepTime,2^sleep$term_gpa,
     xlab = "Total Time asleep in minutes",
     ylab = "Exponential Transformed term GPA",
     main = "Transformed term GPA vs Sleep Time")
sleep.exp.lm <- lm(I(2^(term_gpa)) ~ TotalSleepTime, data=sleep)


## ---- fig.width=4, fig.height=3, fig.cap="Figure 7"---------------------------
#positive linearish correlation, probably means that the most students did not perform or make many adjustments to their schedule, even when tracking. This means that term gpa should suffice as a performance metric.
plot(sleep$term_gpa, sleep$cum_gpa,
     xlab="Term GPA",
     ylab="Cumulative GPA",
     main="Term GPA vs Cumulative GPA")


## -----------------------------------------------------------------------------
#tried removing influential points, not good
filtered_sleep <- sleep[-c(100,135,471),] 

## ---- eval=FALSE--------------------------------------------------------------
## plot(lm(TotalSleepTime ~ I(3^(term_gpa)), data=filtered_sleep),
##      which = 1)
## 
## plot(lm(TotalSleepTime ~ I((3^term_gpa)), data=filtered_sleep),
##      which = 2)
## 
## summary(lm(TotalSleepTime ~ I((3^term_gpa)), data=filtered_sleep))


## ----fig.width=4, fig.height=3, fig.cap="Figure 8"----------------------------
#look pretty good! put this in methods!
sleep.exp.lm <- lm(I(2^term_gpa) ~ I(TotalSleepTime), data=sleep)
plot(sleep.exp.lm,
     which = 1)


## ----fig.width=4, fig.height=3, fig.cap="Figure 9"----------------------------
#look pretty good! put this in methods!
plot(sleep.exp.lm,
     which = 2)


## ---- eval=FALSE--------------------------------------------------------------
## summary(sleep.exp.lm)
## confint(sleep.exp.lm,level=0.95)

