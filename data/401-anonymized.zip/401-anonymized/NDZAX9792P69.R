## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(tidyverse)
library(ggplot2)


## ---- fig.height = 3, fig.width=4---------------------------------------------
library(ggplot2)
sleep <- read.csv("cmu-sleep.csv")
ggplot(data=sleep, aes(x=TotalSleepTime)) +
  geom_histogram(bins = 20) +
  labs(title = "Figure 1: Distribution of Total Minutes Slept",
       x = "Number of Minutes Slept",
       y = "Count")

## ----eval=F-------------------------------------------------------------------
## summary(sleep$TotalSleepTime)


## ---- fig.height = 3, fig.width=4---------------------------------------------
ggplot(data=sleep, aes(x=term_gpa)) +
  geom_histogram(bins = 20) +
  labs(title = "Figure 2: GPA of Semester Studied",
       x = "GPA out of 4.0",
       y = "Count")


## ----eval=F-------------------------------------------------------------------
## summary(sleep$term_gpa)


## ---- fig.height = 3, fig.width=4---------------------------------------------
ggplot(data=sleep, aes(x=cum_gpa)) +
  geom_histogram(bins = 20) +
  labs(title = "Figure 3: GPA of Previous Semester Studied",
       x = "GPA out of 4.0",
       y = "Count")


## ----eval=F-------------------------------------------------------------------
## summary(sleep$cum_gpa)


## ----eval=F-------------------------------------------------------------------
## summary(sleep$change_gpa)


## ---- fig.height = 3, fig.width=4---------------------------------------------
sleep$change_gpa <- sleep$term_gpa - sleep$cum_gpa
ggplot(data=sleep, aes(x=change_gpa)) +
  geom_histogram(bins = 20) +
  labs(title = "Figure 4: Change in GPA Distribution",
       x = "Change in GPA out of 4.0",
       y = "Count")


## ---- fig.height = 3, fig.width=5---------------------------------------------
ggplot(data=sleep, aes(x=term_gpa, y=TotalSleepTime)) +
  geom_point() +
  labs(title = "Figure 5:", 
       subtitle = "Positive Relationship Between GPA and Minutes Slept",
       x = "GPA out of 4.0 of Semester Studied",
       y = "Average Time Slept in Minutes") +
  geom_smooth(method = "lm") +
  theme(text=element_text(size=9))


## ----eval=F-------------------------------------------------------------------
## cor(sleep$term_gpa, sleep$TotalSleepTime)


## ---- fig.height = 3, fig.width=5---------------------------------------------
ggplot(data=sleep, aes(x=change_gpa, y=TotalSleepTime)) +
  geom_point() +
  labs(title = "Figure 6 ",
  subtitle = "Positive Relationship Between Change in GPA and Minutes Slept",
       x = "Change in GPA out of 4.0",
       y = "Average Time Slept in Minutes") +
  geom_smooth(method = "lm") +
  theme(text=element_text(size=9))


## ----eval=F-------------------------------------------------------------------
## cor(sleep$change_gpa, sleep$TotalSleepTime)


## -----------------------------------------------------------------------------
test_lm <- lm(data=sleep, term_gpa~TotalSleepTime + cum_gpa)


## ---- eval=FALSE--------------------------------------------------------------
## stargazer(test_lm, title = "Regression using Total Sleep and Cumulative GPA")


## ---- fig.width = 8, fig.height=3---------------------------------------------
res <- resid(test_lm)
par(mfrow = c(1, 2))
plot(fitted(test_lm), res,
     main = "Figure 7: Assessing Residuals for Model 1")
abline(0,0)
qqnorm(res, main = "")
qqline(res)


## -----------------------------------------------------------------------------
change_lm <- lm(data=sleep, change_gpa~TotalSleepTime)


## ---- eval=FALSE--------------------------------------------------------------
## stargazer(change_lm, title = "Regression using Total Sleep")


## ---- fig.width = 8, fig.height=3---------------------------------------------
res2 <- resid(change_lm)
par(mfrow = c(1, 2))
plot(fitted(change_lm), res2,
     main = "Figure 8: Assessing Residuals for Model 2")
abline(0,0)
qqnorm(res2, main = "")
qqline(res2)


## ---- eval=FALSE--------------------------------------------------------------
## confint(change_lm)
## confint(change_lm) * 60

