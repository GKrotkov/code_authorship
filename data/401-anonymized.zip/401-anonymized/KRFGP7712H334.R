## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(alr4)
library(dplyr)
data = Rateprof
library(GGally)
library(tidyverse)
library(knitr)
library(pander)



## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = gender)) + 
    geom_bar(aes(fill = gender)) + 
    labs(title = "Bar chart of Gender")


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = pepper)) + 
    geom_bar(aes(fill = pepper)) + 
    
    labs(title = "Bar chart of attractiveness")


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = easiness)) + 
    geom_histogram(fill = "red", bins = 30) + 
    labs(title = "Histogram of class easiness")


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = discipline)) + 
    geom_bar(aes(fill = discipline)) + 
    
    labs(title = "Bar graph of discipline")


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = quality)) + 
    geom_histogram(fill="blue", bins = 30) + 
    labs(title = "Histogram of quality")


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = gender, y = quality)) + 
    geom_boxplot(aes(fill = gender)) +
    
    labs(title = "Quality vs Gender") 


## ---- echo = FALSE,  fig.width=5, fig.height=3--------------------------------
data %>% 
    ggplot(aes(x = easiness, y = quality)) + 
    geom_point(color = "red") +
    
    labs(title = "Quality vs Easiness") 


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x = pepper, y = quality)) + 
    geom_boxplot(aes(fill = pepper)) +
    
    labs(title = "Quality and Attractiveness") 


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
data %>% 
    ggplot(aes(x= discipline, y = quality)) + 
    geom_boxplot(aes(fill = discipline)) +
    
    labs(title = "Quality and Discipline") 


## ---- echo = FALSE------------------------------------------------------------
model<- lm(data = data, quality ~ easiness + gender + pepper + discipline+ easiness:gender +
              easiness:discipline)



## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
qqnorm(model$residuals)
qqline(model$residuals, col = "blue")


## ---- echo = FALSE, fig.width=5, fig.height=3---------------------------------
res = model$residuals
xval = model$fitted.values

plot(x= xval, y= res, xlab = "x", ylab = "residuals", main = "residuals of fitted values")
abline(h=0, lty=2)


## ---- echo = FALSE------------------------------------------------------------
pander(summary(model)$coefficients)


## ---- include = FALSE---------------------------------------------------------
confint(model)


## ---- echo = FALSE------------------------------------------------------------
noGen <-lm(data = data, quality ~ easiness + gender + pepper + discipline +
              easiness:discipline)
noDis <- lm(data = data, quality ~ easiness + gender + pepper + discipline+ easiness:gender)


## ---- echo = FALSE------------------------------------------------------------
pander(anova(noGen,model))


## ---- echo = FALSE------------------------------------------------------------
pander(anova(noDis,model))

