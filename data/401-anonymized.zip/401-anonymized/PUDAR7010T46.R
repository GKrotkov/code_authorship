## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)


## ---- include = FALSE---------------------------------------------------------
library(ggplot2)
library(dplyr)
library(tidyr)
library(corrplot)


## ---- include=F---------------------------------------------------------------
data <- read.csv('cmu-sleep.csv')
head(data)
summary(data)


## ---- message=F---------------------------------------------------------------
library(tidyverse)
library(kableExtra) 
#Source: https://cran.r-project.org/web/packages/kableExtra/vignettes/awesome_table_in_html.html


# Compute statistics for each variable
statistics <- data.frame(
  Variable = c("Total Sleep Time", "Term GPA", "Cumulative GPA"),
  Mean = c(mean(data$TotalSleepTime), mean(data$term_gpa), mean(data$cum_gpa)),
  Median = c(median(data$TotalSleepTime), median(data$term_gpa), median(data$cum_gpa)),
  Min = c(min(data$TotalSleepTime), min(data$term_gpa), min(data$cum_gpa)),
  Max = c(max(data$TotalSleepTime), max(data$term_gpa), max(data$cum_gpa))
)

# Print table with kable
kable(statistics, 
      col.names = c("Variable", "Mean", "Median", "Minimum", "Maximum"),
      align = c("l", "c", "c", "c", "c"),
      caption = "Summary Statistics") %>%
  kable_styling()



## ---- fig.width=8, fig.height=3, fig.cap="Histograms for Univariate Analysis"----
# Univariate Analysis
par(mfrow=c(1,3))

# Histogram for TotalSleepTime
hist(data$TotalSleepTime, main="Distribution of Total Sleep Time", 
     xlab="Total Sleep Time (in minutes)", col="skyblue", breaks=25)

# Histogram for term_gpa
hist(data$term_gpa, main="Distribution of Term GPA",
     xlab="Term GPA", col="lightgreen", breaks=30)

# Histogram for cum_gpa
hist(data$cum_gpa, main="Distribution of Cumulative GPA",
     xlab="Cumulative GPA", col="lightyellow", breaks=30)


## ---- fig.width=5, fig.height=4, fig.cap="Histograms for Change in GPA"-------
hist(data$term_gpa-data$cum_gpa, main="Distribution of Cumulative GPA",
     xlab="Cumulative GPA", col="purple", breaks=30)


## ---- fig.width=6, fig.height=3, fig.cap="Scatterplots for Bivariate Analysis"----

# Scatterplots for Bivariate Analysis
plot(data$TotalSleepTime, data$term_gpa-data$cum_gpa, 
     main="Total Sleep Time vs. Difference between Last Term and Current Term's GPA", 
     xlab="Total Sleep Time (in minutes)", ylab="GPA Change",
     col="blue", pch=20, cex.main=0.8, cex=0.9)

# Calculate the regression line
lm_model_term_gpa <- lm(data$term_gpa-data$cum_gpa ~ data$TotalSleepTime)

# Add the regression line to the plot
abline(lm_model_term_gpa, col="red")





## ---- message = FALSE, warning=FALSE, fig.width=8, fig.height=3, fig.cap="Plots for Pre-Log Transformed Model"----
library(tidyverse)


# Fit the model
model <- lm(term_gpa-cum_gpa ~ TotalSleepTime, data=data)


# Diagnostic Plots
par(mfrow=c(1,3))

# Residuals vs Fitted
plot(model$fitted.values, model$residuals, 
     main="Residuals vs Fitted",
     xlab="Fitted Values",
     ylab="Residuals")
abline(h=0, col="red")

# Normal Q-Q Plot
qqnorm(model$residuals, 
       main="Normal Q-Q Plot",
       xlab="Theoretical Quantiles",
       ylab="Sample Quantiles")
qqline(model$residuals)


# Source: https://www.statology.org/residuals-vs-leverage-plot/
plot(hatvalues(model), model$residuals, 
     main="Residuals vs Leverage",
     xlab="Leverage",
     ylab="Residuals")
abline(h=0, col="black") # Add a horizontal line at y = 0

# Calculate Cook's distance
cooksd <- cooks.distance(model)

# Add Cook's distance lines to the plot
lines(cooksd, col="red", lty=2)


# Label influential points with Cook's distance greater than a threshold
threshold <- 4 / length(cooksd)
influential_points <- which(cooksd > threshold)
text(cooksd[influential_points], model$residuals[influential_points], influential_points, pos=3)



## ----include=F----------------------------------------------------------------
summary(model)


## ----warning=F----------------------------------------------------------------
library(tidyverse)
library(broom) #Source: https://cran.r-project.org/web/packages/broom/vignettes/broom.html
library(kableExtra) #Source: https://cran.r-project.org/web/packages/kableExtra/vignettes/awesome_table_in_html.html
tidy_output <- tidy(model) %>%
  bind_cols(confint_tidy(model))

library(knitr)
kable(tidy_output, 
      col.names = c("Variable", "Estimate", "Std. Error", "t value", "p value", "Conf. Lower", "Conf. Upper"),
      align = c("l", "c", "c", "c", "c", "c", "c"),
      caption = "Regression Output") %>%
  kable_styling()

