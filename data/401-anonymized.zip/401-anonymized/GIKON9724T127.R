## ----setup, include = FALSE---------------------------------------------------
# By default, do not include R source code in the PDF. We do not want to see
# code, only your text and figures.
knitr::opts_chunk$set(echo = FALSE)
library(alr4)


## ---- fig.width=4, fig.height=3, fig.cap="distribution of quality."-----------
hist(Rateprof$quality, col = "blue", main = "Histogram of Quality", xlab = "Quality", ylab = "Frequency")



## ---- fig.width=4, fig.height=3, fig.cap="distribution of easiness."----------
hist(Rateprof$easiness, col = "blue", main = "Histogram of Easiness", xlab = "Easiness", ylab = "Frequency")


## ---- fig.width=3, fig.height=3, fig.cap="scatterplots and boxplots for predictor and response."----
library(ggplot2)
ggplot(Rateprof, aes(x = easiness, y = quality)) +
  geom_point() +
  labs(title = "Scatter Plot: Easiness vs. Quality",
       x = "Easiness",
       y = "Quality")

ggplot(Rateprof, aes(x = gender, y = quality)) +
  geom_boxplot() +
  labs(title = "Box Plot: Gender vs. Quality",
       x = "Gender",
       y = "Quality")

ggplot(Rateprof, aes(x = pepper, y = quality)) +
  geom_boxplot() +
  labs(title = "Box Plot: Attractiveness vs. Quality",
       x = "Attractiveness",
       y = "Quality")

ggplot(Rateprof, aes(x = discipline, y = quality)) +
  geom_boxplot() +
  labs(title = "Box Plot: Discipline vs. Quality",
       x = "Discipline",
       y = "Quality")


## ---- fig.width=4, fig.height=3, fig.cap="Residuals vs Fittted Values for model."----
model = lm(quality ~ gender+pepper+easiness+discipline, Rateprof)
plot(model, which = 1, col = "blue", main = "Residuals vs Fitted Values")


## ---- fig.width=4, fig.height=3, fig.cap="Cook's Distance Plot for model."----
plot(cooks.distance(model), main = "Cook's Distance Plot", col = "blue", xlab = "Observation", ylab = "Cook's Distance")


## ---- fig.width=4, fig.height=3, fig.cap="QQ Plot of Residuals for model."----
qqnorm(residuals(model), main = "QQ Plot of Residuals")
qqline(residuals(model), col = 2)


## ---- fig.width=4, fig.height=3, fig.cap="Table output for model"-------------
library(palmerpenguins)
library(modelsummary)
modelsummary(list("Model 1" = model),
             gof_map = c("r.squared", "nobs"), statistic = "p = {p.value}")
#summary(model)
#confint(model, "gendermale", level = 0.95)
#confint(model, "pepperyes", level = 0.95)
#confint(model, "easiness", level = 0.95)


## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
fullmodel1 = lm(quality ~ gender+pepper+easiness+discipline+easiness*gender, Rateprof)
reducedmodel1 = lm(quality ~ gender+pepper+easiness+discipline, Rateprof)
anova(fullmodel1,reducedmodel1)

## ---- fig.width=4, fig.height=3, fig.cap="Distance it took cars at each speed to stop."----
fullmodel2 = lm(quality ~ gender+pepper+easiness+discipline+easiness*discipline, Rateprof)
reducedmodel2 = lm(quality ~ gender+pepper+easiness+discipline, Rateprof)
anova(fullmodel2,reducedmodel2)

